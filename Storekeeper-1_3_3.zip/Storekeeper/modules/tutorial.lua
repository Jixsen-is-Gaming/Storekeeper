-- Storekeeper: Tutorial
-- First-use guided tutorial. Replay via /sk tutorial

local SK = Storekeeper
SK.Tutorial = {}
local TU = SK.Tutorial

local FONT = "Fonts\\FRIZQT__.TTF"

-- ── Steps ─────────────────────────────────────────────────────────────────────

local STEPS = {
    {
        text  = "|cffFFD700Welcome to Storekeeper!|r\n\nStorekeeper is a roleplay Point-of-Sale register for WoW merchants.\n\nThis short guide walks you through the basics. Press Next to continue.",
        target = nil,
        wide   = true,
    },
    {
        text   = "This is the |cffFFD700minimap button|r.\n\nLeft-click to open or close the register. Drag it to reposition it anywhere around the minimap.",
        target = function() return _G["StorekeeperMinimapButton"] end,
        arrow  = "DOWN",
    },
    {
        text   = "The |cffFFD700sidebar tabs|r on the right let you navigate all sections:\n\nRegister, Orders, Management, Products, Shops, Activity Log, Settings, and What's New.",
        target = function()
            local r = SK.Register
            if r and r.sidebarBtns and r.sidebarBtns[1] then return r.sidebarBtns[1] end
        end,
        arrow  = "LEFT",
        setup  = function()
            local r = SK.Register
            if r then
                if not r.mainFrame then r:Build() end
                if r.mainFrame then r.mainFrame:Show(); r.isOpen = true end
            end
        end,
    },
    {
        text   = "Start here — the |cffFFD700Shop(s) Overview tab|r.\n\nCreate your first shop by typing a name and clicking Create. The shop you activate here is the one shown in the register.",
        target = function()
            local r = SK.Register
            if not r or not r.sidebarBtns then return nil end
            for _, btn in ipairs(r.sidebarBtns) do
                if btn.key == "shops" then return btn end
            end
        end,
        arrow  = "LEFT",
        setup  = function()
            local r = SK.Register
            if r and r.SwitchToTab then r.SwitchToTab("shops") end
        end,
    },
    {
        text   = "Go to the |cffFFD700Products tab|r to build your inventory.\n\nGive each product a name, category, price, rarity, and icon. Products sync automatically to all your staff when they come online.",
        target = function()
            local r = SK.Register
            if not r or not r.sidebarBtns then return nil end
            for _, btn in ipairs(r.sidebarBtns) do
                if btn.key == "products" then return btn end
            end
        end,
        arrow  = "LEFT",
        setup  = function()
            local r = SK.Register
            if r and r.SwitchToTab then r.SwitchToTab("products") end
        end,
    },
    {
        text   = "The |cffFFD700Management tab|r is where you build your team.\n\nAdd employees by name — tick the checkbox on any row to promote them to Manager. Use the Category Order section to control how categories appear in your register.",
        target = function()
            local r = SK.Register
            if not r or not r.sidebarBtns then return nil end
            for _, btn in ipairs(r.sidebarBtns) do
                if btn.key == "people" then return btn end
            end
        end,
        arrow  = "LEFT",
        setup  = function()
            local r = SK.Register
            if r and r.SwitchToTab then r.SwitchToTab("people") end
        end,
    },
    {
        text   = "Time to sell! The |cffFFD700Register tab|r shows your products grouped by category.\n\nClick a product to add it to the cart. When ready, press |cffFFD700Receipt / Order|r to finalise or create a tracked order.",
        target = function()
            local r = SK.Register
            if not r or not r.sidebarBtns then return nil end
            for _, btn in ipairs(r.sidebarBtns) do
                if btn.key == "register" then return btn end
            end
        end,
        arrow  = "LEFT",
        setup  = function()
            local r = SK.Register
            if r and r.SwitchToTab then r.SwitchToTab("register") end
        end,
    },
    {
        text   = "|cffFFD700You're all set!|r\n\nYou can replay this guide any time with |cffFFFF00/sk tutorial|r.\n\nGood luck at the market!",
        target = nil,
        final  = true,
        wide   = true,
    },
}

-- ── Gold ring highlight around target ─────────────────────────────────────────

local _ring
local function GetRing()
    if _ring then return _ring end
    _ring = CreateFrame("Frame", "SKTutRing", UIParent, "BackdropTemplate")
    _ring:SetFrameStrata("FULLSCREEN_DIALOG")
    _ring:SetFrameLevel(190)
    _ring:SetBackdrop({
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
        edgeSize = 16,
        insets   = {left=4, right=4, top=4, bottom=4},
    })
    _ring:SetBackdropBorderColor(1, 0.82, 0, 0.9)
    _ring:Hide()
    return _ring
end

local function ShowRing(target)
    if not target or not target.GetRect then GetRing():Hide(); return end
    local left, bottom, width, height = target:GetRect()
    if not left then GetRing():Hide(); return end
    local PAD = 6
    local ring = GetRing()
    ring:ClearAllPoints()
    ring:SetSize(width + PAD*2, height + PAD*2)
    ring:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", left - PAD, bottom - PAD)
    ring:Show()
end

local function HideRing() GetRing():Hide() end

-- ── Bubble ────────────────────────────────────────────────────────────────────

function TU:Build()
    if self._frame then return end

    local bubble = CreateFrame("Frame", "SKTutorialBubble", UIParent, "BackdropTemplate")
    bubble:SetFrameStrata("FULLSCREEN_DIALOG")
    bubble:SetFrameLevel(200)
    bubble:SetClampedToScreen(true)
    bubble:SetBackdrop({
        bgFile   = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
        tile=true, tileSize=256,
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
        edgeSize = 24,
        insets   = {left=6, right=6, top=6, bottom=6},
    })
    bubble:SetBackdropColor(0.04, 0.05, 0.10, 0.97)
    bubble:SetBackdropBorderColor(1, 1, 1, 1)
    bubble:SetMovable(true); bubble:EnableMouse(true)
    bubble:RegisterForDrag("LeftButton")
    bubble:SetScript("OnDragStart", function(s) s:StartMoving() end)
    bubble:SetScript("OnDragStop",  function(s) s:StopMovingOrSizing() end)
    bubble:Hide()
    self._frame = bubble
    tinsert(UISpecialFrames, "SKTutorialBubble")

    -- Corner decorations (same textures as main register frame)
    local cov = CreateFrame("Frame", nil, bubble)
    cov:SetAllPoints(); cov:SetFrameLevel(bubble:GetFrameLevel() + 10)
    local CPATH = "Interface\\AddOns\\Storekeeper\\textures\\"
    for _, cd in ipairs({
        {point="TOPLEFT",    tex="corner_tl", ox=-8, oy= 8},
        {point="TOPRIGHT",   tex="corner_tr", ox= 8, oy= 8},
        {point="BOTTOMLEFT", tex="corner_bl", ox=-8, oy=-8},
        {point="BOTTOMRIGHT",tex="corner_br", ox= 8, oy=-8},
    }) do
        local t = cov:CreateTexture(nil,"OVERLAY",nil,7)
        t:SetSize(64,61); t:SetPoint(cd.point, bubble, cd.point, cd.ox, cd.oy)
        t:SetTexture(CPATH..cd.tex)
    end

    -- Header bar
    local hdr = bubble:CreateTexture(nil,"BACKGROUND",nil,1)
    hdr:SetColorTexture(1,0.82,0,0.08); hdr:SetHeight(28)
    hdr:SetPoint("TOPLEFT",  bubble,"TOPLEFT",   7,-7)
    hdr:SetPoint("TOPRIGHT", bubble,"TOPRIGHT",  -7,-7)

    -- Bag icon
    local ic = bubble:CreateTexture(nil,"OVERLAY")
    ic:SetSize(18,18); ic:SetPoint("TOPLEFT", bubble,"TOPLEFT",12,-12)
    ic:SetTexture("Interface\\Icons\\INV_Misc_Bag_07")
    ic:SetTexCoord(0.08,0.92,0.08,0.92)

    -- Title
    local title = bubble:CreateFontString(nil,"OVERLAY")
    title:SetFont(FONT,11,"OUTLINE"); title:SetTextColor(1,0.82,0)
    title:SetPoint("TOPLEFT", bubble,"TOPLEFT",34,-12)
    title:SetText("Storekeeper Guide")

    -- Step counter
    local stepLbl = bubble:CreateFontString(nil,"OVERLAY")
    stepLbl:SetFont(FONT,9,""); stepLbl:SetTextColor(0.55,0.50,0.40)
    stepLbl:SetPoint("TOPRIGHT", bubble,"TOPRIGHT",-56,-14)
    self._stepLbl = stepLbl

    -- Divider
    local div = bubble:CreateTexture(nil,"ARTWORK")
    div:SetColorTexture(1,0.82,0,0.25); div:SetHeight(1)
    div:SetPoint("TOPLEFT",  bubble,"TOPLEFT",   8,-30)
    div:SetPoint("TOPRIGHT", bubble,"TOPRIGHT",  -8,-30)

    -- Body text
    local body = bubble:CreateFontString(nil,"OVERLAY")
    body:SetFont(FONT,11,""); body:SetTextColor(0.92,0.92,0.92)
    body:SetJustifyH("LEFT"); body:SetJustifyV("TOP")
    body:SetPoint("TOPLEFT",  bubble,"TOPLEFT",   14,-38)
    body:SetPoint("TOPRIGHT", bubble,"TOPRIGHT",  -14,-38)
    body:SetWordWrap(true)
    self._body = body

    -- Progress dots row
    local dotRow = CreateFrame("Frame", nil, bubble); dotRow:SetHeight(10)
    dotRow:SetPoint("BOTTOMLEFT",  bubble,"BOTTOMLEFT",  14,36)
    dotRow:SetPoint("BOTTOMRIGHT", bubble,"BOTTOMRIGHT", -14,36)
    self._dotRow = dotRow
    self._dots   = {}

    -- Skip button
    local skipBtn = CreateFrame("Button",nil,bubble,"UIPanelButtonTemplate")
    skipBtn:SetSize(70,22); skipBtn:SetPoint("BOTTOMLEFT",bubble,"BOTTOMLEFT",10,8)
    skipBtn:SetText("Skip")
    skipBtn:SetScript("OnClick", function() TU:Finish(true) end)
    self._skipBtn = skipBtn

    -- Next button
    local nextBtn = CreateFrame("Button",nil,bubble,"UIPanelButtonTemplate")
    nextBtn:SetSize(80,22); nextBtn:SetPoint("BOTTOMRIGHT",bubble,"BOTTOMRIGHT",-10,8)
    nextBtn:SetText("Next >")
    nextBtn:SetScript("OnClick", function() TU:NextStep() end)
    self._nextBtn = nextBtn
end

-- ── Progress dots ─────────────────────────────────────────────────────────────

function TU:BuildDots(total, current)
    for _, d in ipairs(self._dots) do d:Hide(); d:SetParent(nil) end
    self._dots = {}
    local DOT = 8; local GAP = 12
    local rowW = (self._frame:GetWidth() or 340) - 28
    local totalW = total * DOT + (total-1) * (GAP-DOT)
    local startX = (rowW - totalW) / 2
    for i = 1, total do
        local d = self._dotRow:CreateTexture(nil,"ARTWORK"); d:SetSize(DOT,DOT)
        d:SetPoint("LEFT", self._dotRow,"LEFT", startX+(i-1)*GAP, 0)
        if i == current then d:SetColorTexture(1,0.82,0,1)
        else d:SetColorTexture(0.3,0.28,0.20,0.8) end
        tinsert(self._dots, d)
    end
end

-- ── Position bubble near target ───────────────────────────────────────────────

function TU:PositionBubble(step)
    local bubble = self._frame
    bubble:ClearAllPoints()
    local target = step.target and step.target()
    if not target or not target.GetRect then
        bubble:SetPoint("CENTER", UIParent,"CENTER",0,80); return
    end
    local left, bottom, width, height = target:GetRect()
    if not left then bubble:SetPoint("CENTER",UIParent,"CENTER",0,80); return end
    local bw = bubble:GetWidth(); local bh = bubble:GetHeight(); local GAP = 30
    local cx = left + width/2; local cy = bottom + height/2
    local dir = step.arrow or "UP"
    if dir == "DOWN" then
        local bx = math.max(10, math.min(cx-bw/2, GetScreenWidth()-bw-10))
        bubble:SetPoint("BOTTOMLEFT", UIParent,"BOTTOMLEFT", bx, cy+height/2+GAP)
    elseif dir == "UP" then
        local bx = math.max(10, math.min(cx-bw/2, GetScreenWidth()-bw-10))
        bubble:SetPoint("TOPLEFT", UIParent,"BOTTOMLEFT", bx, cy-height/2-GAP-bh)
    elseif dir == "LEFT" then
        local by = math.max(10, math.min(cy-bh/2, GetScreenHeight()-bh-10))
        bubble:SetPoint("BOTTOMLEFT", UIParent,"BOTTOMLEFT", left+width+GAP, by)
    elseif dir == "RIGHT" then
        local by = math.max(10, math.min(cy-bh/2, GetScreenHeight()-bh-10))
        bubble:SetPoint("BOTTOMRIGHT", UIParent,"BOTTOMLEFT", left-GAP, by)
    else
        bubble:SetPoint("CENTER", UIParent,"CENTER",0,80)
    end
end

-- ── Show one step ─────────────────────────────────────────────────────────────

function TU:ShowStep(idx)
    self:Build()
    if idx > #STEPS then self:Finish(false); return end
    self._stepIdx = idx
    local step = STEPS[idx]
    if step.setup then pcall(step.setup) end

    local function Render()
        local bubble = self._frame
        local bw = step.wide and 420 or 340
        self._body:SetWidth(bw-28)
        self._body:SetText(step.text or "")
        local textH = self._body:GetStringHeight()
        bubble:SetSize(bw, math.max(150, textH+85))
        self._stepLbl:SetText(idx.." / "..#STEPS)
        self:BuildDots(#STEPS, idx)
        if step.final then
            self._nextBtn:SetText("Done"); self._skipBtn:Hide()
        else
            self._nextBtn:SetText("Next >"); self._skipBtn:Show()
        end
        self:PositionBubble(step)
        ShowRing(step.target and step.target())
        bubble:SetAlpha(0); bubble:Show()
        UIFrameFadeIn(bubble, 0.2, 0, 1)
    end

    if step.setup then C_Timer.After(0.05, Render) else Render() end
end

-- ── Navigation ────────────────────────────────────────────────────────────────

function TU:NextStep()
    if self._stepIdx >= #STEPS then self:Finish(false)
    else self:ShowStep(self._stepIdx+1) end
end

function TU:Finish(skipped)
    if SK.db then SK.db.tutorialDone = true end
    HideRing()
    if self._frame then
        UIFrameFadeOut(self._frame, 0.3, 1, 0)
        C_Timer.After(0.35, function()
            if TU._frame then TU._frame:Hide() end
        end)
    end
end

-- ── Entry point ───────────────────────────────────────────────────────────────

function TU:Start()
    self._stepIdx = 0
    self:ShowStep(1)
end

-- ── Slash command ─────────────────────────────────────────────────────────────

local _origSK = SlashCmdList["STOREKEEPER"]
SlashCmdList["STOREKEEPER"] = function(msg)
    if strtrim(msg):lower() == "tutorial" then
        local r = SK.Register
        if r then
            if not r.mainFrame then r:Build() end
            if r.mainFrame then r.mainFrame:Show(); r.isOpen = true end
        end
        C_Timer.After(0.2, function() TU:Start() end)
    elseif _origSK then
        _origSK(msg)
    end
end

-- ── Auto-run on first install ─────────────────────────────────────────────────

local autoFrame = CreateFrame("Frame")
autoFrame:RegisterEvent("PLAYER_LOGIN")
autoFrame:SetScript("OnEvent", function(self)
    self:UnregisterEvent("PLAYER_LOGIN")
    C_Timer.After(6, function()
        if SK.db and not SK.db.tutorialDone then
            SK.db.tutorialDone = true
            local r = SK.Register
            if r then
                if not r.mainFrame then r:Build() end
                if r.mainFrame then r.mainFrame:Show(); r.isOpen = true end
            end
            C_Timer.After(0.5, function() TU:Start() end)
        end
    end)
end)
