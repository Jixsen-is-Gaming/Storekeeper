-- Storekeeper: Register UI

Storekeeper.Register = Storekeeper.Register or {}
local SK = Storekeeper
local R  = SK.Register

R.cart   = {}
R.isOpen = false

local PAD = 10  -- universal inner padding

-- ─── Helpers ──────────────────────────────────────────────────────────────────

local function FS(parent, text, size, r, g, b)
    local f = parent:CreateFontString(nil,"OVERLAY","GameFontNormal")
    f:SetFont("Fonts\\FRIZQT__.TTF", size or 11, "")
    f:SetText(text or "")
    f:SetTextColor(r or 1, g or 1, b or 1, 1)
    return f
end

local function Btn(parent, text, w, h)
    local b = CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetSize(w or 80, h or 22); b:SetText(text or "")
    return b
end

local function Box(parent, w, h)
    local e = CreateFrame("EditBox",nil,parent,"InputBoxTemplate")
    e:SetSize(w or 150, h or 20); e:SetAutoFocus(false)
    e:SetScript("OnEscapePressed", function(s) s:ClearFocus() end)
    return e
end

local function Panel(parent, r, g, b, a)
    local f = CreateFrame("Frame",nil,parent,"BackdropTemplate")
    f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    f:SetBackdropColor(r or 0.06, g or 0.06, b or 0.09, a or 1)
    f:SetBackdropBorderColor(0.3,0.3,0.38,1)
    return f
end

-- ─── Cart ─────────────────────────────────────────────────────────────────────

-- variant: optional {name, priceCopper} table; nil = no variant selected
function R:AddToCart(product, variant)
    local vkey = variant and variant.name or ""
    for _, e in ipairs(R.cart) do
        if e.product.id==product.id and (e.variantKey or "")==vkey then
            e.qty=e.qty+1; R:RefreshCart(); return
        end
    end
    tinsert(R.cart, {product=product, qty=1, variant=variant, variantKey=vkey})
    R:RefreshCart()
end

function R:RemoveFromCart(pid, variantKey)
    variantKey = variantKey or ""
    for i, e in ipairs(R.cart) do
        if e.product.id==pid and (e.variantKey or "")==variantKey then
            e.qty=e.qty-1
            if e.qty<=0 then tremove(R.cart,i) end
            R:RefreshCart(); return
        end
    end
end

function R:ClearCart() R.cart={}; R:RefreshCart() end

-- ─── Tab mode ─────────────────────────────────────────────────────────────────
-- When active, clicking a product adds it to the target open tab instead of the cart.

function R:BeginTabMode(shopName, tabID)
    local tab = SK.DB:GetTab(shopName, tabID)
    if not tab then return end
    R.tabMode = {active=true, shopName=shopName, tabID=tabID, holders=tab.holders}
    -- Jump to the register so the user can click products
    if R.SwitchToTab then R.SwitchToTab("register") end
    R:UpdateTabModeBanner()
    print(string.format("|cffFFD700[SK]|r Adding items to Tab #%d (%s). Click products to add, then click 'Done' on the banner.", tabID, tab.holders))
end

function R:EndTabMode()
    R.tabMode = nil
    R:UpdateTabModeBanner()
    R:RefreshCart()
end

function R:AddToTab(product, variant)
    if not (R.tabMode and R.tabMode.active) then return end
    local ok, err = SK.DB:AddTabItem(R.tabMode.shopName, R.tabMode.tabID, product, variant, 1)
    if not ok then
        print("|cffFFD700[SK]|r "..tostring(err))
        if err == "Tab is closed." or err == "Tab not found." then R:EndTabMode() end
        return
    end
    if SK.Net and SK.Net.BroadcastTab then
        SK.Net:BroadcastTab(R.tabMode.shopName, SK.DB:GetTab(R.tabMode.shopName, R.tabMode.tabID))
    end
    R:UpdateTabModeBanner()
    R:RefreshCart()
end

-- A small banner shown at the top of the register while in tab mode
function R:UpdateTabModeBanner()
    if not R.registerContent then return end
    local tm = R.tabMode
    if not (tm and tm.active) then
        if R._tabBanner then R._tabBanner:Hide() end
        return
    end
    if not R._tabBanner then
        local b = CreateFrame("Frame", nil, R.registerContent, "BackdropTemplate")
        b:SetPoint("TOPLEFT", 6, -2); b:SetPoint("TOPRIGHT", -6, -2); b:SetHeight(24)
        b:SetFrameStrata("HIGH")
        b:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
        b:SetBackdropColor(0.10,0.08,0.02,0.95); b:SetBackdropBorderColor(0.85,0.6,0.2,1)
        local t = b:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        t:SetPoint("LEFT",6,0); b.text = t
        local done = CreateFrame("Button",nil,b,"UIPanelButtonTemplate")
        done:SetSize(50,18); done:SetPoint("RIGHT",-4,0); done:SetText("Done")
        done:SetScript("OnClick",function()
            R:EndTabMode()
            if R.SwitchToTab then R.SwitchToTab("tabs") end
        end)
        R._tabBanner = b
    end
    local tab = SK.DB:GetTab(tm.shopName, tm.tabID)
    local total = tab and SK.DB:GetTabTotal(tab) or 0
    R._tabBanner.text:SetText(string.format("|cffFFD700Adding to Tab #%d (%s)|r  —  Total: %s",
        tm.tabID, tm.holders, SK:FormatMoney(total)))
    R._tabBanner.text:SetTextColor(1,0.9,0.5,1)
    R._tabBanner:Show()
end

function R:CartTotal()
    local t=0
    for _,e in ipairs(R.cart) do
        local price = (e.variant and e.variant.priceCopper) or e.product.priceCopper
        t=t+price*e.qty
    end
    if R.activeDiscount and R.activeDiscount.pct then
        t = math.floor(t * (1 - R.activeDiscount.pct/100))
    end
    return t
end

-- Show a small popup for the user to pick a variant before adding to cart
function R:ShowVariantPicker(prod, anchor, toTab)
    -- Clean up any existing picker
    if R._varPicker then R._varPicker:Hide(); R._varPicker:SetParent(nil) end

    local vars = prod.variants
    local ROW_H = 22
    local popH  = #vars * ROW_H + 30
    local popW  = 180

    local pop = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
    R._varPicker = pop
    pop:SetSize(popW, popH)
    pop:SetFrameStrata("FULLSCREEN")
    pop:SetPoint("BOTTOM", anchor, "TOP", 0, 4)
    pop:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        edgeSize = 10,
        insets   = {left=3,right=3,top=3,bottom=3},
    })
    pop:SetBackdropColor(0.06,0.06,0.10,0.98)
    pop:SetBackdropBorderColor(0.5,0.38,0.10,1)

    local title = pop:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    title:SetPoint("TOPLEFT",6,-4); title:SetText(prod.name)
    title:SetTextColor(1,0.82,0,1)

    local yo = -18
    for _, v in ipairs(vars) do
        local row = CreateFrame("Button",nil,pop)
        row:SetSize(popW-8, ROW_H); row:SetPoint("TOPLEFT",4,yo)
        local txt = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        txt:SetPoint("LEFT",4,0); txt:SetSize(popW-60,ROW_H); txt:SetJustifyH("LEFT")
        txt:SetText(v.name); txt:SetTextColor(0.9,0.9,0.9,1)
        local ptxt = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        ptxt:SetPoint("RIGHT",-4,0); ptxt:SetText(SK:FormatMoney(v.priceCopper))
        ptxt:SetTextColor(1,0.82,0,1)
        local vname = v.name; local vpc = v.priceCopper; local vsc = v.stockCost or 1
        local vtrp3 = v.trp3ItemID
        row:SetScript("OnEnter",function() txt:SetTextColor(1,0.95,0.5,1) end)
        row:SetScript("OnLeave",function() txt:SetTextColor(0.9,0.9,0.9,1) end)
        row:SetScript("OnClick",function()
            if toTab then
                R:AddToTab(prod, {name=vname, priceCopper=vpc, stockCost=vsc, trp3ItemID=vtrp3})
            else
                R:AddToCart(prod, {name=vname, priceCopper=vpc, stockCost=vsc, trp3ItemID=vtrp3})
            end
            pop:Hide(); pop:SetParent(nil)
            if R._varCloser then R._varCloser:Hide(); R._varCloser:SetParent(nil) end
        end)
        yo = yo - ROW_H
    end

    -- Close on outside click
    local closer = CreateFrame("Frame",nil,UIParent)
    R._varCloser = closer
    closer:SetAllPoints(); closer:EnableMouse(true); closer:SetFrameStrata("FULLSCREEN")
    closer:SetScript("OnMouseDown",function()
        pop:Hide(); pop:SetParent(nil)
        closer:Hide(); closer:SetParent(nil)
    end)
    pop:SetFrameLevel(closer:GetFrameLevel()+1)
end

function R:RefreshCart()
    if not R.cartChild then return end
    for _, w in ipairs(R.cartRows or {}) do w:Hide(); w:SetParent(nil) end
    R.cartRows = {}

    -- Get a reliable width — cartChild may report 0 before first layout pass
    local cw = R.cartChild:GetWidth()
    if cw <= 0 and R.cartSF then cw = R.cartSF:GetWidth() - 4 end
    if cw <= 0 then cw = 200 end  -- last resort fallback

    local yo, rh = 0, 22

    -- ── Tab mode: show the target tab's items instead of the cart ──
    if R.tabMode and R.tabMode.active then
        local tab = SK.DB:GetTab(R.tabMode.shopName, R.tabMode.tabID)
        local items = tab and tab.items or {}
        for idx, e in ipairs(items) do
            local p = e.product
            local row = CreateFrame("Frame",nil,R.cartChild,"BackdropTemplate")
            row:SetHeight(rh); row:SetPoint("TOPLEFT",0,-yo)
            row:SetPoint("RIGHT", R.cartChild, "RIGHT", 0, 0)  -- track panel width on resize
            row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8"})
            row:SetBackdropColor(0.10,0.08,0.02, yo%44==0 and 0.4 or 0.2)

            local ti = R.tabMode.tabID
            local ii = idx
            -- − button removes one of this line from the tab
            local decBtn = CreateFrame("Button",nil,row,"UIPanelButtonTemplate")
            decBtn:SetSize(18,16); decBtn:SetPoint("RIGHT", -2, 0)
            decBtn:SetText("-")
            decBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 13, "OUTLINE")
            decBtn:SetScript("OnClick", function()
                SK.DB:RemoveTabItem(R.tabMode.shopName, ti, ii)
                if SK.Net and SK.Net.BroadcastTab then
                    SK.Net:BroadcastTab(R.tabMode.shopName, SK.DB:GetTab(R.tabMode.shopName, ti))
                end
                R:RefreshCart(); R:UpdateTabModeBanner()
            end)

            -- + button adds one more of this product/variant to the tab
            local addBtn = CreateFrame("Button",nil,row,"UIPanelButtonTemplate")
            addBtn:SetSize(18,16); addBtn:SetPoint("RIGHT", decBtn, "LEFT", -1, 0)
            addBtn:SetText("+")
            addBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11, "OUTLINE")
            local evar = e.variant
            addBtn:SetScript("OnClick", function() R:AddToTab(p, evar); R:RefreshCart() end)

            -- qty label
            local qL = row:CreateFontString(nil,"OVERLAY","GameFontNormal")
            qL:SetFont("Fonts\\FRIZQT__.TTF",10,""); qL:SetWidth(22)
            qL:SetPoint("RIGHT", addBtn, "LEFT", -1, 0)
            qL:SetText(e.qty or 1); qL:SetTextColor(1,0.82,0,1); qL:SetJustifyH("CENTER")

            local unitPrice = (e.variant and e.variant.priceCopper) or (p and p.priceCopper) or 0
            local pL = row:CreateFontString(nil,"OVERLAY","GameFontNormal")
            pL:SetFont("Fonts\\FRIZQT__.TTF",9,""); pL:SetPoint("RIGHT", qL, "LEFT", -4, 0)
            pL:SetText(SK:FormatMoney(unitPrice*(e.qty or 1)))

            local displayName = SK:LineLabel(p and p.name, e.variantKey)
            local nL = row:CreateFontString(nil,"OVERLAY","GameFontNormal")
            nL:SetFont("Fonts\\FRIZQT__.TTF",10,""); nL:SetPoint("LEFT",6,0)
            nL:SetPoint("RIGHT", pL, "LEFT", -4, 0)
            nL:SetText(displayName); nL:SetTextColor(1,1,1,1); nL:SetJustifyH("LEFT")

            tinsert(R.cartRows,row); yo=yo+rh
        end

        if #items==0 then
            local nl=R.cartChild:CreateFontString(nil,"OVERLAY","GameFontDisable")
            nl:SetPoint("TOP",0,-6); nl:SetText("Tab is empty —|nclick products to add")
            nl:SetJustifyH("CENTER")
            tinsert(R.cartRows,nl)
        end

        R.cartChild:SetHeight(math.max(yo,30))
        if R.totalLabel then
            local tabTotal = tab and SK.DB:GetTabTotal(tab) or 0
            local txt = SK:FormatMoney(tabTotal)
            if tab and (tab.paymentMode=="prepaid" or tab.paymentMode=="deposit") and (tab.deposit or 0) > 0 then
                local rem = (tab.deposit or 0) - tabTotal
                if rem >= 0 then txt = txt.."|n|cff88FF88"..SK:FormatMoney(rem).." left|r"
                else             txt = txt.."|n|cffFF6666"..SK:FormatMoney(-rem).." owed|r" end
            end
            R.totalLabel:SetText(txt)
        end
        return
    end

    for _, e in ipairs(R.cart) do
        local p   = e.product
        local pid = p.id
        local row = CreateFrame("Frame",nil,R.cartChild,"BackdropTemplate")
        row:SetHeight(rh)
        row:SetPoint("TOPLEFT",0,-yo)
        row:SetPoint("RIGHT", R.cartChild, "RIGHT", 0, 0)  -- track panel width on resize
        row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8"})
        row:SetBackdropColor(0,0,0, yo%44==0 and 0.3 or 0.12)

        -- Remove (×) button — far right, removes all of this line
        local rb = CreateFrame("Button",nil,row,"UIPanelCloseButton")
        rb:SetSize(18,18); rb:SetPoint("RIGHT",-1,0)
        local evkey = e.variantKey or ""
        rb:SetScript("OnClick", function()
            for i, v in ipairs(R.cart) do
                if v.product.id == pid and (v.variantKey or "") == evkey then tremove(R.cart, i); break end
            end
            R:RefreshCart()
        end)

        -- + button — right of qty label, adds one
        local addBtn = CreateFrame("Button",nil,row,"UIPanelButtonTemplate")
        addBtn:SetSize(18,16); addBtn:SetPoint("RIGHT", rb, "LEFT", -2, 0)
        addBtn:SetText("+")
        addBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11, "OUTLINE")
        addBtn:SetScript("OnClick", function() R:AddToCart(p, e.variant) end)

        -- qty EditBox â between + and - buttons; click to type a number directly
        local qL = CreateFrame("EditBox", nil, row, "InputBoxTemplate")
        qL:SetSize(30, 16)
        qL:SetPoint("RIGHT", addBtn, "LEFT", -3, 0)
        qL:SetAutoFocus(false)
        qL:SetNumeric(true)
        qL:SetMaxLetters(4)
        qL:SetJustifyH("CENTER")
        qL:SetTextColor(1, 0.82, 0, 1)
        qL:SetText(tostring(e.qty))
        local function ApplyQty()
            local val = tonumber(qL:GetText()) or 0
            if val < 1 then val = 1 end
            for _, ce in ipairs(R.cart) do
                if ce.product.id == pid and (ce.variantKey or "") == evkey then
                    ce.qty = val; break
                end
            end
            R:RefreshCart()
        end
        qL:SetScript("OnEnterPressed", function(s) s:ClearFocus(); ApplyQty() end)
        qL:SetScript("OnEscapePressed", function(s) s:ClearFocus(); s:SetText(tostring(e.qty)) end)
        qL:SetScript("OnEditFocusLost", ApplyQty)

        -- â button â left of qty box, decrements by 1
        local decBtn = CreateFrame("Button",nil,row,"UIPanelButtonTemplate")
        decBtn:SetSize(18,16); decBtn:SetPoint("RIGHT", qL, "LEFT", -3, 0)
        decBtn:SetText("-")
        decBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 13, "OUTLINE")
        decBtn:SetScript("OnClick", function() R:RemoveFromCart(pid, evkey) end)


        -- price label — left of the stepper group
        local unitPrice = (e.variant and e.variant.priceCopper) or p.priceCopper
        local pL = row:CreateFontString(nil,"OVERLAY","GameFontNormal")
        pL:SetFont("Fonts\\FRIZQT__.TTF",9,"")
        pL:SetPoint("RIGHT", decBtn, "LEFT", -4, 0)
        pL:SetText(SK:FormatMoney(unitPrice*e.qty))

        -- product name (+ variant) — fills remaining space on the left
        local displayName = SK:LineLabel(p.name, e.variant and e.variant.name)
        local nL = row:CreateFontString(nil,"OVERLAY","GameFontNormal")
        nL:SetFont("Fonts\\FRIZQT__.TTF",10,""); nL:SetPoint("LEFT",6,0)
        nL:SetPoint("RIGHT", pL, "LEFT", -4, 0)
        nL:SetText(displayName); nL:SetTextColor(1,1,1,1); nL:SetJustifyH("LEFT")

        tinsert(R.cartRows,row); yo=yo+rh
    end

    if #R.cart==0 then
        local nl=R.cartChild:CreateFontString(nil,"OVERLAY","GameFontDisable")
        nl:SetPoint("CENTER"); nl:SetText("Cart is empty")
        tinsert(R.cartRows,nl)
    end

    R.cartChild:SetHeight(math.max(yo,30))
    if R.totalLabel then
        local total = R:CartTotal()
        local txt = SK:FormatMoney(total)
        if R.activeDiscount then
            txt = txt.."|n|cffFFD700-"..R.activeDiscount.pct.."%|r"
        end
        R.totalLabel:SetText(txt)
    end
end

-- ─── Product Grid — foldable accordion categories ─────────────────────────────

-- Which category is currently open (nil = all closed, or first opens by default)
R.openCategory = nil

function R:BuildProductGrid()
    if not R.gridChild then return end
    for _, w in ipairs(R.productBtns or {}) do w:Hide(); w:SetParent(nil) end
    R.productBtns = {}

    local shopName = SK.db and SK.db.activeShop
    if not shopName then
        local nl = R.gridChild:CreateFontString(nil,"OVERLAY","GameFontDisable")
        nl:SetPoint("CENTER"); nl:SetText("No shop. Open Manager to create one.")
        tinsert(R.productBtns, nl); R.gridChild:SetHeight(30); return
    end

    local cats, order = SK.DB:GetProductsByCategory(shopName)

    -- Filter out categories disabled by the manager
    do
        local enabledOrder = {}
        for _, cat in ipairs(order) do
            if SK.DB:IsCategoryEnabled(shopName, cat) then
                tinsert(enabledOrder, cat)
            end
        end
        order = enabledOrder
    end

    -- Apply search filter (this tab only). Matches product name, case-insensitive.
    local query = (R.productSearch or ""):lower()
    if query ~= "" then
        local fcats, forder = {}, {}
        for _, cat in ipairs(order) do
            local matches = {}
            for _, prod in ipairs(cats[cat]) do
                if (prod.name or ""):lower():find(query, 1, true) then
                    tinsert(matches, prod)
                end
            end
            if #matches > 0 then
                fcats[cat] = matches
                tinsert(forder, cat)
            end
        end
        cats, order = fcats, forder
    end

    if #order == 0 then
        local nl = R.gridChild:CreateFontString(nil,"OVERLAY","GameFontDisable")
        nl:SetPoint("CENTER")
        nl:SetText(query ~= "" and "No products match your search." or "No products. Add them in the Manager.")
        tinsert(R.productBtns, nl); R.gridChild:SetHeight(30); return
    end

    -- Auto-open first category if none is open or open one no longer exists
    if not R.openCategory or not cats[R.openCategory] then
        R.openCategory = order[1]
    end

    local c       = SK:C()
    local gw      = R.gridChild:GetWidth()
    local cols    = 2
    local colW    = math.floor((gw - 6) / cols) - 2
    local colH    = 54
    local pad     = 4
    local headerH = 28
    local yo      = 0

    -- We need to build all sections; keep a reference to each section's
    -- content widgets so we can show/hide them when a header is clicked.
    local sections = {}  -- { catName, headerBtn, items[] }

    local function RebuildPositions()
        local searching = (R.productSearch or "") ~= ""
        local autoClose = SK:Cfg().autoCloseCategory ~= false
        yo = 0
        for _, sec in ipairs(sections) do
            local isOpen
            if searching then
                isOpen = true  -- show all matches while filtering
            elseif autoClose then
                isOpen = (sec.catName == R.openCategory)
            else
                R.openCategories = R.openCategories or {}
                isOpen = R.openCategories[sec.catName]
            end
            sec.headerBtn:SetPoint("TOPLEFT", 0, -yo)
            yo = yo + headerH + 2
            if isOpen then
                local col = 0
                for _, item in ipairs(sec.items) do
                    item:Show()
                    item:SetPoint("TOPLEFT", col*(colW+pad), -yo)
                    col = col + 1
                    if col >= cols then col = 0; yo = yo + colH + pad end
                end
                if col ~= 0 then yo = yo + colH + pad end
                yo = yo + 4
            else
                for _, item in ipairs(sec.items) do item:Hide() end
            end
        end
        R.gridChild:SetHeight(math.max(yo, 30))
    end

    local function ToggleCategory(catName)
        local autoClose = SK:Cfg().autoCloseCategory ~= false
        if R.openCategory == catName then
            R.openCategory = nil  -- clicking open one closes it
        elseif autoClose then
            R.openCategory = catName  -- close others, open this one
        else
            -- Multi-open mode: track as table
            R.openCategories = R.openCategories or {}
            if R.openCategories[catName] then
                R.openCategories[catName] = nil
            else
                R.openCategories[catName] = true
            end
            R.openCategory = catName  -- keep for backwards compat
        end
        -- Update arrow indicators and colors on all headers
        for _, sec in ipairs(sections) do
            local isOpen
            if autoClose then
                isOpen = (sec.catName == R.openCategory)
            else
                R.openCategories = R.openCategories or {}
                isOpen = R.openCategories[sec.catName]
            end
            sec.arrow:SetText(isOpen and "-" or "+")
            if sec.HdrColor then sec.HdrColor(isOpen) end
        end
        RebuildPositions()
    end

    -- Build all sections (headers + product buttons) without positioning yet
    for _, cat in ipairs(order) do
        local isOpen = (cat == R.openCategory)
        -- Get this category's custom color (falls back to gold)
        local cr, cg, cb = SK.DB:GetCategoryColor(shopName, cat)

        -- Header button
        local hBtn = CreateFrame("Button", nil, R.gridChild, "BackdropTemplate")
        hBtn:SetSize(gw, headerH)
        hBtn:EnableMouse(true)  -- required for BackdropTemplate buttons to receive first click
        hBtn:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
        local function HdrColor(open)
            if open then
                hBtn:SetBackdropColor(cr*0.35, cg*0.35, cb*0.35, 1)
                hBtn:SetBackdropBorderColor(cr*0.7, cg*0.7, cb*0.7, 1)
            else
                hBtn:SetBackdropColor(cr*0.12, cg*0.12, cb*0.12, 1)
                hBtn:SetBackdropBorderColor(cr*0.4, cg*0.4, cb*0.4, 1)
            end
        end
        HdrColor(isOpen)
        hBtn:SetNormalTexture(""); hBtn:SetHighlightTexture(""); hBtn:SetPushedTexture("")

        -- Hover tint
        hBtn:SetScript("OnEnter", function(s)
            s:SetBackdropColor(cr*0.45, cg*0.45, cb*0.45, 1)
        end)
        hBtn:SetScript("OnLeave", function(s)
            HdrColor(cat == R.openCategory)
        end)

        -- Arrow indicator (FontString with ASCII +/-)
        local arrow = hBtn:CreateFontString(nil,"OVERLAY","GameFontNormal")
        arrow:SetFont("Fonts\\MORPHEUS.TTF",14,"OUTLINE")
        arrow:SetPoint("LEFT",4,0); arrow:SetSize(16,headerH)
        arrow:SetJustifyH("CENTER"); arrow:SetJustifyV("MIDDLE")
        arrow:SetText(isOpen and "-" or "+")
        arrow:SetTextColor(c.accent[1],c.accent[2],c.accent[3],1)

        -- Category name
        local catLabel = hBtn:CreateFontString(nil,"OVERLAY","GameFontNormal")
        catLabel:SetFont("Fonts\\FRIZQT__.TTF",11,"OUTLINE")
        catLabel:SetPoint("LEFT",26,0)
        catLabel:SetText(cat)
        catLabel:SetTextColor(cr, cg, cb, 1)

        -- Item count badge
        local countLabel = hBtn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        countLabel:SetPoint("RIGHT",-6,0)
        countLabel:SetText(#cats[cat].." item"..(#cats[cat]==1 and "" or "s"))
        countLabel:SetTextColor(c.textDim[1], c.textDim[2], c.textDim[3], 1)

        local catName = cat
        hBtn:RegisterForClicks("AnyUp")
        hBtn:SetScript("OnClick", function() ToggleCategory(catName) end)
        tinsert(R.productBtns, hBtn)

        -- Product buttons for this category
        local itemBtns = {}
        for _, prod in ipairs(cats[cat]) do
            local btn = CreateFrame("Button", nil, R.gridChild, "BackdropTemplate")
            btn:SetSize(colW, colH)
            btn:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
            btn:SetBackdropColor(c.bg[1],c.bg[2],c.bg[3],0.9)
            btn:SetBackdropBorderColor(c.border[1]*0.5,c.border[2]*0.5,c.border[3]*0.5,1)

            local ic = btn:CreateTexture(nil,"ARTWORK")
            ic:SetSize(36,36); ic:SetPoint("LEFT",5,0)
            ic:SetTexture(type(prod.icon)=="number" and prod.icon or 134400)
            ic:SetTexCoord(0.08,0.92,0.08,0.92)

            local nL = btn:CreateFontString(nil,"OVERLAY","GameFontNormal")
            nL:SetFont("Fonts\\FRIZQT__.TTF",10,""); nL:SetPoint("TOPLEFT",46,-6)
            nL:SetSize(colW-52,16); nL:SetText(prod.name)
            -- Color by rarity
            local RARITY_COLORS = {
                poor={0.62,0.62,0.62}, common={1,1,1}, uncommon={0.12,1,0},
                rare={0,0.44,0.87}, epic={0.64,0.21,0.93}, legendary={1,0.5,0},
            }
            local rc = RARITY_COLORS[prod.rarity or "common"] or {1,1,1}
            nL:SetTextColor(rc[1],rc[2],rc[3],1)

            local pL = btn:CreateFontString(nil,"OVERLAY","GameFontNormal")
            pL:SetFont("Fonts\\FRIZQT__.TTF",9,""); pL:SetPoint("BOTTOMLEFT",46,7)
            pL:SetText(SK:FormatMoney(prod.priceCopper))

            -- TRP3 Extended item indicator — small scroll icon in bottom-right corner
            if prod.hasTRP3Item then
                local trpIc = btn:CreateTexture(nil,"OVERLAY")
                trpIc:SetSize(14,14)
                trpIc:SetPoint("BOTTOMRIGHT",-4,4)
                trpIc:SetTexture("Interface\\Icons\\INV_Scroll_07")
                trpIc:SetTexCoord(0.08,0.92,0.08,0.92)
            end

            -- Dim and disable if out of stock
            local outOfStock = prod.stock ~= nil and prod.stock <= 0
            if outOfStock then
                btn:SetBackdropColor(0.06,0.06,0.06,0.9)
                btn:SetBackdropBorderColor(0.3,0.1,0.1,1)
                nL:SetTextColor(0.4,0.4,0.4,1)
                pL:SetTextColor(0.4,0.4,0.4,1)
                ic:SetDesaturated(true)
                btn:SetScript("OnEnter",function(s)
                    GameTooltip:SetOwner(s,"ANCHOR_RIGHT")
                    GameTooltip:AddLine(prod.name,0.5,0.5,0.5)
                    GameTooltip:AddLine("|cffFF4444Out of stock|r",1,1,1)
                    GameTooltip:Show()
                end)
                btn:SetScript("OnLeave",function() GameTooltip:Hide() end)
                btn:SetScript("OnClick",function()
                    print("|cffFFD700[SK]|r "..prod.name.." is out of stock.")
                end)
            else
                btn:SetScript("OnEnter",function(s)
                    s:SetBackdropColor(c.primary[1],c.primary[2],c.primary[3],0.9)
                    s:SetBackdropBorderColor(c.accent[1],c.accent[2],c.accent[3],1)
                    GameTooltip:SetOwner(s,"ANCHOR_RIGHT")
                    GameTooltip:AddLine(prod.name,rc[1],rc[2],rc[3])
                    if prod.description and prod.description~="" then
                        GameTooltip:AddLine(prod.description,1,1,1,true)
                    end
                    GameTooltip:AddLine("Price: "..SK:FormatMoney(prod.priceCopper),1,1,1)
                    if prod.stock ~= nil then
                        if prod.stock <= 5 then
                            GameTooltip:AddLine("Stock: |cffFFCC00"..prod.stock.." remaining|r",1,1,1)
                        else
                            GameTooltip:AddLine("Stock: "..prod.stock,0.7,0.7,0.7)
                        end
                    end
                    if prod.hasTRP3Item then
                        GameTooltip:AddLine("|cff888888Has a TRP3 Extended item|r",1,1,1)
                    end
                    GameTooltip:Show()
                end)
                btn:SetScript("OnLeave",function(s)
                    s:SetBackdropColor(c.bg[1],c.bg[2],c.bg[3],0.9)
                    s:SetBackdropBorderColor(c.border[1]*0.5,c.border[2]*0.5,c.border[3]*0.5,1)
                    GameTooltip:Hide()
                end)
                btn:SetScript("OnClick",function()
                    local vars = prod.variants
                    if R.tabMode and R.tabMode.active then
                        if vars and #vars > 0 then
                            R:ShowVariantPicker(prod, btn, true)  -- true = add to tab
                        else
                            R:AddToTab(prod, nil)
                        end
                    elseif vars and #vars > 0 then
                        R:ShowVariantPicker(prod, btn)
                    else
                        R:AddToCart(prod)
                    end
                end)
            end

            tinsert(R.productBtns, btn)
            tinsert(itemBtns, btn)
        end

        tinsert(sections, {catName=cat, headerBtn=hBtn, arrow=arrow, items=itemBtns, HdrColor=HdrColor})
    end

    -- Store sections for ToggleCategory to access
    R.productSections = sections
    RebuildPositions()
end

-- ─── Order / Receipt Popup ────────────────────────────────────────────────────

function R:OpenOrderPopup()
    if #R.cart==0 then print("|cffFFD700[SK]|r Cart is empty."); return end
    local shopName = SK.db and SK.db.activeShop
    if not shopName then print("|cffFFD700[SK]|r No active shop."); return end

    -- Destroy old popup if any
    if R.orderPopup then R.orderPopup:Hide(); R.orderPopup=nil end

    -- The Get Items row only exists when TRP3 Extended is loaded far enough to
    -- hand us its addItem entry point. When it isn't, extraH stays 0 and the
    -- popup is laid out exactly as it was before — no gap, no stray button.
    -- The per-item Get panel now lives in a side panel attached to the popup's
    -- right edge (built at the end of this function), so the popup itself no
    -- longer reserves a bottom row for a single Get Items button.
    local extraH = 0

    -- Provisional height only. The real height is derived from the laid-out
    -- content at the end of this function, because the order summary panel
    -- grows with the cart: at 4+ lines a fixed height pushed the contact
    -- fields down on top of the Open as Tab button.
    local W,H = 380, 570 + extraH
    local pop = CreateFrame("Frame","StorekeeperOrderPopup",UIParent,"BackdropTemplate")
    pop:SetSize(W,H)
    pop:SetPoint("CENTER")
    pop:SetMovable(true); pop:EnableMouse(true)
    pop:RegisterForDrag("LeftButton")
    pop:SetScript("OnDragStart",pop.StartMoving)
    pop:SetScript("OnDragStop",pop.StopMovingOrSizing)
    pop:SetFrameStrata("HIGH"); pop:SetToplevel(true)
    pop:SetBackdrop({
        bgFile="Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
        edgeFile="Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
        edgeSize=24, insets={left=6,right=6,top=6,bottom=6}
    })
    pop:SetBackdropColor(0,0,0,1); pop:SetBackdropBorderColor(1,1,1,1)
    R.orderPopup = pop

    -- Escape closes the popup
    tinsert(UISpecialFrames, "StorekeeperOrderPopup")

    -- Title bar
    local tb=Panel(pop,0.08,0.08,0.12,1); tb:SetHeight(30)
    tb:SetPoint("TOPLEFT",PAD,-PAD); tb:SetPoint("TOPRIGHT",-PAD,-PAD)
    local tl=tb:CreateFontString(nil,"OVERLAY","GameFontNormal")
    tl:SetFont("Fonts\\FRIZQT__.TTF",12,"OUTLINE"); tl:SetPoint("LEFT",10,0)
    tl:SetText("Finalise Order"); tl:SetTextColor(1,0.82,0,1)
    local xb=CreateFrame("Button",nil,tb,"UIPanelCloseButton")
    xb:SetSize(24,24); xb:SetPoint("RIGHT",-2,0)
    xb:SetScript("OnClick",function() pop:Hide(); R.orderPopup=nil end)

    local yo = -PAD-30-8

    -- Order summary — scrollable, capped at 5 visible rows
    local ITEM_ROW_H = 16
    local SUM_HDR_H  = 22   -- "Order Summary" title
    local SUM_TOT_H  = 20   -- "Total:" footer
    local MAX_VISIBLE = 5
    local visibleItems = math.min(#R.cart, MAX_VISIBLE)
    local sumInnerH = SUM_HDR_H + visibleItems * ITEM_ROW_H + SUM_TOT_H + 8
    local sumPanelH = sumInnerH + 2  -- +2 for border

    local sumPanel = Panel(pop, 0.05, 0.05, 0.08, 1)
    sumPanel:SetPoint("TOPLEFT", PAD, yo)
    sumPanel:SetPoint("TOPRIGHT", -PAD, yo)
    sumPanel:SetHeight(sumPanelH)
    yo = yo - sumPanelH - 6

    local sumTitle = sumPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    sumTitle:SetFont("Fonts\\FRIZQT__.TTF", 10, "OUTLINE")
    sumTitle:SetPoint("TOPLEFT", 6, -5)
    sumTitle:SetText("Order Summary")
    sumTitle:SetTextColor(1, 0.82, 0, 1)

    -- Scroll frame for the item list
    local sumSF = CreateFrame("ScrollFrame", nil, sumPanel, "UIPanelScrollFrameTemplate")
    sumSF:SetPoint("TOPLEFT",  4, -(SUM_HDR_H))
    sumSF:SetPoint("BOTTOMRIGHT", -20, SUM_TOT_H + 4)
    sumSF:EnableMouseWheel(true)
    sumSF:SetScript("OnMouseWheel", function(s, delta)
        local child = s:GetScrollChild()
        local maxScroll = child and math.max(0, (child:GetHeight() or 0) - (s:GetHeight() or 0)) or 0
        local cur = s:GetVerticalScroll() or 0
        local new = math.max(0, math.min(cur - delta * ITEM_ROW_H, maxScroll))
        s:SetVerticalScroll(new)
    end)
    local sumSC = CreateFrame("Frame", nil, sumSF)
    sumSC:SetWidth(sumSF:GetWidth() - (visibleItems < #R.cart and 20 or 4))
    sumSC:SetHeight(#R.cart * ITEM_ROW_H)
    sumSF:SetScrollChild(sumSC)

    for i, e in ipairs(R.cart) do
        local line = sumSC:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        line:SetPoint("TOPLEFT", 4, -(i-1) * ITEM_ROW_H)
        line:SetWidth(sumSC:GetWidth() - 4)
        local unitPrice = (e.variant and e.variant.priceCopper) or e.product.priceCopper
        local dName = SK:LineLabel(e.product.name, e.variant and e.variant.name)
        line:SetText(string.format("%dx %s - %s", e.qty, dName, SK:FormatMoney(unitPrice * e.qty)))
    end

    local totL = sumPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    totL:SetFont("Fonts\\FRIZQT__.TTF", 11, "OUTLINE")
    totL:SetPoint("BOTTOMRIGHT", -6, 6)
    totL:SetText("Total: " .. SK:FormatMoney(R:CartTotal()))
    totL:SetTextColor(1, 0.82, 0, 1)

    -- Payment type — WoW dropdown
    local ptLabel=FS(pop,"Payment Type",10,1,0.82,0); ptLabel:SetPoint("TOPLEFT",PAD,yo); yo=yo-18

    local PAYMENT_TYPES = {
        {key="paid",     label="Paid in Full",      desc="Added to treasury"},
        {key="favor",    label="Paid as a Favour",  desc="No treasury change"},
        {key="delivery", label="Pay After Delivery", desc="Pending payment"},
    }
    R.selectedPayment = "paid"

    local payDD = CreateFrame("Frame","SK_PaymentDropDown",pop,"UIDropDownMenuTemplate")
    payDD:SetPoint("TOPLEFT",PAD-16,yo+4)
    UIDropDownMenu_SetWidth(payDD, W-PAD*2-42)
    UIDropDownMenu_SetText(payDD, "Paid in Full")
    UIDropDownMenu_Initialize(payDD, function(self, level)
        for _, pt in ipairs(PAYMENT_TYPES) do
            local info = UIDropDownMenu_CreateInfo()
            info.text     = pt.label.." |cff888888("..pt.desc..")|r"
            info.value    = pt.key
            info.func     = function(btn)
                R.selectedPayment = btn.value
                UIDropDownMenu_SetText(payDD, pt.label)
                if payPanel then payPanel:SetShown(R.selectedPayment == "paid") end
            end
            info.checked  = (R.selectedPayment == pt.key)
            UIDropDownMenu_AddButton(info, level)
        end
    end)
    yo = yo - 30 - 6

    -- ── Payment Details panel (Paid in Full only) ─────────────────────────────
    -- Gratuity, Customer Paid, Change Due
    local PAY_H = 72
    local payPanel = Panel(pop, 0.05, 0.05, 0.08, 1)
    payPanel:SetPoint("TOPLEFT", PAD, yo)
    payPanel:SetPoint("TOPRIGHT", -PAD, yo)
    payPanel:SetHeight(PAY_H)
    payPanel:SetShown(true)  -- shown by default since "paid" is default

    -- Helper: small currency label
    local function CurrLbl(parent, text, r, g, b)
        local l = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        l:SetFont("Fonts\\FRIZQT__.TTF", 9, "")
        l:SetText(text); l:SetTextColor(r, g, b, 1)
        return l
    end
    -- Helper: small currency EditBox
    local function CurrBox(parent, w)
        local e = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
        e:SetSize(w or 36, 18); e:SetAutoFocus(false); e:SetNumeric(true)
        e:SetScript("OnEscapePressed", function(s) s:ClearFocus() end)
        e:SetText("0")
        return e
    end

    -- Change due label — computed dynamically
    local changeLbl = payPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    changeLbl:SetFont("Fonts\\FRIZQT__.TTF", 10, "OUTLINE")
    changeLbl:SetPoint("BOTTOMRIGHT", -8, 6)
    changeLbl:SetTextColor(1, 0.82, 0, 1)

    local function ReadCopper(g, s, c)
        return ((tonumber(g:GetText()) or 0) * 10000)
             + ((tonumber(s:GetText()) or 0) * 100)
             + (tonumber(c:GetText()) or 0)
    end

    local function UpdateChangeDue()
        local total   = R:CartTotal()
        local tip     = ReadCopper(R.payGratuityG, R.payGratuityS, R.payGratuityC)
        local paid    = ReadCopper(R.payCustomerG, R.payCustomerS, R.payCustomerC)
        local due     = total + tip
        local change  = paid - due
        if change > 0 then
            changeLbl:SetText("Change: " .. SK:FormatMoney(change))
            changeLbl:SetTextColor(0.4, 1, 0.4, 1)
        elseif change < 0 then
            changeLbl:SetText("Short: " .. SK:FormatMoney(-change))
            changeLbl:SetTextColor(1, 0.4, 0.4, 1)
        else
            changeLbl:SetText("Change: " .. SK:FormatMoney(0))
            changeLbl:SetTextColor(0.7, 0.7, 0.7, 1)
        end
    end

    -- Row 1: Gratuity
    local gratLbl = payPanel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    gratLbl:SetPoint("TOPLEFT", 8, -8); gratLbl:SetText("Gratuity:")
    gratLbl:SetTextColor(0.7, 0.7, 0.7, 1)

    R.payGratuityG = CurrBox(payPanel, 34); R.payGratuityG:SetPoint("TOPLEFT", 72, -5)
    local gg = CurrLbl(payPanel, "g", 1, 0.82, 0); gg:SetPoint("LEFT", R.payGratuityG, "RIGHT", 2, 0)
    R.payGratuityS = CurrBox(payPanel, 34); R.payGratuityS:SetPoint("LEFT", gg, "RIGHT", 3, 0)
    local gs = CurrLbl(payPanel, "s", 0.7, 0.7, 0.7); gs:SetPoint("LEFT", R.payGratuityS, "RIGHT", 2, 0)
    R.payGratuityC = CurrBox(payPanel, 34); R.payGratuityC:SetPoint("LEFT", gs, "RIGHT", 3, 0)
    local gc = CurrLbl(payPanel, "c", 0.7, 0.4, 0.1); gc:SetPoint("LEFT", R.payGratuityC, "RIGHT", 2, 0)
    R.payGratuityG:SetScript("OnTextChanged", UpdateChangeDue)
    R.payGratuityS:SetScript("OnTextChanged", UpdateChangeDue)
    R.payGratuityC:SetScript("OnTextChanged", UpdateChangeDue)

    -- Row 2: Customer Paid
    local paidLbl = payPanel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    paidLbl:SetPoint("TOPLEFT", 8, -32); paidLbl:SetText("Customer Paid:")
    paidLbl:SetTextColor(0.7, 0.7, 0.7, 1)

    R.payCustomerG = CurrBox(payPanel, 34); R.payCustomerG:SetPoint("TOPLEFT", 100, -29)
    local pg = CurrLbl(payPanel, "g", 1, 0.82, 0); pg:SetPoint("LEFT", R.payCustomerG, "RIGHT", 2, 0)
    R.payCustomerS = CurrBox(payPanel, 34); R.payCustomerS:SetPoint("LEFT", pg, "RIGHT", 3, 0)
    local ps = CurrLbl(payPanel, "s", 0.7, 0.7, 0.7); ps:SetPoint("LEFT", R.payCustomerS, "RIGHT", 2, 0)
    R.payCustomerC = CurrBox(payPanel, 34); R.payCustomerC:SetPoint("LEFT", ps, "RIGHT", 3, 0)
    local pc = CurrLbl(payPanel, "c", 0.7, 0.4, 0.1); pc:SetPoint("LEFT", R.payCustomerC, "RIGHT", 2, 0)
    R.payCustomerG:SetScript("OnTextChanged", UpdateChangeDue)
    R.payCustomerS:SetScript("OnTextChanged", UpdateChangeDue)
    R.payCustomerC:SetScript("OnTextChanged", UpdateChangeDue)

    UpdateChangeDue()

    yo = yo - PAY_H - 6

    -- Contact / Details panel — always visible
    local cfPanel = Panel(pop,0.05,0.05,0.08,1)
    cfPanel:SetPoint("TOPLEFT",PAD,yo); cfPanel:SetPoint("TOPRIGHT",-PAD,yo)
    cfPanel:SetHeight(170)
    R.commissionFields = cfPanel
    yo = yo - 170 - 6

    local function CFL(text,y) local l=FS(cfPanel,text,9,0.7,0.7,0.7); l:SetPoint("TOPLEFT",6,y); return l end
    local function CFI(y,w) local i=Box(cfPanel,w or cfPanel:GetWidth()-16,18); i:SetPoint("TOPLEFT",6,y); return i end

    -- Row 1: Buyer OOC (left) | Buyer IC (right)
    CFL("Buyer OOC Name", -6)
    R.cfBuyerOOC = CFI(-18, (cfPanel:GetWidth()-16)/2-2)

    local buyerICLabel = FS(cfPanel,"Buyer IC Name",9,0.7,0.7,0.7)
    buyerICLabel:SetPoint("TOPLEFT", cfPanel:GetWidth()/2+2, -6)
    R.cfBuyerIC = Box(cfPanel, (cfPanel:GetWidth()-16)/2-2, 18)
    R.cfBuyerIC:SetPoint("TOPLEFT", cfPanel:GetWidth()/2+2, -18)

    -- Auto-fill buyer from mouseover target
    local fillBtn = CreateFrame("Button", nil, cfPanel, "UIPanelButtonTemplate")
    fillBtn:SetSize((cfPanel:GetWidth()-16)/2-2, 18)
    fillBtn:SetPoint("TOPLEFT", cfPanel:GetWidth()/2 + 2, -38)
    fillBtn:SetText("Fill Target")
    fillBtn:SetScript("OnClick", function()
        -- Prefer hard target (persists on click); fall back to mouseover
        local unit = UnitExists("target") and "target" or (UnitExists("mouseover") and "mouseover" or nil)
        local targetName = unit and UnitName(unit)
        if not targetName or targetName == "" then
            print("|cffFFD700[SK]|r No target. Target or hover the buyer first.")
            return
        end
        if R.cfBuyerOOC then R.cfBuyerOOC:SetText(targetName) end

        -- Build Name-Realm string TRP3 uses as its register key
        local function BuildUnitID(u)
            if TRP3_API then
                local getUnitID = TRP3_API.utils and TRP3_API.utils.str and TRP3_API.utils.str.getUnitID
                if getUnitID then
                    local ok, val = pcall(getUnitID, u)
                    if ok and val and val ~= "" then return val end
                end
            end
            local uname, realm = UnitFullName(u)
            if not uname then return nil end
            if not realm or realm == "" then realm = GetRealmName() end
            return uname .. "-" .. realm
        end

        local icName = ""
        if TRP3_API then
            local unitID = BuildUnitID(unit)

            -- Method 1: getUnitIDCurrentProfile (modern TRP3)
            if unitID and unitID ~= "" then
                local ok, profile = pcall(function()
                    return TRP3_API.register
                        and TRP3_API.register.getUnitIDCurrentProfile
                        and TRP3_API.register.getUnitIDCurrentProfile(unitID)
                end)
                if ok and profile and profile.player then
                    local first = strtrim(profile.player.FN or "")
                    local last  = strtrim(profile.player.LN or "")
                    if last ~= "" then icName = first ~= "" and (first.." "..last) or last
                    elseif first ~= "" then icName = first end
                end
            end

            -- Method 2: getProfileByCharacter (older TRP3 API)
            if icName == "" and unitID and unitID ~= "" then
                local ok, profile = pcall(function()
                    return TRP3_API.register
                        and TRP3_API.register.getProfileByCharacter
                        and TRP3_API.register.getProfileByCharacter(unitID)
                end)
                if ok and profile and profile.player then
                    local first = strtrim(profile.player.FN or "")
                    local last  = strtrim(profile.player.LN or "")
                    if last ~= "" then icName = first ~= "" and (first.." "..last) or last
                    elseif first ~= "" then icName = first end
                end
            end

            -- Method 3: MSP (Mary Sue Protocol)
            if icName == "" then
                local ok, name3 = pcall(function()
                    if msp and msp.char then
                        local c = msp.char[UnitName(unit)]
                        if c and c.field then return strtrim(c.field.NA or "") end
                    end
                end)
                if ok and name3 and name3 ~= "" then icName = name3 end
            end
        end

        if R.cfBuyerIC then R.cfBuyerIC:SetText(icName) end
        if icName == "" and TRP3_API then
            print("|cffFFD700[SK]|r OOC name filled. No TRP3 IC name found â they may need to be nearby for TRP3 to load their profile.")
        end
    end)
    fillBtn:SetScript("OnEnter", function(s)
        GameTooltip:SetOwner(s, "ANCHOR_TOP")
        GameTooltip:SetFrameStrata("FULLSCREEN_DIALOG")
        GameTooltip:AddLine("Fill from Target", 1,1,1)
        GameTooltip:AddLine("Fills buyer OOC name and TRP3 IC name\nfrom the player you are hovering or targeting.", 0.7,0.7,0.7)
        GameTooltip:Show()
    end)
    fillBtn:SetScript("OnLeave", function() GameTooltip:Hide(); GameTooltip:SetFrameStrata("DIALOG") end)

    CFL("Delivery / Pick-up Note", -64); R.cfDelivery = CFI(-78, cfPanel:GetWidth()-12)
    CFL("Additional Notes",         -100); R.cfNotes    = CFI(-114, cfPanel:GetWidth()-12)

    -- Row 4: Seller OOC (left) | Seller IC (right)
    CFL("Your OOC Name", -134)
    R.cfSellerOOC = CFI(-148, (cfPanel:GetWidth()-16)/2-2)
    local selICLabel = FS(cfPanel,"Your IC Name",9,0.7,0.7,0.7)
    selICLabel:SetPoint("TOPLEFT", cfPanel:GetWidth()/2+2, -134)
    R.cfSellerIC = Box(cfPanel, (cfPanel:GetWidth()-16)/2-2, 18)
    R.cfSellerIC:SetPoint("TOPLEFT", cfPanel:GetWidth()/2+2, -148)

    -- Pre-fill seller
    local defaultIC = SK:GetSavedSellerIC()
    if R.cfSellerIC then R.cfSellerIC:SetText(defaultIC~="" and defaultIC or SK:GetRPName()) end
    if R.cfSellerOOC then R.cfSellerOOC:SetText(UnitName("player") or "") end

    -- Buttons — three rows
    local halfW = math.floor((W-PAD*2-4)/2)

    -- Row 0 (top): Open as Tab — full width
    local tabBtn=Btn(pop,"Open as Tab",W-PAD*2,24)
    tabBtn:SetPoint("BOTTOMLEFT",PAD,PAD+64+extraH)
    tabBtn:SetScript("OnClick",function()
        if #R.cart==0 then print("|cffFFD700[SK]|r Cart is empty."); return end
        -- Use the buyer IC name as the tab holder; fall back to OOC name
        local holder = (R.cfBuyerIC and strtrim(R.cfBuyerIC:GetText())) or ""
        if holder=="" then holder = (R.cfBuyerOOC and strtrim(R.cfBuyerOOC:GetText())) or "" end
        if holder=="" then
            if R.cfBuyerIC then R.cfBuyerIC:SetFocus() end
            print("|cffFFD700[SK]|r Enter a buyer name to use as the tab holder."); return
        end
        local opener = (R.cfSellerIC and R.cfSellerIC:GetText()~="" and R.cfSellerIC:GetText()) or SK:GetRPName()
        local ok, tab = SK.DB:CreateTab(shopName, {
            holders=holder, openedBy=opener, paymentMode="end", deposit=0,
        })
        if not ok then print("|cffFFD700[SK]|r "..tostring(tab)); return end
        -- Move every cart line onto the tab
        for _, e in ipairs(R.cart) do
            SK.DB:AddTabItem(shopName, tab.id, e.product, e.variant, e.qty or 1)
        end
        if SK.Net and SK.Net.BroadcastTab then
            SK.Net:BroadcastTab(shopName, SK.DB:GetTab(shopName, tab.id))
        end
        print(string.format("|cffFFD700[SK]|r Opened Tab #%d for %s with %d line(s).", tab.id, holder, #R.cart))
        R:ClearCart()
        if R.orderPopup then R.orderPopup:Hide(); R.orderPopup=nil end
        -- Jump to the Tabs tab so they can see it
        if R.SwitchToTab then R.SwitchToTab("tabs") end
    end)
    tabBtn:SetScript("OnEnter",function(s)
        GameTooltip:SetOwner(s,"ANCHOR_TOP")
        GameTooltip:SetFrameStrata("FULLSCREEN_DIALOG")
        GameTooltip:AddLine("Open as Tab",1,1,1)
        GameTooltip:AddLine("Starts an open tavern tab with these items instead of",0.7,0.7,0.7)
        GameTooltip:AddLine("finalising now. Uses the buyer name as the tab holder.",0.7,0.7,0.7)
        GameTooltip:Show()
    end)
    tabBtn:SetScript("OnLeave",function() GameTooltip:Hide(); GameTooltip:SetFrameStrata("DIALOG") end)

    -- Row 1: Confirm & Log (left) | Finalize (right)
    local confirmBtn=Btn(pop,"Confirm & Log Order",halfW,26)
    confirmBtn:SetPoint("BOTTOMLEFT",PAD,PAD+32+extraH)
    confirmBtn:SetScript("OnClick",function()
        local bicName = R.cfBuyerIC  and strtrim(R.cfBuyerIC:GetText())  or ""
        if bicName=="" then if R.cfBuyerIC then R.cfBuyerIC:SetFocus() end
            print("|cffFFD700[SK]|r Buyer IC name required."); return end
        -- OOC is optional — if blank, it will be stored empty and display will fall back to IC
        if R.cfBuyerOOC and strtrim(R.cfBuyerOOC:GetText())==""  then
            R.cfBuyerOOC:SetText("")  -- leave blank so display knows there is no separate OOC
        end
        R:ConfirmOrder(shopName)
    end)

    -- "Finalize" = log to Activity Log only, update treasury, NO order created in order list
    local finalizeBtn=Btn(pop,"Finalize",halfW,26)
    finalizeBtn:SetPoint("LEFT",confirmBtn,"RIGHT",4,0)
    finalizeBtn:SetScript("OnClick",function()
        -- Check favour permission
        if R.selectedPayment=="favor" then
            local sn2=SK.db and SK.db.activeShop
            local shop2=sn2 and SK.DB:GetShop(sn2)
            local myR=sn2 and SK.DB:GetMyRole(sn2)
            if shop2 then SK.DB:MigrateShop(shop2) end
            local canFavour=(myR=="owner") or (myR=="manager") or
                SK.DB:CanPayAsFavour(shopName)
            if not canFavour then
                print("|cffFFD700[SK]|r You do not have permission to finalise as Paid as a Favour."); return
            end
        end
        local pt    = R.selectedPayment or "paid"
        local total = R:CartTotal()
        local seller = (R.cfSellerIC and R.cfSellerIC:GetText()~="" and R.cfSellerIC:GetText()) or SK:GetRPName()
        -- Build a human-readable item summary for the log
        local itemParts = {}
        for _, e in ipairs(R.cart) do
            local dn = SK:LineLabel(e.product.name, e.variant and e.variant.name)
            tinsert(itemParts, e.qty.."x "..dn)
        end
        local itemsStr = table.concat(itemParts, ", ")
        local ptLabel  = ({paid="Paid in Full",favor="Paid as a Favour",delivery="Pay After Delivery"})[pt] or pt

        -- Payment details (only meaningful for "paid")
        local tipCopper    = 0
        local changeCopper = 0
        if pt == "paid" then
            local function RC(g, s, c)
                return ((tonumber(g:GetText()) or 0)*10000)
                     + ((tonumber(s:GetText()) or 0)*100)
                     + (tonumber(c:GetText()) or 0)
            end
            tipCopper    = (R.payGratuityG and RC(R.payGratuityG, R.payGratuityS, R.payGratuityC)) or 0
            local custPaid = (R.payCustomerG and RC(R.payCustomerG, R.payCustomerS, R.payCustomerC)) or 0
            changeCopper = math.max(0, custPaid - (total + tipCopper))
        end

        local logMsg   = string.format("Finalized: %s | %s | %s | Seller: %s",
            ptLabel, itemsStr, SK:FormatMoneyPlain(total), seller)
        if tipCopper > 0 then
            logMsg = logMsg .. " | Tip: " .. SK:FormatMoneyPlain(tipCopper)
        end
        if changeCopper > 0 then
            logMsg = logMsg .. " | Change given: " .. SK:FormatMoneyPlain(changeCopper)
        end
        -- Write to Activity Log
        SK.DB:AddLog(shopName, logMsg, "treasury")
        -- Treasury: add sale + tip, deduct change for "paid"
        if pt=="paid" then
            local net = total + tipCopper - changeCopper
            if net > 0 then
                SK.DB:AddTreasury(shopName, net)
            elseif net < 0 then
                SK.DB:AddTreasury(shopName, net)  -- negative = withdrawal
            end
        end
        -- Decrease stock per item; use variant stockCost if set
        for _, e in ipairs(R.cart) do
            if e.product and e.product.id then
                local cost = 1
                if e.variant and e.variant.stockCost and e.variant.stockCost > 1 then
                    cost = e.variant.stockCost
                end
                SK.DB:DecreaseStock(shopName, e.product.id, (e.qty or 1) * cost)
            end
        end
        local netMsg = "no treasury change"
        if pt == "paid" then
            local net = total + tipCopper - changeCopper
            netMsg = (net >= 0 and "+" or "") .. "|cffFFD700" .. SK:FormatMoneyPlain(math.abs(net)) .. "|r to treasury"
            if tipCopper > 0 then netMsg = netMsg .. " (incl. tip)" end
            if changeCopper > 0 then netMsg = netMsg .. " (change: " .. SK:FormatMoneyPlain(changeCopper) .. ")" end
        end
        print(string.format("|cffFFD700[SK]|r Finalized (%s) — %s", ptLabel, netMsg))
        if SK:Cfg().autoClearCart ~= false then R:ClearCart() end
        if R.orderPopup then R.orderPopup:Hide(); R.orderPopup=nil end
    end)

    -- Row 2: Copy Receipt (left) | Send as Emote (right)
    local copyBtn=Btn(pop,"Copy Receipt",halfW,26)
    copyBtn:SetPoint("BOTTOMLEFT",PAD,PAD+extraH)
    copyBtn:SetScript("OnClick",function() R:CopyReceipt(shopName) end)
    copyBtn:SetScript("OnEnter",function(s)
        GameTooltip:SetOwner(s,"ANCHOR_TOP")
        GameTooltip:SetFrameStrata("FULLSCREEN_DIALOG")
        GameTooltip:AddLine("Copy Receipt Text",1,1,1)
        GameTooltip:AddLine("Opens a copyable text box with the receipt.",0.7,0.7,0.7)
        GameTooltip:Show()
    end)
    copyBtn:SetScript("OnLeave",function() GameTooltip:Hide(); GameTooltip:SetFrameStrata("DIALOG") end)

    local emoteBtn=Btn(pop,"Send as Emote",halfW,26)
    emoteBtn:SetPoint("LEFT",copyBtn,"RIGHT",4,0)
    emoteBtn:SetScript("OnClick",function() R:SendOrderEmote(shopName) end)

    -- (The Get Items action now lives in a per-item side panel, built after the
    -- popup height is finalised below.)

    -- ── Final height ─────────────────────────────────────────────────────────
    -- Top-down content ends at -yo. The bottom-anchored button stack reaches
    -- up to PAD + extraH + 88 (the top edge of the Open as Tab row). Sizing to
    -- fit both, plus a small gap, keeps them from ever meeting regardless of
    -- how many lines the cart has or whether the payment panel is showing.
    local BTN_STACK_H = PAD + extraH + 88
    local contentH    = -yo   -- yo is negative and ends just below cfPanel
    pop:SetHeight(contentH + 6 + BTN_STACK_H)

    -- ── Per-item Get Items side panel (TRP3 Extended) ─────────────────────────
    -- Instead of one all-or-nothing button, list every TRP3 line with its own
    -- Get button so the seller can pull items one at a time and trade them as
    -- they go. This matches TRP3's reality: the bag holds only 17 slots and a
    -- container's contents don't survive a trade, so large orders change hands
    -- piece by piece.
    local trpReady = (SK.TRP3 and SK.TRP3.CanGiveItems and SK.TRP3:CanGiveItems()) and true or false
    if trpReady then
        -- Which cart lines actually carry a TRP3 item? Re-resolve stubs by id.
        local byID = {}
        for _, dp in ipairs(SK.DB:GetProducts(shopName) or {}) do
            if dp.id ~= nil then byID[dp.id] = dp end
        end
        local trpLines = {}
        for _, e in ipairs(R.cart) do
            local p = e.product
            if p and p.id ~= nil and byID[p.id] then p = byID[p.id] end
            if p and p.hasTRP3Item then tinsert(trpLines, e) end
        end

        do
            local SP_W  = 220
            local ROW_H = 26
            local TITLE_H = 24
            local RCPT_H  = 30           -- "Get Receipt" button row
            local FOOT_H  = 30
            local MAXV  = 10
            local hasItems = #trpLines > 0
            local visible = math.min(#trpLines, MAXV)
            local listBlock = hasItems and (4 + visible*ROW_H + 6 + FOOT_H) or 0
            local spH = PAD + TITLE_H + 4 + RCPT_H + listBlock + PAD

            local sp = CreateFrame("Frame", nil, pop, "BackdropTemplate")
            sp:SetSize(SP_W, spH)
            sp:SetPoint("TOPLEFT", pop, "TOPRIGHT", 6, 0)
            sp:SetFrameStrata("HIGH"); sp:SetToplevel(true)
            sp:SetBackdrop({
                bgFile="Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
                edgeFile="Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
                edgeSize=24, insets={left=6,right=6,top=6,bottom=6}
            })
            sp:SetBackdropColor(0,0,0,1); sp:SetBackdropBorderColor(1,1,1,1)

            -- Title bar
            local sptb = Panel(sp,0.08,0.08,0.12,1); sptb:SetHeight(TITLE_H)
            sptb:SetPoint("TOPLEFT",PAD,-PAD); sptb:SetPoint("TOPRIGHT",-PAD,-PAD)
            local spt = sptb:CreateFontString(nil,"OVERLAY","GameFontNormal")
            spt:SetFont("Fonts\\FRIZQT__.TTF",11,"OUTLINE"); spt:SetPoint("LEFT",8,0)
            spt:SetText("Hand to Buyer"); spt:SetTextColor(1,0.82,0,1)

            -- Get Receipt: build a filled-in receipt item for this order and drop
            -- it in your bag. Available whenever TRP3 Extended is loaded.
            local rcptBtn = Btn(sp, "Get Receipt", SP_W - PAD*2, 22)
            rcptBtn:SetPoint("TOPLEFT", PAD, -(PAD+TITLE_H+4))
            rcptBtn:SetScript("OnClick", function() R:GetOrderReceipt(shopName) end)
            rcptBtn:SetScript("OnEnter", function(s)
                GameTooltip:SetOwner(s,"ANCHOR_TOP"); GameTooltip:SetFrameStrata("FULLSCREEN_DIALOG")
                GameTooltip:AddLine("Get Receipt",1,1,1)
                GameTooltip:AddLine("Creates a TRP3 Extended receipt item filled with this",0.7,0.7,0.7)
                GameTooltip:AddLine("order's items and total, and adds it to your bag.",0.7,0.7,0.7)
                GameTooltip:AddLine("Design the layout in the Receipt tab.",0.7,0.7,0.7)
                GameTooltip:Show()
            end)
            rcptBtn:SetScript("OnLeave", function() GameTooltip:Hide(); GameTooltip:SetFrameStrata("DIALOG") end)

            if hasItems then
            -- Scroll list of item rows
            local sf = CreateFrame("ScrollFrame", nil, sp, "UIPanelScrollFrameTemplate")
            sf:SetPoint("TOPLEFT", PAD, -(PAD+TITLE_H+4+RCPT_H))
            sf:SetPoint("BOTTOMRIGHT", -(PAD+18), PAD+FOOT_H)
            sf:EnableMouseWheel(true)
            local sc = CreateFrame("Frame", nil, sf)
            sc:SetSize(SP_W - PAD*2 - 18, #trpLines*ROW_H)
            sf:SetScrollChild(sc)
            sf:SetScript("OnMouseWheel", function(s, d)
                local maxS = math.max(0, (sc:GetHeight() or 0) - (s:GetHeight() or 0))
                s:SetVerticalScroll(math.max(0, math.min(maxS, (s:GetVerticalScroll() or 0) - d*ROW_H)))
            end)

            -- Give a single cart line, report the outcome, and mark the row done.
            local rowBtns = {}
            local function GiveOne(e, btn)
                if not (SK.TRP3 and SK.TRP3.CanGiveItems and SK.TRP3:CanGiveItems()) then
                    print("|cffFFD700[SK]|r TRP3 Extended was not detected, so items cannot be added. Make sure Total RP 3: Extended is enabled.")
                    return
                end
                local added, problems, missingClass, dropped = SK.TRP3:GiveCartItems({ e })
                if added > 0 then
                    print(string.format("|cffFFD700[SK]|r Added %d to your bag.", added))
                end
                if dropped and dropped > 0 then
                    print(string.format("|cffFFD700[SK]|r Bag full - %d item(s) dropped at your feet. Pick them up or clear space.", dropped))
                end
                if #problems > 0 then
                    print("|cffFFD700[SK]|r "..table.concat(problems, ", "))
                    if missingClass then
                        print("|cffFFD700[SK]|r Ask the shop owner for the item's TRP3 Extended export string, then use Quick Object Import once to add it to your database.")
                    end
                end
                -- Delivered (added or dropped) => mark done so it isn't given twice.
                if added > 0 or (dropped or 0) > 0 then
                    btn:SetText("Got")
                    btn:Disable()
                end
            end

            local yo2 = 0
            for _, e in ipairs(trpLines) do
                local row = CreateFrame("Frame", nil, sc)
                row:SetSize(sc:GetWidth(), ROW_H); row:SetPoint("TOPLEFT", 0, -yo2)

                local getB = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
                getB:SetSize(46, 20); getB:SetPoint("RIGHT", -2, 0)
                getB:SetText("Get")

                local lbl = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
                lbl:SetPoint("LEFT", 2, 0); lbl:SetPoint("RIGHT", getB, "LEFT", -4, 0)
                lbl:SetJustifyH("LEFT")
                local nm = SK:LineLabel(e.product.name, e.variant and e.variant.name)
                local q = e.qty or 1
                lbl:SetText(nm .. (q > 1 and ("  x"..q) or ""))
                lbl:SetTextColor(0.9,0.9,0.9,1)

                getB:SetScript("OnClick", function(s) GiveOne(e, s) end)
                tinsert(rowBtns, getB)
                yo2 = yo2 + ROW_H
            end

            -- Footer: Get all remaining lines at once.
            local allB = Btn(sp, "Get All Remaining", SP_W - PAD*2, 22)
            allB:SetPoint("BOTTOMLEFT", PAD, PAD)
            allB:SetScript("OnClick", function()
                for i, e in ipairs(trpLines) do
                    local b = rowBtns[i]
                    if b and b:IsEnabled() then GiveOne(e, b) end
                end
            end)
            allB:SetScript("OnEnter", function(s)
                GameTooltip:SetOwner(s,"ANCHOR_TOP"); GameTooltip:SetFrameStrata("FULLSCREEN_DIALOG")
                GameTooltip:AddLine("Get everything not yet pulled",1,1,1)
                GameTooltip:AddLine("Adds all remaining items to YOUR bag at once.",0.7,0.7,0.7)
                GameTooltip:AddLine("Watch your bag space - the overflow drops at your feet.",0.7,0.7,0.7)
                GameTooltip:Show()
            end)
            allB:SetScript("OnLeave", function() GameTooltip:Hide(); GameTooltip:SetFrameStrata("DIALOG") end)
            end  -- if hasItems
        end
    end

end
function R:ConfirmOrder(shopName)
    local orderData = {
        items       = R.cart,
        totalCopper = R:CartTotal(),
        paymentType = R.selectedPayment or "paid",
        status      = "open",
        sellerOOC   = R.cfSellerOOC and R.cfSellerOOC:GetText() or "",
        sellerIC    = R.cfSellerIC  and R.cfSellerIC:GetText()  or SK:GetRPName(),
        buyerOOC    = R.cfBuyerOOC  and R.cfBuyerOOC:GetText()  or "",
        buyerIC     = R.cfBuyerIC   and R.cfBuyerIC:GetText()   or "",
        deliveryNote= R.cfDelivery  and R.cfDelivery:GetText()  or "",
        notes       = R.cfNotes     and R.cfNotes:GetText()     or "",
    }
    local ok, order = SK.DB:CreateOrder(shopName, orderData)
    if ok then
        print(string.format("|cffFFD700[SK]|r Order #%d logged (%s).", order.id, orderData.paymentType))
        -- Broadcast to all staff
        if SK.Net then SK.Net:BroadcastOrder(shopName, order) end
        if SK:Cfg().autoClearCart ~= false then R:ClearCart() end
        if R.orderPopup then R.orderPopup:Hide(); R.orderPopup=nil end
    else
        print("|cffFFD700[SK]|r Could not save order.")
    end
end

-- Helper: build and send emote from a template body string
local function FireEmote(shopName, templateBody)
    local shop = SK.DB:GetShop(shopName)
    local cfg  = SK:Cfg()
    local shopDisplay = shop and shopName or "the shop"
    local seller = (R.cfSellerIC and R.cfSellerIC:GetText()~="" and R.cfSellerIC:GetText()) or SK:GetRPName()
    local pt = R.selectedPayment or "paid"
    local ptLabel = ({paid="Paid in full",favor="Paid as a favour",delivery="Pay after delivery",commission="Commission - to be made"})[pt] or pt

    local itemParts = {}
    for _, e in ipairs(R.cart) do
        local dn = SK:LineLabel(e.product.name, e.variant and e.variant.name)
        tinsert(itemParts, e.qty.."x "..dn)
    end
    local itemsStr = table.concat(itemParts, ", ")
    local totalStr = SK:FormatMoneyPlain(R:CartTotal())

    local emoteBody = (templateBody or "")
        :gsub("{shop}",    shopDisplay)
        :gsub("{seller}",  seller)
        :gsub("{items}",   itemsStr)
        :gsub("{total}",   totalStr)
        :gsub("{payment}", ptLabel)

    print("|cffFFD700[SK Receipt — "..shopDisplay.."]|r")
    for _, e in ipairs(R.cart) do
        local dn = SK:LineLabel(e.product.name, e.variant and e.variant.name)
        local unitPrice = (e.variant and e.variant.priceCopper) or e.product.priceCopper
        print(string.format("  %dx %s — %s", e.qty, dn, SK:FormatMoneyPlain(unitPrice*e.qty)))
    end
    print("Total: "..totalStr.."  |  Payment: "..ptLabel.."  |  Seller: "..seller)

    local channel = cfg.emoteChannel or "EMOTE"
    if channel == "EMOTE" then SendChatMessage(emoteBody, "EMOTE") end
end

-- Build a filled-in TRP3 Extended receipt item for the CURRENT cart/order and
-- put a copy in the seller's bag to hand over. Uses the shop's saved receipt
-- template (or a built-in default), substituting this order's details. Each call
-- mints a fresh item so past receipts aren't overwritten.
function R:GetOrderReceipt(shopName)
    if #R.cart == 0 then print("|cffFFD700[SK]|r Cart is empty."); return end
    if not (SK.TRP3 and SK.TRP3.CanGiveItems and SK.TRP3:CanGiveItems()) then
        print("|cffFFD700[SK]|r TRP3 Extended was not detected, so a receipt item can't be created.")
        return
    end

    local shop = SK.DB:GetShop(shopName)
    local rc   = (shop and shop.receipt) or {}
    local body = rc.body
    if not body or strtrim(body) == "" then body = SK:DefaultReceiptBody() end

    -- Order details
    local buyerIC  = R.cfBuyerIC  and strtrim(R.cfBuyerIC:GetText())  or ""
    local buyerOOC = R.cfBuyerOOC and strtrim(R.cfBuyerOOC:GetText()) or ""
    local buyer    = (buyerIC ~= "" and buyerIC) or (buyerOOC ~= "" and buyerOOC) or "Customer"
    local seller   = (R.cfSellerIC and R.cfSellerIC:GetText() ~= "" and R.cfSellerIC:GetText()) or SK:GetRPName()
    local pt       = R.selectedPayment or "paid"
    local ptLabel  = ({paid="Paid in full",favor="Paid as a favour",delivery="Pay after delivery",commission="Commission - to be made"})[pt] or pt

    local lines = {}
    for _, e in ipairs(R.cart) do
        local nm   = SK:LineLabel(e.product.name, e.variant and e.variant.name)
        local unit = (e.variant and e.variant.priceCopper) or e.product.priceCopper or 0
        tinsert(lines, (e.qty or 1) .. "x " .. nm .. " - " .. SK:FormatMoneyPlain(unit * (e.qty or 1)))
    end

    local filled = SK:FillReceipt(body, {
        shop    = shopName,
        buyer   = buyer,
        seller  = seller,
        items   = table.concat(lines, "\n"),
        total   = SK:FormatMoneyPlain(R:CartTotal()),
        payment = ptLabel,
        date    = date("%d/%m/%Y"),
    })

    local rname = (rc.name and strtrim(rc.name) ~= "" and rc.name) or (shopName .. " Receipt")
    local ok, res = SK.TRP3:AuthorReceiptItem({
        name = rname, icon = rc.icon, actionLabel = rc.actionLabel, body = filled,
        -- no itemID: each order gets its own item so earlier receipts stay intact
    })
    if not ok then
        print("|cffFFD700[SK]|r Could not create the receipt item: " .. tostring(res))
        return
    end

    local gok, how = SK.TRP3:GiveItemByID(res, rname)
    if gok and how == "dropped" then
        print("|cffFFD700[SK]|r Receipt created; your bag was full so it dropped at your feet.")
    elseif gok then
        print("|cffFFD700[SK]|r Receipt added to your bag. Hand it over with Extended's trade window.")
    else
        print("|cffFFD700[SK]|r Receipt item created (" .. res .. ") but " .. tostring(how))
    end
end

function R:SendOrderEmote(shopName)
    local cfg = SK:Cfg()
    local responses = cfg.emoteResponses or {}

    -- If only one response, fire it immediately
    if #responses == 1 then
        FireEmote(shopName, responses[1].body)
        return
    end
    -- If no responses defined, use fallback
    if #responses == 0 then
        FireEmote(shopName, "hands over a receipt from {shop} — {items} — Total: {total} ({payment}), served by {seller}.")
        return
    end

    -- Show picker popup
    if R._emotePicker then R._emotePicker:Hide() end
    local pickerW, pickerH = 300, math.min(#responses * 30 + 56, 360)
    local picker = CreateFrame("Frame", "SK_EmotePicker", UIParent, "BackdropTemplate")
    R._emotePicker = picker
    picker:SetSize(pickerW, pickerH)
    picker:SetPoint("CENTER", UIParent, "CENTER", 0, 60)
    picker:SetFrameStrata("FULLSCREEN_DIALOG")
    picker:SetFrameLevel(200)
    picker:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    picker:SetBackdropColor(0.08,0.06,0.04,0.97)
    picker:SetBackdropBorderColor(0.6,0.5,0.2,1)
    picker:EnableMouse(true)
    picker:SetMovable(true)
    picker:RegisterForDrag("LeftButton")
    picker:SetScript("OnDragStart", function(s) s:StartMoving() end)
    picker:SetScript("OnDragStop",  function(s) s:StopMovingOrSizing() end)

    local title = picker:CreateFontString(nil,"OVERLAY","GameFontNormal")
    title:SetPoint("TOPLEFT",8,-8); title:SetText("|cffFFD700Choose Emote Response|r")

    -- Random button
    local randBtn = CreateFrame("Button",nil,picker,"UIPanelButtonTemplate")
    randBtn:SetSize(pickerW-16, 22); randBtn:SetPoint("TOPLEFT",8,-26); randBtn:SetText("Random")
    randBtn:SetScript("OnClick",function()
        local r2 = responses[math.random(1, #responses)]
        picker:Hide()
        FireEmote(shopName, r2.body)
    end)

    -- Scroll list of named responses
    local listSF = CreateFrame("ScrollFrame",nil,picker,"UIPanelScrollFrameTemplate")
    listSF:SetPoint("TOPLEFT",8,-54); listSF:SetPoint("BOTTOMRIGHT",-26,8)
    local listSC = CreateFrame("Frame",nil,listSF)
    listSC:SetWidth(listSF:GetWidth()-4); listSC:SetHeight(1)
    listSF:SetScrollChild(listSC)

    local ly = 0
    for i, resp in ipairs(responses) do
        local btn = CreateFrame("Button",nil,listSC,"BackdropTemplate")
        btn:SetHeight(26); btn:SetPoint("TOPLEFT",0,-ly); btn:SetPoint("TOPRIGHT",0,-ly)
        btn:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
        btn:SetBackdropColor(0,0,0,0.1); btn:SetBackdropBorderColor(0.4,0.35,0.2,0.3)
        btn:SetScript("OnEnter",function(s) s:SetBackdropColor(0.15,0.12,0.05,0.9) end)
        btn:SetScript("OnLeave",function(s) s:SetBackdropColor(0,0,0,0.1) end)
        local lbl = btn:CreateFontString(nil,"OVERLAY","GameFontNormal")
        lbl:SetAllPoints(); lbl:SetJustifyH("LEFT"); lbl:SetPoint("LEFT",6,0)
        lbl:SetText((resp.name ~= "" and resp.name) or ("Response "..i))
        local idx = i
        btn:SetScript("OnClick",function()
            picker:Hide()
            FireEmote(shopName, responses[idx].body)
        end)
        ly = ly + 28
    end
    listSC:SetHeight(math.max(ly, 10))

    -- Close button
    local closeX = CreateFrame("Button",nil,picker,"UIPanelCloseButton")
    closeX:SetPoint("TOPRIGHT",0,0)
    closeX:SetScript("OnClick",function() picker:Hide() end)
end

function R:CopyReceipt(shopName)
    local shop = SK.DB:GetShop(shopName)
    local shopDisplay = shop and shopName or "the shop"
    local seller = (R.cfSellerIC and R.cfSellerIC:GetText()~="" and R.cfSellerIC:GetText()) or SK:GetRPName()
    local pt = R.selectedPayment or "paid"
    local ptLabel = ({paid="Paid in full",favor="Paid as a favour",delivery="Pay after delivery",commission="Commission - to be made"})[pt] or pt
    local totalStr = SK:FormatMoneyPlain(R:CartTotal())

    -- Build receipt text — formatted for a TRP3 document
    -- Use plain ASCII dashes for separators (WoW font has no box-drawing glyphs)
    local SEP = string.rep("-", 32)
    local lines = {}
    tinsert(lines, "Receipt -- "..shopDisplay)
    tinsert(lines, SEP)
    for _, e in ipairs(R.cart) do
        local dn = SK:LineLabel(e.product.name, e.variant and e.variant.name)
        local unitPrice = (e.variant and e.variant.priceCopper) or e.product.priceCopper
        local lineTotal = SK:FormatMoneyPlain(unitPrice * e.qty)
        tinsert(lines, string.format("%dx %s - %s", e.qty, dn, lineTotal))
    end
    tinsert(lines, SEP)
    if R.activeDiscount then
        tinsert(lines, "Discount: "..R.activeDiscount.label.." (-"..R.activeDiscount.pct.."%)")
    end
    tinsert(lines, "Total: "..totalStr)
    tinsert(lines, "Payment: "..ptLabel)
    tinsert(lines, "Served by: "..seller)
    tinsert(lines, "Shop: "..shopDisplay)
    local receiptText = table.concat(lines, "\n")

    -- Show copy popup
    if R.copyPopup then R.copyPopup:Hide() end
    local cp = CreateFrame("Frame","StorekeeperCopyPopup",UIParent,"BackdropTemplate")
    cp:SetSize(400, 260); cp:SetPoint("CENTER")
    cp:SetFrameStrata("FULLSCREEN_DIALOG"); cp:SetToplevel(true)
    cp:SetFrameLevel(200)
    cp:SetMovable(true); cp:EnableMouse(true); cp:RegisterForDrag("LeftButton")
    cp:SetScript("OnDragStart",cp.StartMoving); cp:SetScript("OnDragStop",cp.StopMovingOrSizing)
    cp:SetBackdrop({
        bgFile="Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
        edgeFile="Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
        edgeSize=22, insets={left=6,right=6,top=6,bottom=6}
    })
    cp:SetBackdropColor(0,0,0,1); cp:SetBackdropBorderColor(1,1,1,1)
    R.copyPopup = cp
    if not R._copySpecialRegistered then
        tinsert(UISpecialFrames, "StorekeeperCopyPopup")
        R._copySpecialRegistered = true
    end

    -- Title bar fully inside the border inset (inset=6, so start at 8)
    local cpTB = Panel(cp,0.08,0.08,0.12,1); cpTB:SetHeight(28)
    cpTB:SetPoint("TOPLEFT",8,-8); cpTB:SetPoint("TOPRIGHT",-8,-8)
    cpTB:EnableMouse(true); cpTB:RegisterForDrag("LeftButton")
    cpTB:SetScript("OnDragStart",function() cp:StartMoving() end)
    cpTB:SetScript("OnDragStop", function() cp:StopMovingOrSizing() end)

    local cpTitle = cpTB:CreateFontString(nil,"OVERLAY","GameFontNormal")
    cpTitle:SetFont("Fonts\\FRIZQT__.TTF",11,"OUTLINE")
    cpTitle:SetPoint("LEFT",8,0); cpTitle:SetText("|cffFFD700Copy Receipt|r")

    local cpClose = CreateFrame("Button",nil,cpTB,"UIPanelCloseButton")
    cpClose:SetSize(22,22); cpClose:SetPoint("RIGHT",-2,0)
    cpClose:SetScript("OnClick",function() cp:Hide(); R.copyPopup=nil end)

    -- Instruction text inside border
    local hint = cp:CreateFontString(nil,"OVERLAY","GameFontNormal")
    hint:SetFont("Fonts\\FRIZQT__.TTF",9,"")
    hint:SetPoint("TOPLEFT",10,-42)
    hint:SetPoint("TOPRIGHT",-10,-42)
    hint:SetText("Ctrl+A to select all, Ctrl+C to copy. Paste into a TRP3 Extended document item.")
    hint:SetTextColor(0.7,0.7,0.7,1)
    hint:SetJustifyH("LEFT")

    -- Edit box with scroll, inside border
    local sf = CreateFrame("ScrollFrame",nil,cp,"UIPanelScrollFrameTemplate")
    sf:SetPoint("TOPLEFT",10,-58); sf:SetPoint("BOTTOMRIGHT",-28,40)

    local eb = CreateFrame("EditBox",nil,sf)
    eb:SetWidth(sf:GetWidth()); eb:SetHeight(300)
    eb:SetMultiLine(true); eb:SetFontObject("GameFontNormal")
    eb:SetText(receiptText); eb:SetAutoFocus(true)
    eb:HighlightText()  -- pre-select all text
    sf:SetScrollChild(eb)

    local closeBtn = Btn(cp,"Close",80,24)
    closeBtn:SetPoint("BOTTOMRIGHT",-10,10)
    closeBtn:SetScript("OnClick",function() cp:Hide(); R.copyPopup=nil end)
end

-- ─── Main Frame — Unified Guild & Communities style ───────────────────────────

function R:Build()
    if R.mainFrame then R.mainFrame:Show(); return end

    local BTN_SZ    = 32   -- tab button size
    local BTN_GAP   = 1    -- gap between tab buttons
    local BTN_STRIP = BTN_SZ + 6  -- strip width outside frame
    local W, H      = 720, 560    -- frame width (buttons sit outside to the right)
    local TITLE_H   = 34
    local SIDEBAR_W = 130
    local BOT_H     = 104
    local INSET     = 4

    -- ── Outer frame ───────────────────────────────────────────────────────────
    local f = CreateFrame("Frame","StorekeeperRegisterFrame",UIParent,"BackdropTemplate")
    f:SetSize(W,H); f:SetPoint("CENTER")
    f:SetMovable(true); f:EnableMouse(true)
    f:SetClampedToScreen(true)
    -- Move on mouse-down rather than RegisterForDrag. OnDragStart only fires once
    -- the cursor has crossed a drag threshold, so StartMoving latches onto the
    -- pointer a few pixels from the grab point and the frame visibly jumps before
    -- it starts tracking. Mouse-down begins the move at zero offset, so it drags
    -- smoothly from the first pixel. A guard flag prevents it sticking to the
    -- cursor if a matching mouse-up is ever missed.
    local function StartFrameMove()
        if not f._moving then f:StartMoving(); f._moving = true end
    end
    local function StopFrameMove()
        if f._moving then f:StopMovingOrSizing(); f._moving = false end
    end
    f:SetScript("OnMouseDown", function(_, btn) if btn == "LeftButton" then StartFrameMove() end end)
    f:SetScript("OnMouseUp",   function(_, btn) if btn == "LeftButton" then StopFrameMove() end end)
    f:SetFrameStrata("MEDIUM"); f:SetToplevel(true)
    f:SetBackdrop({
        bgFile   = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
        tile=true, tileSize=256,
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
        edgeSize = 24, insets={left=6,right=6,top=6,bottom=6},
    })
    f:SetBackdropColor(0.05,0.06,0.10,0.98)
    f:SetBackdropBorderColor(1,1,1,1)

    -- Ornate corner decorations — parented to a dedicated overlay frame that
    -- sits above the backdrop and all child panels, so they're always visible.
    -- Textures are loaded automatically by WoW from the addon folder path.
    local cornerOverlay = CreateFrame("Frame", nil, f)
    cornerOverlay:SetAllPoints(f)
    cornerOverlay:SetFrameLevel(f:GetFrameLevel() + 100)
    local CORNER_W, CORNER_H = 64, 61
    local cornerDefs = {
        {point="TOPLEFT",     tex="corner_tl", ox=-8,  oy=8 },
        {point="TOPRIGHT",    tex="corner_tr", ox=8,   oy=8 },
        {point="BOTTOMLEFT",  tex="corner_bl", ox=-8,  oy=-8},
        {point="BOTTOMRIGHT", tex="corner_br", ox=8,   oy=-8},
    }
    for _, cd in ipairs(cornerDefs) do
        local t = cornerOverlay:CreateTexture(nil, "OVERLAY", nil, 7)
        t:SetSize(CORNER_W, CORNER_H)
        t:SetPoint(cd.point, f, cd.point, cd.ox, cd.oy)
        t:SetTexture("Interface\\AddOns\\Storekeeper\\textures\\" .. cd.tex)
    end

    R.mainFrame  = f
    R.themedFrames = {}

    -- ── Resize handle (TRP3 shadow frame approach) ────────────────────────────
    local MIN_W, MIN_H = 560, 440

    -- Shadow frame: an invisible resizable frame that tracks the drag live.
    -- The real frame only snaps to the final size on mouse-up.
    -- This is exactly how TRP3 handles resizing for smoothness.
    local shadow = CreateFrame("Frame", "StorekeeperResizeShadow", UIParent)
    shadow:SetFrameStrata("FULLSCREEN_DIALOG")
    shadow:SetFrameLevel(300)
    shadow:Hide()
    if shadow.SetResizeBounds then
        shadow:SetResizeBounds(MIN_W, MIN_H)
    else
        shadow:SetMinResize(MIN_W, MIN_H)
    end
    shadow:SetResizable(true)
    -- Dashed border on the shadow so user can see the resize outline
    local shadowTex = shadow:CreateTexture(nil, "BACKGROUND")
    shadowTex:SetAllPoints()
    shadowTex:SetColorTexture(1, 1, 1, 0.08)

    -- Resize button using TRP3's resize button texture (blz-redbutton2x.blp)
    -- TexCoords match TRP3_RedButtonResizeArtTemplate exactly
    local resizeBtn = CreateFrame("Button", nil, cornerOverlay)
    resizeBtn:SetSize(24, 24)
    resizeBtn:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -2, 2)

    local TRP3_TEX = "Interface\\AddOns\\Storekeeper\\textures\\blz-redbutton2x"
    local rNorm = resizeBtn:CreateTexture(nil, "ARTWORK")
    rNorm:SetTexture(TRP3_TEX)
    rNorm:SetTexCoord(0.14453125, 0.00390625, 0.0078125, 0.3046875)
    rNorm:SetAllPoints()
    resizeBtn:SetNormalTexture(rNorm)

    local rPush = resizeBtn:CreateTexture(nil, "ARTWORK")
    rPush:SetTexture(TRP3_TEX)
    rPush:SetTexCoord(0.14453125, 0.00390625, 0.6328125, 0.9296875)
    rPush:SetAllPoints()
    resizeBtn:SetPushedTexture(rPush)

    local rHigh = resizeBtn:CreateTexture(nil, "HIGHLIGHT")
    rHigh:SetTexture(TRP3_TEX)
    rHigh:SetTexCoord(0.44921875, 0.58984375, 0.0078125, 0.3046875)
    rHigh:SetAllPoints()
    resizeBtn:SetHighlightTexture(rHigh)

    resizeBtn:SetScript("OnMouseDown", function(self, btn)
        if btn ~= "LeftButton" then return end
        shadow:ClearAllPoints()
        shadow:SetPoint("CENTER", f, "CENTER", 0, 0)
        shadow:SetSize(f:GetWidth(), f:GetHeight())
        shadow:Show()
        shadow:StartSizing("BOTTOMRIGHT")
        SetCursor("Interface\\CURSOR\\UI-Cursor-Size")
    end)

    resizeBtn:SetScript("OnMouseUp", function()
        shadow:StopMovingOrSizing()
        ResetCursor()
        local newW = math.max(shadow:GetWidth(),  MIN_W)
        local newH = math.max(shadow:GetHeight(), MIN_H)
        shadow:Hide()
        f:SetSize(newW, newH)
        -- Save
        if SK.db then SK.db.frameW = math.floor(newW); SK.db.frameH = math.floor(newH) end
        -- Update left panel and grid child width for new frame size
        local newLeftW = math.floor((newW - INSET*2) * 0.46) - 6  -- 6 = PAD_X (defined later)
        if R.leftPanel then R.leftPanel:SetWidth(newLeftW) end
        if R.gridChild then R.gridChild:SetWidth(math.max(newLeftW - 50, 100)) end
        -- Rebuild active tab
        C_Timer.After(0.05, function()
            if not R.built then return end
            local tab = R.activeTab or "register"
            if tab == "register" then
                R:BuildProductGrid()
            else
                if R.SwitchToTab then R.SwitchToTab(tab) end
            end
        end)
    end)

    resizeBtn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("Drag to resize", 1, 1, 1)
        GameTooltip:Show()
    end)
    resizeBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- Restore saved size
    if SK.db and SK.db.frameW and SK.db.frameH then
        f:SetSize(math.max(SK.db.frameW, MIN_W), math.max(SK.db.frameH, MIN_H))
    end

    -- Escape key
    f:EnableKeyboard(true); f:SetPropagateKeyboardInput(false)
    f:SetScript("OnKeyDown",function(self,key)
        if key=="ESCAPE" then R:Toggle()
        else self:SetPropagateKeyboardInput(true) end
    end)
    f:SetScript("OnKeyUp",function(self) self:SetPropagateKeyboardInput(false) end)
    f:SetScript("OnHide",function() StopFrameMove(); R.isOpen=false end)

    -- ── Title bar ─────────────────────────────────────────────────────────────
    local titleBar=CreateFrame("Frame",nil,f,"BackdropTemplate"); titleBar:SetHeight(TITLE_H)
    titleBar:SetPoint("TOPLEFT", INSET,-INSET); titleBar:SetPoint("TOPRIGHT",-INSET,-INSET)
    titleBar:SetBackdrop({
        bgFile="Interface\\DialogFrame\\UI-DialogBox-Background-Dark",tile=true,tileSize=256,
        edgeFile="Interface\\DialogFrame\\UI-DialogBox-Gold-Border",edgeSize=16,
        insets={left=4,right=4,top=4,bottom=4},
    })
    titleBar:SetBackdropColor(0.04,0.05,0.08,1)
    titleBar:SetBackdropBorderColor(1,1,1,1)
    titleBar:EnableMouse(true)
    titleBar:SetScript("OnMouseDown",function(_, btn) if btn == "LeftButton" then StartFrameMove() end end)
    titleBar:SetScript("OnMouseUp",  function(_, btn) if btn == "LeftButton" then StopFrameMove() end end)

    -- Title: "STOREKEEPER" centred, shop name on left
    local titleLbl=titleBar:CreateFontString(nil,"OVERLAY","GameFontNormal")
    titleLbl:SetFont("Fonts\\FRIZQT__.TTF",12,"OUTLINE")
    titleLbl:SetPoint("CENTER",0,0)
    titleLbl:SetText("|cffFFD700— STOREKEEPER —|r")

    R.shopLabel=FS(titleBar,"",9,0.75,0.62,0.35)
    R.shopLabel:SetPoint("LEFT",10,0)

    -- Close button
    local closeBtn=CreateFrame("Button",nil,titleBar,"UIPanelCloseButton")
    closeBtn:SetSize(26,26); closeBtn:SetPoint("RIGHT",-2,0)
    closeBtn:SetScript("OnClick",function() R:Toggle() end)

    -- What's New button — lives in the title bar, left of close
    local wnBtn = CreateFrame("Button", nil, titleBar, "BackdropTemplate")
    wnBtn:SetSize(26, 22)
    wnBtn:SetPoint("RIGHT", closeBtn, "LEFT", -2, 0)
    wnBtn:SetBackdrop({
        bgFile  = "Interface\\Buttons\\WHITE8X8", tile=true, tileSize=8,
        edgeFile= "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=10,
        insets  = {left=2,right=2,top=2,bottom=2},
    })
    wnBtn:SetBackdropColor(0.06, 0.06, 0.10, 0.90)
    wnBtn:SetBackdropBorderColor(0.45, 0.35, 0.12, 0.85)
    local wnIc = wnBtn:CreateTexture(nil, "ARTWORK")
    wnIc:SetSize(16, 16); wnIc:SetPoint("CENTER", 0, 0)
    wnIc:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
    wnIc:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    wnIc:SetVertexColor(0.75, 0.68, 0.55, 1)

    -- Highlight if this is a new version
    local wnSeen = SK.db and SK.db.seenVersion
    local wnIsNew = (wnSeen ~= SK.VERSION)
    if wnIsNew then
        wnBtn:SetBackdropColor(0.12, 0.09, 0.02, 0.95)
        wnBtn:SetBackdropBorderColor(1, 0.72, 0, 0.9)
        wnIc:SetVertexColor(1, 0.85, 0.2, 1)
    end

    wnBtn:SetScript("OnEnter", function(self)
        wnBtn:SetBackdropColor(0.10, 0.10, 0.16, 0.95)
        wnBtn:SetBackdropBorderColor(0.75, 0.58, 0.2, 1)
        wnIc:SetVertexColor(1, 0.82, 0.2, 1)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOMLEFT")
        GameTooltip:AddLine("What's New / Report Bug", 1, 1, 1)
        if wnIsNew then
            GameTooltip:AddLine("|cffFFD700New in v"..SK.VERSION.."|r", 1, 0.82, 0)
        end
        GameTooltip:Show()
    end)
    wnBtn:SetScript("OnLeave", function()
        wnBtn:SetBackdropColor(0.06, 0.06, 0.10, 0.90)
        wnBtn:SetBackdropBorderColor(0.45, 0.35, 0.12, 0.85)
        wnIc:SetVertexColor(0.75, 0.68, 0.55, 1)
        GameTooltip:Hide()
    end)
    wnBtn:SetScript("OnClick", function()
        if SK.db then SK.db.seenVersion = SK.VERSION end
        wnIsNew = false
        wnBtn:SetBackdropColor(0.06, 0.06, 0.10, 0.90)
        wnBtn:SetBackdropBorderColor(0.45, 0.35, 0.12, 0.85)
        wnIc:SetVertexColor(0.75, 0.68, 0.55, 1)
        if R.SwitchToTab then R.SwitchToTab("whatsnew") end
    end)

    -- Auto-open What's New on first login after a version update.
    if wnIsNew and not R._autoOpenedWhatsNew then
        R._autoOpenedWhatsNew = true
        C_Timer.After(1.5, function()
            if SK.db then SK.db.seenVersion = SK.VERSION end
            wnIsNew = false
            wnBtn:SetBackdropColor(0.06, 0.06, 0.10, 0.90)
            wnBtn:SetBackdropBorderColor(0.45, 0.35, 0.12, 0.85)
            wnIc:SetVertexColor(0.75, 0.68, 0.55, 1)
            if not R.mainFrame:IsShown() then
                R.mainFrame:Show(); R.isOpen = true
            end
            if R.SwitchToTab then R.SwitchToTab("whatsnew") end
            print("|cffFFD700[Storekeeper]|r Updated to v"..SK.VERSION..". Check the |cffFFD700What\'s New|r tab for changes!")
        end)
    end

    -- ── Content panel — full width, tabs float outside frame ────────────────────
    -- Content fills the full (narrower) frame — buttons are outside to the right
    local content = CreateFrame("Frame",nil,f)
    content:SetPoint("TOPLEFT",    INSET, -(INSET+TITLE_H+2))
    content:SetPoint("BOTTOMRIGHT",-INSET, INSET)
    R.contentPanel = content



    -- ── Tab definitions ───────────────────────────────────────────────────────
    -- Register tab + Manager tabs all in one sidebar
    local ALL_TABS = {
        {key="register",  icon="Interface\\Icons\\INV_Misc_Bag_07",            label="Register"},
        {key="products",  icon="Interface\\Icons\\INV_Misc_Coin_01",           label="Products"},
        {key="shops",     icon="Interface\\Icons\\INV_Box_01",                 label="Shop(s) Overview"},
        {key="people",    icon="Interface\\Icons\\INV_Misc_GroupNeedMore",     label="Management"},
        {key="orders",    icon="Interface\\Icons\\INV_Scroll_07",              label="Orders"},
        {key="tabs",      icon="Interface\\Icons\\INV_Misc_Note_01",           label="Tabs"},
        {key="logs",      icon="Interface\\Icons\\INV_Misc_Book_01",           label="Activity Log"},
        {key="settings",  icon="Interface\\Icons\\INV_Misc_Gear_01",           label="Personal Settings"},
    }

    R.activeTab = R.activeTab or "register"
    R.sidebarBtns = {}

    local TAB_H    = 44
    local TAB_PAD  = 6
    local ICON_SZ  = 28

    -- Hard-nuke everything in content panel except registerContent
    -- Graveyard: hidden off-screen frame so buried widgets never render
    local _grave = CreateFrame("Frame",nil,UIParent)
    _grave:Hide(); _grave:SetSize(1,1); _grave:SetPoint("CENTER",UIParent,"CENTER",10000,10000)
    local function Bury(w)
        if not w then return end
        if w.ClearAllPoints then w:ClearAllPoints() end
        if w.Hide           then w:Hide() end
        if w.SetParent      then w:SetParent(_grave); w:Hide() end
    end

    local function NukeContent()
        local skip = R.registerContent
        for _, child in ipairs({content:GetChildren()}) do
            if child and child ~= skip then Bury(child) end
        end
        R._contentChildren = {}
        if SK.Manager then
            SK.Manager.contentPanel    = nil
            SK.Manager.contentChildren = {}
        end
    end

    local function SwitchToTab(key)
        R.activeTab = key
        for _, tb in ipairs(R.sidebarBtns) do
            if tb.Refresh then tb.Refresh() end
        end

        NukeContent()

        local isReg = (key == "register")
        if R.registerContent then R.registerContent:SetShown(isReg) end

        if key == "register" then
            R:RefreshCart()
            R:BuildProductGrid()
            R:UpdateTabModeBanner()
        else
            local mgr = SK.Manager
            if not mgr then return end
            R._contentChildren        = {}
            mgr.contentPanel          = content
            mgr.contentChildren       = R._contentChildren
            if     key=="products" then mgr:BuildProductTab()
            elseif key=="staff"    then mgr:BuildPeopleTab()
            elseif key=="orders"   then
                mgr:BuildOrdersTab()
                local sn = SK.db and SK.db.activeShop
                if sn and SK.Net and not SK.Net.suppressAutoSync
                   and not SK.DB:IsMyManager(sn) then
                    SK.Net:RequestOrderSync(sn)
                end
            elseif key=="tabs"     then
                mgr:BuildTabsTab()
                local sn = SK.db and SK.db.activeShop
                if sn and SK.Net and not SK.Net.suppressAutoSync
                   and not SK.DB:IsMyManager(sn) then
                    if SK.Net.RequestTabSync then SK.Net:RequestTabSync(sn) end
                end
            elseif key=="logs"     then
                mgr:BuildLogsTab()
                local sn = SK.db and SK.db.activeShop
                if sn and SK.Net and not SK.Net.suppressAutoSync
                   and not SK.DB:IsMyManager(sn) then
                    SK.Net:RequestLogSync(sn)
                end
            elseif key=="shops"    then mgr:BuildShopsTab()
            elseif key=="people"   then mgr:BuildPeopleTab()
            elseif key=="settings" then mgr:BuildSettingsTab()
            elseif key=="whatsnew" then mgr:BuildWhatsNewTab()
            end
            mgr.contentPanel    = nil
            mgr.contentChildren = {}
        end
    end
    R.SwitchToTab = SwitchToTab

    -- Build tab buttons — parented to UIParent, anchored to frame's right edge
    -- Frame is narrower so buttons sit cleanly outside with no background bleed

    for i, tab in ipairs(ALL_TABS) do
        -- Parent to f so buttons move with frame and are hidden with it
        local btn = CreateFrame("Button",nil,f,"BackdropTemplate")
        btn:SetSize(BTN_SZ, BTN_SZ)
        -- Anchored just outside the RIGHT border of the frame
        btn:SetPoint("TOPRIGHT", f, "TOPRIGHT",
            BTN_SZ + INSET,   -- positive = to the right of frame TOPRIGHT
            -(INSET + TITLE_H + 2 + (i-1)*(BTN_SZ+BTN_GAP)))
        btn:SetFrameStrata("DIALOG")
        btn:SetBackdrop({
            bgFile  ="Interface\\Buttons\\WHITE8X8", tile=true, tileSize=8,
            edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=10,
            insets  ={left=2,right=2,top=2,bottom=2},
        })
        btn:SetBackdropColor(0.06,0.06,0.10,0.90)
        btn:SetBackdropBorderColor(0.45,0.35,0.12,0.85)

        local ic = btn:CreateTexture(nil,"ARTWORK")
        ic:SetSize(20,20); ic:SetPoint("CENTER",0,0)
        ic:SetTexture(tab.icon); ic:SetTexCoord(0.08,0.92,0.08,0.92)
        ic:SetVertexColor(0.60,0.60,0.60,1)
        btn.icon = ic

        local function Refresh()
            local on = (R.activeTab == tab.key)
            if on then
                btn:SetBackdropColor(0.08,0.18,0.08,0.95)
                btn:SetBackdropBorderColor(0.2,0.70,0.2,1)
                ic:SetVertexColor(1,1,1,1); ic:SetSize(22,22)
            else
                btn:SetBackdropColor(0.06,0.06,0.10,0.90)
                btn:SetBackdropBorderColor(0.45,0.35,0.12,0.85)
                ic:SetVertexColor(0.60,0.60,0.60,1); ic:SetSize(20,20)
            end
        end
        btn.Refresh = Refresh
        Refresh()

        btn:SetScript("OnEnter",function(s)
            if R.activeTab ~= tab.key then
                btn:SetBackdropColor(0.10,0.10,0.16,0.95)
                btn:SetBackdropBorderColor(0.75,0.58,0.2,1)
                ic:SetVertexColor(1,0.82,0.2,1); ic:SetSize(21,21)
            end
            GameTooltip:SetOwner(s,"ANCHOR_LEFT")
            GameTooltip:AddLine(tab.label,1,1,1)
            GameTooltip:Show()
        end)
        btn:SetScript("OnLeave",function()
            Refresh(); GameTooltip:Hide()
        end)
        btn:SetScript("OnClick",function() SwitchToTab(tab.key) end)

        btn.key = tab.key
        btn.highlight = btn
        tinsert(R.sidebarBtns, btn)
    end

    -- ── Register content (products + cart + bottom bar) ────────────────────────
    -- This is a sub-frame inside content that gets shown/hidden
    local regContent = CreateFrame("Frame",nil,content)
    regContent:SetAllPoints()
    R.registerContent = regContent

    local PAD_X     = 6
    local contentY  = -4
    local contentBot= BOT_H + 6

    -- Left panel — product list (46% of usable width)
    local leftPanel=CreateFrame("Frame",nil,regContent,"BackdropTemplate")
    R.leftPanel = leftPanel
    leftPanel:SetPoint("TOPLEFT",    PAD_X, contentY)
    leftPanel:SetPoint("BOTTOMLEFT", PAD_X, contentBot)
    leftPanel:SetWidth(math.floor((W - INSET*2) * 0.46) - PAD_X)
    leftPanel:SetBackdrop({
        bgFile="Interface\\Buttons\\WHITE8X8",tile=true,tileSize=8,
        edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",edgeSize=10,
        insets={left=3,right=3,top=3,bottom=3},
    })
    leftPanel:SetBackdropColor(0,0,0,0.35)
    leftPanel:SetBackdropBorderColor(0.55,0.42,0.12,0.7)

    local gridHeader=FS(regContent,"|cffFFD700PRODUCTS|r",10,1,0.82,0)
    gridHeader:SetPoint("TOPLEFT",PAD_X+4,contentY-3)

    -- Search box for the register product grid (filters this tab only)
    local gridSearch=CreateFrame("EditBox",nil,regContent,"InputBoxTemplate")
    gridSearch:SetAutoFocus(false); gridSearch:SetHeight(18)
    gridSearch:SetPoint("TOPLEFT",  leftPanel,"TOPLEFT",  12, -18)
    gridSearch:SetPoint("TOPRIGHT", leftPanel,"TOPRIGHT", -10, -18)
    gridSearch:SetFontObject("GameFontHighlightSmall")
    R.gridSearch = gridSearch
    gridSearch:SetText(R.productSearch or "")
    local gridSearchPH=gridSearch:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    gridSearchPH:SetPoint("LEFT",4,0); gridSearchPH:SetText("Search products...")
    gridSearchPH:SetShown((R.productSearch or "")=="")
    gridSearch:SetScript("OnTextChanged",function(s)
        R.productSearch = strtrim(s:GetText() or "")
        gridSearchPH:SetShown(R.productSearch=="")
        R:BuildProductGrid()
    end)
    gridSearch:SetScript("OnEscapePressed",function(s) s:SetText(""); s:ClearFocus() end)

    -- Grid scroll frame — anchored inside leftPanel (below the search box)
    local gridSF=CreateFrame("ScrollFrame",nil,regContent,"UIPanelScrollFrameTemplate")
    gridSF:SetPoint("TOPLEFT",   leftPanel,"TOPLEFT",    6,-42)
    gridSF:SetPoint("BOTTOMRIGHT",leftPanel,"BOTTOMRIGHT",-27, 6)

    R.gridChild=CreateFrame("Frame",nil,gridSF)
    -- Set width immediately from leftPanel's known initial width
    local initLeftW = math.floor((W - INSET*2) * 0.46) - PAD_X
    R.gridChild:SetWidth(math.max(initLeftW - 50, 100))
    R.gridChild:SetHeight(1)
    gridSF:SetScrollChild(R.gridChild)

    -- Divider — anchored relative to leftPanel right edge
    local div=regContent:CreateTexture(nil,"ARTWORK"); div:SetWidth(1)
    div:SetPoint("TOPLEFT",    leftPanel,"TOPRIGHT",    4, 0)
    div:SetPoint("BOTTOMLEFT", leftPanel,"BOTTOMRIGHT", 4, 0)
    div:SetColorTexture(0.55,0.42,0.12,0.6)

    -- Right panel — cart area, fills remaining space
    local orderPanel=CreateFrame("Frame",nil,regContent,"BackdropTemplate")
    orderPanel:SetPoint("TOPLEFT",    leftPanel,"TOPRIGHT",    10,  0)
    orderPanel:SetPoint("BOTTOMRIGHT",regContent,"BOTTOMRIGHT",-PAD_X, contentBot)
    orderPanel:SetBackdrop({
        bgFile="Interface\\Buttons\\WHITE8X8",tile=true,tileSize=8,
        edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",edgeSize=10,
        insets={left=3,right=3,top=3,bottom=3},
    })
    orderPanel:SetBackdropColor(0,0,0,0.20)
    orderPanel:SetBackdropBorderColor(0.55,0.42,0.12,0.7)

    local orderHeader=FS(regContent,"|cffFFD700ORDER|r",10,1,0.82,0)
    orderHeader:SetPoint("TOPLEFT",leftPanel,"TOPRIGHT",14,contentY-3)

    R.sellerLabel=FS(regContent,"Seller: "..SK:GetRPName(),9,0.6,0.6,0.6)
    R.sellerLabel:SetPoint("TOPRIGHT",-PAD_X-4,contentY-3)

    -- Cart SF anchored inside orderPanel
    local cartSF=CreateFrame("ScrollFrame",nil,regContent,"UIPanelScrollFrameTemplate")
    cartSF:SetPoint("TOPLEFT",    orderPanel,"TOPLEFT",    6,-20)
    cartSF:SetPoint("BOTTOMRIGHT",orderPanel,"BOTTOMRIGHT",-27, 6)

    R.cartChild=CreateFrame("Frame",nil,cartSF)
    R.cartChild:SetHeight(1)
    R.cartSF = cartSF  -- store so RefreshCart can read width reliably
    cartSF:SetScrollChild(R.cartChild)
    -- Set initial width after one layout frame
    C_Timer.After(0, function()
        if cartSF and R.cartChild then
            R.cartChild:SetWidth(math.max(cartSF:GetWidth(), 100))
        end
    end)
    -- Keep the scroll child (and thus every fluid cart row) matched to the
    -- scroll frame width, so the price / qty box / +/- buttons stay in view
    -- when the panel is resized smaller or larger.
    cartSF:SetScript("OnSizeChanged", function(self, w)
        if not R.cartChild then return end
        R.cartChild:SetWidth(math.max((w and w > 0) and w or self:GetWidth(), 100))
        if R.built and R.RefreshCart then R:RefreshCart() end
    end)

    -- ── Bottom bar ────────────────────────────────────────────────────────────
    local bot=CreateFrame("Frame",nil,regContent,"BackdropTemplate"); bot:SetHeight(BOT_H)
    bot:SetPoint("BOTTOMLEFT", 0, 0)
    bot:SetPoint("BOTTOMRIGHT",0, 0)
    bot:SetBackdrop({
        bgFile="Interface\\DialogFrame\\UI-DialogBox-Background-Dark",tile=true,tileSize=256,
        edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",edgeSize=10,
        insets={left=2,right=2,top=2,bottom=2},
    })
    bot:SetBackdropColor(0.03,0.05,0.10,0.98)
    bot:SetBackdropBorderColor(0.55,0.42,0.12,0.8)

    -- Total box — fixed size, left of bottom bar
    local TOTAL_W = 160
    local TOTAL_H = BOT_H - 28
    local totalBox=CreateFrame("Frame",nil,bot,"BackdropTemplate")
    totalBox:SetSize(TOTAL_W, TOTAL_H)
    totalBox:SetPoint("TOPLEFT",6,-6)
    totalBox:SetBackdrop({
        bgFile="Interface\\Buttons\\WHITE8X8",tile=true,tileSize=8,
        edgeFile="Interface\\DialogFrame\\UI-DialogBox-Gold-Border",edgeSize=16,
        insets={left=5,right=5,top=5,bottom=5},
    })
    totalBox:SetBackdropColor(0.03,0.03,0.03,0.98)
    totalBox:SetBackdropBorderColor(0.75,0.58,0.22,1)

    local totalLbl2=totalBox:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    totalLbl2:SetFont("Fonts\\FRIZQT__.TTF",9,"OUTLINE")
    totalLbl2:SetPoint("TOP",0,-7); totalLbl2:SetText("TOTAL")
    totalLbl2:SetTextColor(0.8,0.65,0.25,1)

    R.totalLabel=totalBox:CreateFontString(nil,"OVERLAY","GameFontNormal")
    R.totalLabel:SetFont("Fonts\\FRIZQT__.TTF",20,"OUTLINE")
    R.totalLabel:SetPoint("TOP",0,-20); R.totalLabel:SetText("0|cff888888c|r")
    R.totalLabel:SetTextColor(1,0.88,0.35,1)

    R.activeDiscount = nil
    local discFrame=CreateFrame("Button",nil,bot,"BackdropTemplate")
    discFrame:SetSize(TOTAL_W-4,18)
    discFrame:SetPoint("BOTTOMLEFT",8,6)
    discFrame:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    discFrame:SetBackdropColor(0.06,0.06,0.10,0.9); discFrame:SetBackdropBorderColor(0.5,0.38,0.10,0.8)
    local discLbl=discFrame:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    discLbl:SetAllPoints(); discLbl:SetFont("Fonts\\FRIZQT__.TTF",9,"OUTLINE")
    discLbl:SetText("|cff888888No Discount|r"); discLbl:SetJustifyH("CENTER")

    local function RefreshDiscountBtn()
        local d=R.activeDiscount
        if d then discLbl:SetText("|cffFFD700"..d.label.." ("..d.pct.."%)|r")
        else      discLbl:SetText("|cff888888No Discount|r") end
        R:RefreshCart()
    end
    R.RefreshDiscountBtn = RefreshDiscountBtn

    discFrame:SetScript("OnClick",function()
        local sn=SK.db and SK.db.activeShop
        if sn then
            local shop0=SK.DB:GetShop(sn); if shop0 then SK.DB:MigrateShop(shop0) end
            local myR=SK.DB:GetMyRole(sn)
            local canUseDisc=(myR=="owner") or (myR=="manager") or
                             SK.DB:CanDiscount(shopName)
            if not canUseDisc then print("|cffFFD700[SK]|r You do not have permission to apply discounts."); return end
        end
        local discounts=sn and SK.DB:GetDiscounts(sn) or {}
        if #discounts==0 then print("|cffFFD700[SK]|r No discounts configured."); return end
        local cur=R.activeDiscount; local nextD=nil
        if not cur then nextD=discounts[1]
        else for i,d in ipairs(discounts) do
            if d.label==cur.label and d.pct==cur.pct then nextD=discounts[i+1]; break end
        end end
        R.activeDiscount=nextD; RefreshDiscountBtn()
    end)
    discFrame:SetScript("OnEnter",function(s)
        GameTooltip:SetOwner(s,"ANCHOR_TOP"); GameTooltip:AddLine("Discount",1,1,1)
        GameTooltip:AddLine("Click to cycle through available discounts.",0.7,0.7,0.7); GameTooltip:Show()
    end)
    discFrame:SetScript("OnLeave",function() GameTooltip:Hide() end)

    -- Bottom buttons — anchored to RIGHT of bot so they fill the remaining space
    -- and resize with the frame. Two buttons split evenly between total+gap and right edge.
    local btnGap = 6
    local btnH   = BOT_H - 20

    -- Use a hidden midpoint frame so both buttons are guaranteed equal width.
    -- printBtn fills left half, clearBtn fills right half — both anchored to bot edges.
    local btnLeft = TOTAL_W + 14
    local btnMid = CreateFrame("Frame", nil, bot)
    btnMid:SetPoint("LEFT",  bot, "LEFT",  btnLeft, 0)
    btnMid:SetPoint("RIGHT", bot, "RIGHT", -(8 + btnGap/2), 0)
    btnMid:SetHeight(1)

    local printBtn=CreateFrame("Button",nil,bot,"BackdropTemplate")
    printBtn:SetHeight(btnH)
    printBtn:SetPoint("LEFT",  bot,    "LEFT",  btnLeft, 0)
    printBtn:SetPoint("RIGHT", btnMid, "CENTER", -btnGap/2, 0)
    printBtn:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",tile=true,tileSize=8,
        edgeFile="Interface\\DialogFrame\\UI-DialogBox-Gold-Border",edgeSize=12,
        insets={left=3,right=3,top=3,bottom=3}})
    printBtn:SetBackdropColor(0.06,0.38,0.32,0.92)
    printBtn:SetBackdropBorderColor(0.15,0.85,0.68,1)
    local printLbl=printBtn:CreateFontString(nil,"OVERLAY","GameFontNormal")
    printLbl:SetFont("Fonts\\FRIZQT__.TTF",11,"OUTLINE"); printLbl:SetAllPoints()
    printLbl:SetText("Finish Transaction"); printLbl:SetTextColor(1,1,1,1)
    printLbl:SetShadowColor(0,0,0,0.8); printLbl:SetShadowOffset(1,-1)
    printBtn:SetScript("OnEnter",function() printBtn:SetBackdropColor(0.09,0.55,0.46,1) end)
    printBtn:SetScript("OnLeave",function() printBtn:SetBackdropColor(0.06,0.38,0.32,0.92) end)
    printBtn:SetScript("OnClick",function() R:OpenOrderPopup() end)

    local clearBtn=CreateFrame("Button",nil,bot,"BackdropTemplate")
    clearBtn:SetHeight(btnH)
    clearBtn:SetPoint("LEFT",  btnMid, "CENTER", btnGap/2, 0)
    clearBtn:SetPoint("RIGHT", bot,    "RIGHT",  -8,       0)
    clearBtn:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",tile=true,tileSize=8,
        edgeFile="Interface\\DialogFrame\\UI-DialogBox-Gold-Border",edgeSize=12,
        insets={left=3,right=3,top=3,bottom=3}})
    clearBtn:SetBackdropColor(0.30,0.20,0.04,0.92)
    clearBtn:SetBackdropBorderColor(0.85,0.65,0.15,1)
    local clearLbl=clearBtn:CreateFontString(nil,"OVERLAY","GameFontNormal")
    clearLbl:SetFont("Fonts\\FRIZQT__.TTF",11,"OUTLINE"); clearLbl:SetAllPoints()
    clearLbl:SetText("Clear Order"); clearLbl:SetTextColor(1,1,1,1)
    clearLbl:SetShadowColor(0,0,0,0.8); clearLbl:SetShadowOffset(1,-1)
    clearBtn:SetScript("OnEnter",function() clearBtn:SetBackdropColor(0.45,0.30,0.06,1) end)
    clearBtn:SetScript("OnLeave",function() clearBtn:SetBackdropColor(0.30,0.20,0.04,0.92) end)
    clearBtn:SetScript("OnClick",function() R:ClearCart() end)

    -- Layout updates handled by TRP3-style shadow frame resize (see resizeBtn above)

    -- ── Initial state ─────────────────────────────────────────────────────────
    R:BuildProductGrid()
    R:RefreshCart()
    R:RefreshShopLabel()
    if R.sellerLabel then R.sellerLabel:SetText("Seller: "..SK:GetRPName()) end
    SwitchToTab(R.activeTab or "register")

    R.built = true  -- allow OnSizeChanged to fire after this point
end

function R:RefreshShopLabel()
    if R.shopLabel then R.shopLabel:SetText("Shop: "..(SK.db and SK.db.activeShop or "none")) end
end

function R:ApplyTheme()
    local wasOpen = R.isOpen
    if R.mainFrame then
        R.mainFrame:Hide(); R.mainFrame=nil
        R.cartChild=nil; R.gridChild=nil; R.leftPanel=nil
        R.productBtns=nil; R.cartRows=nil
        R.themedFrames=nil; R.isOpen=false
        R.registerContent=nil; R.contentPanel=nil
        R.sidebarBtns=nil; R._contentChildren=nil
    end
    if wasOpen then R:Build() end
end

function R:Toggle()
    if not R.mainFrame then R:Build() end
    if R.isOpen then
        R.mainFrame:Hide(); R.isOpen=false
    else
        R:RefreshShopLabel()
        local icName=SK:GetSavedSellerIC()
        if R.sellerLabel then R.sellerLabel:SetText("Seller: "..(icName~="" and icName or SK:GetRPName())) end
        R.mainFrame:Show(); R.isOpen=true
        -- First open after a version update may trigger a feature mini-tutorial
        if SK.Tutorial and SK.Tutorial.MaybeShowOnOpen then
            SK.Tutorial:MaybeShowOnOpen()
        end
        -- Once-per-session notice if a nearby peer is on a newer version
        if SK.Net and SK.Net.MaybeShowVersionPopup then
            C_Timer.After(0.5, function() SK.Net:MaybeShowVersionPopup() end)
        end
    end
end
