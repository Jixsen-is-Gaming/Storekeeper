-- Storekeeper: Manager UI — Guild & Communities visual style

Storekeeper.Manager = Storekeeper.Manager or {}
local SK = Storekeeper
local M  = SK.Manager

M.isOpen    = false
M.activeTab = "products"
M.editingProd = nil

local PAD = 8

-- ─── Helpers ──────────────────────────────────────────────────────────────────

local function FS(parent, text, size, r, g, b)
    -- Wrap in a Frame so it can be reparented/hidden on tab switch
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(300, size and (size+4) or 15)
    local fs = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    fs:SetFont("Fonts\\FRIZQT__.TTF", size or 11, "")
    fs:SetText(text or "")
    fs:SetTextColor(r or 1, g or 1, b or 1, 1)
    fs:SetPoint("LEFT", 0, 0)
    -- Proxy key methods so callers can use the wrapper like a FontString
    f.SetText  = function(_, t) fs:SetText(t) end
    f.GetText  = function(_) return fs:GetText() end
    f.SetTextColor = function(_, r2,g2,b2,a2) fs:SetTextColor(r2,g2,b2,a2 or 1) end
    f.SetPoint_FS  = f.SetPoint  -- keep original for layout
    return f
end

local function HLine(parent, y)
    -- Wrap in a Frame so it can be reparented
    local f = CreateFrame("Frame", nil, parent)
    f:SetHeight(1)
    f:SetPoint("TOPLEFT", PAD, y); f:SetPoint("TOPRIGHT", -PAD, y)
    local t = f:CreateTexture(nil, "ARTWORK"); t:SetAllPoints()
    t:SetColorTexture(0.35, 0.30, 0.20, 0.6)
    return f
end

local function Btn(parent, text, w, h)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(w or 80, h or 22); b:SetText(text or ""); return b
end

local function Box(parent, w, h)
    local e = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
    e:SetSize(w or 150, h or 20); e:SetAutoFocus(false)
    e:SetScript("OnEscapePressed", function(s) s:ClearFocus() end); return e
end

-- ─── Content Wipe ─────────────────────────────────────────────────────────────

local function GetContentPanel()
    return M.contentPanel
end

-- Graveyard: hidden frame to park orphaned widgets so they don't render
local _graveyard = CreateFrame("Frame", "StorekeeperGraveyard", UIParent)
_graveyard:Hide(); _graveyard:SetSize(1,1); _graveyard:SetPoint("CENTER",UIParent,"CENTER",10000,10000)

local function Bury(w)
    if not w then return end
    if w.ClearAllPoints then w:ClearAllPoints() end
    if w.Hide           then w:Hide() end
    if w.SetParent      then w:SetParent(_graveyard); w:Hide() end
end

local function WipeContent()
    local p = M.contentPanel
    if not p then return end
    for _, w in ipairs(M.contentChildren or {}) do Bury(w) end
    M.contentChildren = {}
    local skip = SK.Register and SK.Register.registerContent
    for _, child in ipairs({p:GetChildren()}) do
        if child and child ~= skip then Bury(child) end
    end
end

local function Track(w)
    tinsert(M.contentChildren, w)
    return w
end


-- ─── PRODUCTS TAB ─────────────────────────────────────────────────────────────

-- Arrange mode for the Products tab: drag products to reorder within a category
-- or drop onto another category header to recategorise. Uses a persistent pool
-- of row frames and rebinds drag scripts each rebuild (same robust pattern as
-- the category reorder list).
function M:RenderProductArrange(sc, p, shopName)
    local PADL = 10
    local W = p:GetWidth() - 38
    local rowH, gap, hdrH = 26, 3, 20

    -- Instruction line
    if not M._arrInfo then
        M._arrInfo = sc:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    end
    M._arrInfo:SetParent(sc); M._arrInfo:ClearAllPoints()
    M._arrInfo:SetPoint("TOPLEFT", PADL, -4)
    M._arrInfo:SetText("Drag a product to reorder it, or drop it on a category header to move it there.")
    M._arrInfo:SetTextColor(0.55,0.55,0.55,1); M._arrInfo:Show()

    M._arrRowPool = M._arrRowPool or {}
    M._arrHdrPool = M._arrHdrPool or {}

    -- Shared drag indicator
    if not M._arrInsLine then
        local il = sc:CreateTexture(nil,"OVERLAY")
        il:SetColorTexture(1,0.82,0,1); il:SetHeight(2); il:Hide()
        M._arrInsLine = il
    end
    local insLine = M._arrInsLine
    insLine:SetParent(sc); insLine:Hide()

    -- Layout bookkeeping rebuilt each pass: a flat list of "slots" describing
    -- where each rendered row lives, so the drop logic can map cursor → target.
    local layout  -- { {cat=catName, prod=p, frame=row} ... } in visual order
    local hdrRects -- { {cat=catName, top=, bottom=} ... }

    local Rebuild

    local function CommitMove(prodID, targetCat, targetPos)
        SK.DB:MoveProduct(shopName, prodID, targetCat, targetPos)
        if SK.Register and SK.Register.BuildProductGrid then SK.Register:BuildProductGrid() end
        if SK.Net then SK.Net:BroadcastProducts(shopName) end
    end

    -- Determine drop target (category + position) from the cursor's Y.
    -- Which category does the cursor fall in? Use header tops as boundaries:
    -- the cursor belongs to the last category whose header top is at/above it.
    local function CategoryAt(cy)
        local cat
        for _, hr in ipairs(hdrRects) do
            local htop = hr.frame and hr.frame:GetTop()
            if htop and cy <= htop then cat = hr.cat else break end
        end
        if not cat and #hdrRects > 0 then cat = hdrRects[1].cat end
        return cat
    end

    -- The non-dragged product rows of a given category, in visual order.
    local function CategoryRows(cat, draggedFrame)
        local rows = {}
        for _, slot in ipairs(layout) do
            if slot.cat == cat and slot.frame ~= draggedFrame then
                tinsert(rows, slot.frame)
            end
        end
        return rows
    end

    -- Returns target category + insertion position (1-based among the OTHER
    -- products in that category; nil = append to the end).
    local function CursorTarget(draggedFrame)
        local _, cy = GetCursorPosition()
        local scale = sc:GetEffectiveScale()
        if not scale or scale == 0 then return nil, nil end
        cy = cy / scale

        local cat = CategoryAt(cy)
        if not cat then return nil, nil end

        local rows = CategoryRows(cat, draggedFrame)
        for i, rf in ipairs(rows) do
            local top, bot = rf:GetTop(), rf:GetBottom()
            if top and bot and cy >= (top+bot)/2 then
                return cat, i  -- insert before this row
            end
        end
        return cat, nil  -- below all rows in this category => append
    end

    local function ShowInsertLine(draggedFrame)
        local cat, pos = CursorTarget(draggedFrame)
        if not cat then insLine:Hide(); return end
        local rows = CategoryRows(cat, draggedFrame)
        insLine:ClearAllPoints()
        insLine:SetWidth(W - 24)
        if pos and rows[pos] then
            insLine:SetPoint("BOTTOMLEFT", rows[pos], "TOPLEFT", 12, gap/2)
        elseif #rows > 0 then
            insLine:SetPoint("TOPLEFT", rows[#rows], "BOTTOMLEFT", 12, -gap/2)
        else
            -- empty category (e.g. dragging the only product) -> under its header
            local hdrFrame
            for _, hr in ipairs(hdrRects) do if hr.cat == cat then hdrFrame = hr.frame; break end end
            if hdrFrame then insLine:SetPoint("TOPLEFT", hdrFrame, "BOTTOMLEFT", 12, -1)
            else insLine:Hide(); return end
        end
        insLine:Show()
    end

    -- Pool getters
    local function GetHdr(i)
        local h = M._arrHdrPool[i]
        if h then return h end
        h = CreateFrame("Frame", nil, sc, "BackdropTemplate")
        h:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8"})
        local lbl = h:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        lbl:SetPoint("LEFT",6,0); h.__lbl = lbl
        M._arrHdrPool[i] = h
        return h
    end

    local function GetRow(i)
        local r = M._arrRowPool[i]
        if r then return r end
        r = CreateFrame("Button", nil, sc, "BackdropTemplate")
        r:RegisterForDrag("LeftButton")
        local hi = r:CreateTexture(nil,"BACKGROUND"); hi:SetAllPoints(); r.__hi = hi
        local grip = r:CreateFontString(nil,"OVERLAY","GameFontNormal")
        grip:SetPoint("LEFT",6,0); grip:SetText("="); grip:SetTextColor(0.6,0.55,0.35,1)
        local ic = r:CreateTexture(nil,"ARTWORK"); ic:SetSize(20,20); ic:SetPoint("LEFT",20,0)
        ic:SetTexCoord(0.08,0.92,0.08,0.92); r.__ic = ic
        local nm = r:CreateFontString(nil,"OVERLAY","GameFontNormal")
        nm:SetPoint("LEFT",46,0); nm:SetJustifyH("LEFT"); r.__nm = nm
        r.__resetHi = function() hi:SetColorTexture(1,1,1, (r.__zebra or 0)%2==0 and 0.05 or 0.02) end
        M._arrRowPool[i] = r
        return r
    end

    Rebuild = function()
        insLine:Hide()
        local cats, order = SK.DB:GetProductsByCategory(shopName)
        layout, hdrRects = {}, {}
        local yo = 22
        local rowN, hdrN = 0, 0

        for _, cat in ipairs(order) do
            hdrN = hdrN + 1
            local hdr = GetHdr(hdrN)
            local r,g,b = SK.DB:GetCategoryColor(shopName, cat)
            hdr:SetParent(sc); hdr:ClearAllPoints()
            hdr:SetSize(W, hdrH); hdr:SetPoint("TOPLEFT", 0, -yo)
            hdr:SetBackdropColor((r or 1)*0.25,(g or 0.82)*0.25,(b or 0)*0.25,0.85)
            hdr.__lbl:SetText(cat.."  |cff888888("..#cats[cat]..")|r")
            hdr.__lbl:SetTextColor(r or 1, g or 0.82, b or 0, 1)
            hdr:Show()
            tinsert(hdrRects, {cat=cat, frame=hdr})
            yo = yo + hdrH + 2

            for _, prod in ipairs(cats[cat]) do
                rowN = rowN + 1
                local row = GetRow(rowN)
                row:SetParent(sc); row:ClearAllPoints()
                row:SetSize(W, rowH); row:SetPoint("TOPLEFT", 0, -yo)
                row.__zebra = rowN
                row.__ic:SetTexture(type(prod.icon)=="number" and prod.icon or 134400)
                row.__nm:SetText(prod.name); row.__nm:SetTextColor(1,1,1,1)
                row.__resetHi()
                row.__prodID = prod.id
                row.__cat    = cat
                row:Show()

                row:SetScript("OnEnter", function(s) if not s._dragging then s.__hi:SetColorTexture(1,0.82,0,0.12) end end)
                row:SetScript("OnLeave", function(s) if not s._dragging then s.__resetHi() end end)
                row:SetScript("OnDragStart", function(s)
                    s._dragging = true
                    s.__hi:SetColorTexture(1,0.82,0,0.28)
                    s.__nm:SetTextColor(1,0.9,0.5,1)
                    s:SetScript("OnUpdate", function() ShowInsertLine(s) end)
                end)
                row:SetScript("OnDragStop", function(s)
                    s._dragging = false
                    s:SetScript("OnUpdate", nil)
                    insLine:Hide()
                    local targetCat, targetPos = CursorTarget(s)
                    if targetCat then
                        CommitMove(s.__prodID, targetCat, targetPos)
                    end
                    Rebuild()
                end)

                tinsert(layout, {cat=cat, prod=prod, frame=row})
                yo = yo + rowH + gap
            end
            yo = yo + 6
        end

        -- Hide unused pooled widgets
        for i = rowN+1, #M._arrRowPool do M._arrRowPool[i]:Hide() end
        for i = hdrN+1, #M._arrHdrPool do M._arrHdrPool[i]:Hide() end

        sc:SetHeight(math.max(yo + 8, 60))
    end

    Rebuild()
end

function M:BuildProductTab()
    WipeContent()
    local p   = GetContentPanel()
    local pw  = p:GetWidth() - PAD*2
    local shopName = SK.db and SK.db.activeShop

    if not shopName then
        local l = Track(FS(p, "No shop active. Open the Shops tab to create one.", 11, 0.65, 0.65, 0.65))
        l:SetPoint("CENTER"); return
    end

    local sf = Track(CreateFrame("ScrollFrame", nil, p, "UIPanelScrollFrameTemplate"))
    sf:SetPoint("TOPLEFT", PAD, -PAD-26)
    -- In arrange mode the edit form is hidden, so the list can fill the full panel.
    sf:SetPoint("BOTTOMRIGHT", -PAD-18, M._arrangeMode and PAD or 272)
    M.fProductSF = sf  -- stored so variant panel resize can re-anchor
    local sc = CreateFrame("Frame", nil, sf)
    sc:SetWidth(sf:GetWidth()-4); sc:SetHeight(1); sf:SetScrollChild(sc)

    -- Arrange toggle — only for users who can edit products
    local canArrange = SK.DB:CanManageProducts(shopName)
    if canArrange then
        local arrBtn = Track(Btn(p, M._arrangeMode and "Done Arranging" or "Arrange", 110, 22))
        arrBtn:SetPoint("TOPRIGHT", -PAD-18, -PAD)
        arrBtn:SetScript("OnClick", function()
            M._arrangeMode = not M._arrangeMode
            M:SwitchTab("products")
        end)
        arrBtn:SetScript("OnEnter", function(s)
            GameTooltip:SetOwner(s,"ANCHOR_TOP")
            GameTooltip:AddLine("Arrange products",1,1,1)
            GameTooltip:AddLine("Drag products to reorder them within a category,",0.7,0.7,0.7)
            GameTooltip:AddLine("or drop one on another category's header to move it there.",0.7,0.7,0.7)
            GameTooltip:Show()
        end)
        arrBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    elseif M._arrangeMode then
        M._arrangeMode = false  -- safety: non-editors never stay in arrange mode
    end

    if M._arrangeMode and canArrange then
        M:RenderProductArrange(sc, p, shopName)
        return
    end

    -- Search box (filters the Products tab only)
    local searchBox = Track(CreateFrame("EditBox", nil, p, "InputBoxTemplate"))
    searchBox:SetAutoFocus(false); searchBox:SetHeight(20)
    searchBox:SetPoint("TOPLEFT", PAD+4, -PAD-1)
    searchBox:SetWidth(canArrange and 180 or 220)
    searchBox:SetFontObject("GameFontHighlightSmall")
    searchBox:SetText(M._prodSearch or "")
    local searchPH = searchBox:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    searchPH:SetPoint("LEFT",4,0); searchPH:SetText("Search products...")
    searchPH:SetShown((M._prodSearch or "")=="")
    searchBox:SetScript("OnTextChanged", function(s)
        local txt = strtrim(s:GetText() or "")
        if txt == (M._prodSearch or "") then searchPH:SetShown(txt==""); return end
        M._prodSearch = txt
        searchPH:SetShown(M._prodSearch=="")
        M._prodSearchRefocus = true
        M:SwitchTab("products")
    end)
    searchBox:SetScript("OnEscapePressed", function(s) s:SetText(""); s:ClearFocus() end)
    -- Restore focus after a rebuild triggered by typing, so the user can keep typing
    if M._prodSearchRefocus then
        M._prodSearchRefocus = false
        searchBox:SetFocus()
        searchBox:SetCursorPosition(#(M._prodSearch or ""))
    end

    local products = SK.DB:GetProducts(shopName)
    local prodQuery = (M._prodSearch or ""):lower()
    if prodQuery ~= "" then
        local filtered = {}
        for _, prod in ipairs(products) do
            if (prod.name or ""):lower():find(prodQuery, 1, true) then
                tinsert(filtered, prod)
            end
        end
        products = filtered
    end
    local rh, yo = 30, 0

    -- Column layout constants — defined once, shared by header and every data row.
    -- sc width = sf_width - 4 = (content_W - PAD - (PAD+18)) - 4 = content_W - 38
    -- This must match exactly or rows overflow the scroll child and clip the buttons.
    local EDIT_W, DEL_W, GAP = 38, 34, 4
    local BTN_BLOCK = EDIT_W + DEL_W + GAP + 8
    local W       = p:GetWidth() - 38          -- exact scroll child width
    local NAME_W  = math.floor(W * 0.38)
    local CAT_X   = 28 + NAME_W + 4
    local CAT_W   = math.floor(W * 0.18)
    local PRC_X   = CAT_X + CAT_W + 4
    local PRC_W   = math.floor(W * 0.12)
    local STK_X   = PRC_X + PRC_W + 4
    local STK_W   = 36

    -- Header row
    local function ColHdr(txt, x, w, justify)
        local l = sc:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        l:SetPoint("TOPLEFT", x, -4)
        l:SetSize(w, 14)
        l:SetJustifyH(justify or "LEFT")
        l:SetText(txt)
        l:SetTextColor(1, 0.82, 0, 1)
    end
    ColHdr("Ic.",      2,       24,     "LEFT")
    ColHdr("Name",     28,      NAME_W, "LEFT")
    ColHdr("Variants", CAT_X,   CAT_W,  "CENTER")
    ColHdr("Price",    PRC_X,   PRC_W,  "CENTER")
    ColHdr("Stock",    STK_X,   STK_W,  "LEFT")
    yo = 18

    if #products == 0 then
        local nl = sc:CreateFontString(nil,"OVERLAY","GameFontDisable")
        nl:SetPoint("TOPLEFT",4,-yo-6); nl:SetText("No products yet. Add one below.")
        sc:SetHeight(yo+30)
    end

    -- Group products by category, ordered by the saved category order.
    local byCat = {}
    for _, prod in ipairs(products) do
        local cn = prod.category or "General"
        byCat[cn] = byCat[cn] or {}
        tinsert(byCat[cn], prod)
    end
    -- Determine category display order: saved order first, then any leftovers
    local order, seenCat = {}, {}
    for _, cn in ipairs(SK.DB:GetCategoryOrder(shopName)) do
        if byCat[cn] and not seenCat[cn] then seenCat[cn]=true; tinsert(order, cn) end
    end
    for _, prod in ipairs(products) do
        local cn = prod.category or "General"
        if not seenCat[cn] then seenCat[cn]=true; tinsert(order, cn) end
    end

    local rowIdx = 0
    local function RenderProductRow(prod)
        rowIdx = rowIdx + 1
        local row = CreateFrame("Frame", nil, sc, "BackdropTemplate")
        row:SetSize(W, rh); row:SetPoint("TOPLEFT", 0, -yo)
        row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8"})
        row:SetBackdropColor(0, 0, 0, rowIdx%2==0 and 0.20 or 0.05)

        local ic = row:CreateTexture(nil,"ARTWORK"); ic:SetSize(22,22); ic:SetPoint("LEFT",2,0)
        ic:SetTexture(type(prod.icon)=="number" and prod.icon or 134400)
        ic:SetTexCoord(0.08,0.92,0.08,0.92)

        local n = row:CreateFontString(nil,"OVERLAY","GameFontNormal"); n:SetFont("Fonts\\FRIZQT__.TTF",10,"")
        n:SetPoint("LEFT",28,4); n:SetSize(NAME_W,14); n:SetText(prod.name)
        local RCOL={poor={0.62,0.62,0.62},common={1,1,1},uncommon={0.12,1,0},rare={0,0.44,0.87},epic={0.64,0.21,0.93},legendary={1,0.5,0}}
        local rc2=RCOL[prod.rarity or "common"] or {1,1,1}
        n:SetTextColor(rc2[1],rc2[2],rc2[3],1)
        local d = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        d:SetPoint("LEFT",28,-7); d:SetSize(NAME_W,12)
        d:SetText(prod.description~="" and prod.description or ""); d:SetTextColor(0.5,0.5,0.5,1)

        -- Variant indicator instead of repeating the category (now shown as a header)
        if prod.variants and #prod.variants > 0 then
            local vlbl = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            vlbl:SetPoint("LEFT",CAT_X,0); vlbl:SetSize(CAT_W,rh); vlbl:SetJustifyH("CENTER")
            vlbl:SetText("|cff9999FF"..#prod.variants.." variants|r")
        end

        local pr = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        pr:SetPoint("LEFT",PRC_X,0); pr:SetSize(math.max(PRC_W,20),rh)
        pr:SetText(SK:FormatMoney(prod.priceCopper))

        if prod.stock ~= nil then
            local stk = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            stk:SetPoint("LEFT", STK_X, 0); stk:SetSize(STK_W, rh)
            local stkcol = prod.stock<=0 and "FF4444" or prod.stock<=5 and "FFCC00" or "88FF88"
            stk:SetText("|cff"..stkcol..tostring(prod.stock).."|r")
        end

        local pid = prod.id
        local canEditProd = SK.DB:CanManageProducts(shopName)
        if canEditProd then
            local eb = Btn(row,"Edit",EDIT_W,18); eb:SetPoint("RIGHT",-(DEL_W+GAP+2),0)
            local db = Btn(row,"Del",DEL_W,18);  db:SetPoint("RIGHT",-2,0)
            eb:SetScript("OnClick", function() M:OpenEditor(pid) end)
            db:SetScript("OnClick", function()
                SK.DB:DeleteProduct(shopName,pid); M:SwitchTab("products")
                if SK.Register and SK.Register.BuildProductGrid then SK.Register:BuildProductGrid() end
                if SK.Net then SK.Net:BroadcastProducts(shopName) end
            end)
        end
        yo = yo + rh + 2
    end

    M._prodCatCollapsed = M._prodCatCollapsed or {}
    for _, cn in ipairs(order) do
        -- Category header bar (clickable to fold/unfold)
        local r,g,b = SK.DB:GetCategoryColor(shopName, cn)
        local collapsed = M._prodCatCollapsed[cn] and (prodQuery == "")
        local hdr = CreateFrame("Button", nil, sc, "BackdropTemplate")
        hdr:SetSize(W, 18); hdr:SetPoint("TOPLEFT", 0, -yo)
        hdr:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8"})
        hdr:SetBackdropColor((r or 1)*0.25,(g or 0.82)*0.25,(b or 0)*0.25,0.85)
        -- Fold arrow
        local arrow = hdr:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        arrow:SetPoint("LEFT",6,0); arrow:SetText(collapsed and "+" or "-")
        arrow:SetTextColor(r or 1, g or 0.82, b or 0, 1)
        local hl = hdr:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        hl:SetPoint("LEFT",18,0)
        hl:SetText(cn.."  |cff888888("..#byCat[cn]..")|r")
        hl:SetTextColor(r or 1, g or 0.82, b or 0, 1)
        local cnName = cn
        hdr:SetScript("OnClick", function()
            M._prodCatCollapsed[cnName] = not M._prodCatCollapsed[cnName]
            M:SwitchTab("products")
        end)
        hdr:SetScript("OnEnter", function(s) s:SetBackdropColor((r or 1)*0.4,(g or 0.82)*0.4,(b or 0)*0.4,0.9) end)
        hdr:SetScript("OnLeave", function(s) s:SetBackdropColor((r or 1)*0.25,(g or 0.82)*0.25,(b or 0)*0.25,0.85) end)
        yo = yo + 20

        if not collapsed then
            for _, prod in ipairs(byCat[cn]) do RenderProductRow(prod) end
        end
        yo = yo + 4  -- gap between categories
    end
    sc:SetHeight(math.max(yo+4, 30))

    -- Form — only shown if user can edit products
    local canShowForm = SK.DB:CanManageProducts(shopName)
    if not canShowForm then return end  -- employees see read-only list
    local form = Track(CreateFrame("Frame", nil, p, "BackdropTemplate"))
    form:SetPoint("BOTTOMLEFT",0,0); form:SetPoint("BOTTOMRIGHT",0,0); form:SetHeight(308)
    form:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    form:SetBackdropColor(0.05,0.06,0.10,1.0); form:SetBackdropBorderColor(0.45,0.35,0.12,0.9)

    FS(form,"Add / Edit Product",11,1,0.82,0):SetPoint("TOPLEFT",PAD,-8)

    -- Load Existing — WoW UIDropDownMenu
    FS(form,"Load existing:",9,0.6,0.6,0.6):SetPoint("TOPLEFT",PAD,-28)
    local loadDD = CreateFrame("Frame","SK_LoadProductDD",form,"UIDropDownMenuTemplate")
    loadDD:SetPoint("TOPLEFT",PAD-16,-40)
    UIDropDownMenu_SetWidth(loadDD, pw - 24)
    UIDropDownMenu_SetText(loadDD, "-- select to load --")

    local function RefreshLoadDD()
        UIDropDownMenu_Initialize(loadDD, function(self, level)
            local prods = SK.DB:GetProducts(SK.db and SK.db.activeShop or "")
            if #prods == 0 then
                local info = UIDropDownMenu_CreateInfo()
                info.text = "|cff666666No products yet|r"; info.notCheckable = true
                UIDropDownMenu_AddButton(info, level)
                return
            end
            for _, prod in ipairs(prods) do
                local info = UIDropDownMenu_CreateInfo()
                info.text  = prod.name
                info.value = prod.id
                info.func  = function(btn)
                    M:OpenEditor(btn.value)
                    UIDropDownMenu_SetText(loadDD, prod.name)
                end
                UIDropDownMenu_AddButton(info, level)
            end
        end)
    end
    RefreshLoadDD()
    M.loadDD = loadDD
    M.RefreshLoadDD = RefreshLoadDD
    local nameW = math.floor(pw*0.55); local catW = pw - nameW - 8
    FS(form,"Name",9,0.7,0.7,0.7):SetPoint("TOPLEFT",PAD+4,-112)
    FS(form,"Category",9,0.7,0.7,0.7):SetPoint("TOPLEFT",PAD+nameW+8,-112)
    M.fName = Box(form,nameW,20); M.fName:SetPoint("TOPLEFT",PAD+4,-126)

    -- Category: plain EditBox the user types directly into, with a dropdown arrow
    -- for selecting existing categories, plus a color swatch.
    local catBtnW = catW - 28
    -- The EditBox is the source of truth — no proxy, no M.fCatName intermediate
    local catEdit = CreateFrame("EditBox",nil,form,"InputBoxTemplate")
    catEdit:SetSize(catBtnW-20,20); catEdit:SetPoint("TOPLEFT",PAD+nameW+8,-126)
    catEdit:SetAutoFocus(false); catEdit:SetMaxLetters(64)
    catEdit:SetText("General")
    catEdit:SetScript("OnEscapePressed",function(s) s:ClearFocus() end)
    M.fCatEdit = catEdit  -- SaveProduct reads this directly

    -- Small dropdown arrow button to the right of the editbox
    local catArrowBtn = CreateFrame("Button",nil,form,"UIPanelButtonTemplate")
    catArrowBtn:SetSize(22,20); catArrowBtn:SetPoint("LEFT",catEdit,"RIGHT",2,0)
    local catArrowLbl=catArrowBtn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    catArrowLbl:SetAllPoints(); catArrowLbl:SetText("v"); catArrowLbl:SetTextColor(0.7,0.7,0.7,1)

    -- Color swatch button
    local colorSwatch=CreateFrame("Button",nil,form,"BackdropTemplate")
    colorSwatch:SetSize(22,20); colorSwatch:SetPoint("LEFT",catArrowBtn,"RIGHT",4,0)
    colorSwatch:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    colorSwatch:SetBackdropColor(1,0.82,0,1); colorSwatch:SetBackdropBorderColor(0.5,0.4,0.1,1)

    M.fCatColor = {1,0.82,0}
    M._colorSwatchFrame = colorSwatch  -- stored so OpenEditor can update it
    local function UpdateCatColor()
        local r,g,b = M.fCatColor[1],M.fCatColor[2],M.fCatColor[3]
        colorSwatch:SetBackdropColor(r,g,b,1)
    end

    -- When user finishes typing a category name, load its color
    catEdit:SetScript("OnEditFocusLost",function(s)
        local txt = strtrim(s:GetText())
        if txt=="" then s:SetText("General"); txt="General" end
        local sn = SK.db and SK.db.activeShop
        if sn then
            local r,g,b = SK.DB:GetCategoryColor(sn,txt)
            M.fCatColor={r,g,b}; UpdateCatColor()
        end
    end)

    -- Color swatch
    colorSwatch:SetScript("OnClick",function()
        local pr,pg,pb = M.fCatColor[1],M.fCatColor[2],M.fCatColor[3]
        local function ApplyColor()
            local r,g,b
            if ColorPickerFrame.GetColorRGB then
                r,g,b = ColorPickerFrame:GetColorRGB()
            elseif ColorPickerFrame.Content and ColorPickerFrame.Content.ColorPicker then
                r,g,b = ColorPickerFrame.Content.ColorPicker:GetColorRGB()
            end
            if r then
                M.fCatColor={r,g,b}; UpdateCatColor()
                local sn = SK.db and SK.db.activeShop
                local catName = strtrim(catEdit:GetText())
                if sn and catName~="" then SK.DB:SetCategoryColor(sn,catName,r,g,b) end
            end
        end
        if ColorPickerFrame.SetupColorPickerAndShow then
            ColorPickerFrame:SetupColorPickerAndShow({r=pr,g=pg,b=pb,hasOpacity=false,
                swatchFunc=ApplyColor,cancelFunc=function() M.fCatColor={pr,pg,pb}; UpdateCatColor() end})
        else
            ColorPickerFrame.func=ApplyColor; ColorPickerFrame.hasOpacity=false
            ColorPickerFrame.cancelFunc=function() M.fCatColor={pr,pg,pb}; UpdateCatColor() end
            if ColorPickerFrame.SetColorRGB then ColorPickerFrame:SetColorRGB(pr,pg,pb) end
            ColorPickerFrame:Hide(); ColorPickerFrame:Show()
        end
    end)
    colorSwatch:SetScript("OnEnter",function(s)
        GameTooltip:SetOwner(s,"ANCHOR_TOP"); GameTooltip:AddLine("Category colour",1,1,1)
        GameTooltip:AddLine("Click to change this category's colour.",0.7,0.7,0.7); GameTooltip:Show()
    end)
    colorSwatch:SetScript("OnLeave",function() GameTooltip:Hide() end)

    -- Dropdown arrow: shows existing categories to pick from
    catArrowBtn:SetScript("OnClick",function(self)
        -- Use the saved category order so the dropdown matches the register
        -- and the management reorder list.
        local cats,seen={},{}
        for _, cn in ipairs(SK.DB:GetCategoryOrder(shopName)) do
            if not seen[cn] then seen[cn]=true; tinsert(cats,cn) end
        end
        -- Include any categories from products not yet in the order list
        for _, p in ipairs(SK.DB:GetProducts(shopName)) do
            local cn=p.category or "General"
            if not seen[cn] then seen[cn]=true; tinsert(cats,cn) end
        end
        if not seen["General"] then tinsert(cats,1,"General") end
        if #cats==0 then return end

        local ROW_H    = 20
        local MAX_ROWS = 8
        local INNER_PAD= 4
        local visible  = math.min(#cats, MAX_ROWS)
        local menuH    = visible * ROW_H + 6
        local innerW   = catBtnW - INNER_PAD * 2

        local closer=CreateFrame("Frame",nil,UIParent)
        closer:SetAllPoints(); closer:EnableMouse(true); closer:SetFrameStrata("FULLSCREEN")

        local menu=CreateFrame("Frame",nil,UIParent,"BackdropTemplate")
        menu:SetFrameStrata("FULLSCREEN"); menu:SetSize(catBtnW, menuH)
        menu:SetPoint("TOPLEFT",catEdit,"BOTTOMLEFT",0,0)
        menu:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",
            edgeSize=10,insets={left=3,right=3,top=3,bottom=3}})
        menu:SetBackdropColor(0.06,0.06,0.10,0.98); menu:SetBackdropBorderColor(0.5,0.38,0.10,1)
        menu:EnableMouseWheel(true)

        -- Clip region — children outside this area are hidden
        local clip=CreateFrame("Frame",nil,menu)
        clip:SetPoint("TOPLEFT",     menu,"TOPLEFT",      INNER_PAD, -3)
        clip:SetPoint("BOTTOMRIGHT", menu,"BOTTOMRIGHT", -INNER_PAD,  3)
        clip:SetClipsChildren(true)

        -- Scrollable child taller than clip when list exceeds MAX_ROWS
        local totalH=#cats*ROW_H
        local child=CreateFrame("Frame",nil,clip)
        child:SetSize(innerW, totalH)
        child:SetPoint("TOPLEFT", clip,"TOPLEFT", 0, 0)

        local function CloseMenu()
            menu:Hide(); menu:SetParent(nil)
            closer:Hide(); closer:SetParent(nil)
        end

        for i, cn in ipairs(cats) do
            local r,g,b=SK.DB:GetCategoryColor(shopName,cn)
            local item=CreateFrame("Button",nil,child)
            item:SetSize(innerW, ROW_H); item:SetPoint("TOPLEFT",0,-(i-1)*ROW_H)
            local itxt=item:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            itxt:SetAllPoints(); itxt:SetJustifyH("LEFT")
            itxt:SetText(cn); itxt:SetTextColor(r,g,b,1)
            local cn2=cn
            item:SetScript("OnEnter",function() itxt:SetTextColor(1,0.95,0.5,1) end)
            item:SetScript("OnLeave",function() itxt:SetTextColor(r,g,b,1) end)
            item:SetScript("OnClick",function()
                catEdit:SetText(cn2)
                M.fCatColor={r,g,b}; UpdateCatColor()
                CloseMenu()
            end)
        end

        -- Scroll state
        local scrollY=0
        local function SetScroll(newY)
            local maxY=math.max(0, totalH - visible*ROW_H)
            scrollY=math.max(0, math.min(newY, maxY))
            -- Positive Y offset moves the child UP, revealing lower rows.
            child:SetPoint("TOPLEFT", clip,"TOPLEFT", 0, scrollY)
        end
        menu:SetScript("OnMouseWheel",function(_, delta)
            SetScroll(scrollY - delta*ROW_H)
        end)

        -- Scroll indicator when list exceeds MAX_ROWS
        if #cats > MAX_ROWS then
            local arrow=menu:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            arrow:SetPoint("BOTTOMRIGHT",-6,3); arrow:SetText("|cff888888v|r")
        end

        menu:SetFrameLevel(closer:GetFrameLevel()+1)
        clip:SetFrameLevel(menu:GetFrameLevel()+1)
        child:SetFrameLevel(clip:GetFrameLevel()+1)
        closer:SetScript("OnMouseDown", CloseMenu)
    end)

    FS(form,"Description",9,0.7,0.7,0.7):SetPoint("TOPLEFT",PAD+4,-152)
    M.fDesc = Box(form,pw,20); M.fDesc:SetPoint("TOPLEFT",PAD+4,-166)

    FS(form,"Price",9,0.7,0.7,0.7):SetPoint("TOPLEFT",PAD+4,-192)
    -- Price boxes: gold, silver, copper — use raw tiny label frames (not FS wrapper)
    local function CurrLabel(parent, text, r,g,b)
        local f=CreateFrame("Frame",nil,parent); f:SetSize(12,20)
        local fs=f:CreateFontString(nil,"OVERLAY","GameFontNormal")
        fs:SetFont("Fonts\\FRIZQT__.TTF",9,""); fs:SetAllPoints()
        fs:SetText(text); fs:SetTextColor(r,g,b,1); return f
    end
    M.fGold   = Box(form,38,20); M.fGold:SetPoint("TOPLEFT",PAD+4,-206)
    local gL  = CurrLabel(form,"g",1,0.82,0);    gL:SetPoint("LEFT",M.fGold,"RIGHT",2,0)
    M.fSilver = Box(form,38,20);             M.fSilver:SetPoint("LEFT",gL,"RIGHT",2,0)
    local sL  = CurrLabel(form,"s",0.7,0.7,0.7); sL:SetPoint("LEFT",M.fSilver,"RIGHT",2,0)
    M.fCopper = Box(form,38,20);             M.fCopper:SetPoint("LEFT",sL,"RIGHT",2,0)
    CurrLabel(form,"c",0.7,0.4,0.1):SetPoint("LEFT",M.fCopper,"RIGHT",2,0)

    -- Restock Cost row: what it costs the merchant to restock one unit. When the
    -- shop has production costs enabled, this is drained from the treasury each
    -- time the item is restocked in the Stock tab. 0 = free (no charge).
    FS(form,"Restock Cost",9,0.7,0.7,0.7):SetPoint("TOPLEFT",PAD+4,-230)
    M.fRestockGold   = Box(form,38,20); M.fRestockGold:SetPoint("TOPLEFT",PAD+4,-244)
    M.fRestockGold:SetNumeric(true)
    local rgL = CurrLabel(form,"g",1,0.82,0);     rgL:SetPoint("LEFT",M.fRestockGold,"RIGHT",2,0)
    M.fRestockSilver = Box(form,38,20);           M.fRestockSilver:SetPoint("LEFT",rgL,"RIGHT",2,0)
    M.fRestockSilver:SetNumeric(true)
    local rsL = CurrLabel(form,"s",0.7,0.7,0.7);  rsL:SetPoint("LEFT",M.fRestockSilver,"RIGHT",2,0)
    M.fRestockCopper = Box(form,38,20);           M.fRestockCopper:SetPoint("LEFT",rsL,"RIGHT",2,0)
    M.fRestockCopper:SetNumeric(true)
    CurrLabel(form,"c",0.7,0.4,0.1):SetPoint("LEFT",M.fRestockCopper,"RIGHT",2,0)

    local iconSz = 26; local chooseBtnW = 60
    -- Icon lives on the same row as Rarity (y=-70 label, y=-82 frame)
    local iconX = pw - (iconSz + 6 + chooseBtnW)
    FS(form,"Icon",9,0.7,0.7,0.7):SetPoint("TOPLEFT",PAD+iconX,-70)
    local ipf = CreateFrame("Frame",nil,form,"BackdropTemplate"); ipf:SetSize(iconSz,iconSz)
    ipf:SetPoint("TOPLEFT",PAD+iconX,-82)
    ipf:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    ipf:SetBackdropColor(0,0,0,0.5); ipf:SetBackdropBorderColor(0.4,0.35,0.2,1)
    M.fIconPreview = ipf:CreateTexture(nil,"ARTWORK"); M.fIconPreview:SetSize(28,28); M.fIconPreview:SetPoint("CENTER")
    M.fIconPreview:SetTexture(133784); M.fIconPreview:SetTexCoord(0.08,0.92,0.08,0.92)
    M.fIconName = 133784

    local chooseBtn = Btn(form,"Choose",chooseBtnW,22)
    chooseBtn:SetPoint("LEFT",ipf,"RIGHT",6,0)
    chooseBtn:SetScript("OnClick",function()
        SK.IconPicker:Toggle(function(fid, label)
            M.fIconName = fid
            if M.fIconPreview then M.fIconPreview:SetTexture(fid) end
        end, form)
    end)

    -- Rarity dropdown
    local RARITIES = {
        {key="poor",      label="Poor",      r=0.62, g=0.62, b=0.62},
        {key="common",    label="Common",    r=1,    g=1,    b=1   },
        {key="uncommon",  label="Uncommon",  r=0.12, g=1,    b=0   },
        {key="rare",      label="Rare",      r=0,    g=0.44, b=0.87},
        {key="epic",      label="Epic",      r=0.64, g=0.21, b=0.93},
        {key="legendary", label="Legendary", r=1,    g=0.5,  b=0   },
    }
    M.fRarity = "common"
    FS(form,"Rarity",9,0.7,0.7,0.7):SetPoint("TOPLEFT",PAD,-70)

    local rarDD = CreateFrame("Frame","SK_RarityDropDown",form,"UIDropDownMenuTemplate")
    rarDD:SetPoint("TOPLEFT",PAD-16,-82)
    UIDropDownMenu_SetWidth(rarDD, 100)

    local function SetRarity(key)
        M.fRarity = key
        for _, rr in ipairs(RARITIES) do
            if rr.key == key then
                local col = string.format("|cff%02x%02x%02x%s|r",
                    math.floor(rr.r*255), math.floor(rr.g*255), math.floor(rr.b*255), rr.label)
                UIDropDownMenu_SetText(rarDD, col)
                if M.fName then M.fName:SetTextColor(rr.r,rr.g,rr.b,1) end
                break
            end
        end
    end

    UIDropDownMenu_Initialize(rarDD, function(self, level)
        for _, rr in ipairs(RARITIES) do
            local info = UIDropDownMenu_CreateInfo()
            local col = string.format("|cff%02x%02x%02x%s|r",
                math.floor(rr.r*255), math.floor(rr.g*255), math.floor(rr.b*255), rr.label)
            info.text    = col
            info.value   = rr.key
            info.func    = function(btn) SetRarity(btn.value) end
            info.checked = (M.fRarity == rr.key)
            UIDropDownMenu_AddButton(info, level)
        end
    end)
    SetRarity("common")
    M.rarDD = rarDD  -- stored so ClearForm/LoadProduct can update it

    local saveB = Btn(form,"Save",90,22); saveB:SetPoint("BOTTOMLEFT",PAD,8)
    saveB:SetScript("OnClick",function() M:SaveProduct() end)
    local clrB  = Btn(form,"Clear",70,22); clrB:SetPoint("LEFT",saveB,"RIGHT",6,0)
    clrB:SetScript("OnClick",function() M:ClearForm() end)

    -- TRP3 profile export — opens settings panel above the button
    local trpExBtn = Btn(form,"TRP3 Profile Text",126,22)
    M.trpExBtn = trpExBtn  -- stored for the what's-new spotlight step
    trpExBtn:SetPoint("LEFT",clrB,"RIGHT",14,0)
    trpExBtn:SetScript("OnClick",function()
        if SK.Export then SK.Export:OpenSettings(trpExBtn) end
    end)
    trpExBtn:SetScript("OnEnter",function(self)
        GameTooltip:SetOwner(self,"ANCHOR_TOP")
        GameTooltip:SetText("TRP3 Profile Text",1,0.82,0,1)
        GameTooltip:AddLine("Generate ready-to-paste markup for your\nTRP3 About tab. Opens a settings panel\nwhere you can customise the output.",1,1,1,1)
        GameTooltip:Show()
    end)
    trpExBtn:SetScript("OnLeave",function() GameTooltip:Hide() end)

    -- Stock — same row as rarity (y=-168 label, y=-183 checkbox)
    FS(form,"Stock",9,0.7,0.7,0.7):SetPoint("TOPLEFT",PAD+4+180,-192)

    -- Manual checkbox: a toggle button with a square visual
    local stockCb=CreateFrame("Button",nil,form,"BackdropTemplate")
    stockCb:SetSize(16,16); stockCb:SetPoint("TOPLEFT",PAD+4+180,-206)
    stockCb:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",
        edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    stockCb:SetBackdropColor(0.06,0.06,0.10,1); stockCb:SetBackdropBorderColor(0.45,0.35,0.12,1)
    local stockCheck=stockCb:CreateTexture(nil,"ARTWORK"); stockCheck:SetAllPoints()
    stockCheck:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
    stockCheck:SetAlpha(0)
    local stockLbl=form:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    stockLbl:SetPoint("LEFT",stockCb,"RIGHT",3,0); stockLbl:SetText("Limited")
    stockLbl:SetTextColor(0.7,0.7,0.7,1)

    M.fStockLimited = false

    -- Stock amount box: anchored off the "Limited" label so it never sits
    -- on top of the label text, regardless of font width
    local stockAmtBox=Box(form,36,20); stockAmtBox:SetPoint("LEFT",stockLbl,"RIGHT",6,0)
    stockAmtBox:SetNumeric(true); stockAmtBox:SetText("")
    stockAmtBox:SetShown(false)
    local stockAmtHint=stockAmtBox:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    stockAmtHint:SetPoint("LEFT",4,0); stockAmtHint:SetText("qty")
    stockAmtHint:SetTextColor(0.35,0.35,0.35,1)
    stockAmtBox:SetScript("OnTextChanged",function(s) stockAmtHint:SetShown(s:GetText()=="") end)
    M.fStockAmt = stockAmtBox

    stockCb:SetScript("OnClick",function()
        M.fStockLimited = not M.fStockLimited
        stockCheck:SetAlpha(M.fStockLimited and 1 or 0)
        stockCb:SetBackdropColor(M.fStockLimited and 0.08 or 0.06,
            M.fStockLimited and 0.18 or 0.06, M.fStockLimited and 0.08 or 0.10, 1)
        stockAmtBox:SetShown(M.fStockLimited)
        if M.fStockLimited and stockAmtBox:GetText()=="" then stockAmtHint:SetShown(true) end
    end)
    M.fStockCb = stockCb

    -- TRP3 Extended item checkbox — moved right of stock amount box
    FS(form,"TRP3 Item",9,0.7,0.7,0.7):SetPoint("TOPLEFT",PAD+4+292,-192)
    local trpCb=CreateFrame("Button",nil,form,"BackdropTemplate")
    trpCb:SetSize(16,16); trpCb:SetPoint("TOPLEFT",PAD+4+292,-206)
    trpCb:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",
        edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    trpCb:SetBackdropColor(0.06,0.06,0.10,1); trpCb:SetBackdropBorderColor(0.45,0.35,0.12,1)
    local trpCheck=trpCb:CreateTexture(nil,"ARTWORK"); trpCheck:SetAllPoints()
    trpCheck:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
    trpCheck:SetAlpha(0)
    local trpLbl=form:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    trpLbl:SetPoint("LEFT",trpCb,"RIGHT",3,0)
    trpLbl:SetText("TRP3")
    trpLbl:SetTextColor(0.7,0.7,0.7,1)
    local trpIcon=form:CreateTexture(nil,"ARTWORK")
    trpIcon:SetSize(14,14); trpIcon:SetPoint("LEFT",trpLbl,"RIGHT",4,0)
    trpIcon:SetTexture("Interface\\Icons\\INV_Scroll_07")
    trpIcon:SetAlpha(0)
    M.fTRP3Item = false
    trpCb:SetScript("OnClick",function()
        M.fTRP3Item = not M.fTRP3Item
        trpCheck:SetAlpha(M.fTRP3Item and 1 or 0)
        trpIcon:SetAlpha(M.fTRP3Item and 1 or 0)
        trpCb:SetBackdropColor(0.06, 0.06, M.fTRP3Item and 0.18 or 0.10, 1)
    end)
    M.fTRP3Cb = trpCb
    M.fTRP3Check = trpCheck
    M.fTRP3Icon = trpIcon

    -- ── Variants ─────────────────────────────────────────────────────────────
    -- Checkbox: "Has Variants" — when ticked, reveals a sub-editor below
    -- the stock/TRP3 row. Variants share the parent stock pool.
    form:SetHeight(308)  -- base height (incl. Restock Cost row); extended when variants are open

    FS(form,"Variants",9,0.7,0.7,0.7):SetPoint("TOPLEFT",PAD+4+370,-192)
    local varCb=CreateFrame("Button",nil,form,"BackdropTemplate")
    varCb:SetSize(16,16); varCb:SetPoint("TOPLEFT",PAD+4+370,-206)
    varCb:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",
        edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    varCb:SetBackdropColor(0.06,0.06,0.10,1); varCb:SetBackdropBorderColor(0.45,0.35,0.12,1)
    local varCheck=varCb:CreateTexture(nil,"ARTWORK"); varCheck:SetAllPoints()
    varCheck:SetTexture("Interface\\Buttons\\UI-CheckBox-Check"); varCheck:SetAlpha(0)
    local varLbl=form:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    varLbl:SetPoint("LEFT",varCb,"RIGHT",3,0); varLbl:SetText("Has Variants")
    varLbl:SetTextColor(0.7,0.7,0.7,1)

    M.fVariantsEnabled = false
    M.fVariants = {}  -- list of {name, priceCopper}

    -- The variants panel (hidden until checkbox is ticked)
    local varPanel=CreateFrame("Frame",nil,form,"BackdropTemplate")
    varPanel:SetPoint("TOPLEFT",PAD,-272)
    varPanel:SetPoint("TOPRIGHT",-PAD,-248)
    varPanel:SetHeight(100)
    varPanel:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    varPanel:SetBackdropColor(0.04,0.05,0.08,1); varPanel:SetBackdropBorderColor(0.3,0.25,0.08,0.7)
    varPanel:Hide()
    M.fVarPanel = varPanel

    FS(varPanel,'Variants  |cff666666(shared stock pool; set Stock Uses to deduct more than 1 unit per sale. e.g. set 4 for a keg variant when base stock is in mugs)|r',9,0.45,0.45,0.45):SetPoint('TOPLEFT',4,-4)

    -- Scroll area for variant rows — UIPanelScrollFrameTemplate gives a visible scrollbar
    local vsf=CreateFrame("ScrollFrame",nil,varPanel,"UIPanelScrollFrameTemplate")
    vsf:SetPoint("TOPLEFT",4,-16); vsf:SetPoint("BOTTOMRIGHT",-6,26)
    -- Inset 20px on the right so rows never slide under the scrollbar chrome
    local VAR_ROW_W = pw - 36
    local vchild=CreateFrame("Frame",nil,vsf)
    vchild:SetSize(VAR_ROW_W,1); vsf:SetScrollChild(vchild)
    vsf:EnableMouseWheel(true)
    vsf:SetScript("OnMouseWheel",function(s,d)
        local cur = s:GetVerticalScroll()
        local max = math.max(0, (vchild:GetHeight() or 0) - (s:GetHeight() or 0))
        s:SetVerticalScroll(math.max(0, math.min(max, cur - d*18)))
    end)
    M.fVarScroll  = vsf
    M.fVarChild   = vchild
    M.fVarRows    = {}   -- widget refs for cleanup

    local function RebuildVariantRows()
        for _, w in ipairs(M.fVarRows) do w:Hide(); w:SetParent(nil) end
        M.fVarRows = {}
        local rw = VAR_ROW_W
        local yo = 0
        local RH = 24
        local LEFT = 6
        local NAME_W = 120
        for i, v in ipairs(M.fVariants) do
            local row=CreateFrame("Frame",nil,vchild)
            row:SetSize(rw, RH); row:SetPoint("TOPLEFT",0,-yo)

            local idx=i

            local nb=Box(row, NAME_W, 18); nb:SetPoint("TOPLEFT",LEFT,-2)
            nb:SetText(v.name or ""); nb:SetAutoFocus(false)
            nb:SetScript("OnEditFocusLost",function(s)
                if M.fVariants[idx] then M.fVariants[idx].name=strtrim(s:GetText()) end
            end)
            nb:SetScript("OnEnterPressed",function(s) s:ClearFocus() end)
            nb:SetScript("OnEscapePressed",function(s) s:ClearFocus() end)

            local prLbl=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            prLbl:SetPoint("LEFT",nb,"RIGHT",10,0)
            prLbl:SetText("Price:"); prLbl:SetTextColor(0.55,0.55,0.55,1)

            local g2=math.floor((v.priceCopper or 0)/10000)
            local s2=math.floor(((v.priceCopper or 0)%10000)/100)
            local c2=(v.priceCopper or 0)%100

            local gB=Box(row,28,18); gB:SetPoint("LEFT",prLbl,"RIGHT",6,0)
            gB:SetNumeric(true); gB:SetText(tostring(g2))
            local gLf=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            gLf:SetPoint("LEFT",gB,"RIGHT",2,0); gLf:SetText("g")
            gLf:SetTextColor(1,0.82,0,1); gLf:SetSize(10,18)

            local sB=Box(row,28,18); sB:SetPoint("LEFT",gLf,"RIGHT",4,0)
            sB:SetNumeric(true); sB:SetText(tostring(s2))
            local sLf=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            sLf:SetPoint("LEFT",sB,"RIGHT",2,0); sLf:SetText("s")
            sLf:SetTextColor(0.75,0.75,0.75,1); sLf:SetSize(10,18)

            local cB=Box(row,28,18); cB:SetPoint("LEFT",sLf,"RIGHT",4,0)
            cB:SetNumeric(true); cB:SetText(tostring(c2))
            local cLf=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            cLf:SetPoint("LEFT",cB,"RIGHT",2,0); cLf:SetText("c")
            cLf:SetTextColor(0.7,0.4,0.1,1); cLf:SetSize(10,18)

            local function SaveVarPrice()
                if not M.fVariants[idx] then return end
                M.fVariants[idx].priceCopper =
                    (tonumber(gB:GetText()) or 0)*10000 +
                    (tonumber(sB:GetText()) or 0)*100   +
                    (tonumber(cB:GetText()) or 0)
            end
            for _, b in ipairs({gB,sB,cB}) do
                b:SetScript("OnEditFocusLost", SaveVarPrice)
                b:SetScript("OnEnterPressed",  function(s) s:ClearFocus() end)
                b:SetScript("OnEscapePressed",  function(s) s:ClearFocus() end)
            end

            local scLbl=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            scLbl:SetPoint("LEFT",cLf,"RIGHT",10,0)
            scLbl:SetText("Uses:"); scLbl:SetTextColor(0.55,0.55,0.55,1)

            local scB=Box(row,30,18); scB:SetPoint("LEFT",scLbl,"RIGHT",6,0)
            scB:SetNumeric(true); scB:SetText(tostring(v.stockCost or 1))
            scB:SetScript("OnEditFocusLost",function(s)
                if M.fVariants[idx] then
                    M.fVariants[idx].stockCost = math.max(1, tonumber(s:GetText()) or 1)
                    s:SetText(tostring(M.fVariants[idx].stockCost))
                end
            end)
            scB:SetScript("OnEnterPressed", function(s) s:ClearFocus() end)
            scB:SetScript("OnEscapePressed", function(s) s:ClearFocus() end)
            scB:SetScript("OnEnter",function(s)
                GameTooltip:SetOwner(s,"ANCHOR_TOP")
                GameTooltip:AddLine("Stock Uses",1,1,1)
                GameTooltip:AddLine("Units of base stock deducted per sale. Default: 1",0.7,0.7,0.7)
                GameTooltip:Show()
            end)
            scB:SetScript("OnLeave",function() GameTooltip:Hide() end)

            -- X remove button — right edge, label explicitly centred
            local delBtn=Btn(row,"X",22,18); delBtn:SetPoint("TOPRIGHT",-2,-3)
            if delBtn:GetFontString() then
                delBtn:GetFontString():SetJustifyH("CENTER")
                delBtn:GetFontString():SetJustifyV("MIDDLE")
            end
            local di=i
            delBtn:SetScript("OnClick",function()
                tremove(M.fVariants,di); RebuildVariantRows()
            end)

            local sep=row:CreateTexture(nil,"ARTWORK")
            sep:SetHeight(1); sep:SetPoint("BOTTOMLEFT",0,0); sep:SetPoint("BOTTOMRIGHT",0,0)
            sep:SetColorTexture(0.3,0.25,0.1,0.4)

            tinsert(M.fVarRows,row)
            yo=yo+RH+2
        end
        vchild:SetHeight(math.max(yo,20))
        if M.UpdateVarPanelHeight then M.UpdateVarPanelHeight() end
    end
    M.RebuildVariantRows = RebuildVariantRows

    -- "Add Variant" button at bottom of panel
    local addVarBtn=Btn(varPanel,"+ Add Variant",100,20)
    addVarBtn:SetPoint("BOTTOMLEFT",4,4)
    addVarBtn:SetScript("OnClick",function()
        tinsert(M.fVariants,{name="",priceCopper=0})
        RebuildVariantRows()
    end)

    -- Toggle panel visibility when checkbox is clicked
    local function UpdateVarPanelHeight()
        local formH
        if M.fVariantsEnabled then
            local rowCount = math.max(#M.fVariants, 1)
            local panelH = 16 + math.min(rowCount, 5) * 26 + 28
            varPanel:SetHeight(panelH)
            formH = 308 + panelH + 8
        else
            formH = 308
        end
        form:SetHeight(formH)
        -- Re-anchor the product scroll frame so it ends exactly where the form begins
        if M.fProductSF then
            M.fProductSF:SetPoint("BOTTOMRIGHT", -PAD-18, formH)
        end
    end

    varCb:SetScript("OnClick",function()
        M.fVariantsEnabled = not M.fVariantsEnabled
        varCheck:SetAlpha(M.fVariantsEnabled and 1 or 0)
        varCb:SetBackdropColor(
            M.fVariantsEnabled and 0.08 or 0.06,
            M.fVariantsEnabled and 0.08 or 0.06,
            M.fVariantsEnabled and 0.18 or 0.10, 1)
        varPanel:SetShown(M.fVariantsEnabled)
        RebuildVariantRows()
        UpdateVarPanelHeight()
    end)
    M.fVarCb     = varCb
    M.fVarCheck  = varCheck
    M.fVarPanel  = varPanel
    M.UpdateVarPanelHeight = UpdateVarPanelHeight

    M:ClearForm()

end

function M:ClearForm()
    M.editingProd = nil
    if M.fName   then M.fName:SetText("") end
    if M.fCatEdit then M.fCatEdit:SetText("General") end
    M.fCatColor={1,0.82,0}
    if M._colorSwatchFrame then M._colorSwatchFrame:SetBackdropColor(1,0.82,0,1) end
    if M.fDesc   then M.fDesc:SetText("") end
    if M.fGold   then M.fGold:SetText("0") end
    if M.fSilver then M.fSilver:SetText("0") end
    if M.fCopper then M.fCopper:SetText("0") end
    if M.fRestockGold   then M.fRestockGold:SetText("0")   end
    if M.fRestockSilver then M.fRestockSilver:SetText("0") end
    if M.fRestockCopper then M.fRestockCopper:SetText("0") end
    M.fIconName = 133784
    if M.fIconPreview then M.fIconPreview:SetTexture(133784) end
    M.fRarity = "common"
    if M.rarDD then UIDropDownMenu_SetText(M.rarDD, "Common") end
    if M.loadDD then UIDropDownMenu_SetText(M.loadDD, "-- select to load --") end
    -- Reset stock: if currently limited, click to toggle off
    if M.fStockLimited and M.fStockCb then M.fStockCb:Click() end
    M.fStockLimited = false
    if M.fStockAmt then M.fStockAmt:SetText(""); M.fStockAmt:SetShown(false) end
    -- Reset TRP3 item checkbox
    M.fTRP3Item = false
    if M.fTRP3Check then M.fTRP3Check:SetAlpha(0) end
    if M.fTRP3Icon  then M.fTRP3Icon:SetAlpha(0) end
    if M.fTRP3Cb    then M.fTRP3Cb:SetBackdropColor(0.06,0.06,0.10,1) end
    -- Reset variants
    M.fVariantsEnabled = false
    M.fVariants = {}
    if M.fVarCheck  then M.fVarCheck:SetAlpha(0) end
    if M.fVarCb     then M.fVarCb:SetBackdropColor(0.06,0.06,0.10,1) end
    if M.fVarPanel  then M.fVarPanel:Hide() end
    if M.RebuildVariantRows then M.RebuildVariantRows() end
    if M.UpdateVarPanelHeight then M.UpdateVarPanelHeight() end
end

function M:OpenEditor(pid)
    local shopName = SK.db and SK.db.activeShop; if not shopName then return end
    for _, prod in ipairs(SK.DB:GetProducts(shopName)) do
        if prod.id == pid then
            M.editingProd = pid
            if M.fName   then M.fName:SetText(prod.name or "") end
            if M.fDesc   then M.fDesc:SetText(prod.description or "") end
            if M.fCatEdit then M.fCatEdit:SetText(prod.category or "General") end
            -- Load the saved color for this product's category
            local r, g, b = SK.DB:GetCategoryColor(shopName, prod.category or "General")
            M.fCatColor = {r, g, b}
            -- Update the swatch if it exists
            if M._colorSwatchFrame then
                M._colorSwatchFrame:SetBackdropColor(r, g, b, 1)
            end
            M.fIconName = prod.icon or 133784
            if M.fIconPreview then M.fIconPreview:SetTexture(M.fIconName) end
            M.fRarity = prod.rarity or "common"
            if M.rarDD then UIDropDownMenu_Initialize(M.rarDD, nil); UIDropDownMenu_SetSelectedValue(M.rarDD, M.fRarity) end
            local hasStock = prod.stock ~= nil
            if hasStock ~= M.fStockLimited then
                if M.fStockCb then M.fStockCb:Click() end
            end
            M.fStockLimited = hasStock
            if M.fStockAmt then
                M.fStockAmt:SetText(hasStock and tostring(prod.stock) or "")
                M.fStockAmt:SetShown(hasStock)
            end
            -- Restore TRP3 item checkbox
            local hasTRP3 = prod.hasTRP3Item == true
            if hasTRP3 ~= M.fTRP3Item then
                if M.fTRP3Cb then M.fTRP3Cb:Click() end
            end
            -- Restore variants
            local varList = prod.variants or {}
            local hasVars = #varList > 0
            -- Copy so edits don't stomp the DB directly until Save
            M.fVariants = {}
            for _, v in ipairs(varList) do
                tinsert(M.fVariants, {name=v.name or "", priceCopper=v.priceCopper or 0, stockCost=v.stockCost or 1})
            end
            if hasVars ~= M.fVariantsEnabled then
                if M.fVarCb then M.fVarCb:Click() end
            end
            if M.fVarPanel  then M.fVarPanel:SetShown(hasVars) end
            if M.fVarCheck  then M.fVarCheck:SetAlpha(hasVars and 1 or 0) end
            if M.fVarCb     then M.fVarCb:SetBackdropColor(hasVars and 0.08 or 0.06, hasVars and 0.08 or 0.06, hasVars and 0.18 or 0.10, 1) end
            if M.RebuildVariantRows then M.RebuildVariantRows() end
            if M.UpdateVarPanelHeight then M.UpdateVarPanelHeight() end
            local g2 = math.floor(prod.priceCopper/10000)
            local s  = math.floor((prod.priceCopper%10000)/100)
            local cv = prod.priceCopper%100
            if M.fGold   then M.fGold:SetText(tostring(g2)) end
            if M.fSilver then M.fSilver:SetText(tostring(s)) end
            if M.fCopper then M.fCopper:SetText(tostring(cv)) end
            local rc = tonumber(prod.restockCost) or 0
            local rg = math.floor(rc/10000)
            local rs = math.floor((rc%10000)/100)
            local rcv = rc%100
            if M.fRestockGold   then M.fRestockGold:SetText(tostring(rg))   end
            if M.fRestockSilver then M.fRestockSilver:SetText(tostring(rs)) end
            if M.fRestockCopper then M.fRestockCopper:SetText(tostring(rcv)) end
            return
        end
    end
end

function M:SaveProduct()
    local shopName = SK.db and SK.db.activeShop
    if not shopName then print("|cffFFD700[SK]|r No active shop."); return end
    local name = M.fName and strtrim(M.fName:GetText()) or ""
    if name == "" then print("|cffFFD700[SK]|r Name required."); return end
    local g = tonumber(M.fGold and M.fGold:GetText()) or 0
    local s = tonumber(M.fSilver and M.fSilver:GetText()) or 0
    local c = tonumber(M.fCopper and M.fCopper:GetText()) or 0
    local rg = tonumber(M.fRestockGold   and M.fRestockGold:GetText())   or 0
    local rs = tonumber(M.fRestockSilver and M.fRestockSilver:GetText()) or 0
    local rc = tonumber(M.fRestockCopper and M.fRestockCopper:GetText()) or 0
    local restockCopper = rg*10000 + rs*100 + rc
    local catName = (M.fCatEdit and strtrim(M.fCatEdit:GetText())~="" and strtrim(M.fCatEdit:GetText())) or "General"
    -- Save category color
    if M.fCatColor then
        SK.DB:SetCategoryColor(shopName, catName, M.fCatColor[1], M.fCatColor[2], M.fCatColor[3])
    end
    local stockVal = nil
    if M.fStockLimited then stockVal = tonumber(M.fStockAmt and M.fStockAmt:GetText()) or 0 end
    -- Collect variants (flush focus from any open editboxes first)
    local variantData = {}
    if M.fVariantsEnabled then
        for _, v in ipairs(M.fVariants or {}) do
            local vname = strtrim(v.name or "")
            if vname ~= "" then
                tinsert(variantData, {name=vname, priceCopper=v.priceCopper or 0, stockCost=v.stockCost or 1})
            end
        end
    end
    local fields = {name=name, description=M.fDesc and strtrim(M.fDesc:GetText()) or "",
        category=catName, icon=M.fIconName or 133784, priceCopper=g*10000+s*100+c,
        rarity=M.fRarity or "common", stock=stockVal, hasTRP3Item=M.fTRP3Item or false,
        restockCost=restockCopper, variants=variantData}
    if M.editingProd then
        SK.DB:EditProduct(shopName,M.editingProd,fields)
    else
        local ok,prod=SK.DB:AddProduct(shopName,fields.name,fields.description,fields.priceCopper,fields.category,fields.icon)
        if ok and prod then prod.rarity=fields.rarity; prod.stock=fields.stock; prod.hasTRP3Item=fields.hasTRP3Item; prod.restockCost=fields.restockCost; prod.variants=fields.variants end
    end
    -- Preserve the product-list scroll position across the rebuild so editing
    -- an item near the bottom of the list doesn't snap the view back to the top.
    local prevScroll = M.fProductSF and M.fProductSF:GetVerticalScroll() or 0
    M:ClearForm(); M:SwitchTab("products")
    local nsf = M.fProductSF
    if nsf then
        C_Timer.After(0, function()
            local child = nsf:GetScrollChild()
            local maxS = child and math.max(0, (child:GetHeight() or 0) - (nsf:GetHeight() or 0)) or 0
            nsf:SetVerticalScroll(math.min(prevScroll, maxS))
        end)
    end
    if M.RefreshLoadDD then M.RefreshLoadDD() end
    if SK.Register and SK.Register.BuildProductGrid then SK.Register:BuildProductGrid() end
    if SK.Net then
        SK.Net:BroadcastProducts(shopName)
        SK.Net:BroadcastCategoryColors(shopName)
    end
end

-- ─── ORDERS TAB ───────────────────────────────────────────────────────────────

local STATUS_COLORS  = {open={1,0.6,0.1,1},in_progress={0.3,0.7,1,1},ready={0.2,1,0.4,1},complete={0.5,0.5,0.5,1}}
local STATUS_LABELS  = {open="Open",in_progress="In Progress",ready="Ready",complete="Complete"}
local PAYMENT_LABELS = {paid="Paid in Full",favor="Favour",delivery="Pay on Delivery",commission="Commission"}

local function FormatETA(order)
    if not order.claimedAt or order.claimedAt == 0 then return nil end
    if not order.estimatedMinutes or order.estimatedMinutes == 0 then return nil end
    local elapsed  = math.floor((time() - order.claimedAt) / 60)
    local remaining = order.estimatedMinutes - elapsed
    if remaining <= 0 then
        return "|cffFF4444Overdue by "..(math.abs(remaining)).." min|r"
    else
        return "|cff44FF44Delivery Estimate: ~"..remaining.." min remaining|r"
    end
end

function M:BuildTabsTab()
    WipeContent()
    local p = GetContentPanel()
    local pw = p:GetWidth() - PAD*2
    local shopName = SK.db and SK.db.activeShop
    if not shopName then local l=Track(FS(p,"No shop active.",11,0.65,0.65,0.65)); l:SetPoint("CENTER"); return end

    local isStaff = SK.DB:IsMyStaff(shopName)

    -- Bottom form: "Open New Tab" (staff only)
    local FORM_H = 120
    if isStaff then
        local form = Track(CreateFrame("Frame", nil, p, "BackdropTemplate"))
        form:SetPoint("BOTTOMLEFT",0,0); form:SetPoint("BOTTOMRIGHT",0,0); form:SetHeight(FORM_H)
        form:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
        form:SetBackdropColor(0.05,0.06,0.10,1.0); form:SetBackdropBorderColor(0.45,0.35,0.12,0.9)

        FS(form,"Open New Tab",11,1,0.82,0):SetPoint("TOPLEFT",PAD,-8)

        FS(form,"Tab holder name(s)",9,0.7,0.7,0.7):SetPoint("TOPLEFT",PAD+4,-26)
        local holderBox = Box(form, math.floor(pw*0.5)-66, 20)
        holderBox:SetPoint("TOPLEFT",PAD+4,-40)

        -- Fill IC button next to the holder box — looks up the target's TRP3 IC name
        local holderFillBtn = CreateFrame("Button",nil,form,"UIPanelButtonTemplate")
        holderFillBtn:SetSize(60,20)
        holderFillBtn:SetPoint("LEFT",holderBox,"RIGHT",4,0)
        holderFillBtn:SetText("Fill IC")
        holderFillBtn:SetScript("OnClick",function()
            local unit = UnitExists("target") and UnitIsPlayer("target") and "target" or nil
            if unit then
                -- Try TRP3 IC name first
                local icName = ""
                if TRP3_API then
                    local getUnitID = TRP3_API.utils and TRP3_API.utils.str and TRP3_API.utils.str.getUnitID
                    local unitID = getUnitID and (pcall(getUnitID, unit) and select(2, pcall(getUnitID, unit))) or nil
                    if unitID then
                        local ok, profile = pcall(function()
                            return TRP3_API.register and TRP3_API.register.getUnitIDCurrentProfile and
                                   TRP3_API.register.getUnitIDCurrentProfile(unitID)
                        end)
                        if ok and profile and profile.player then
                            local first = strtrim(profile.player.FN or "")
                            local last  = strtrim(profile.player.LN or "")
                            icName = strtrim(first .. (last ~= "" and " "..last or ""))
                        end
                    end
                end
                if icName ~= "" then
                    holderBox:SetText(icName)
                else
                    -- Fallback to OOC name
                    local name = UnitName("target")
                    if name and name ~= "" then
                        holderBox:SetText(name:match("^([^%-]+)") or name)
                        print("|cffFFD700[SK]|r No TRP3 IC name found — used OOC name instead.")
                    end
                end
            else
                print("|cffFFD700[SK]|r No player targeted.")
            end
        end)
        holderFillBtn:SetScript("OnEnter",function(s)
            GameTooltip:SetOwner(s,"ANCHOR_TOP")
            GameTooltip:AddLine("Fill IC name from target",1,1,1)
            GameTooltip:AddLine("Fills the holder name with your target's TRP3 IC name\n(falls back to OOC name if no TRP3 profile is found).",0.7,0.7,0.7)
            GameTooltip:Show()
        end)
        holderFillBtn:SetScript("OnLeave",function() GameTooltip:Hide() end)

        FS(form,"Opened by",9,0.7,0.7,0.7):SetPoint("TOPLEFT",PAD+4+math.floor(pw*0.5)+12,-26)
        local openerBox = Box(form, math.floor(pw*0.32), 20)
        openerBox:SetPoint("TOPLEFT",PAD+4+math.floor(pw*0.5)+12,-40)
        openerBox:SetText(SK:GetRPName() or "")

        -- Payment mode cycle: Pay at end → Deposit (credit) → Prepaid (drains)
        FS(form,"Payment",9,0.7,0.7,0.7):SetPoint("TOPLEFT",PAD+4,-62)
        local mode = {v="end"}
        local modeBtn = Btn(form,"Pay at end of night",180,20)
        modeBtn:SetPoint("TOPLEFT",PAD+4+58,-62)

        -- Deposit/amount fields on their OWN row beneath the toggle (left-aligned)
        -- Small currency label helper (FS here returns a frame wrapper without
        -- FontString methods, so build the label directly).
        local function CurLbl(parent, text, r,g,b)
            local f=CreateFrame("Frame",nil,parent); f:SetSize(9,20)
            local fs=f:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            fs:SetAllPoints(); fs:SetJustifyH("CENTER"); fs:SetText(text); fs:SetTextColor(r,g,b,1)
            return f
        end
        local depLbl = FS(form,"Amount",9,0.7,0.7,0.7)
        depLbl:SetPoint("TOPLEFT",PAD+4,-86)
        local depG = Box(form,34,20); depG:SetPoint("LEFT",depLbl,"RIGHT",8,0); depG:SetNumeric(true); depG:SetText("0")
        local depGl= CurLbl(form,"g",1,0.82,0); depGl:SetPoint("LEFT",depG,"RIGHT",4,0)
        local depS = Box(form,34,20); depS:SetPoint("LEFT",depGl,"RIGHT",6,0); depS:SetNumeric(true); depS:SetText("0")
        local depSl= CurLbl(form,"s",0.75,0.75,0.75); depSl:SetPoint("LEFT",depS,"RIGHT",4,0)
        local depC = Box(form,34,20); depC:SetPoint("LEFT",depSl,"RIGHT",6,0); depC:SetNumeric(true); depC:SetText("0")
        local depCl= CurLbl(form,"c",0.7,0.4,0.1); depCl:SetPoint("LEFT",depC,"RIGHT",4,0)
        local function SetDepShown(on)
            depLbl:SetShown(on); depG:SetShown(on); depGl:SetShown(on)
            depS:SetShown(on); depSl:SetShown(on); depC:SetShown(on); depCl:SetShown(on)
        end
        SetDepShown(false)
        modeBtn:SetScript("OnClick",function(self)
            if mode.v=="end" then
                mode.v="deposit"; self:SetText("Deposit (credit at close)"); SetDepShown(true)
            elseif mode.v=="deposit" then
                mode.v="prepaid"; self:SetText("Prepaid (drains as you go)"); SetDepShown(true)
            else
                mode.v="end"; self:SetText("Pay at end of night"); SetDepShown(false)
            end
        end)

        local openBtn = Btn(form,"Open Tab",100,22)
        openBtn:SetPoint("BOTTOMRIGHT",-PAD,6)
        openBtn:SetScript("OnClick",function()
            local holders = strtrim(holderBox:GetText())
            if holders=="" then print("|cffFFD700[SK]|r Tab holder name required."); return end
            local deposit = 0
            if mode.v=="deposit" or mode.v=="prepaid" then
                deposit = (tonumber(depG:GetText()) or 0)*10000 + (tonumber(depS:GetText()) or 0)*100 + (tonumber(depC:GetText()) or 0)
            end
            local ok, tab = SK.DB:CreateTab(shopName, {
                holders=holders, openedBy=strtrim(openerBox:GetText()),
                paymentMode=mode.v, deposit=deposit,
            })
            if ok then
                if SK.Net and SK.Net.BroadcastTab then SK.Net:BroadcastTab(shopName, tab) end
                -- Defer the rebuild by one frame so the current layout pass completes
                -- before WipeContent destroys the form widgets
                C_Timer.After(0, function() M:SwitchTab("tabs") end)
            else
                print("|cffFFD700[SK]|r "..tostring(tab))
            end
        end)
    end

    -- Scroll list of open tabs above the form
    local sf=Track(CreateFrame("ScrollFrame",nil,p,"UIPanelScrollFrameTemplate"))
    sf:SetPoint("TOPLEFT",PAD,-PAD)
    sf:SetPoint("BOTTOMRIGHT",-PAD-18, isStaff and (FORM_H+6) or PAD)
    local sc=CreateFrame("Frame",nil,sf); sc:SetWidth(sf:GetWidth()-4); sc:SetHeight(1); sf:SetScrollChild(sc)

    local tabs = SK.DB:GetTabs(shopName)
    -- Show open tabs first (newest first), then closed
    local openTabs, closedTabs = {}, {}
    for i=#tabs,1,-1 do
        if tabs[i].status=="open" then tinsert(openTabs,tabs[i]) else tinsert(closedTabs,tabs[i]) end
    end

    if #openTabs==0 and #closedTabs==0 then
        local nl=sc:CreateFontString(nil,"OVERLAY","GameFontDisable")
        nl:SetPoint("TOPLEFT",4,-10); nl:SetText("No open tabs. Use the form below to open one.")
        sc:SetHeight(30); return
    end

    local yo, W = 0, sc:GetWidth()

    local function BuildTabCard(tab)
        local total = SK.DB:GetTabTotal(tab)
        local nItems = #(tab.items or {})
        local closed = (tab.status=="closed")
        -- Preview at most 3 item lines; if more, a "+N more..." line is shown
        local MAX_PREVIEW = 3
        local shownLines = math.min(nItems, MAX_PREVIEW)
        local hasMore    = nItems > MAX_PREVIEW
        local displayRows = math.max(shownLines, 1) + (hasMore and 1 or 0)
        -- Card height: header(2 lines) + item rows + footer buttons
        local rh = 46 + displayRows*16 + 30
        local row=CreateFrame("Frame",nil,sc,"BackdropTemplate")
        row:SetSize(W,rh); row:SetPoint("TOPLEFT",0,-yo)
        row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
        if closed then
            row:SetBackdropColor(0,0,0,0.10); row:SetBackdropBorderColor(0.3,0.3,0.3,0.8)
        else
            row:SetBackdropColor(0.04,0.05,0.03,0.5); row:SetBackdropBorderColor(0.8,0.6,0.25,0.9)
        end

        -- Header: holders + status
        local hdr=row:CreateFontString(nil,"OVERLAY","GameFontNormal")
        hdr:SetFont("Fonts\\FRIZQT__.TTF",11,"OUTLINE"); hdr:SetPoint("TOPLEFT",6,-5)
        hdr:SetText(string.format("Tab #%d  —  %s", tab.id, tab.holders))
        hdr:SetTextColor(closed and 0.6 or 1, closed and 0.6 or 0.82, closed and 0.6 or 0.3, 1)

        local statusTxt = closed and "CLOSED" or "OPEN"
        local st=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        st:SetPoint("TOPRIGHT",-6,-6); st:SetText(statusTxt)
        st:SetTextColor(closed and 0.6 or 0.4, closed and 0.6 or 1, closed and 0.6 or 0.4, 1)

        -- Sub-header: opened by + payment mode
        local modeStr
        if tab.paymentMode=="deposit" then
            modeStr = "Deposit: "..SK:FormatMoney(tab.deposit or 0)
        elseif tab.paymentMode=="prepaid" then
            modeStr = "Prepaid: "..SK:FormatMoney(tab.deposit or 0)
        else
            modeStr = "Pay at end"
        end
        local sub=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        sub:SetPoint("TOPLEFT",6,-22)
        sub:SetText(string.format("Opened by %s  |  %s", tab.openedBy~="" and tab.openedBy or "?", modeStr))
        sub:SetTextColor(0.6,0.6,0.6,1)

        -- Items list
        local iy = 40
        if nItems==0 then
            local em=row:CreateFontString(nil,"OVERLAY","GameFontDisable")
            em:SetPoint("TOPLEFT",10,-iy); em:SetText("(no items yet)")
            iy = iy + 16
        else
            for idx, e in ipairs(tab.items) do
              if idx <= MAX_PREVIEW then
                local unit = (e.variant and e.variant.priceCopper) or (e.product and e.product.priceCopper) or 0
                local dn = (e.product and e.product.name or "?")
                    .. ((e.variantKey and e.variantKey~="") and (" ("..e.variantKey..")") or "")
                local il=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
                il:SetPoint("TOPLEFT",10,-iy); il:SetSize(W*0.62,14); il:SetJustifyH("LEFT")
                il:SetText(string.format("%dx %s", e.qty or 1, dn)); il:SetTextColor(0.85,0.85,0.85,1)
                local ip=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
                ip:SetPoint("TOPLEFT",W*0.62+12,-iy); ip:SetSize(W*0.22,14)
                ip:SetText(SK:FormatMoney(unit*(e.qty or 1))); ip:SetTextColor(0.7,0.7,0.7,1)
                -- Remove button (open tabs + staff only)
                if not closed and isStaff then
                    local rmv=Btn(row,"-",18,14); rmv:SetPoint("TOPRIGHT",-6,-iy+1)
                    local ti, ii = tab.id, idx
                    rmv:SetScript("OnClick",function()
                        SK.DB:RemoveTabItem(shopName, ti, ii)
                        if SK.Net and SK.Net.BroadcastTab then SK.Net:BroadcastTab(shopName, SK.DB:GetTab(shopName,ti)) end
                        M:SwitchTab("tabs")
                    end)
                end
                iy = iy + 16
              end
            end
            -- "+N more..." summary line when the tab has more than the preview cap
            if hasMore then
                local moreN = nItems - MAX_PREVIEW
                local ml=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
                ml:SetPoint("TOPLEFT",10,-iy)
                ml:SetText("...and "..moreN.." more line"..(moreN==1 and "" or "s").." (open Tabs to manage)")
                ml:SetTextColor(0.55,0.55,0.55,1)
                iy = iy + 16
            end
        end

        -- Footer: total (+ remaining balance for deposit/prepaid) + action buttons
        local tot=row:CreateFontString(nil,"OVERLAY","GameFontNormal")
        tot:SetFont("Fonts\\FRIZQT__.TTF",11,"OUTLINE")
        tot:SetPoint("BOTTOMLEFT",8,8)
        local totText = "Total: "..SK:FormatMoney(total)
        if (tab.paymentMode=="prepaid" or tab.paymentMode=="deposit") and (tab.deposit or 0) > 0 then
            local remaining = (tab.deposit or 0) - total
            if remaining >= 0 then
                totText = totText .. "   |cff88FF88Remaining: "..SK:FormatMoney(remaining).."|r"
            else
                totText = totText .. "   |cffFF6666Owed: "..SK:FormatMoney(-remaining).."|r"
            end
        end
        tot:SetText(totText); tot:SetTextColor(1,0.82,0,1)

        if not closed and isStaff then
            -- Add Items: jumps to register in "add to tab" mode
            local addB=Btn(row,"Add Items",90,20); addB:SetPoint("BOTTOMRIGHT",-6,6)
            local ti=tab.id
            addB:SetScript("OnClick",function()
                if SK.Register and SK.Register.BeginTabMode then
                    SK.Register:BeginTabMode(shopName, ti)
                end
            end)
            local setB=Btn(row,"Settle & Close",110,20); setB:SetPoint("RIGHT",addB,"LEFT",-6,0)
            setB:SetScript("OnClick",function()
                M:ShowSettleTabDialog(shopName, ti)
            end)
            -- Edit (payment settings) — permission gated
            if SK.DB:CanManageTabs(shopName) then
                local edB=Btn(row,"Edit",54,20); edB:SetPoint("RIGHT",setB,"LEFT",-6,0)
                edB:SetScript("OnClick",function()
                    M:ShowEditTabDialog(shopName, ti)
                end)
            end
        elseif closed and isStaff then
            local canManage = SK.DB:CanManageTabs(shopName)
            local rightmost
            if SK.DB:IsMyManager(shopName) then
                local delB=Btn(row,"Delete",70,20); delB:SetPoint("BOTTOMRIGHT",-6,6)
                local ti=tab.id
                delB:SetScript("OnClick",function()
                    SK.DB:DeleteTab(shopName, ti)
                    if SK.Net and SK.Net.BroadcastTabDelete then SK.Net:BroadcastTabDelete(shopName, ti) end
                    M:SwitchTab("tabs")
                end)
                rightmost = delB
            end
            if canManage then
                local ti=tab.id
                local reB=Btn(row,"Reopen",70,20)
                if rightmost then reB:SetPoint("RIGHT",rightmost,"LEFT",-6,0)
                else reB:SetPoint("BOTTOMRIGHT",-6,6) end
                reB:SetScript("OnClick",function()
                    local ok, err = SK.DB:ReopenTab(shopName, ti)
                    if ok then
                        if SK.Net and SK.Net.BroadcastTab then SK.Net:BroadcastTab(shopName, SK.DB:GetTab(shopName,ti)) end
                        M:SwitchTab("tabs")
                    else
                        print("|cffFFD700[SK]|r "..tostring(err))
                    end
                end)
            end
        end

        yo = yo + rh + 6
    end

    for _, tab in ipairs(openTabs)   do BuildTabCard(tab) end
    if #closedTabs > 0 then
        local sep=sc:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        sep:SetPoint("TOPLEFT",4,-yo); sep:SetText("Closed tabs"); sep:SetTextColor(0.5,0.5,0.5,1)
        yo = yo + 18
        for _, tab in ipairs(closedTabs) do BuildTabCard(tab) end
    end

    sc:SetHeight(math.max(yo,30))
end


-- ─── Settle Tab dialog (with optional tip) ───────────────────────────────────
-- ─── Rename Category dialog ───────────────────────────────────────────────────
-- Renames a category everywhere (all products, color, order). If the typed name
-- matches an existing category, the two are merged.
function M:ShowRenameCategoryDialog(shopName, oldName, onDone)
    if M._renameCatDlg then M._renameCatDlg:Hide(); M._renameCatDlg:SetParent(nil); M._renameCatDlg=nil end

    local W,H = 320, 150
    local dlg = CreateFrame("Frame","StorekeeperRenameCat",UIParent,"BackdropTemplate")
    dlg:SetSize(W,H); dlg:SetPoint("CENTER"); dlg:SetFrameStrata("FULLSCREEN_DIALOG"); dlg:SetToplevel(true)
    dlg:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
        edgeFile="Interface\\DialogFrame\\UI-DialogBox-Gold-Border",edgeSize=20,insets={left=5,right=5,top=5,bottom=5}})
    dlg:SetBackdropColor(0,0,0,1); dlg:SetBackdropBorderColor(1,1,1,1)
    dlg:EnableMouse(true)
    M._renameCatDlg = dlg
    tinsert(UISpecialFrames,"StorekeeperRenameCat")

    local title=dlg:CreateFontString(nil,"OVERLAY","GameFontNormal")
    title:SetFont("Fonts\\FRIZQT__.TTF",12,"OUTLINE"); title:SetPoint("TOP",0,-14)
    title:SetText("Rename Category"); title:SetTextColor(1,0.82,0,1)

    local sub=dlg:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    sub:SetPoint("TOP",0,-32); sub:SetWidth(W-36); sub:SetText("All products in '"..oldName.."' will update to the new name.")
    sub:SetTextColor(0.65,0.65,0.65,1)

    local box=Box(dlg, W-40, 22); box:SetPoint("TOP",0,-58); box:SetText(oldName)
    box:SetAutoFocus(true); box:HighlightText()

    local note=dlg:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    note:SetPoint("TOPLEFT",18,-84); note:SetWidth(W-36); note:SetJustifyH("LEFT")
    note:SetTextColor(0.8,0.55,0.2,1)

    local function DoRename()
        local newName = strtrim(box:GetText() or "")
        if newName == "" then note:SetText("Name cannot be empty."); return end
        if newName == oldName then dlg:Hide(); dlg:SetParent(nil); M._renameCatDlg=nil; return end
        local ok, mergedOrErr = SK.DB:RenameCategory(shopName, oldName, newName)
        if not ok then note:SetText(tostring(mergedOrErr)); return end
        if SK.Net and SK.Net.BroadcastProducts then SK.Net:BroadcastProducts(shopName) end
        if SK.Net and SK.Net.BroadcastCategoryColors then SK.Net:BroadcastCategoryColors(shopName) end
        if SK.Register and SK.Register.BuildProductGrid then SK.Register:BuildProductGrid() end
        dlg:Hide(); dlg:SetParent(nil); M._renameCatDlg=nil
        if onDone then onDone() end
    end

    box:SetScript("OnEnterPressed", DoRename)
    box:SetScript("OnEscapePressed", function() dlg:Hide(); dlg:SetParent(nil); M._renameCatDlg=nil end)

    local save=Btn(dlg,"Rename",100,24); save:SetPoint("BOTTOMLEFT",16,14)
    save:SetScript("OnClick", DoRename)
    local cancel=Btn(dlg,"Cancel",90,24); cancel:SetPoint("BOTTOMRIGHT",-16,14)
    cancel:SetScript("OnClick", function() dlg:Hide(); dlg:SetParent(nil); M._renameCatDlg=nil end)
end

function M:ShowSettleTabDialog(shopName, tabID)
    local tab = SK.DB:GetTab(shopName, tabID)
    if not tab then return end
    if M._settleDlg then M._settleDlg:Hide(); M._settleDlg:SetParent(nil); M._settleDlg=nil end

    local total = SK.DB:GetTabTotal(tab)
    local W,H = 320, 200
    local dlg = CreateFrame("Frame","StorekeeperSettleTab",UIParent,"BackdropTemplate")
    dlg:SetSize(W,H); dlg:SetPoint("CENTER"); dlg:SetFrameStrata("FULLSCREEN_DIALOG"); dlg:SetToplevel(true)
    dlg:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
        edgeFile="Interface\\DialogFrame\\UI-DialogBox-Gold-Border",edgeSize=20,insets={left=5,right=5,top=5,bottom=5}})
    dlg:SetBackdropColor(0,0,0,1); dlg:SetBackdropBorderColor(1,1,1,1)
    dlg:EnableMouse(true)
    M._settleDlg = dlg
    tinsert(UISpecialFrames,"StorekeeperSettleTab")

    local title=dlg:CreateFontString(nil,"OVERLAY","GameFontNormal")
    title:SetFont("Fonts\\FRIZQT__.TTF",12,"OUTLINE"); title:SetPoint("TOP",0,-14)
    title:SetText("Settle Tab #"..tabID); title:SetTextColor(1,0.82,0,1)

    local sub=dlg:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    sub:SetPoint("TOP",0,-34); sub:SetText(tab.holders); sub:SetTextColor(0.7,0.7,0.7,1)

    local totL=dlg:CreateFontString(nil,"OVERLAY","GameFontNormal")
    totL:SetPoint("TOPLEFT",18,-58); totL:SetText("Items total: "..SK:FormatMoney(total)); totL:SetTextColor(1,1,1,1)

    -- Remaining/owed for deposit/prepaid
    local owedNote
    if (tab.paymentMode=="deposit" or tab.paymentMode=="prepaid") and (tab.deposit or 0) > 0 then
        local rem = (tab.deposit or 0) - total
        local txt = rem >= 0 and ("Prepaid covers it (|cff88FF88"..SK:FormatMoney(rem).." left|r)")
                              or ("Balance owed: |cffFF6666"..SK:FormatMoney(-rem).."|r")
        owedNote=dlg:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        owedNote:SetPoint("TOPLEFT",18,-76); owedNote:SetText(txt); owedNote:SetTextColor(0.8,0.8,0.8,1)
    end

    -- Tip row
    local tipLbl=dlg:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    tipLbl:SetPoint("TOPLEFT",18,-100); tipLbl:SetText("Tip (optional):"); tipLbl:SetTextColor(0.7,0.7,0.7,1)
    local function CurLbl(parent,text,r,g,b)
        local f=CreateFrame("Frame",nil,parent); f:SetSize(9,20)
        local fs=f:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        fs:SetAllPoints(); fs:SetJustifyH("CENTER"); fs:SetText(text); fs:SetTextColor(r,g,b,1); return f
    end
    local tg=Box(dlg,34,20); tg:SetPoint("TOPLEFT",110,-98); tg:SetNumeric(true); tg:SetText("0")
    local tgl=CurLbl(dlg,"g",1,0.82,0); tgl:SetPoint("LEFT",tg,"RIGHT",4,0)
    local ts=Box(dlg,34,20); ts:SetPoint("LEFT",tgl,"RIGHT",6,0); ts:SetNumeric(true); ts:SetText("0")
    local tsl=CurLbl(dlg,"s",0.75,0.75,0.75); tsl:SetPoint("LEFT",ts,"RIGHT",4,0)
    local tc=Box(dlg,34,20); tc:SetPoint("LEFT",tsl,"RIGHT",6,0); tc:SetNumeric(true); tc:SetText("0")
    local tcl=CurLbl(dlg,"c",0.7,0.4,0.1); tcl:SetPoint("LEFT",tc,"RIGHT",4,0)

    -- Buttons
    local confirm=Btn(dlg,"Settle & Close",130,24); confirm:SetPoint("BOTTOMLEFT",16,14)
    confirm:SetScript("OnClick",function()
        local tip=(tonumber(tg:GetText()) or 0)*10000 + (tonumber(ts:GetText()) or 0)*100 + (tonumber(tc:GetText()) or 0)
        local ok=SK.DB:CloseTab(shopName, tabID, tip)
        if ok then
            if SK.Net and SK.Net.BroadcastTab then SK.Net:BroadcastTab(shopName, SK.DB:GetTab(shopName,tabID)) end
        end
        dlg:Hide(); dlg:SetParent(nil); M._settleDlg=nil
        M:SwitchTab("tabs")
    end)
    local cancel=Btn(dlg,"Cancel",90,24); cancel:SetPoint("BOTTOMRIGHT",-16,14)
    cancel:SetScript("OnClick",function() dlg:Hide(); dlg:SetParent(nil); M._settleDlg=nil end)
end

-- ─── Edit Tab dialog (holders + payment mode/deposit) ────────────────────────
function M:ShowEditTabDialog(shopName, tabID)
    local tab = SK.DB:GetTab(shopName, tabID)
    if not tab then return end
    if M._editTabDlg then M._editTabDlg:Hide(); M._editTabDlg:SetParent(nil); M._editTabDlg=nil end

    local W,H = 340, 230
    local dlg = CreateFrame("Frame","StorekeeperEditTab",UIParent,"BackdropTemplate")
    dlg:SetSize(W,H); dlg:SetPoint("CENTER"); dlg:SetFrameStrata("FULLSCREEN_DIALOG"); dlg:SetToplevel(true)
    dlg:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
        edgeFile="Interface\\DialogFrame\\UI-DialogBox-Gold-Border",edgeSize=20,insets={left=5,right=5,top=5,bottom=5}})
    dlg:SetBackdropColor(0,0,0,1); dlg:SetBackdropBorderColor(1,1,1,1)
    dlg:EnableMouse(true)
    M._editTabDlg = dlg
    tinsert(UISpecialFrames,"StorekeeperEditTab")

    local title=dlg:CreateFontString(nil,"OVERLAY","GameFontNormal")
    title:SetFont("Fonts\\FRIZQT__.TTF",12,"OUTLINE"); title:SetPoint("TOP",0,-14)
    title:SetText("Edit Tab #"..tabID); title:SetTextColor(1,0.82,0,1)

    -- Holders
    local hl=dlg:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    hl:SetPoint("TOPLEFT",18,-40); hl:SetText("Tab holder name(s)"); hl:SetTextColor(0.7,0.7,0.7,1)
    local hb=Box(dlg,W-36,20); hb:SetPoint("TOPLEFT",18,-54); hb:SetText(tab.holders or "")

    -- Payment mode cycle
    local pl=dlg:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    pl:SetPoint("TOPLEFT",18,-82); pl:SetText("Payment"); pl:SetTextColor(0.7,0.7,0.7,1)
    local mode={v=tab.paymentMode or "end"}
    local function ModeText(v)
        if v=="deposit" then return "Deposit (credit at close)"
        elseif v=="prepaid" then return "Prepaid (drains as you go)"
        else return "Pay at end of night" end
    end
    local modeBtn=Btn(dlg,ModeText(mode.v),190,20); modeBtn:SetPoint("TOPLEFT",78,-82)

    -- Deposit/amount row
    local function CurLbl(parent,text,r,g,b)
        local f=CreateFrame("Frame",nil,parent); f:SetSize(9,20)
        local fs=f:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        fs:SetAllPoints(); fs:SetJustifyH("CENTER"); fs:SetText(text); fs:SetTextColor(r,g,b,1); return f
    end
    local dep0 = tab.deposit or 0
    local al=dlg:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    al:SetPoint("TOPLEFT",18,-110); al:SetText("Amount"); al:SetTextColor(0.7,0.7,0.7,1)
    local ag=Box(dlg,34,20); ag:SetPoint("TOPLEFT",78,-108); ag:SetNumeric(true); ag:SetText(tostring(math.floor(dep0/10000)))
    local agl=CurLbl(dlg,"g",1,0.82,0); agl:SetPoint("LEFT",ag,"RIGHT",4,0)
    local as=Box(dlg,34,20); as:SetPoint("LEFT",agl,"RIGHT",6,0); as:SetNumeric(true); as:SetText(tostring(math.floor((dep0%10000)/100)))
    local asl=CurLbl(dlg,"s",0.75,0.75,0.75); asl:SetPoint("LEFT",as,"RIGHT",4,0)
    local ac=Box(dlg,34,20); ac:SetPoint("LEFT",asl,"RIGHT",6,0); ac:SetNumeric(true); ac:SetText(tostring(dep0%100))
    local acl=CurLbl(dlg,"c",0.7,0.4,0.1); acl:SetPoint("LEFT",ac,"RIGHT",4,0)

    local function SetAmtShown(on)
        al:SetShown(on); ag:SetShown(on); agl:SetShown(on); as:SetShown(on); asl:SetShown(on); ac:SetShown(on); acl:SetShown(on)
    end
    SetAmtShown(mode.v=="deposit" or mode.v=="prepaid")
    modeBtn:SetScript("OnClick",function(self)
        if mode.v=="end" then mode.v="deposit"
        elseif mode.v=="deposit" then mode.v="prepaid"
        else mode.v="end" end
        self:SetText(ModeText(mode.v))
        SetAmtShown(mode.v=="deposit" or mode.v=="prepaid")
    end)

    local note=dlg:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    note:SetPoint("TOPLEFT",18,-138); note:SetWidth(W-36); note:SetJustifyH("LEFT")
    note:SetText("Changing the prepaid/deposit amount adjusts the treasury by the difference.")
    note:SetTextColor(0.5,0.5,0.5,1)

    local save=Btn(dlg,"Save",110,24); save:SetPoint("BOTTOMLEFT",16,14)
    save:SetScript("OnClick",function()
        local dep=0
        if mode.v=="deposit" or mode.v=="prepaid" then
            dep=(tonumber(ag:GetText()) or 0)*10000 + (tonumber(as:GetText()) or 0)*100 + (tonumber(ac:GetText()) or 0)
        end
        local ok,err=SK.DB:EditTab(shopName, tabID, {holders=hb:GetText(), paymentMode=mode.v, deposit=dep})
        if ok then
            if SK.Net and SK.Net.BroadcastTab then SK.Net:BroadcastTab(shopName, SK.DB:GetTab(shopName,tabID)) end
        else
            print("|cffFFD700[SK]|r "..tostring(err))
        end
        dlg:Hide(); dlg:SetParent(nil); M._editTabDlg=nil
        M:SwitchTab("tabs")
    end)
    local cancel=Btn(dlg,"Cancel",90,24); cancel:SetPoint("BOTTOMRIGHT",-16,14)
    cancel:SetScript("OnClick",function() dlg:Hide(); dlg:SetParent(nil); M._editTabDlg=nil end)
end

function M:BuildOrdersTab()
    WipeContent()
    local p = GetContentPanel()
    local shopName = SK.db and SK.db.activeShop
    if not shopName then local l=Track(FS(p,"No shop active.",11,0.65,0.65,0.65)); l:SetPoint("CENTER"); return end

    local myName  = SK:GetRPName()
    local isOwner = SK.DB:IsMyManager(shopName)

    -- For non-owners: show a Request Sync button at the top
    local topOffset = -PAD
    if not isOwner then
        local syncBtn = Track(Btn(p, "Request Order Sync", 160, 22))
        syncBtn:SetPoint("TOPRIGHT", -PAD-18, topOffset)
        syncBtn:SetScript("OnClick", function()
            if SK.Net then SK.Net:RequestOrderSync(shopName) end
        end)
        syncBtn:SetScript("OnEnter", function(s)
            GameTooltip:SetOwner(s, "ANCHOR_BOTTOM")
            GameTooltip:AddLine("Request Order Sync", 1, 1, 1)
            GameTooltip:AddLine("Asks the shop owner to push\nall current orders to you.", 0.7, 0.7, 0.7)
            GameTooltip:Show()
        end)
        syncBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
        topOffset = topOffset - 30
    end

    local sf=Track(CreateFrame("ScrollFrame",nil,p,"UIPanelScrollFrameTemplate"))
    sf:SetPoint("TOPLEFT",PAD,topOffset); sf:SetPoint("BOTTOMRIGHT",-PAD-18,PAD)
    local sc=CreateFrame("Frame",nil,sf); sc:SetWidth(sf:GetWidth()-4); sc:SetHeight(1); sf:SetScrollChild(sc)

    local orders=SK.DB:GetOrders(shopName)
    local sorted={}; for i=#orders,1,-1 do tinsert(sorted,orders[i]) end

    if #sorted==0 then
        local nl=sc:CreateFontString(nil,"OVERLAY","GameFontDisable")
        nl:SetPoint("TOPLEFT",4,-10); nl:SetText("No orders yet."); sc:SetHeight(30); return
    end

    local yo,W=0,sc:GetWidth()
    for _,order in ipairs(sorted) do
        -- Migrate old orders that lack new fields
        order.assignedTo       = order.assignedTo       or ""
        order.estimatedMinutes = order.estimatedMinutes or 0
        order.claimedAt        = order.claimedAt        or 0

        local sc_col = STATUS_COLORS[order.status] or {0.7,0.7,0.7,1}
        local isAssigned = (order.assignedTo ~= "")
        local isMine     = (order.assignedTo == myName)
        local eta        = (order.status ~= "complete") and FormatETA(order) or nil

        -- Calculate row height based on content lines
        local isFree = not isAssigned
        -- IC Seller, OOC Seller, IC Buyer, OOC Buyer always shown (4 lines)
        local extraLines = 4
        if order.deliveryNote and order.deliveryNote~="" then extraLines=extraLines+1 end
        if isAssigned then extraLines=extraLines+1 end
        if eta then extraLines=extraLines+1 end
        local rh = 76 + extraLines*13

        local row=CreateFrame("Frame",nil,sc,"BackdropTemplate")
        row:SetSize(W,rh); row:SetPoint("TOPLEFT",0,-yo)
        row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
        row:SetBackdropColor(0,0,0,0.18)
        row:SetBackdropBorderColor(sc_col[1]*0.4,sc_col[2]*0.4,sc_col[3]*0.4,1)

        -- Header line
        local hdr=row:CreateFontString(nil,"OVERLAY","GameFontNormal")
        hdr:SetFont("Fonts\\FRIZQT__.TTF",10,"OUTLINE"); hdr:SetPoint("TOPLEFT",6,-5)
        hdr:SetText(string.format("Order #%d  |cff888888%s|r  —  %s  —  |c"..
            string.format("ff%02x%02x%02x",sc_col[1]*255,sc_col[2]*255,sc_col[3]*255).."%s|r",
            order.id, date("%d/%m/%Y",order.timestamp),
            PAYMENT_LABELS[order.paymentType] or order.paymentType,
            STATUS_LABELS[order.status] or order.status))

        -- Items + total
        local allItemLabels = {}
        for _, e in ipairs(order.items) do
            local dn = e.product.name..(e.variant and e.variant.name~="" and (" ("..e.variant.name..")") or "")
            tinsert(allItemLabels, e.qty.."x "..dn)
        end
        local itemsShort = table.concat(allItemLabels, ", ")
        local il = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        il:SetPoint("TOPLEFT",6,-18); il:SetPoint("TOPRIGHT",-80,-18); il:SetHeight(26)
        il:SetWordWrap(true); il:SetNonSpaceWrap(false)
        local TRUNC = 100
        if #itemsShort > TRUNC then
            local cut = itemsShort:sub(1, TRUNC):match("(.+),") or itemsShort:sub(1, TRUNC)
            il:SetText(cut.."... |cff888888(see View Order)|r")
        else
            il:SetText(itemsShort)
        end
        il:SetTextColor(0.82,0.82,0.82,1)
        local tl = row:CreateFontString(nil,"OVERLAY","GameFontNormal")
        tl:SetPoint("TOPRIGHT",-6,-18); tl:SetText(SK:FormatMoney(order.totalCopper))

        -- Info lines
        local iy=32
        local function InfoLine(text, r, g, b)
            local l=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            l:SetPoint("TOPLEFT",6,-iy); l:SetText(text)
            l:SetTextColor(r or 0.65, g or 0.65, b or 0.65, 1)
            iy=iy+13
        end

        -- ── Bottom control strip ──────────────────────────────────────────
        local isComplete = (order.status == "complete")

        -- Seller / Buyer info — always shown so names are never hidden
        local sIc  = (order.sellerIC  and order.sellerIC  ~= "") and order.sellerIC  or "|cff888888—|r"
        local sOoc = (order.sellerOOC and order.sellerOOC ~= "") and order.sellerOOC or "|cff888888—|r"
        local bIc  = (order.buyerIC   and order.buyerIC   ~= "") and order.buyerIC   or "|cff888888—|r"
        local bOoc = (order.buyerOOC  and order.buyerOOC  ~= "") and order.buyerOOC  or "|cff888888—|r"
        InfoLine("IC Seller: "..sIc)
        InfoLine("OOC Seller: "..sOoc, 0.55, 0.75, 0.55)
        InfoLine("IC Buyer: "..bIc)
        InfoLine("OOC Buyer: "..bOoc, 0.55, 0.75, 0.55)
        if order.deliveryNote and order.deliveryNote ~= "" then InfoLine("Delivery: "..order.deliveryNote) end

        -- Assignment line (prominent if in progress)
        if isAssigned then
            local assignText
            if isComplete then
                assignText = "Completed by: |cffFFD700"..order.assignedTo.."|r"
            else
                assignText = "Working on it: |cffFFD700"..order.assignedTo.."|r"
                if order.estimatedMinutes > 0 then
                    assignText = assignText.."  (Est. "..order.estimatedMinutes.." min)"
                end
            end
            InfoLine(assignText, isComplete and 0.4 or 0.9, isComplete and 0.8 or 0.85, isComplete and 0.4 or 0.4)
        end
        if eta then InfoLine(eta, 1, 1, 1) end
        local canSeeStatus = isMine or isOwner
        local canReopen   = isOwner or SK.DB:CanReopenOrders(shopName)

        -- Delete button — top-right corner of the row
        local delOrdTop = CreateFrame("Button",nil,row,"UIPanelButtonTemplate")
        delOrdTop:SetSize(52,18); delOrdTop:SetPoint("TOPRIGHT",-2,-2)
        delOrdTop:SetText("Delete")
        do local oid=order.id
            delOrdTop:SetScript("OnClick",function()
                SK.DB:DeleteOrder(shopName,oid)
                if SK.Net then SK.Net:BroadcastOrderDelete(shopName, oid) end
                M:SwitchTab("orders")
            end)
        end

        -- Note button — shown when the order has a delivery note
        if order.notes and order.notes ~= "" then
            local noteBtn = CreateFrame("Button",nil,row,"UIPanelButtonTemplate")
            noteBtn:SetSize(22,18); noteBtn:SetPoint("RIGHT",delOrdTop,"LEFT",-4,0)
            noteBtn:SetText("!")
            local noteText = order.notes
            noteBtn:SetScript("OnEnter",function(s)
                GameTooltip:SetOwner(s,"ANCHOR_BOTTOM")
                GameTooltip:AddLine("Additional Note",1,0.82,0,1)
                GameTooltip:AddLine(noteText,1,1,1,true)
                GameTooltip:Show()
            end)
            noteBtn:SetScript("OnLeave",function() GameTooltip:Hide() end)
        end

        -- Status dropdown — WoW UIDropDownMenu, anchored inside the row
        local CLAIM_W   = 80
        local VIEW_W    = 90   -- "View Order" button
        local STATUS_OPTS = {
            {key="open",        label="Open"},
            {key="in_progress", label="In Progress"},
            {key="ready",       label="Ready"},
            {key="complete",    label="Complete"},
        }
        local function GetStatusLabel(k)
            for _, s in ipairs(STATUS_OPTS) do if s.key==k then return s.label end end
            return k
        end
        local canChangeStatus = canSeeStatus and (isMine or isOwner) and not isComplete
        -- Status DD: fixed compact width (enough for "In Progress" + chrome)
        local DD_TEXT_W = 110
        local statusDD = CreateFrame("Frame","SK_OrdDD_"..order.id,row,"UIDropDownMenuTemplate")
        statusDD:SetPoint("BOTTOMLEFT", 4-16, 6)
        UIDropDownMenu_SetWidth(statusDD, DD_TEXT_W)
        UIDropDownMenu_SetText(statusDD, GetStatusLabel(order.status))
        if canChangeStatus then
            UIDropDownMenu_Initialize(statusDD, function(self, level)
                for _, sb in ipairs(STATUS_OPTS) do
                    local info = UIDropDownMenu_CreateInfo()
                    info.text    = sb.label
                    info.value   = sb.key
                    info.checked = (order.status == sb.key)
                    info.func    = function(btn)
                        local oid2 = order.id
                        SK.DB:UpdateOrderStatus(shopName, oid2, btn.value)
                        UIDropDownMenu_SetText(statusDD, GetStatusLabel(btn.value))
                        local shop2 = SK.DB:GetShop(shopName)
                        if shop2 and SK.Net then
                            for _, o in ipairs(shop2.orders) do
                                if o.id == oid2 then SK.Net:BroadcastOrder(shopName, o); break end
                            end
                        end
                        if SK:Cfg().notifyOrderStatus ~= false then
                            print("|cffFFD700[SK]|r Order #"..oid2.." -> "..btn.value)
                        end
                        M:SwitchTab("orders")
                    end
                    UIDropDownMenu_AddButton(info, level)
                end
            end)
        else
            UIDropDownMenu_Initialize(statusDD, function(self, level)
                local info = UIDropDownMenu_CreateInfo()
                info.text = GetStatusLabel(order.status)
                info.notCheckable = true; info.disabled = true
                UIDropDownMenu_AddButton(info, level)
            end)
            if statusDD.Button then statusDD.Button:SetEnabled(false) end
        end

        -- View Order button — always visible, opens item checklist popup
        local viewBtn = CreateFrame("Button",nil,row,"UIPanelButtonTemplate")
        viewBtn:SetSize(VIEW_W, 22)
        viewBtn:SetPoint("BOTTOMRIGHT", -(CLAIM_W+8), 6)
        viewBtn:SetText("View Order")
        do
            local capturedOrder = order
            local capturedShop  = shopName
            viewBtn:SetScript("OnClick", function()
                -- Close any existing popup
                if _G["SK_ViewOrderPopup"] then _G["SK_ViewOrderPopup"]:Hide() end

                local pop = CreateFrame("Frame","SK_ViewOrderPopup",UIParent,"BackdropTemplate")
                pop:SetSize(340, math.min(60 + #capturedOrder.items * 26 + 20, 480))
                pop:SetPoint("CENTER", UIParent, "CENTER", 0, 40)
                pop:SetFrameStrata("DIALOG"); pop:SetFrameLevel(120)
                pop:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
                pop:SetBackdropColor(0.06,0.07,0.11,0.97)
                pop:SetBackdropBorderColor(0.8,0.65,0.2,1)
                pop:EnableMouse(true); pop:SetMovable(true)
                pop:RegisterForDrag("LeftButton")
                pop:SetScript("OnDragStart",function(s) s:StartMoving() end)
                pop:SetScript("OnDragStop", function(s) s:StopMovingOrSizing() end)

                -- Title
                local title = pop:CreateFontString(nil,"OVERLAY","GameFontNormal")
                title:SetPoint("TOPLEFT",12,-10)
                title:SetText("|cffFFD700Order #"..capturedOrder.id.."|r  —  "..table.concat({"Items"},", "))
                title:SetText("|cffFFD700Order #"..capturedOrder.id.."|r  —  All Items")

                -- Close button
                local closeBtn = CreateFrame("Button",nil,pop,"UIPanelButtonTemplate")
                closeBtn:SetSize(22,18); closeBtn:SetPoint("TOPRIGHT",-4,-4)
                closeBtn:SetText("X"); closeBtn:SetScript("OnClick",function() pop:Hide() end)

                -- Scroll frame for items
                local sf2 = CreateFrame("ScrollFrame",nil,pop,"UIPanelScrollFrameTemplate")
                sf2:SetPoint("TOPLEFT",8,-30); sf2:SetPoint("BOTTOMRIGHT",-26,8)
                local sc2 = CreateFrame("Frame",nil,sf2)
                sc2:SetWidth(sf2:GetWidth()-4); sc2:SetHeight(1); sf2:SetScrollChild(sc2)

                local canCheck = (capturedOrder.assignedTo == myName)
                local cy = 0
                capturedOrder.checkedItems = capturedOrder.checkedItems or {}

                for i, e in ipairs(capturedOrder.items) do
                    local dn = e.product.name..(e.variant and e.variant.name~="" and (" ("..e.variant.name..")") or "")
                    local label = e.qty.."x  "..dn

                    local itemRow = CreateFrame("Frame",nil,sc2,"BackdropTemplate")
                    itemRow:SetSize(sc2:GetWidth(), 22)
                    itemRow:SetPoint("TOPLEFT",0,-cy)

                    local cb = CreateFrame("CheckButton",nil,itemRow,"UICheckButtonTemplate")
                    cb:SetSize(20,20); cb:SetPoint("LEFT",2,0)
                    cb:SetChecked(capturedOrder.checkedItems[i] == true)
                    cb:SetEnabled(canCheck)
                    if not canCheck then cb:SetAlpha(0.5) end

                    local lbl2 = itemRow:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
                    lbl2:SetPoint("LEFT",cb,"RIGHT",4,0)
                    lbl2:SetPoint("RIGHT",itemRow,"RIGHT",-4,0)
                    lbl2:SetJustifyH("LEFT")
                    lbl2:SetText(label)
                    if capturedOrder.checkedItems[i] then
                        lbl2:SetTextColor(0.4,0.8,0.4,1)
                    else
                        lbl2:SetTextColor(0.85,0.85,0.85,1)
                    end

                    if canCheck then
                        local idx = i
                        cb:SetScript("OnClick",function(s)
                            local checked = s:GetChecked()
                            SK.DB:SetOrderItemChecked(capturedShop, capturedOrder.id, idx, checked)
                            capturedOrder.checkedItems = capturedOrder.checkedItems or {}
                            capturedOrder.checkedItems[idx] = checked or nil
                            lbl2:SetTextColor(checked and 0.4 or 0.85, checked and 0.8 or 0.85, checked and 0.4 or 0.85, 1)
                        end)
                    end

                    -- Subtle zebra stripe
                    if i % 2 == 0 then
                        itemRow:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8"})
                        itemRow:SetBackdropColor(1,1,1,0.04)
                    end

                    cy = cy + 22
                end
                sc2:SetHeight(math.max(cy, 10))
                pop:SetHeight(math.min(cy + 50, 480))
                pop:Show()
            end)
        end
        viewBtn:SetScript("OnEnter",function(s)
            GameTooltip:SetOwner(s,"ANCHOR_TOP")
            GameTooltip:AddLine("View Order",1,1,1)
            GameTooltip:AddLine("See all items. If you claimed this order,\nyou can tick items off as you prepare them.",0.7,0.7,0.7)
            GameTooltip:Show()
        end)
        viewBtn:SetScript("OnLeave",function() GameTooltip:Hide() end)

        -- Claim / Release button (WoW UIPanelButtonTemplate)
        local claimBtn=CreateFrame("Button",nil,row,"UIPanelButtonTemplate")
        claimBtn:SetSize(CLAIM_W,22)
        claimBtn:SetPoint("BOTTOMRIGHT",-4,6)

        if isComplete then
            if canReopen then
                -- Owner/permitted manager can reopen a completed order
                claimBtn:SetText("Reopen")
                local oid=order.id
                claimBtn:SetScript("OnClick",function()
                    SK.DB:UpdateOrderStatus(shopName,oid,"open")
                    SK.DB:UnclaimOrder(shopName,oid)
                    local shop2=SK.DB:GetShop(shopName)
                    if shop2 and SK.Net then
                        for _,o in ipairs(shop2.orders) do
                            if o.id==oid then SK.Net:BroadcastOrder(shopName,o); break end
                        end
                    end
                    M:SwitchTab("orders")
                end)
            else
                claimBtn:SetText("Completed")
                claimBtn:SetEnabled(false)
                claimBtn:SetAlpha(0.4)
            end
        elseif isMine then
            -- I hold it — show Release
            claimBtn:SetText("Release")
            local oid=order.id
            claimBtn:SetScript("OnClick",function()
                SK.DB:UnclaimOrder(shopName,oid)
                local shop2 = SK.DB:GetShop(shopName)
                if shop2 and SK.Net then
                    for _, o in ipairs(shop2.orders) do
                        if o.id == oid then SK.Net:BroadcastOrder(shopName, o); break end
                    end
                end
                M:SwitchTab("orders")
            end)
        elseif isAssigned then
            -- Someone else holds it — greyed out
            claimBtn:SetText("Claimed")
            claimBtn:SetEnabled(false)
            claimBtn:SetAlpha(0.5)
        else
            -- Free to claim — clicking Claim opens a popup for delivery estimate
            claimBtn:SetText("Claim")

            local oid = order.id
            claimBtn:SetScript("OnClick", function()
                -- Build a small popup dialog for the delivery estimate
                local popup = CreateFrame("Frame", "SK_ClaimPopup_"..oid, UIParent, "BackdropTemplate")
                popup:SetSize(260, 120)
                popup:SetPoint("CENTER", UIParent, "CENTER", 0, 80)
                popup:SetFrameStrata("DIALOG")
                popup:SetFrameLevel(100)
                popup:SetBackdrop({
                    bgFile   = "Interface\\Buttons\\WHITE8X8",
                    edgeFile = "Interface\\Buttons\\WHITE8X8",
                    edgeSize = 1,
                })
                popup:SetBackdropColor(0.06, 0.07, 0.11, 0.97)
                popup:SetBackdropBorderColor(0.8, 0.65, 0.2, 1)
                popup:EnableMouse(true)
                popup:SetMovable(true)
                popup:RegisterForDrag("LeftButton")
                popup:SetScript("OnDragStart", function(s) s:StartMoving() end)
                popup:SetScript("OnDragStop",  function(s) s:StopMovingOrSizing() end)

                -- Title
                local title = popup:CreateFontString(nil, "OVERLAY", "GameFontNormal")
                title:SetPoint("TOP", 0, -10)
                title:SetText("Claim Order #"..oid)
                title:SetTextColor(1, 0.82, 0, 1)

                -- Label
                local lbl = popup:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                lbl:SetPoint("TOPLEFT", 14, -32)
                lbl:SetText("Delivery Estimate (optional):")
                lbl:SetTextColor(0.75, 0.75, 0.75, 1)

                -- Number input
                local numBox = CreateFrame("EditBox", nil, popup, "InputBoxTemplate")
                numBox:SetSize(46, 20)
                numBox:SetPoint("TOPLEFT", 14, -50)
                numBox:SetAutoFocus(true)
                numBox:SetNumeric(true)
                numBox:SetMaxLetters(4)
                numBox:SetText("")
                numBox:SetScript("OnEscapePressed", function() popup:Hide() end)

                -- Unit cycle button
                local UNITS = {
                    {label="min",  mult=1},
                    {label="hrs",  mult=60},
                    {label="days", mult=1440},
                    {label="wks",  mult=10080},
                }
                local selUnit = 1
                local unitBtn2 = CreateFrame("Button", nil, popup, "UIPanelButtonTemplate")
                unitBtn2:SetSize(42, 20)
                unitBtn2:SetPoint("LEFT", numBox, "RIGHT", 4, 0)
                unitBtn2:SetText(UNITS[selUnit].label)
                unitBtn2:SetScript("OnClick", function()
                    selUnit = (selUnit % #UNITS) + 1
                    unitBtn2:SetText(UNITS[selUnit].label)
                end)
                unitBtn2:SetScript("OnEnter", function(s)
                    GameTooltip:SetOwner(s, "ANCHOR_TOP")
                    GameTooltip:AddLine("Click to change unit", 1, 1, 1)
                    GameTooltip:AddLine("min / hrs / days / wks", 0.7, 0.7, 0.7)
                    GameTooltip:Show()
                end)
                unitBtn2:SetScript("OnLeave", function() GameTooltip:Hide() end)

                -- Hint text
                local hint = popup:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                hint:SetPoint("LEFT", unitBtn2, "RIGHT", 6, 0)
                hint:SetText("|cff888888Leave blank to skip|r")

                -- Confirm button
                local confirmBtn = CreateFrame("Button", nil, popup, "UIPanelButtonTemplate")
                confirmBtn:SetSize(100, 22)
                confirmBtn:SetPoint("BOTTOMRIGHT", -10, 8)
                confirmBtn:SetText("Confirm Claim")
                confirmBtn:SetScript("OnClick", function()
                    local val = tonumber(numBox:GetText()) or 0
                    local mins = val * UNITS[selUnit].mult
                    local shop2 = SK.DB:GetShop(shopName)
                    local ok, err = SK.DB:ClaimOrder(shopName, oid, myName, mins)
                    popup:Hide()
                    if ok then
                        if shop2 and SK.Net then
                            for _, o in ipairs(shop2.orders) do
                                if o.id == oid then SK.Net:BroadcastOrder(shopName, o); break end
                            end
                            SK.Net:BroadcastClaimNotice(shopName, oid, myName, mins)
                        end
                        local estStr = mins > 0 and " (Delivery Estimate: "..mins.." min)" or ""
                        print("|cffFFD700[SK]|r Order #"..oid.." claimed"..estStr..".")
                        M:SwitchTab("orders")
                    else
                        print("|cffFFD700[SK]|r "..(err or "Could not claim."))
                    end
                end)
                numBox:SetScript("OnEnterPressed", function() confirmBtn:Click() end)

                -- Cancel button
                local cancelBtn = CreateFrame("Button", nil, popup, "UIPanelButtonTemplate")
                cancelBtn:SetSize(60, 22)
                cancelBtn:SetPoint("BOTTOMLEFT", 10, 8)
                cancelBtn:SetText("Cancel")
                cancelBtn:SetScript("OnClick", function() popup:Hide() end)

                popup:Show()
            end)
            claimBtn:SetScript("OnEnter", function()
                GameTooltip:SetOwner(claimBtn, "ANCHOR_TOP")
                GameTooltip:AddLine("Claim this order", 1, 1, 1)
                GameTooltip:AddLine("Opens a window to set a delivery estimate.", 0.7, 0.7, 0.7)
                GameTooltip:Show()
            end)
            claimBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
        end

        -- (Delete button now at top-right corner — see delOrdTop above)

        yo=yo+rh+10
    end
    sc:SetHeight(math.max(yo,30))
end

-- ─── LOGS TAB ─────────────────────────────────────────────────────────────────

function M:BuildLogsTab()
    WipeContent()
    local p = GetContentPanel()
    if not p then return end  -- content panel not ready (can happen during tab switch)
    local pw = p:GetWidth()-PAD*2
    local shopName = SK.db and SK.db.activeShop
    if not shopName then local l=Track(FS(p,"No shop active.",11,0.65,0.65,0.65)); l:SetPoint("CENTER"); return end
    if not SK.DB:CanViewLogs(shopName) then
        local l=Track(FS(p,"|cff888888You do not have permission to view the activity log.|r",10,0.6,0.6,0.6))
        l:SetPoint("CENTER"); return
    end

    -- Filter tabs
    local FILTERS = {
        {key="all",      label="All"},
        {key="treasury", label="Treasury"},
        {key="order",    label="Orders"},
        {key="tab",      label="Tabs"},
        {key="product",  label="Products"},
        {key="staff",    label="Staff"},
    }
    M._logFilter = M._logFilter or "all"

    local TAB_H = 24
    local CLEAR_W = 62  -- width reserved for the Clear button
    local tabW  = math.floor((pw - CLEAR_W - 4) / #FILTERS)
    local filterBtns = {}
    for i, ft in ipairs(FILTERS) do
        local fb=Track(CreateFrame("Button",nil,p,"BackdropTemplate"))
        fb:SetSize(tabW,TAB_H); fb:SetPoint("TOPLEFT",PAD+(i-1)*tabW,-PAD)
        fb:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
        local lbl=fb:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); lbl:SetAllPoints()
        lbl:SetText(ft.label); lbl:SetJustifyH("CENTER")
        fb.key=ft.key; fb.lbl=lbl
        tinsert(filterBtns, fb)
        local function Refresh()
            for _, b in ipairs(filterBtns) do
                local on=(b.key==M._logFilter)
                b:SetBackdropColor(on and 0.12 or 0.06, on and 0.12 or 0.06, on and 0.18 or 0.10, 1)
                b:SetBackdropBorderColor(on and 0.5 or 0.25, on and 0.38 or 0.25, on and 0.10 or 0.10, 1)
                b.lbl:SetTextColor(on and 1 or 0.65, on and 0.82 or 0.65, on and 0 or 0.65, 1)
            end
        end
        fb:SetScript("OnClick",function()
            M._logFilter = ft.key
            M:SwitchTab("logs")  -- go through SwitchTab so content panel is always valid
        end)
        Refresh()
    end

    -- Clear All — sits in the filter tab row at the far right, raised above scroll content
    local clearAllBtn=Track(Btn(p,"Clear",58,TAB_H))
    clearAllBtn:SetPoint("TOPRIGHT",-PAD,-PAD)
    clearAllBtn:SetFrameLevel(clearAllBtn:GetFrameLevel()+10)
    clearAllBtn:SetScript("OnClick",function()
        SK.DB:ClearLogs(shopName)
        M:SwitchTab("logs")
    end)

    -- Scroll frame below filter tabs
    local sf=Track(CreateFrame("ScrollFrame",nil,p,"UIPanelScrollFrameTemplate"))
    sf:SetPoint("TOPLEFT",PAD,-(PAD+TAB_H+8))
    sf:SetPoint("BOTTOMRIGHT",-PAD-18,PAD)
    local sc=CreateFrame("Frame",nil,sf); sc:SetWidth(sf:GetWidth()-4); sc:SetHeight(1); sf:SetScrollChild(sc)

    local logs=SK.DB:GetLogs(shopName)
    -- Filter
    local filtered={}
    for i=#logs,1,-1 do
        local log=logs[i]
        if M._logFilter=="all" or (log.category or "system")==M._logFilter then
            tinsert(filtered, {entry=log, idx=i})
        end
    end

    if #filtered==0 then
        local nl=sc:CreateFontString(nil,"OVERLAY","GameFontDisable")
        nl:SetPoint("TOPLEFT",4,-10); nl:SetText("No entries for this filter."); sc:SetHeight(30); return
    end

    -- Color per category
    local CAT_COLOR = {
        treasury={1,0.82,0.2},  order={0.4,0.8,1},  product={0.6,1,0.6},
        staff={1,0.6,0.8},      system={0.6,0.6,0.6},  tab={1,0.7,0.3},
    }

    local yo,rh=0,20
    for _, item in ipairs(filtered) do
        local log=item.entry; local realIdx=item.idx
        local col=CAT_COLOR[log.category or "system"] or {0.6,0.6,0.6}
        local row=CreateFrame("Frame",nil,sc); row:SetSize(sc:GetWidth(),rh); row:SetPoint("TOPLEFT",0,-yo)
        local catDot=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        catDot:SetPoint("LEFT",2,0); catDot:SetSize(8,rh)
        catDot:SetText("•"); catDot:SetTextColor(col[1],col[2],col[3],1)
        local txt=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        txt:SetPoint("LEFT",14,0); txt:SetPoint("RIGHT",row,"RIGHT",-22,0); txt:SetHeight(rh)
        txt:SetJustifyV("MIDDLE"); txt:SetNonSpaceWrap(false)
        txt:SetText("|cff777777"..date("[%d/%m %H:%M]",log.timestamp).."|r  "..log.message)
        local xBtn=CreateFrame("Button",nil,row); xBtn:SetSize(16,16); xBtn:SetPoint("RIGHT",-2,0)
        local xTex=xBtn:CreateTexture(nil,"ARTWORK"); xTex:SetAllPoints()
        xTex:SetTexture("Interface\\Buttons\\UI-StopButton"); xTex:SetTexCoord(0.15,0.85,0.15,0.85)
        xTex:SetVertexColor(0.6,0.2,0.2,1)
        xBtn:SetScript("OnEnter",function() xTex:SetVertexColor(1,0.3,0.3,1) end)
        xBtn:SetScript("OnLeave",function() xTex:SetVertexColor(0.6,0.2,0.2,1) end)
        xBtn:SetScript("OnClick",function() SK.DB:DeleteLog(shopName,realIdx); M:BuildLogsTab() end)
        yo=yo+rh
    end
    sc:SetHeight(math.max(yo,30))
end

-- ─── SHOPS TAB ────────────────────────────────────────────────────────────────

function M:BuildShopsTab()
    WipeContent()
    local p0 = GetContentPanel(); local pw0 = p0:GetWidth()-PAD*2

    -- Wrap in scroll frame
    local sf = Track(CreateFrame("ScrollFrame", nil, p0, "UIPanelScrollFrameTemplate"))
    sf:SetPoint("TOPLEFT", PAD, -PAD); sf:SetPoint("BOTTOMRIGHT", -PAD-16, PAD)
    local sc = CreateFrame("Frame", nil, sf)
    sc:SetWidth(sf:GetWidth()-4); sc:SetHeight(1); sf:SetScrollChild(sc)
    local p = sc
    local pw = sc:GetWidth()-PAD*2
    local myName = UnitName("player") or ""
    local shops = SK.DB:GetAllShops()
    local activeShop = SK.db.activeShop
    local activeData = activeShop and SK.DB:GetShop(activeShop)
    local isOwner   = activeShop and SK.DB:GetRole(activeShop, myName) == "owner"
    local isManager = activeShop and SK.DB:IsManager(activeShop, myName)
    local canTreasury = activeShop and SK.DB:CanTreasury(activeShop, myName)

    -- ── Section header ─────────────────────────────────────────────────
    Track(FS(p,"Shop(s) Overview",13,1,0.82,0)):SetPoint("TOPLEFT",PAD,-PAD)
    Track(HLine(p,-(PAD+18)))
    local yo = -(PAD+26)

    -- ── Active Shop dropdown ────────────────────────────────────────────
    Track(FS(p,"Active Shop",9,0.7,0.7,0.7)):SetPoint("TOPLEFT",PAD,yo); yo=yo-14

    local shopDD=Track(CreateFrame("Frame","SK_ActiveShopDD",p,"UIDropDownMenuTemplate"))
    shopDD:SetPoint("TOPLEFT",PAD-16,yo+4)
    UIDropDownMenu_SetWidth(shopDD, pw-24)
    UIDropDownMenu_SetText(shopDD, activeShop or "-- Select a shop --")
    UIDropDownMenu_Initialize(shopDD, function(self, level)
        if #shops==0 then
            local info=UIDropDownMenu_CreateInfo()
            info.text="|cff666666No shops yet|r"; info.notCheckable=true
            UIDropDownMenu_AddButton(info,level); return
        end
        for _,entry in ipairs(shops) do
            local info=UIDropDownMenu_CreateInfo()
            local isAct=(entry.name==activeShop)
            info.text    = (isAct and "|cffFFD700>> |r" or "")..entry.name
            info.value   = entry.name
            info.checked = isAct
            info.func    = function(btn)
                SK.DB:SetActiveShop(btn.value)
                UIDropDownMenu_SetText(shopDD, btn.value)
                M:SwitchTab("shops")
                if SK.Register then SK.Register:RefreshShopLabel(); SK.Register:BuildProductGrid(); SK.Register:ClearCart() end
            end
            UIDropDownMenu_AddButton(info,level)
        end
    end)
    yo=yo-30

    -- ── Create new shop ────────────────────────────────────────────────
    local newRow=Track(CreateFrame("Frame",nil,p)); newRow:SetSize(pw,24); newRow:SetPoint("TOPLEFT",PAD,yo)
    local ni=Box(newRow,pw-82,20); ni:SetPoint("LEFT",0,0)
    local nHint=newRow:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    nHint:SetPoint("LEFT",ni,"LEFT",4,0); nHint:SetText("New shop name..."); nHint:SetTextColor(0.35,0.35,0.35,1)
    ni:SetScript("OnTextChanged",function(s) nHint:SetShown(s:GetText()=="") end)
    local ncb=Btn(newRow,"Create",76,22); ncb:SetPoint("RIGHT",0,0)
    ncb:SetScript("OnClick",function()
        local name=strtrim(ni:GetText() or "")
        if name=="" then print("|cffFFD700[SK]|r Name required."); return end
        local ok,err=SK.DB:CreateShop(name)
        if ok then ni:SetText(""); M:SwitchTab("shops")
        else print("|cffFFD700[SK]|r "..(err or "Error.")) end
    end)
    yo=yo-32

    if not activeShop or not activeData then
        Track(FS(p,"Select or create a shop above.",10,0.55,0.55,0.55)):SetPoint("TOPLEFT",PAD,yo)
        sc:SetHeight(math.max(math.abs(yo)+60,200))
        return
    end

    Track(HLine(p,yo-4)); yo=yo-16
    SK.DB:MigrateShop(activeData)

    -- ── Shop details + Rename ──────────────────────────────────────────
    Track(FS(p,"|cffFFD700"..activeShop.."|r",12)):SetPoint("TOPLEFT",PAD,yo)

    if isOwner then
        -- Rename inline
        local renameInp = Track(Box(p, pw-120, 20))
        renameInp:SetPoint("TOPLEFT", PAD, yo-20)
        renameInp:SetText(activeShop)
        local renameHint = p:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        renameHint:SetPoint("LEFT",renameInp,"LEFT",4,0)
        renameHint:SetText("New shop name..."); renameHint:SetTextColor(0.35,0.35,0.35,1)
        renameInp:SetScript("OnTextChanged",function(s) renameHint:SetShown(s:GetText()=="" or s:GetText()==activeShop) end)
        local renameBtn = Track(Btn(p,"Rename",72,20)); renameBtn:SetPoint("LEFT",renameInp,"RIGHT",4,0)
        renameBtn:SetScript("OnClick",function()
            local newName = strtrim(renameInp:GetText() or "")
            if newName=="" or newName==activeShop then return end
            local ok, err = SK.DB:RenameShop(activeShop, newName)
            if ok then
                M:SwitchTab("shops")
                if SK.Register then SK.Register:RefreshShopLabel() end
            else print("|cffFFD700[SK]|r "..(err or "Error.")) end
        end)
        yo=yo-46
    else
        Track(FS(p,"Owner: |cffFFD700"..activeData.owner.."|r  —  Your role: "..(SK.DB:GetRole(activeShop,myName) or "?"),9,0.7,0.7,0.7)):SetPoint("TOPLEFT",PAD,yo-18)
        yo=yo-36
    end

    -- Staff summary
    local staffLbl=Track(FS(p,"Managers: "..#(activeData.managers or {}).."  |  Employees: "..#(activeData.employees or {}),9,0.6,0.6,0.6))
    staffLbl:SetPoint("TOPLEFT",PAD,yo); yo=yo-20

    -- ── Staff overview (plain read-only list) ──────────────────────────
    Track(HLine(p,yo)); yo=yo-12
    Track(FS(p,"Staff",11,1,0.82,0)):SetPoint("TOPLEFT",PAD,yo); yo=yo-18

    -- Owner
    local ownerRow=Track(CreateFrame("Frame",nil,p,"BackdropTemplate"))
    ownerRow:SetHeight(22); ownerRow:SetPoint("TOPLEFT",PAD,yo); ownerRow:SetPoint("TOPRIGHT",-PAD,yo)
    ownerRow:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    ownerRow:SetBackdropColor(0,0,0,0.15); ownerRow:SetBackdropBorderColor(0.5,0.38,0.10,0.4)
    local ownerBadge=ownerRow:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); ownerBadge:SetPoint("LEFT",4,0)
    ownerBadge:SetText("|cffFFD700[Owner]|r  "..(SK.DB:GetOwnerDisplay(activeData.name or "") ~= "?" and SK.DB:GetOwnerDisplay(activeData.name or "") or (activeData.owner or "")))
    yo=yo-24

    for _,name in ipairs(activeData.managers or {}) do
        local mr=Track(CreateFrame("Frame",nil,p,"BackdropTemplate")); mr:SetHeight(20)
        mr:SetPoint("TOPLEFT",PAD,yo); mr:SetPoint("TOPRIGHT",-PAD,yo)
        mr:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
        mr:SetBackdropColor(0,0,0,0.10); mr:SetBackdropBorderColor(0.35,0.28,0.10,0.3)
        local ml=mr:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); ml:SetPoint("LEFT",4,0)
        ml:SetText("|cffFFCC55[Mgr]|r  "..name)
        yo=yo-22
    end
    for _,name in ipairs(activeData.employees or {}) do
        local er=Track(CreateFrame("Frame",nil,p,"BackdropTemplate")); er:SetHeight(20)
        er:SetPoint("TOPLEFT",PAD,yo); er:SetPoint("TOPRIGHT",-PAD,yo)
        er:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
        er:SetBackdropColor(0,0,0,0.10); er:SetBackdropBorderColor(0.25,0.22,0.10,0.25)
        local el=er:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); el:SetPoint("LEFT",4,0)
        el:SetText("|cff888888[Emp]|r  "..name)
        yo=yo-22
    end
    if #(activeData.managers or{})==0 and #(activeData.employees or{})==0 then
        Track(FS(p,"No staff yet.",9,0.45,0.45,0.45)):SetPoint("TOPLEFT",PAD+4,yo); yo=yo-18
    end

    -- ── Treasury (view only) ──────────────────────────────────────────
    Track(HLine(p,yo-4)); yo=yo-16
    Track(FS(p,"Treasury",11,1,0.82,0)):SetPoint("TOPLEFT",PAD,yo); yo=yo-20

    local treasStr = SK:FormatMoneyPlain(activeData.treasury or 0)
    local tLbl=Track(FS(p,treasStr,13,1,0.88,0.35)); tLbl:SetPoint("TOPLEFT",PAD,yo)
    Track(FS(p,"|cff555555View only. Use the Management tab to deposit or withdraw.|r",9)):SetPoint("TOPLEFT",PAD,yo-18)
    yo=yo-36

    -- ── Export / Import ────────────────────────────────────────────────
    Track(HLine(p,yo-4)); yo=yo-16
    Track(FS(p,"Export / Import",11,1,0.82,0)):SetPoint("TOPLEFT",PAD,yo); yo=yo-18
    Track(FS(p,"Share shop data (products, categories, discounts) with others.",9,0.6,0.6,0.6)):SetPoint("TOPLEFT",PAD,yo); yo=yo-18

    -- Export button
    if isManager then
        local expBtn=Track(Btn(p,"Export Shop Code",140,24)); expBtn:SetPoint("TOPLEFT",PAD,yo)
        expBtn:SetScript("OnClick",function()
            local code, err = SK.DB:ExportShop(activeShop)
            if not code then print("|cffFFD700[SK]|r Export failed: "..(err or "?")); return end
            -- Show code in a copyable popup
            if not _G.SKExportFrame then
                local ef = CreateFrame("Frame","SKExportFrame",UIParent,"BackdropTemplate")
                ef:SetSize(500,120); ef:SetPoint("CENTER")
                ef:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\DialogFrame\\UI-DialogBox-Gold-Border",edgeSize=24,insets={left=6,right=6,top=6,bottom=6}})
                ef:SetBackdropColor(0.05,0.06,0.10,0.98); ef:SetBackdropBorderColor(1,1,1,1)
                ef:SetMovable(true); ef:EnableMouse(true); ef:RegisterForDrag("LeftButton")
                ef:SetScript("OnDragStart",ef.StartMoving); ef:SetScript("OnDragStop",ef.StopMovingOrSizing)
                ef:SetFrameStrata("DIALOG")
                local title=ef:CreateFontString(nil,"OVERLAY","GameFontNormal")
                title:SetPoint("TOPLEFT",10,-10); title:SetText("|cffFFD700Shop Export Code|r  — Copy and share this on Discord")
                local eb=CreateFrame("EditBox",nil,ef,"InputBoxTemplate")
                eb:SetSize(480,28); eb:SetPoint("TOPLEFT",10,-30)
                eb:SetAutoFocus(true); eb:SetMaxLetters(0)
                ef.editbox=eb
                local closeBtn=CreateFrame("Button",nil,ef,"UIPanelCloseButton"); closeBtn:SetSize(26,26); closeBtn:SetPoint("TOPRIGHT",-2,0)
                closeBtn:SetScript("OnClick",function() ef:Hide() end)
                local copyHint=ef:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
                copyHint:SetPoint("TOPLEFT",10,-62); copyHint:SetText("|cff888888Press Ctrl+A then Ctrl+C to copy the code.|r")
                tinsert(UISpecialFrames,"SKExportFrame")
            end
            _G.SKExportFrame.editbox:SetText(code)
            _G.SKExportFrame.editbox:SetFocus()
            _G.SKExportFrame.editbox:HighlightText()
            _G.SKExportFrame:Show()
        end)
        expBtn:SetScript("OnEnter",function(s) GameTooltip:SetOwner(s,"ANCHOR_TOP"); GameTooltip:AddLine("Export shop data as a shareable code",1,1,1); GameTooltip:Show() end)
        expBtn:SetScript("OnLeave",function() GameTooltip:Hide() end)
        yo=yo-32
    end

    -- Import row
    local importRow=Track(CreateFrame("Frame",nil,p)); importRow:SetSize(pw,24); importRow:SetPoint("TOPLEFT",PAD,yo)
    local importInp=Box(importRow,pw-96,20); importInp:SetPoint("LEFT",0,0)
    local importHint=importRow:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    importHint:SetPoint("LEFT",importInp,"LEFT",4,0); importHint:SetText("Paste export code here..."); importHint:SetTextColor(0.35,0.35,0.35,1)
    importInp:SetScript("OnTextChanged",function(s) importHint:SetShown(s:GetText()=="") end)
    local importBtn=Btn(importRow,"Import",90,22); importBtn:SetPoint("RIGHT",0,0)
    importBtn:SetScript("OnClick",function()
        local code=strtrim(importInp:GetText() or "")
        if code=="" then return end
        local ok,result=SK.DB:ImportShop(activeShop,code)
        if ok then
            importInp:SetText("")
            print("|cffFFD700[SK]|r Import successful! "..tostring(result).." products added.")
            M:SwitchTab("shops")
            if SK.Register and SK.Register.BuildProductGrid then SK.Register:BuildProductGrid() end
        else print("|cffFFD700[SK]|r Import failed: "..(result or "Unknown error.")) end
    end)
    yo=yo-34

    -- ── Sync / Delete / Leave ──────────────────────────────────────────
    yo=yo-6; Track(HLine(p,yo)); yo=yo-14
    if activeShop and SK.Net then
        local syncBtn = Track(Btn(p, "Request Sync", 120, 26))
        syncBtn:SetPoint("TOPLEFT", PAD, yo)
        syncBtn:SetScript("OnClick", function()
            SK.Net:RequestSync(activeShop)
            print("|cffFFD700[SK]|r Sync requested for |cffFFD700"..activeShop.."|r.")
        end)
        syncBtn:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:AddLine("Request a full sync from the shop owner.", 1, 1, 1)
            GameTooltip:AddLine("Auto-sync runs on login; use this if data seems out of date.", 0.7, 0.7, 0.7)
            GameTooltip:Show()
        end)
        syncBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    end
    if isOwner then
        local delBtn=Track(Btn(p,"Delete This Shop",140,26)); delBtn:SetPoint("TOPLEFT",PAD+128,yo)
        delBtn:SetScript("OnClick",function()
            if SK.Net then SK.Net:BroadcastShopDelete(activeShop) end
            SK.DB:DeleteShop(activeShop); M:SwitchTab("shops")
        end)
    else
        local leaveBtn=Track(Btn(p,"Leave This Shop",140,26)); leaveBtn:SetPoint("TOPLEFT",PAD+128,yo)
        leaveBtn:SetScript("OnClick",function()
            if SK.Net then SK.Net:Leave(activeShop) end
            M:SwitchTab("shops")
        end)
    end
    sc:SetHeight(math.max(math.abs(yo) + 60, 400))
end

-- ─── SETTINGS TAB ─────────────────────────────────────────────────────────────

function M:BuildSettingsTab()
    M._settingsSubTab = M._settingsSubTab or "general"
    WipeContent()
    local p   = GetContentPanel()
    local cfg = SK:Cfg()
    local pw  = p:GetWidth() - PAD*2

    -- ── Sub-tab bar ────────────────────────────────────────────────────────
    local SUB_TABS = {
        {key="general",   label="General"},
        {key="responses", label="Responses"},
    }
    local SUB_H = 26
    local subW  = math.floor((pw - PAD) / #SUB_TABS)
    local subBtns = {}
    for i, st in ipairs(SUB_TABS) do
        local sb = Track(CreateFrame("Button",nil,p,"BackdropTemplate"))
        sb:SetSize(subW, SUB_H)
        sb:SetPoint("TOPLEFT", PAD + (i-1)*subW, 0)
        sb:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
        local lbl = sb:CreateFontString(nil,"OVERLAY","GameFontNormal")
        lbl:SetAllPoints(); lbl:SetJustifyH("CENTER"); lbl:SetText(st.label)
        sb.lbl = lbl; sb.key = st.key
        tinsert(subBtns, sb)
    end

    -- Content area below sub-tab bar
    local contentY = -(SUB_H + 4)
    local sf = Track(CreateFrame("ScrollFrame",nil,p,"UIPanelScrollFrameTemplate"))
    sf:SetPoint("TOPLEFT",PAD,contentY); sf:SetPoint("BOTTOMRIGHT",-PAD-18,PAD)
    local regW = SK.Register and SK.Register.mainFrame and SK.Register.mainFrame:GetWidth() or 760
    local spw = regW - 38 - PAD*2 - 8 - 22
    if spw < 100 then spw = 400 end

    -- sc is recreated on every sub-tab switch so FontStrings/Textures (regions,
    -- not Frame children) are properly discarded rather than ghosting behind new content.
    local sc = nil
    local yo = 0

    local function MakeSC()
        if sc then sc:Hide(); sc:SetParent(nil) end
        sc = CreateFrame("Frame", nil, sf)
        sc:SetWidth(spw); sc:SetHeight(1)
        sf:SetScrollChild(sc)
        yo = 0
        cbIdx = 0
    end

    local cbIdx = 0

    local function SH(text)
        local lbl = sc:CreateFontString(nil,"OVERLAY","GameFontNormal")
        lbl:SetFont("Fonts\\FRIZQT__.TTF",10,"OUTLINE")
        lbl:SetPoint("TOPLEFT",0,-yo); lbl:SetText(text); lbl:SetTextColor(1,0.82,0,1)
        local ln = sc:CreateTexture(nil,"ARTWORK"); ln:SetHeight(1)
        ln:SetPoint("TOPLEFT",0,-(yo+14)); ln:SetPoint("TOPRIGHT",0,-(yo+14))
        ln:SetColorTexture(0.55,0.42,0.12,0.5)
        yo = yo + 24
    end

    local function Tog(label, getter, setter)
        cbIdx = cbIdx + 1
        local nm = "SKSet_"..cbIdx.."_"..math.floor(GetTime()*1000)
        local cb = CreateFrame("CheckButton",nm,sc,"ChatConfigCheckButtonTemplate")
        cb:SetSize(24,24); cb:SetPoint("TOPLEFT",0,-yo)
        cb:SetChecked(getter() and true or false)
        cb.Text:SetText(label); cb.Text:SetFont("Fonts\\FRIZQT__.TTF",10,"")
        cb:SetScript("OnClick",function(s) setter(s:GetChecked() and true or false) end)
        yo = yo + 28
    end

    local function Label(text, r,g,b)
        local l = sc:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        l:SetPoint("TOPLEFT",0,-yo); l:SetText(text)
        l:SetTextColor(r or 0.7,g or 0.7,b or 0.7,1)
        yo = yo + 14
        return l
    end

    -- ── Build sub-tab content ─────────────────────────────────────────────
    local function BuildGeneral()
        MakeSC()
        -- ══ NOTIFICATIONS ════════════════════════════════════════════════
        SH("Notifications")
        Tog("Order claimed by staff",
            function() return cfg.notifyOrderClaimed~=false end,
            function(v) cfg.notifyOrderClaimed=v end)
        Tog("Order released / expired",
            function() return cfg.notifyOrderReleased~=false end,
            function(v) cfg.notifyOrderReleased=v end)
        Tog("Order status changed",
            function() return cfg.notifyOrderStatus~=false end,
            function(v) cfg.notifyOrderStatus=v end)
        Tog("New staff member joined",
            function() return cfg.notifyStaffJoined~=false end,
            function(v) cfg.notifyStaffJoined=v end)
        Tog("Sync messages (verbose)",
            function() return cfg.notifySync==true end,
            function(v) cfg.notifySync=v end)
        yo = yo + 6

        -- ══ BEHAVIOUR ════════════════════════════════════════════════════
        SH("Behaviour")
        Tog("Auto-clear cart after confirming an order",
            function() return cfg.autoClearCart~=false end,
            function(v) cfg.autoClearCart=v end)
        Tog("Auto-close category when opening another",
            function() return cfg.autoCloseCategory~=false end,
            function(v) cfg.autoCloseCategory=v end)
        yo = yo + 4

        -- Emote channel dropdown
        yo = yo + 4
        SH("Receipt & Emote")
        Label("Send emote as:")
        local chanDD = CreateFrame("Frame","SK_EmoteChanDD",sc,"UIDropDownMenuTemplate")
        chanDD:SetPoint("TOPLEFT",PAD-16,-yo)
        UIDropDownMenu_SetWidth(chanDD, 160)
        local CHAN_OPTIONS = {
            {key="EMOTE", label="Emote (/emote)"},
            {key="SAY",   label="Say (/say)"},
            {key="PRINT", label="Print to chat only"},
        }
        local function GetChanLabel(key)
            for _, o in ipairs(CHAN_OPTIONS) do
                if o.key == key then return o.label end
            end
            return "Emote (/emote)"
        end
        UIDropDownMenu_SetText(chanDD, GetChanLabel(cfg.emoteChannel or "EMOTE"))
        UIDropDownMenu_Initialize(chanDD, function(self, level)
            for _, o in ipairs(CHAN_OPTIONS) do
                local info = UIDropDownMenu_CreateInfo()
                info.text    = o.label
                info.value   = o.key
                info.func    = function(btn)
                    cfg.emoteChannel = btn.value
                    UIDropDownMenu_SetText(chanDD, o.label)
                end
                info.checked = (cfg.emoteChannel or "EMOTE") == o.key
                UIDropDownMenu_AddButton(info, level)
            end
        end)
        yo = yo + 32
        yo = yo + 4

        -- Seller IC name
        Label("Seller IC name:  |cff666666(saved separately per character — auto-filled from TRP3 on first login)|r")
        local selInp = CreateFrame("EditBox",nil,sc,"InputBoxTemplate")
        selInp:SetSize(spw-8-84,20); selInp:SetPoint("TOPLEFT",PAD+4,-yo); selInp:SetAutoFocus(false)
        selInp:SetScript("OnEscapePressed",function(s) s:ClearFocus() end)
        local saved = SK:GetSavedSellerIC()
        selInp:SetText(saved)
        selInp:SetScript("OnTextChanged",function(s) SK:SetSavedSellerIC(strtrim(s:GetText())) end)
        local trpBtn = CreateFrame("Button",nil,sc,"UIPanelButtonTemplate")
        trpBtn:SetSize(78,20); trpBtn:SetPoint("LEFT",selInp,"RIGHT",4,0)
        trpBtn:SetText("From TRP3")
        trpBtn:SetScript("OnClick",function()
            local n = SK:GetRPName()
            if n == "" then
                print("|cffFFD700[SK]|r No IC name found in TRP3. Make sure your character's first/last name is set in the TRP3 About tab.")
                return
            end
            selInp:SetText(n); SK:SetSavedSellerIC(n)
        end)
        if not TRP3_API then trpBtn:Disable() end
        yo = yo + 28

        yo = yo + 6
        -- ══ MINIMAP ══════════════════════════════════════════════════════
        SH("Minimap")
        Label("Angle (0-360\194\176, or drag the minimap button):")
        local angInp = CreateFrame("EditBox",nil,sc,"InputBoxTemplate")
        angInp:SetSize(56,20); angInp:SetPoint("TOPLEFT",PAD+4,-yo); angInp:SetAutoFocus(false)
        angInp:SetScript("OnEscapePressed",function(s) s:ClearFocus() end)
        angInp:SetText(tostring(math.floor(SK.db.minimapAngle or 220)))
        local angBtn = CreateFrame("Button",nil,sc,"UIPanelButtonTemplate")
        angBtn:SetSize(58,20); angBtn:SetPoint("LEFT",angInp,"RIGHT",6,0); angBtn:SetText("Apply")
        angBtn:SetScript("OnClick",function()
            local a=tonumber(angInp:GetText()); if a then SK.db.minimapAngle=a%360; SK.MinimapBtn:UpdatePosition() end
        end)
        yo = yo + 28

        yo = yo + 8
        -- ══ RESET ════════════════════════════════════════════════════════
        local sep2=sc:CreateTexture(nil,"ARTWORK"); sep2:SetHeight(1)
        sep2:SetPoint("TOPLEFT",0,-yo); sep2:SetPoint("TOPRIGHT",0,-yo)
        sep2:SetColorTexture(0.35,0.30,0.20,0.6); yo=yo+10
        local rstBtn = CreateFrame("Button",nil,sc,"UIPanelButtonTemplate")
        rstBtn:SetSize(200,22); rstBtn:SetPoint("TOPLEFT",PAD+4,-yo); rstBtn:SetText("Reset All Settings to Default")
        rstBtn:SetScript("OnClick",function()
            SK.db.settings={
                emoteResponses={{name="Default",body="hands over a receipt from {shop} \xE2\x80\x94 {items} \xE2\x80\x94 Total: {total} ({payment}), served by {seller}."}},
                emoteChannel="EMOTE",showPrice=true,autoClearCart=true,defaultSellerIC="",
                autoCloseCategory=true,
                notifyOrderClaimed=true,notifyOrderReleased=true,
                notifyOrderStatus=true,notifyStaffJoined=true,notifySync=false,
            }
            M:SwitchTab("settings"); print("|cffFFD700[SK]|r Settings reset.")
        end)
        yo = yo + 32
        sc:SetHeight(yo + 10)
    end

    local function BuildResponses()
        MakeSC()
        SH("Emote Responses")
        Label("|cffFFD700Tokens:|r  {shop}   {seller}   {items}   {total}   {payment}",1,1,1)
        yo = yo + 4

        -- Ensure responses table exists; migrate legacy single template if needed
        cfg.emoteResponses = cfg.emoteResponses or {}
        if #cfg.emoteResponses == 0 then
            local legacy = cfg.emoteTemplate or "hands over a receipt from {shop} \xE2\x80\x94 {items} \xE2\x80\x94 Total: {total} ({payment}), served by {seller}."
            tinsert(cfg.emoteResponses, {name="Default", body=legacy})
        end

        -- Row layout constants
        -- Header row: 26px (name label + box + X button)
        -- Body box:   56px tall (multi-line, no scroll overlap)
        -- Gap:         6px between rows
        local HDR_H  = 26
        local BODY_H = 56
        local ROW_H  = HDR_H + BODY_H + 4   -- 86px total per response
        local GAP    = 6

        local responseRows = {}
        local responseContainer = CreateFrame("Frame", nil, sc)
        responseContainer:SetPoint("TOPLEFT", 0, -yo)
        responseContainer:SetWidth(spw)
        responseContainer:SetHeight(10)

        local function BuildResponseRows()
            for _, f2 in ipairs(responseRows) do f2:Hide() end
            responseRows = {}
            local ry = 0
            for i, resp in ipairs(cfg.emoteResponses) do
                local row = CreateFrame("Frame", nil, responseContainer, "BackdropTemplate")
                row:SetPoint("TOPLEFT", 0, -ry)
                row:SetWidth(spw); row:SetHeight(ROW_H)
                row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
                row:SetBackdropColor(0,0,0,0.2); row:SetBackdropBorderColor(0.4,0.35,0.2,0.5)
                tinsert(responseRows, row)

                -- Header: "Name:" label + editbox + X button, all vertically centred in HDR_H
                local nLbl = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
                nLbl:SetPoint("TOPLEFT",6,-4); nLbl:SetText("Name:"); nLbl:SetTextColor(0.7,0.7,0.7,1)

                -- X button: right-aligned, vertically centred in the header row
                local idx = i
                local delBtn = CreateFrame("Button",nil,row,"UIPanelButtonTemplate")
                delBtn:SetSize(24,20); delBtn:SetPoint("TOPRIGHT",-4,-3)
                delBtn:SetText("X")
                -- Force the button label to be centred (UIPanelButtonTemplate can misalign it)
                if delBtn:GetFontString() then
                    delBtn:GetFontString():SetJustifyH("CENTER")
                    delBtn:GetFontString():SetJustifyV("MIDDLE")
                end
                delBtn:SetScript("OnClick",function()
                    tremove(cfg.emoteResponses, idx)
                    M._settingsSubTab = "responses"
                    M:SwitchTab("settings")
                end)

                local nameBox = CreateFrame("EditBox",nil,row,"InputBoxTemplate")
                -- Stretch between "Name:" label and X button with small margins
                nameBox:SetHeight(20)
                nameBox:SetPoint("TOPLEFT", 48, -3)
                nameBox:SetPoint("TOPRIGHT", -(24+8), -3)
                nameBox:SetAutoFocus(false)
                nameBox:SetText(resp.name or "")
                nameBox:SetScript("OnTextChanged",function(s) if cfg.emoteResponses[idx] then cfg.emoteResponses[idx].name=s:GetText() end end)
                nameBox:SetScript("OnEscapePressed",function(s) s:ClearFocus() end)

                -- Body: a plain multi-line EditBox with a dark inset backdrop.
                -- No UIPanelScrollFrameTemplate — that adds a scrollbar that eats
                -- ~20px of the right edge and makes the box look tiny. Instead we
                -- use a plain ScrollFrame with manual wheel scrolling so the full
                -- width is available for text.
                local bodyOuter = CreateFrame("Frame",nil,row,"BackdropTemplate")
                bodyOuter:SetPoint("TOPLEFT", 4, -(HDR_H+2))
                bodyOuter:SetPoint("BOTTOMRIGHT", -4, 4)
                bodyOuter:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
                bodyOuter:SetBackdropColor(0,0,0,0.40); bodyOuter:SetBackdropBorderColor(0.35,0.28,0.12,0.7)

                local bodySF = CreateFrame("ScrollFrame",nil,bodyOuter)
                bodySF:SetPoint("TOPLEFT",3,-3); bodySF:SetPoint("BOTTOMRIGHT",-3,3)
                bodySF:EnableMouseWheel(true)

                local bodyBox = CreateFrame("EditBox",nil,bodySF)
                bodyBox:SetWidth(bodySF:GetWidth()); bodyBox:SetHeight(BODY_H - 8)
                bodyBox:SetMultiLine(true); bodyBox:SetAutoFocus(false)
                bodyBox:SetFontObject("GameFontNormal")
                bodyBox:SetText(resp.body or "")
                bodyBox:SetScript("OnEscapePressed",function(s2) s2:ClearFocus() end)
                bodyBox:SetScript("OnTextChanged",function(s2)
                    if cfg.emoteResponses[idx] then cfg.emoteResponses[idx].body=s2:GetText() end
                end)
                bodySF:SetScrollChild(bodyBox)
                bodySF:SetScript("OnMouseWheel",function(s,d)
                    local cur = s:GetVerticalScroll()
                    s:SetVerticalScroll(math.max(0, cur - d*14))
                end)

                ry = ry + ROW_H + GAP
            end
            responseContainer:SetHeight(math.max(ry, 10))
        end

        BuildResponseRows()
        local rcH = (#cfg.emoteResponses > 0) and (#cfg.emoteResponses * (ROW_H + GAP)) or 10
        yo = yo + rcH

        local addRespBtn = CreateFrame("Button",nil,sc,"UIPanelButtonTemplate")
        addRespBtn:SetSize(120,22); addRespBtn:SetPoint("TOPLEFT",PAD+4,-yo); addRespBtn:SetText("+ Add Response")
        addRespBtn:SetScript("OnClick",function()
            tinsert(cfg.emoteResponses, {name="Response "..(#cfg.emoteResponses+1), body="hands over a receipt from {shop} \xE2\x80\x94 {items} \xE2\x80\x94 Total: {total} ({payment}), served by {seller}."})
            M._settingsSubTab = "responses"
            M:SwitchTab("settings")
        end)
        yo = yo + 32
        sc:SetHeight(yo + 10)
    end

    -- ── Sub-tab switching ─────────────────────────────────────────────────
    local function ActivateSubTab(key)
        M._settingsSubTab = key
        -- Style buttons
        for _, sb in ipairs(subBtns) do
            local active = (sb.key == key)
            sb:SetBackdropColor(active and 0.15 or 0.05, active and 0.12 or 0.04, active and 0.05 or 0.02, active and 1 or 0.9)
            sb:SetBackdropBorderColor(active and 0.8 or 0.35, active and 0.65 or 0.30, active and 0.2 or 0.12, 1)
            sb.lbl:SetTextColor(active and 1 or 0.6, active and 0.82 or 0.6, active and 0 or 0.6, 1)
        end
        -- Wipe and rebuild scroll content
        -- sc is recreated by MakeSC() inside Build* functions
        if key == "general" then
            BuildGeneral()
        elseif key == "responses" then
            BuildResponses()
        end
        sf:SetVerticalScroll(0)
    end

    for _, sb in ipairs(subBtns) do
        local k = sb.key
        sb:SetScript("OnClick", function() ActivateSubTab(k) end)
    end

    ActivateSubTab(M._settingsSubTab or "general")
end


-- ─── MANAGEMENT TAB (People, Permissions, Stock, Discounts, Categories) ────────

function M:BuildPeopleTab()
    -- Track which sub-tab is active
    M._peopleSubTab = M._peopleSubTab or "staff"
    WipeContent()
    local p0  = GetContentPanel()
    local pw0 = p0:GetWidth() - PAD*2
    local shopName = SK.db and SK.db.activeShop
    if not shopName then
        Track(FS(p0,"No shop active.",11,0.65,0.65,0.65)):SetPoint("CENTER"); return
    end
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end
    SK.DB:MigrateShop(shop)

    local myName  = UnitName("player") or ""
    local role    = SK.DB:GetRole(shopName)
    local isOwner   = (role == "owner")
    local isManager = (role == "manager") or isOwner

    -- ── Sub-tab bar ────────────────────────────────────────────────────────
    local SUB_TABS = {
        {key="staff",       label="Staff"},
        {key="permissions", label="Permissions"},
        {key="inventory",   label="Stock & Treasury"},
        {key="categories",  label="Categories"},
    }
    local SUB_H = 26
    local subW  = math.floor((pw0 - PAD) / #SUB_TABS)

    local subBtns = {}
    for i, st in ipairs(SUB_TABS) do
        local sb = Track(CreateFrame("Button",nil,p0,"BackdropTemplate"))
        sb:SetSize(subW, SUB_H)
        sb:SetPoint("TOPLEFT", PAD + (i-1)*subW, 0)
        sb:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
        local lbl = sb:CreateFontString(nil,"OVERLAY","GameFontNormal")
        lbl:SetAllPoints(); lbl:SetJustifyH("CENTER"); lbl:SetText(st.label)
        sb.lbl = lbl; sb.key = st.key
        tinsert(subBtns, sb)

        local function RefreshSubBtns()
            for _, b in ipairs(subBtns) do
                local on = (b.key == M._peopleSubTab)
                b:SetBackdropColor(on and 0.12 or 0.06, on and 0.12 or 0.06, on and 0.18 or 0.10, 1)
                b:SetBackdropBorderColor(on and 0.5 or 0.25, on and 0.38 or 0.25, on and 0.10 or 0.10, 1)
                b.lbl:SetTextColor(on and 1 or 0.55, on and 0.82 or 0.55, on and 0 or 0.55, 1)
            end
        end

        sb:SetScript("OnClick", function()
            M._peopleSubTab = st.key
            RefreshSubBtns()
            M:BuildPeopleSubTab(shopName, shop, isOwner, isManager, role)
        end)
        RefreshSubBtns()
    end

    -- ── Sub-content scroll area ────────────────────────────────────────────
    local sf = Track(CreateFrame("ScrollFrame", nil, p0, "UIPanelScrollFrameTemplate"))
    sf:SetPoint("TOPLEFT", PAD, -(SUB_H+2)); sf:SetPoint("BOTTOMRIGHT", -16, PAD)
    sf:EnableMouseWheel(true)
    sf:SetScript("OnMouseWheel", function(s, delta)
        -- Match the "Load existing" scroll: clamp against the child's actual
        -- height vs the visible frame height (always current), rather than
        -- GetVerticalScrollRange() which is stale until a layout pass and causes
        -- the view to scroll into empty space above the content.
        local child = s:GetScrollChild()
        local maxScroll = 0
        if child then
            maxScroll = math.max(0, (child:GetHeight() or 0) - (s:GetHeight() or 0))
        end
        local cur = s:GetVerticalScroll() or 0
        local new = cur - delta * 28   -- wheel-down (delta=-1) -> scroll down
        if new < 0 then new = 0 elseif new > maxScroll then new = maxScroll end
        s:SetVerticalScroll(new)
    end)
    local sc = CreateFrame("Frame", nil, sf)
    sc:SetWidth(sf:GetWidth()-4); sc:SetHeight(1); sf:SetScrollChild(sc)
    M._peopleSC = sc
    M._peoplePW = sc:GetWidth() - PAD*2

    M:BuildPeopleSubTab(shopName, shop, isOwner, isManager, role)
end

-- Helper: clears and rebuilds the scrolled sub-content for the active sub-tab.
-- Called on first render and whenever a sub-tab button is clicked.
function M:BuildPeopleSubTab(shopName, shop, isOwner, isManager, role)
    local sc  = M._peopleSC
    local pw  = M._peoplePW
    if not sc then M:SwitchTab("people"); return end

    -- Wipe previous sub-tab content
    for _, w in ipairs(M._peopleSubChildren or {}) do
        if w.ClearAllPoints then w:ClearAllPoints() end
        if w.Hide then w:Hide() end
        if w.SetParent then w:SetParent(_graveyard); w:Hide() end
    end
    M._peopleSubChildren = {}

    -- Hide pooled category-reorder widgets so they don't ghost behind other sub-tabs.
    -- These are pooled (not tracked in _peopleSubChildren) so they must be hidden here.
    if M._catPool then
        for _, r in ipairs(M._catPool) do r:Hide() end
    end
    if M._catInsLine then M._catInsLine:Hide() end
    if M._catEmpty   then M._catEmpty:Hide()   end
    local function Sub(w) tinsert(M._peopleSubChildren, w); return w end
    local function TrackS(w) Track(w); Sub(w); return w end

    local yo = -PAD

    local function SH(text)
        TrackS(FS(sc,text,10,1,0.82,0)):SetPoint("TOPLEFT",PAD,yo)
        TrackS(HLine(sc,yo-14))
        yo = yo - 24
    end
    local function Row(leftText, r,g,b, rightBtnLabel, rightBtnCb, rightBtnW)
        local row = TrackS(CreateFrame("Frame",nil,sc,"BackdropTemplate"))
        row:SetPoint("TOPLEFT",PAD,yo); row:SetPoint("TOPRIGHT",-PAD,yo); row:SetHeight(26)
        row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
        row:SetBackdropColor(0,0,0,0.15); row:SetBackdropBorderColor(0.3,0.25,0.10,0.4)
        local lbl=row:CreateFontString(nil,"OVERLAY","GameFontNormal")
        lbl:SetPoint("LEFT",6,0); lbl:SetFont("Fonts\\FRIZQT__.TTF",10,"")
        lbl:SetText(leftText); lbl:SetTextColor(r or 1,g or 1,b or 1,1)
        if rightBtnLabel then
            local btn=Btn(row,rightBtnLabel,rightBtnW or 52,18)
            btn:SetPoint("RIGHT",-4,0)
            btn:SetScript("OnClick",rightBtnCb)
        end
        yo = yo - 28
        return row
    end

    local sub = M._peopleSubTab

    -- ═══════════════════════════════════════════════════════════════════════
    -- SUB-TAB 1: STAFF
    -- ═══════════════════════════════════════════════════════════════════════
    if sub == "staff" then
        SH("Staff Roster")

        if isOwner then
            -- Add employee input
            local addRow = TrackS(CreateFrame("Frame",nil,sc))
            addRow:SetPoint("TOPLEFT",PAD,yo); addRow:SetPoint("TOPRIGHT",-PAD,yo); addRow:SetHeight(24)
            local addBtn = Btn(addRow,"Add",50,20); addBtn:SetPoint("RIGHT",0,0); TrackS(addBtn)
            local targetBtn = Btn(addRow,"Target",58,20); targetBtn:SetPoint("RIGHT",addBtn,"LEFT",-4,0); TrackS(targetBtn)
            local ni = Box(addRow, pw-56-58-4-4, 20); ni:SetPoint("LEFT",0,0)
            local niHint = addRow:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            niHint:SetPoint("LEFT",ni,"LEFT",4,0); niHint:SetText("Add employee by name")
            niHint:SetTextColor(0.35,0.35,0.35,1)
            ni:SetScript("OnTextChanged",function(s) niHint:SetShown(s:GetText()=="") end)
            targetBtn:SetScript("OnClick",function()
                if UnitExists("target") and UnitIsPlayer("target") then
                    local name = UnitName("target")
                    if name and name ~= "" then
                        ni:SetText(name:match("^([^%-]+)") or name)
                        ni:SetCursorPosition(#ni:GetText())
                    end
                else
                    print("|cffFFD700[SK]|r No player targeted.")
                end
            end)
            targetBtn:SetScript("OnEnter",function(s)
                GameTooltip:SetOwner(s,"ANCHOR_TOP")
                GameTooltip:AddLine("Copy target name",1,1,1)
                GameTooltip:AddLine("Fills the box with your current target's OOC character name.",0.7,0.7,0.7)
                GameTooltip:Show()
            end)
            targetBtn:SetScript("OnLeave",function() GameTooltip:Hide() end)
            local function DoAddEmp()
                local t = strtrim(ni:GetText() or "")
                if t=="" then return end
                t = t:match("^([^%-]+)") or t
                ni:SetText("")
                if SK.Net then SK.Net:SendInvite(shopName,t,"employee") end
                M:SwitchTab("people")
            end
            addBtn:SetScript("OnClick", DoAddEmp)
            ni:SetScript("OnEnterPressed", DoAddEmp)
            yo = yo - 30

            -- Column headers
            local ICON_W = 22; local CB_W = 24; local REM_W = 30; local GAP = 4
            local colName = TrackS(sc:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"))
            colName:SetPoint("TOPLEFT", PAD+ICON_W+2, yo); colName:SetText("|cff888888Name|r")
            local colMgr = TrackS(sc:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"))
            colMgr:SetPoint("TOPRIGHT", -(REM_W+GAP+2), yo); colMgr:SetText("|cff888888Manager|r")
            yo = yo - 18

            local function RosterRow(name, rowRole)
                local row = TrackS(CreateFrame("Frame",nil,sc,"BackdropTemplate"))
                row:SetHeight(26)
                row:SetPoint("TOPLEFT", PAD, yo); row:SetPoint("TOPRIGHT", -PAD, yo)
                row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
                row:SetBackdropColor(0,0,0,0.15); row:SetBackdropBorderColor(0.25,0.22,0.10,0.3)

                local ic = row:CreateTexture(nil,"ARTWORK"); ic:SetSize(16,16); ic:SetPoint("LEFT",3,0)
                if rowRole=="owner" then ic:SetTexture(236377); ic:SetTexCoord(0.08,0.92,0.08,0.92)
                elseif rowRole=="manager" then ic:SetTexture(135872); ic:SetTexCoord(0.08,0.92,0.08,0.92)
                else ic:SetAlpha(0) end

                local nl = row:CreateFontString(nil,"OVERLAY","GameFontNormal")
                nl:SetPoint("LEFT", ICON_W+4, 0); nl:SetPoint("RIGHT", -(CB_W+GAP+REM_W+GAP+2), 0)
                nl:SetJustifyH("LEFT"); nl:SetWordWrap(false)
                if rowRole=="owner" then nl:SetText("|cffFFD700"..name.."|r")
                elseif rowRole=="manager" then nl:SetText("|cffFFCC55"..name.."|r")
                else nl:SetText(name) end

                if rowRole ~= "owner" then
                    local tb2 = Btn(row, rowRole=="manager" and "Demote" or "Promote", CB_W+40, 18)
                    tb2:SetPoint("RIGHT", -(REM_W+GAP+2), 0)
                    tb2:SetScript("OnEnter",function()
                        GameTooltip:SetOwner(tb2,"ANCHOR_TOP")
                        GameTooltip:AddLine(rowRole=="manager" and "Demote to Employee" or "Promote to Manager",1,1,1)
                        GameTooltip:Show()
                    end)
                    tb2:SetScript("OnLeave",function() GameTooltip:Hide() end)
                    tb2:SetScript("OnClick",function()
                        if rowRole=="manager" then
                            SK.DB:RemoveManager(shopName,name); SK.DB:AddEmployee(shopName,name)
                        else
                            SK.DB:RemoveEmployee(shopName,name); SK.DB:AddManager(shopName,name)
                        end
                        if SK.Net then
                            local shop2 = SK.DB:GetShop(shopName)
                            if shop2 then
                                local myShort = (UnitName("player") or ""):lower()
                                local function pushTo(n)
                                    local s = (n:match("^([^%-]+)") or n):lower()
                                    if s ~= myShort then SK.Net:SyncShop(shopName, n) end
                                end
                                for _, n in ipairs(shop2.managers)  do pushTo(n) end
                                for _, n in ipairs(shop2.employees) do pushTo(n) end
                            end
                        end
                        M:SwitchTab("people")
                    end)
                    TrackS(tb2)

                    local rb = Btn(row,"X",REM_W,20); rb:SetPoint("RIGHT",-2,0); TrackS(rb)
                    local n2,r2 = name,rowRole
                    rb:SetScript("OnClick",function()
                        if SK.Net then SK.Net:SendKick(shopName,n2) end
                        if r2=="manager" then SK.DB:RemoveManager(shopName,n2)
                        else SK.DB:RemoveEmployee(shopName,n2) end
                        M:SwitchTab("people")
                    end)
                end
                yo = yo - 28
            end

            RosterRow(SK.DB:GetOwnerDisplay(shopName), "owner")
            for _,name in ipairs(shop.managers  or {}) do RosterRow(name,"manager")  end
            for _,name in ipairs(shop.employees or {}) do RosterRow(name,"employee") end
            if #(shop.managers or{})==0 and #(shop.employees or{})==0 and #(shop.pendingInvites or {})==0 then
                TrackS(FS(sc,"No staff yet. Add an employee above.",9,0.45,0.45,0.45)):SetPoint("TOPLEFT",PAD,yo); yo=yo-18
            end

            -- Pending invites — shown below confirmed staff with a cancel (X) button only
            for _, inv in ipairs(shop.pendingInvites or {}) do
                local prow = TrackS(CreateFrame("Frame",nil,sc,"BackdropTemplate"))
                prow:SetHeight(24); prow:SetPoint("TOPLEFT",PAD,yo); prow:SetPoint("TOPRIGHT",-PAD,yo)
                prow:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
                prow:SetBackdropColor(0,0,0,0.08); prow:SetBackdropBorderColor(0.3,0.3,0.3,0.3)
                local pendLbl = prow:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
                pendLbl:SetPoint("LEFT",6,0)
                pendLbl:SetText("|cff888888"..inv.name.."|r  |cff555555(Pending — "..inv.role..")|r")
                local xb = Btn(prow,"X",REM_W,18); xb:SetPoint("RIGHT",-2,0); TrackS(xb)
                local invName = inv.name
                xb:SetScript("OnClick",function()
                    SK.Net:SendWithdrawInvite(shopName, invName)
                    M:SwitchTab("people")
                end)
                xb:SetScript("OnEnter",function()
                    GameTooltip:SetOwner(xb,"ANCHOR_TOP")
                    GameTooltip:AddLine("Cancel invite",1,0.4,0.4)
                    GameTooltip:Show()
                end)
                xb:SetScript("OnLeave",function() GameTooltip:Hide() end)
                yo = yo - 26
            end
            yo = yo - 8

            -- Sync All
            local syncAll=TrackS(Btn(sc,"Sync Products to All Staff",200,26)); syncAll:SetPoint("TOPLEFT",PAD,yo); yo=yo-34
            syncAll:SetScript("OnClick",function()
                for _,n in ipairs(shop.managers  or {}) do SK.Net:SyncProducts(shopName,n) end
                for _,n in ipairs(shop.employees or {}) do SK.Net:SyncProducts(shopName,n) end
                print("|cffFFD700[SK]|r Synced to all staff.")
            end)


        else
            -- Non-owner view
            TrackS(FS(sc,"Your role:  |cffFFD700"..(role or "?").."|r",11)):SetPoint("TOPLEFT",PAD,yo); yo=yo-22
            TrackS(FS(sc,"Owner:  |cffFFD700"..SK.DB:GetOwnerDisplay(shopName).."|r",10)):SetPoint("TOPLEFT",PAD,yo); yo=yo-20
            TrackS(FS(sc,"Managers",10,1,0.82,0)):SetPoint("TOPLEFT",PAD,yo); yo=yo-18
            for _,n in ipairs(shop.managers) do TrackS(FS(sc,n,10)):SetPoint("TOPLEFT",PAD+4,yo); yo=yo-18 end
            if #shop.managers==0 then TrackS(FS(sc,"None.",9,0.45,0.45,0.45)):SetPoint("TOPLEFT",PAD+4,yo); yo=yo-16 end
            TrackS(HLine(sc,yo-4)); yo=yo-12
            TrackS(FS(sc,"Employees",10,1,0.82,0)):SetPoint("TOPLEFT",PAD,yo); yo=yo-18
            for _,n in ipairs(shop.employees) do TrackS(FS(sc,n,10)):SetPoint("TOPLEFT",PAD+4,yo); yo=yo-18 end
            if #shop.employees==0 then TrackS(FS(sc,"None.",9,0.45,0.45,0.45)):SetPoint("TOPLEFT",PAD+4,yo); yo=yo-16 end
            yo=yo-8
            local syncBtn=TrackS(Btn(sc,"Request Sync",120,26)); syncBtn:SetPoint("TOPLEFT",PAD,yo)
            syncBtn:SetScript("OnClick",function() if SK.Net then SK.Net:RequestSync(shopName) end end)
            local leaveBtn=TrackS(Btn(sc,"Leave Shop",110,26)); leaveBtn:SetPoint("TOPLEFT",PAD+128,yo)
            leaveBtn:SetScript("OnClick",function()
                StaticPopupDialogs["SK_LEAVE_CONFIRM"]={text="Leave |cffFFD700"..shopName.."|r?",
                    button1="Leave",button2="Cancel",OnAccept=function() SK.Net:Leave(shopName) end,
                    timeout=0,whileDead=true,hideOnEscape=true}
                StaticPopup_Show("SK_LEAVE_CONFIRM")
            end)
            yo=yo-32
        end

    -- ═══════════════════════════════════════════════════════════════════════════
    -- SUB-TAB 2: PERMISSIONS
    -- ═══════════════════════════════════════════════════════════════════════════
    elseif sub == "permissions" then
        if not isOwner then
            TrackS(FS(sc,"|cff888888Only the store owner can manage permissions.|r",10)):SetPoint("TOPLEFT",PAD,yo)
        else
            local perms = shop.perms
            local DD_W = 160  -- same as the emote channel dropdown

            -- Maps a (mgrsKey, empsKey) pair to a string key and back
            local PERM_OPTS = {
                {key="none",  label="No one",         mgr=false, emp=false},
                {key="mgr",   label="Managers only",  mgr=true,  emp=false},
                {key="emp",   label="Employees only", mgr=false, emp=true},
                {key="both",  label="Both",            mgr=true,  emp=true},
            }
            local function GetOptLabel(k)
                for _, o in ipairs(PERM_OPTS) do if o.key==k then return o.label end end
                return "No one"
            end
            local function GetOptKey(mgrsKey, empsKey)
                local m = perms[mgrsKey] ~= false  -- managers default true
                local e = perms[empsKey] == true    -- employees default false
                if m and e  then return "both" end
                if m        then return "mgr"  end
                if e        then return "emp"  end
                return "none"
            end

            local ddIndex = 0
            local function Perm(label, mgrsKey, empsKey)
                ddIndex = ddIndex + 1
                local lbl = TrackS(sc:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"))
                lbl:SetFont("Fonts\\FRIZQT__.TTF",10,"")
                lbl:SetPoint("TOPLEFT",PAD,yo-6)
                lbl:SetTextColor(0.85,0.85,0.85,1)
                lbl:SetText(label)

                local ddName = "SK_PermDD_"..ddIndex
                local dd = TrackS(CreateFrame("Frame",ddName,sc,"UIDropDownMenuTemplate"))
                dd:SetPoint("TOPRIGHT",-PAD+16,yo)
                UIDropDownMenu_SetWidth(dd, DD_W)
                UIDropDownMenu_SetText(dd, GetOptLabel(GetOptKey(mgrsKey, empsKey)))
                UIDropDownMenu_Initialize(dd, function(self, level)
                    for _, o in ipairs(PERM_OPTS) do
                        local info = UIDropDownMenu_CreateInfo()
                        info.text    = o.label
                        info.value   = o.key
                        info.checked = (GetOptKey(mgrsKey, empsKey) == o.key)
                        info.func    = function(btn)
                            local sel
                            for _, oo in ipairs(PERM_OPTS) do
                                if oo.key == btn.value then sel=oo; break end
                            end
                            if sel then
                                perms[mgrsKey] = sel.mgr
                                perms[empsKey] = sel.emp
                            end
                            UIDropDownMenu_SetText(dd, GetOptLabel(btn.value))
                        end
                        UIDropDownMenu_AddButton(info, level)
                    end
                end)
                yo = yo - 30
            end

            -- Products
            SH("Products")
            Perm("Add / edit / remove products",  "mgrsCanProducts",       "empsCanProducts")
            Perm("Update stock levels",           "mgrsCanStock",          "empsCanStock")

            -- Register
            yo=yo-4; SH("Register")
            Perm("Apply discounts",               "mgrsCanDiscount",       "empsCanDiscount")
            Perm("Finalise as Paid as a Favour",  "mgrsCanFavour",         "empsCanFavour")
            Perm("Finalise / confirm orders",     "mgrsCanFinalizeOrders", "empsCanFinalizeOrders")

            -- Orders & Tabs
            yo=yo-4; SH("Orders & Tabs")
            Perm("Claim / release orders",        "mgrsCanClaimOrders",    "empsCanClaimOrders")
            Perm("Reopen / unclaim completed orders","mgrsCanReopenOrders", "empsCanReopenOrders")
            Perm("Reopen / edit tabs",            "mgrsCanManageTabs",     "empsCanManageTabs")

            -- Treasury
            yo=yo-4; SH("Treasury")
            Perm("Deposit / withdraw",            "mgrsCanTreasury",       "empsCanTreasury")

            -- Staff
            yo=yo-4; SH("Staff")
            Perm("Invite / add employees",        "mgrsCanAddEmployees",   "empsCanAddEmployees")

            -- Logs
            yo=yo-4; SH("Logs")
            Perm("View activity log",             "mgrsCanViewLogs",       "empsCanViewLogs")
        end

    -- ═══════════════════════════════════════════════════════════════════════════
    -- SUB-TAB 3: STOCK & TREASURY & DISCOUNTS
    -- ═══════════════════════════════════════════════════════════════════════════
    elseif sub == "inventory" then
        local canTreasury = SK.DB:CanTreasury(shopName, myName)
        local canDiscount = SK.DB:CanDiscount(shopName)
        local canStock    = SK.DB:CanManageStock(shopName)

        -- Stock
        SH("Stock")

        -- Production-cost toggle (owner only; it's a shop-wide economic policy).
        -- When enabled, each restock (+ in the list below) drains that product's
        -- Restock Cost from the treasury. Syncs owner -> all staff via SHOP_INFO.
        if isOwner then
            local shopRef = SK.DB:GetShop(shopName)
            local tcRow = TrackS(CreateFrame("Frame",nil,sc)); tcRow:SetSize(pw,18); tcRow:SetPoint("TOPLEFT",PAD,yo)
            local cb = TrackS(CreateFrame("Button",nil,tcRow,"BackdropTemplate"))
            cb:SetSize(16,16); cb:SetPoint("LEFT",0,0)
            cb:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
            cb:SetBackdropColor(0.06,0.06,0.10,1); cb:SetBackdropBorderColor(0.45,0.35,0.12,1)
            local chk = cb:CreateTexture(nil,"ARTWORK"); chk:SetAllPoints()
            chk:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
            local function paint()
                local on = shopRef and shopRef.trackProductionCost
                chk:SetAlpha(on and 1 or 0)
                cb:SetBackdropColor(0.06, 0.06, on and 0.18 or 0.10, 1)
            end
            paint()
            local cl = tcRow:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            cl:SetPoint("LEFT",cb,"RIGHT",4,0)
            cl:SetText("Charge production cost on restock"); cl:SetTextColor(0.85,0.85,0.85,1)
            cb:SetScript("OnClick",function()
                if not shopRef then return end
                shopRef.trackProductionCost = not shopRef.trackProductionCost
                paint()
                if SK.Net and SK.Net.BroadcastShopInfo then SK.Net:BroadcastShopInfo(shopName) end
            end)
            yo=yo-18
            local hint = TrackS(FS(sc,"When on, each restock (+) drains that product's Restock Cost from the treasury.",9,0.5,0.5,0.5))
            hint:SetPoint("TOPLEFT",PAD,yo); yo=yo-18
        end

        local products = SK.DB:GetProducts(shopName)
        local hasStock = false
        for _, prod in ipairs(products) do if prod.stock ~= nil then hasStock=true; break end end

        if not hasStock then
            TrackS(FS(sc,"No products with limited stock. Enable limited stock when editing a product.",9,0.55,0.55,0.55)):SetPoint("TOPLEFT",PAD,yo); yo=yo-18
        else
            local sh=TrackS(CreateFrame("Frame",nil,sc,"BackdropTemplate")); sh:SetSize(pw,18); sh:SetPoint("TOPLEFT",PAD,yo)
            sh:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
            sh:SetBackdropColor(0,0,0,0.4); sh:SetBackdropBorderColor(0.35,0.28,0.10,0.6)
            local h1=sh:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); h1:SetPoint("LEFT",6,0); h1:SetText("Product"); h1:SetTextColor(1,0.82,0,1)
            local h2=sh:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); h2:SetPoint("RIGHT",-6,0); h2:SetText("Stock"); h2:SetTextColor(1,0.82,0,1)
            yo=yo-20
            for _, prod in ipairs(products) do
                if prod.stock ~= nil then
                    local sr=TrackS(CreateFrame("Frame",nil,sc,"BackdropTemplate")); sr:SetSize(pw,24); sr:SetPoint("TOPLEFT",PAD,yo)
                    sr:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
                    sr:SetBackdropColor(0,0,0,0.15); sr:SetBackdropBorderColor(0.25,0.20,0.08,0.5)
                    local pn=sr:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); pn:SetPoint("LEFT",6,0); pn:SetText(prod.name)
                    local stCol = prod.stock==0 and {1,0.3,0.3} or prod.stock<=5 and {1,0.8,0.2} or {0.4,1,0.4}
                    local sn2=sr:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); sn2:SetPoint("RIGHT",-60,0)
                    sn2:SetText(prod.stock<=0 and "|cffFF4444Out of stock|r" or tostring(prod.stock))
                    sn2:SetTextColor(stCol[1],stCol[2],stCol[3],1)
                    if canStock then
                        local pid=prod.id
                        -- Update just this row's stock cell in place. GetProducts returns
                        -- live table references and SetStock mutates prod.stock directly,
                        -- so there's no need to rebuild the whole tab — which is what used
                        -- to snap a long stock list back to the top on every +/- click.
                        local function RefreshStockCell()
                            local st = prod.stock or 0
                            local col = st==0 and {1,0.3,0.3} or st<=5 and {1,0.8,0.2} or {0.4,1,0.4}
                            sn2:SetText(st<=0 and "|cffFF4444Out of stock|r" or tostring(st))
                            sn2:SetTextColor(col[1],col[2],col[3],1)
                        end
                        local plus=Btn(sr,"+",26,18); plus:SetPoint("RIGHT",-4,0); TrackS(plus)
                        plus:SetScript("OnClick",function()
                            SK.DB:SetStock(shopName,pid,(prod.stock or 0)+1)
                            -- Charge production cost (no-op unless the shop has it enabled
                            -- and this product has a positive Restock Cost).
                            local cost, _, short = SK.DB:ApplyRestockCost(shopName, prod, 1)
                            RefreshStockCell()
                            if cost > 0 and M._invTreasuryFS then
                                local shp = SK.DB:GetShop(shopName)
                                M._invTreasuryFS:SetText(SK:FormatMoneyPlain(shp and shp.treasury or 0))
                            end
                            if short then
                                print("|cffFFD700[SK]|r Treasury couldn't fully cover the restock cost of "..(prod.name or "item")..".")
                            end
                            if SK.Net then SK.Net:BroadcastProducts(shopName) end
                        end)
                        local minus=Btn(sr,"-",26,18); minus:SetPoint("RIGHT",plus,"LEFT",-2,0); TrackS(minus)
                        minus:SetScript("OnClick",function()
                            SK.DB:SetStock(shopName,pid,math.max(0,(prod.stock or 0)-1))
                            RefreshStockCell()
                            if SK.Net then SK.Net:BroadcastProducts(shopName) end
                        end)
                    end
                    yo=yo-26
                end
            end
        end

        -- Treasury
        yo=yo-8; SH("Treasury")
        local bal = SK.DB:GetShop(shopName) and SK.DB:GetShop(shopName).treasury or 0
        local treasFS = TrackS(FS(sc,SK:FormatMoneyPlain(bal),13,1,0.88,0.35))
        treasFS:SetPoint("TOPLEFT",PAD,yo); yo=yo-28
        M._invTreasuryFS = treasFS  -- so a restock (+) can update the balance in place

        if canTreasury then
            -- Fixed-position currency row so G/S/C columns are always aligned
            -- Layout: [Gold box][g label] [Silver box][s label] [Copper box][c label] [Deposit] [Withdraw]
            local BOX_W  = 44
            local LBL_W  = 14
            local GAP    = 4
            local COL    = BOX_W + LBL_W + GAP  -- width of one currency column
            local tRow=TrackS(CreateFrame("Frame",nil,sc)); tRow:SetSize(pw,24); tRow:SetPoint("TOPLEFT",PAD,yo)

            local function MakeCurrencyPair(xOff, letter, lr, lg, lb)
                local box = Box(tRow, BOX_W, 22); box:SetPoint("TOPLEFT", xOff, -1); box:SetNumeric(true)
                local lbl = tRow:CreateFontString(nil,"OVERLAY","GameFontNormal")
                lbl:SetFont("Fonts\\FRIZQT__.TTF", 12, "")
                lbl:SetPoint("LEFT", box, "RIGHT", 2, 0)
                lbl:SetSize(LBL_W, 22); lbl:SetJustifyH("LEFT")
                lbl:SetText(letter); lbl:SetTextColor(lr, lg, lb, 1)
                return box
            end

            local tG = MakeCurrencyPair(0,           "g", 1,    0.82, 0)
            local tS = MakeCurrencyPair(COL,         "s", 0.75, 0.75, 0.75)
            local tC = MakeCurrencyPair(COL*2,       "c", 0.8,  0.45, 0.15)

            local function GC() return ((tonumber(tG:GetText()) or 0)*10000)+((tonumber(tS:GetText()) or 0)*100)+(tonumber(tC:GetText()) or 0) end
            local function CI() tG:SetText(""); tS:SetText(""); tC:SetText("") end

            local btnX = COL * 3 + 4
            local depBtn=Btn(tRow,"Deposit",76,22); depBtn:SetPoint("TOPLEFT",btnX,-1); TrackS(depBtn)
            depBtn:SetScript("OnClick",function() local a=GC(); if a==0 then return end; SK.DB:AddTreasury(shopName,a); CI(); M:SwitchTab("people") end)
            local wdBtn=Btn(tRow,"Withdraw",80,22); wdBtn:SetPoint("LEFT",depBtn,"RIGHT",4,0); TrackS(wdBtn)
            wdBtn:SetScript("OnClick",function() local a=GC(); if a==0 then return end; SK.DB:AddTreasury(shopName,-a); CI(); M:SwitchTab("people") end)
            if isOwner then
                local waBtn=TrackS(Btn(sc,"Withdraw All",110,22)); waBtn:SetPoint("TOPLEFT",PAD,yo-32)
                waBtn:SetScript("OnClick",function()
                    local b2=SK.DB:GetShop(shopName) and SK.DB:GetShop(shopName).treasury or 0
                    if b2<=0 then return end
                    SK.DB:AddTreasury(shopName,-b2); M:SwitchTab("people")
                end)
            end
            yo = isOwner and (yo-58) or (yo-30)
        else
            TrackS(FS(sc,"|cff666666You don't have permission to access the treasury.",9)):SetPoint("TOPLEFT",PAD,yo); yo=yo-20
        end

        -- Discounts
        yo=yo-8; SH("Discounts")
        local discounts = SK.DB:GetDiscounts(shopName)
        if #discounts == 0 then
            TrackS(FS(sc,"No discounts yet.",9,0.45,0.45,0.45)):SetPoint("TOPLEFT",PAD,yo); yo=yo-18
        else
            for i, d in ipairs(discounts) do
                local di=i
                Row(d.label.."  —  "..d.pct.."%", 1,0.82,0,
                    canDiscount and "Remove" or nil,
                    function() SK.DB:DeleteDiscount(shopName,di); M:SwitchTab("people") end,
                    58)
            end
        end
        if canDiscount then
            local addDisc=TrackS(CreateFrame("Frame",nil,sc,"BackdropTemplate"))
            addDisc:SetPoint("TOPLEFT",PAD,yo); addDisc:SetPoint("TOPRIGHT",-PAD,yo); addDisc:SetHeight(28)
            addDisc:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
            addDisc:SetBackdropColor(0,0,0,0.20); addDisc:SetBackdropBorderColor(0.35,0.28,0.10,0.5)
            local dLabel=Box(addDisc,pw-120,20); dLabel:SetPoint("TOPLEFT",4,-4)
            local dlHint=addDisc:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            dlHint:SetPoint("LEFT",dLabel,"LEFT",4,0); dlHint:SetText("Label"); dlHint:SetTextColor(0.35,0.35,0.35,1)
            dLabel:SetScript("OnTextChanged",function(s) dlHint:SetShown(s:GetText()=="") end)
            local dPct=Box(addDisc,30,20); dPct:SetPoint("LEFT",dLabel,"RIGHT",4,0); dPct:SetNumeric(true)
            local dPctLbl=addDisc:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            dPctLbl:SetPoint("LEFT",dPct,"RIGHT",2,0); dPctLbl:SetText("%"); dPctLbl:SetTextColor(0.7,0.7,0.7,1)
            local dAdd=Btn(addDisc,"Add",38,20); dAdd:SetPoint("RIGHT",-4,-1); TrackS(dAdd)
            dAdd:SetScript("OnClick",function()
                local lbl2=strtrim(dLabel:GetText())
                local pct2=tonumber(dPct:GetText())
                local ok2,err2=SK.DB:AddDiscount(shopName,lbl2,pct2)
                if ok2 then dLabel:SetText(""); dPct:SetText(""); M:SwitchTab("people")
                else print("|cffFFD700[SK]|r "..(err2 or "Error.")) end
            end)
            yo = yo - 34
        end

    -- ═══════════════════════════════════════════════════════════════════════
    -- SUB-TAB 3: CATEGORY ORDER
    -- ═══════════════════════════════════════════════════════════════════════
    elseif sub == "categories" then
        SH("Category Order")
        if not isManager then
            TrackS(FS(sc,"Only managers and owners can reorder categories.",9,0.55,0.55,0.55)):SetPoint("TOPLEFT",PAD,yo); yo=yo-18
        else
            TrackS(FS(sc,"Drag a category by its handle to reorder. The order is used in the register and the product dropdown.",9,0.55,0.55,0.55)):SetPoint("TOPLEFT",PAD,yo)
            yo = yo - 22
            local yoCO = yo
            local rowH, rowGap = 26, 4
            local numW = 26
            local rowW = pw - 12

            local ordOrder = SK.DB:GetCategoryOrder(shopName)

            -- Persistent pools, created once and reused on every rebuild so there
            -- is never more than one widget per slot (no ghosting).
            M._catPool = M._catPool or {}
            if not M._catInsLine then
                local il = sc:CreateTexture(nil,"OVERLAY")
                il:SetColorTexture(1,0.82,0,1); il:SetHeight(2); il:Hide()
                M._catInsLine = il
            end
            local insLine = M._catInsLine
            insLine:SetParent(sc); insLine:Hide()

            local function CommitOrder()
                SK.DB:SetCategoryOrder(shopName, ordOrder)
                if SK.Register and SK.Register.BuildProductGrid then SK.Register:BuildProductGrid() end
                if SK.Net then SK.Net:BroadcastCategoryColors(shopName) end
            end

            local RebuildCO

            local function CursorSlot()
                local _, cy = GetCursorPosition()
                local scale = sc:GetEffectiveScale()
                if not scale or scale == 0 then return #ordOrder + 1 end
                cy = cy / scale
                for i = 1, #ordOrder do
                    local rf = M._catPool[i]
                    if rf and rf:IsShown() then
                        local top, bot = rf:GetTop(), rf:GetBottom()
                        if top and bot and cy >= (top+bot)/2 then return i end
                    end
                end
                return #ordOrder + 1
            end

            local function ShowInsertLine(slot)
                insLine:ClearAllPoints()
                insLine:SetWidth(rowW - numW - 6)
                local idx = math.min(math.max(slot,1), #ordOrder)
                local anchorRow = M._catPool[idx]
                if not anchorRow then insLine:Hide(); return end
                if slot > #ordOrder then
                    insLine:SetPoint("TOPLEFT", anchorRow, "BOTTOMLEFT", numW+6, -(rowGap/2))
                else
                    insLine:SetPoint("BOTTOMLEFT", anchorRow, "TOPLEFT", numW+6, (rowGap/2))
                end
                insLine:Show()
            end

            -- Build (once) or fetch a pooled row widget for slot i
            local function GetRow(i)
                local row = M._catPool[i]
                if row then return row end
                row = CreateFrame("Button", nil, sc, "BackdropTemplate")
                row:SetSize(rowW, rowH)
                row:RegisterForDrag("LeftButton")

                local hi = row:CreateTexture(nil,"BACKGROUND")
                hi:SetAllPoints(); row.__hi = hi

                local grip = row:CreateFontString(nil,"OVERLAY","GameFontNormal")
                grip:SetPoint("LEFT", 6, 0); grip:SetText("="); grip:SetTextColor(0.6,0.55,0.35,1)

                local numLbl = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
                numLbl:SetPoint("LEFT", 22, 0); numLbl:SetSize(numW, rowH); numLbl:SetJustifyH("RIGHT")
                row.__num = numLbl

                local nameLbl = row:CreateFontString(nil,"OVERLAY","GameFontNormal")
                nameLbl:SetPoint("LEFT", 22+numW+8, 0)
                nameLbl:SetPoint("RIGHT", row, "RIGHT", -100, 0)
                nameLbl:SetJustifyH("LEFT")
                nameLbl:SetTextColor(1,1,1,1)
                row.__name = nameLbl

                -- Rename button (right side)
                local renBtn = Btn(row, "Rename", 64, 18)
                renBtn:SetPoint("RIGHT", -4, 0)
                row.__renBtn = renBtn

                -- Enable/disable toggle switch (to the left of Rename)
                -- A WoW-style CheckButton using the secure checkbox template
                local toggleBtn = CreateFrame("CheckButton", "SKCatToggle_"..i, row, "BackdropTemplate")
                toggleBtn:SetSize(18, 18)
                toggleBtn:SetPoint("RIGHT", renBtn, "LEFT", -6, 0)
                toggleBtn:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
                toggleBtn:SetBackdropBorderColor(0.45,0.35,0.12,0.8)
                local toggleCheck = toggleBtn:CreateTexture(nil,"ARTWORK")
                toggleCheck:SetAllPoints(); toggleCheck:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
                toggleBtn.__check = toggleCheck
                row.__toggleBtn = toggleBtn

                row.__resetHi = function() hi:SetColorTexture(1,1,1, (row.__slot or 1)%2==0 and 0.05 or 0.02) end

                M._catPool[i] = row
                return row
            end

            -- (Re)bind the drag/hover scripts for a row using the CURRENT build's
            -- closures. Must run every RebuildCO — the row is pooled and persists
            -- across tab switches, but sc/RebuildCO/ordOrder are recreated each
            -- time the Management tab is rebuilt, so stale captures would point at
            -- a buried scroll child and make the list vanish on drop.
            local function BindRowScripts(row)
                local hi = row.__hi
                row:SetScript("OnEnter", function(s) if not s._dragging then hi:SetColorTexture(1,0.82,0,0.12) end end)
                row:SetScript("OnLeave", function(s) if not s._dragging then s.__resetHi() end end)
                if row.__renBtn then
                    row.__renBtn:SetScript("OnClick", function()
                        local cat = row.__catName
                        if cat then M:ShowRenameCategoryDialog(shopName, cat, RebuildCO) end
                    end)
                end
                if row.__toggleBtn then
                    row.__toggleBtn:SetScript("OnClick", function()
                        local cat = row.__catName
                        if not cat then return end
                        local nowEnabled = not SK.DB:IsCategoryEnabled(shopName, cat)
                        SK.DB:SetCategoryEnabled(shopName, cat, nowEnabled)
                        -- Refresh toggle visual
                        row.__toggleBtn.__check:SetAlpha(nowEnabled and 1 or 0)
                        row.__toggleBtn:SetBackdropColor(nowEnabled and 0.08 or 0.04, nowEnabled and 0.18 or 0.04, nowEnabled and 0.08 or 0.04, 1)
                        row.__name:SetTextColor(nowEnabled and 1 or 0.45, nowEnabled and 1 or 0.45, nowEnabled and 1 or 0.45, 1)
                        -- Refresh the register so hidden categories update immediately
                        if SK.Register and SK.Register.BuildProductGrid then SK.Register:BuildProductGrid() end
                        if SK.Net then SK.Net:BroadcastCategoryColors(shopName) end
                    end)
                    row.__toggleBtn:SetScript("OnEnter", function(s)
                        GameTooltip:SetOwner(s,"ANCHOR_TOP")
                        GameTooltip:AddLine("Toggle category visibility",1,1,1)
                        GameTooltip:AddLine("When off, this category is hidden in the register.",0.7,0.7,0.7)
                        GameTooltip:Show()
                    end)
                    row.__toggleBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
                end
                row:SetScript("OnDragStart", function(s)
                    s._dragging = true
                    hi:SetColorTexture(1,0.82,0,0.28)
                    s.__name:SetTextColor(1,0.9,0.5,1)
                    s:SetScript("OnUpdate", function() ShowInsertLine(CursorSlot()) end)
                end)
                row:SetScript("OnDragStop", function(s)
                    s._dragging = false
                    s:SetScript("OnUpdate", nil)
                    insLine:Hide()
                    local from = s.__slot
                    local slot = CursorSlot()
                    if from and slot ~= from and slot ~= from+1 then
                        local moving = ordOrder[from]
                        if moving then
                            table.remove(ordOrder, from)
                            if slot > from then slot = slot - 1 end
                            slot = math.min(math.max(slot,1), #ordOrder+1)
                            table.insert(ordOrder, slot, moving)
                            CommitOrder()
                        end
                    end
                    RebuildCO()
                end)
            end

            RebuildCO = function()
                ordOrder = SK.DB:GetCategoryOrder(shopName)
                insLine:Hide()

                if #ordOrder == 0 then
                    for _, r in ipairs(M._catPool) do r:Hide() end
                    if not M._catEmpty then
                        M._catEmpty = sc:CreateFontString(nil,"OVERLAY","GameFontDisable")
                    end
                    M._catEmpty:SetParent(sc)
                    M._catEmpty:ClearAllPoints()
                    M._catEmpty:SetPoint("TOPLEFT",PAD,yoCO)
                    M._catEmpty:SetText("No categories yet. Add products with categories first.")
                    M._catEmpty:Show()
                    sc:SetHeight(math.max(math.abs(yoCO)+60, 200))
                    return
                end
                if M._catEmpty then M._catEmpty:Hide() end

                for i, catName in ipairs(ordOrder) do
                    local row = GetRow(i)
                    row:SetParent(sc)
                    row:ClearAllPoints()
                    row:SetSize(rowW, rowH)
                    row:SetPoint("TOPLEFT", PAD, yoCO - (i-1)*(rowH+rowGap))
                    row.__slot = i
                    row._dragging = false
                    row.__catName = catName
                    BindRowScripts(row)  -- rebind to current build's closures
                    row.__num:SetText("|cff888888"..i..".|r")
                    row.__name:SetText(catName)
                    local enabled = SK.DB:IsCategoryEnabled(shopName, catName)
                    row.__name:SetTextColor(enabled and 1 or 0.45, enabled and 1 or 0.45, enabled and 1 or 0.45, 1)
                    if row.__toggleBtn then
                        row.__toggleBtn.__check:SetAlpha(enabled and 1 or 0)
                        row.__toggleBtn:SetBackdropColor(enabled and 0.08 or 0.04, enabled and 0.18 or 0.04, enabled and 0.08 or 0.04, 1)
                    end
                    row.__resetHi()
                    row:Show()
                end
                -- Hide any pooled rows beyond the current count
                for i = #ordOrder+1, #M._catPool do
                    M._catPool[i]:Hide()
                end

                local lastBottom = math.abs(yoCO) + (#ordOrder * (rowH+rowGap))
                sc:SetHeight(math.max(lastBottom + PAD + rowH, 200))
            end
            RebuildCO()
            return
        end
    end

    sc:SetHeight(math.max(math.abs(yo) + PAD, 200))
end

-- ─── WHAT'S NEW TAB ──────────────────────────────────────────────────────────

function M:BuildWhatsNewTab()
    WipeContent()
    local p = GetContentPanel(); if not p then return end

    Track(FS(p, "What's New", 13, 1, 0.82, 0)):SetPoint("TOPLEFT", PAD, -PAD)
    Track(HLine(p, -(PAD+18)))

    local sf = Track(CreateFrame("ScrollFrame", nil, p, "UIPanelScrollFrameTemplate"))
    sf:SetPoint("TOPLEFT", PAD, -(PAD+26))
    sf:SetPoint("BOTTOMRIGHT", -PAD-18, PAD)
    local sc = CreateFrame("Frame", nil, sf)
    sc:SetWidth(sf:GetWidth()-4); sc:SetHeight(1); sf:SetScrollChild(sc)

    local yo = 0
    local function L(text, r, g, b, size)
        local fs = sc:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        fs:SetFont("Fonts\\FRIZQT__.TTF", size or 11, "")
        fs:SetPoint("TOPLEFT", 0, -yo)
        fs:SetWidth(sc:GetWidth())
        fs:SetText(text); fs:SetTextColor(r or 1, g or 1, b or 1, 1)
        fs:SetJustifyH("LEFT"); fs:SetWordWrap(true)
        yo = yo + fs:GetStringHeight() + 4
    end
    local function Gap() yo = yo + 8 end
    local function Sep()
        local line = sc:CreateTexture(nil, "ARTWORK")
        line:SetHeight(1); line:SetPoint("TOPLEFT", 0, -yo)
        line:SetWidth(sc:GetWidth())
        line:SetColorTexture(0.35, 0.30, 0.20, 0.5)
        yo = yo + 10
    end

    -- Tutorial button
    local tutBtn = CreateFrame("Button", nil, sc, "UIPanelButtonTemplate")
    tutBtn:SetSize(160, 26); tutBtn:SetPoint("TOPLEFT", 0, -yo)
    tutBtn:SetText("Start Tutorial")
    tutBtn:SetScript("OnClick", function()
        if SK.Tutorial then SK.Tutorial:Start() end
    end)
    yo = yo + 32
    Gap(); Sep()

    -- ── Community links ────────────────────────────────────────────────────────
    L("|cffFFD700Community & Support|r", 1, 0.82, 0, 12)
    Gap()

    local LINK_W = (sc:GetWidth() - 8) / 3  -- three equal-width buttons with 4px gaps
    local LINK_H = 28

    local links = {
        {
            label   = "|cff7289DADiscord|r",
            sub     = "Community Server",
            url     = "https://discord.gg/dHRTBNGR5S",
            borderR = 0.44, borderG = 0.54, borderB = 0.85,
        },
        {
            label   = "|cffFF6600CurseForge|r",
            sub     = "Project Page / Issues",
            url     = "https://www.curseforge.com/wow/addons/storekeeper-wow-pos",
            borderR = 0.85, borderG = 0.40, borderB = 0.10,
        },
        {
            label   = "|cffAAAAFFGitHub|r",
            sub     = "Source Code",
            url     = "https://github.com/Jixsen-is-Gaming/Storekeeper",
            borderR = 0.65, borderG = 0.65, borderB = 0.80,
        },
    }

    local function MakeLinkBtn(def, offsetX)
        local btn = CreateFrame("Button", nil, sc, "BackdropTemplate")
        btn:SetSize(LINK_W, LINK_H)
        btn:SetPoint("TOPLEFT", offsetX, -yo)
        btn:SetBackdrop({
            bgFile   = "Interface\\Buttons\\WHITE8X8", tile=true, tileSize=8,
            edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize=1,
        })
        btn:SetBackdropColor(0.06, 0.06, 0.10, 1)
        btn:SetBackdropBorderColor(def.borderR, def.borderG, def.borderB, 0.85)

        local lbl = btn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        lbl:SetPoint("TOP", 0, -4)
        lbl:SetWidth(LINK_W - 6)
        lbl:SetJustifyH("CENTER")
        lbl:SetText(def.label)

        local sub = btn:CreateFontString(nil, "OVERLAY")
        sub:SetFont("Fonts\\FRIZQT__.TTF", 9, "")
        sub:SetPoint("BOTTOM", 0, 4)
        sub:SetWidth(LINK_W - 6)
        sub:SetJustifyH("CENTER")
        sub:SetTextColor(0.60, 0.60, 0.60, 1)
        sub:SetText(def.sub)

        btn:SetScript("OnEnter", function(self)
            btn:SetBackdropBorderColor(def.borderR, def.borderG, def.borderB, 1)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:AddLine("Click to open URL dialog", 1, 1, 1)
            GameTooltip:AddLine(def.url, 0.6, 0.8, 1)
            GameTooltip:Show()
        end)
        btn:SetScript("OnLeave", function()
            btn:SetBackdropBorderColor(def.borderR, def.borderG, def.borderB, 0.85)
            GameTooltip:Hide()
        end)
        btn:SetScript("OnClick", function()
            if not StaticPopupDialogs["SK_URL_COPY"] then
                StaticPopupDialogs["SK_URL_COPY"] = {
                    text          = "Press |cffFFD700Ctrl+C|r to copy, then paste into your browser:",
                    hasEditBox    = 1,
                    editBoxWidth  = 320,
                    button1       = "Close",
                    OnAccept      = function(dialog) dialog:Hide() end,
                    EditBoxOnEscapePressed = function(dialog) dialog:GetParent():Hide() end,
                    timeout       = 0,
                    whileDead     = 1,
                    hideOnEscape  = 1,
                    preferredIndex = 3,
                }
            end
            local dialog = StaticPopup_Show("SK_URL_COPY")
            if dialog then
                dialog.EditBox:SetText(def.url)
                dialog.EditBox:SetFocus()
                dialog.EditBox:HighlightText()
            end
        end)
    end

    -- Space each button with a small gap between them
    local gap4 = 4
    MakeLinkBtn(links[1], 0)
    MakeLinkBtn(links[2], LINK_W + gap4)
    MakeLinkBtn(links[3], (LINK_W + gap4) * 2)
    yo = yo + LINK_H + 4
    Gap(); Sep()

    -- Header (current version)
    L("|cffFFD700Storekeeper  v"..SK.VERSION.."|r", 1, 0.82, 0, 13)
    L("Merchant Point of Sale (MPoS)  --  Feature Update", 0.55, 0.55, 0.55, 10)
    Gap(); Sep()

    L("|cff66ccffNew|r", 0.4, 0.8, 1, 11)
    Gap()
    L("+ Production Costs (economics): products now have a Restock Cost field in the edit form (below Sale Price). Turn on 'Charge production cost on restock' per shop in Management > Stock & Treasury (owner only). When enabled, restocking an item with the + button in the Stock tab drains its Restock Cost from the treasury, so buying low and selling high finally matters. Off by default; existing shops are unaffected.", 0.85, 0.85, 0.85)
    Gap()
    L("|cffFF6666Fixed|r", 1, 0.4, 0.4, 11)
    Gap()
    L("- Products tab: editing an item and pressing Save no longer snaps the product list back to the top. Your scroll position is kept where you were working.", 0.85, 0.85, 0.85)
    L("- Management > Stock: pressing + or - on a stocked item no longer jumps a long list back to the top. The row updates in place.", 0.85, 0.85, 0.85)
    Gap(); Sep()

    L("|cff888888Full changelog: github.com/Jixsen-is-Gaming/Storekeeper|r", 0.55, 0.55, 0.55, 10)
    Gap()

    L("|cffFFD700Storekeeper  v1.3.8|r", 1, 0.82, 0, 13)
    L("Merchant Point of Sale (MPoS)  --  Feature Update", 0.55, 0.55, 0.55, 10)
    Gap(); Sep()

    L("|cff66ccffNew|r", 0.4, 0.8, 1, 11)
    Gap()
    L("+ Categories can now be enabled or disabled in Management > Categories. A toggle switch on each row controls visibility in the register. Disabled categories are dimmed in the list. All newly created categories default to enabled.", 0.85, 0.85, 0.85)
    L("+ Open New Tab form: added a 'Fill IC' button next to the tab holder name field. Fills in your target's TRP3 IC name, with an OOC name fallback.", 0.85, 0.85, 0.85)
    L("+ Add Staff row: added a 'Target' button that fills the name box with your current target's OOC character name.", 0.85, 0.85, 0.85)
    L("+ Orders tab: added a 'View Order' button that opens a popup with the full item list. The staff member who claimed the order can tick items off as they're prepared.", 0.85, 0.85, 0.85)
    L("+ Orders tab: an '!' button appears next to Delete when an order has an additional note. Hover to read it.", 0.85, 0.85, 0.85)
    Gap()
    L("|cffFF6666Fixed|r", 1, 0.4, 0.4, 11)
    Gap()
    L("- Settings > Responses: response boxes are now much taller and use the full available width. The X (close) button is properly centred and no longer overlaps the scrollbar.", 0.85, 0.85, 0.85)
    L("- Tabs: opening a new tab now refreshes the list immediately without needing to leave and re-enter the tab.", 0.85, 0.85, 0.85)
    L("- Orders tab: the delete button is now labeled 'Delete' instead of 'X' for clarity.", 0.85, 0.85, 0.85)
    L("- Orders tab: long item lists no longer make the order row grow endlessly. Text now truncates with a pointer to View Order.", 0.85, 0.85, 0.85)
    L("- Orders tab: the status dropdown was disproportionately wide next to the claim/release button. Reduced to a sensible fixed width.", 0.85, 0.85, 0.85)
    L("- Fixed a taint error ('attempt to index a secret string value') that could throw while hovering over players in secure frames like LFR.", 0.85, 0.85, 0.85)
    L("- Product form: fixed an infinite-scroll bug in the variant list and added a visible scrollbar (there wasn't one before).", 0.85, 0.85, 0.85)
    L("- Product form: the variant row's remove (X) button is now correctly centred.", 0.85, 0.85, 0.85)
    L("- Product form: fixed the stock quantity box overlapping the 'Limited' label and the TRP3 item checkbox when Limited stock was ticked.", 0.85, 0.85, 0.85)
    Gap(); Sep()

    L("|cff888888Full changelog: github.com/Jixsen-is-Gaming/Storekeeper|r", 0.55, 0.55, 0.55, 10)
    Gap()

    L("|cffFFD700Storekeeper  v1.3.7|r", 1, 0.82, 0, 13)
    L("Merchant Point of Sale (MPoS)  --  Feature Update", 0.55, 0.55, 0.55, 10)
    Gap(); Sep()

    L("|cff66ccffNew|r", 0.4, 0.8, 1, 11)
    Gap()
    L("+ Permissions overhaul: dedicated Permissions sub-tab in the People tab with Manager and Employee columns. Six categories: Products, Register, Orders & Tabs, Treasury, Staff, Logs. Includes new permissions: Finalise Orders, Claim Orders, Reopen Orders, View Logs, Paid as a Favour.", 0.85, 0.85, 0.85)
    L("+ Emote Responses: multiple named templates with a picker popup (Random or by name) when clicking Send as Emote. Managed via Settings > Responses sub-tab.", 0.85, 0.85, 0.85)
    L("+ Fill Target button in Finalise Order: fills Buyer OOC and IC name from your current target, using TRP3 profile with three fallback methods.", 0.85, 0.85, 0.85)
    L("+ Cart quantity: click the qty number in a cart row and type a value directly.", 0.85, 0.85, 0.85)
    L("+ Variant stock cost: each variant can specify how many units of the base stock it uses per sale (e.g. set 4 for a keg variant when base stock is in mugs).", 0.85, 0.85, 0.85)
    L("+ Orders tab: Buyer OOC name now shown separately when filled in. Completed orders show 'Completed by:' instead of 'Working on it:'. Reopen Orders permission allows owners/managers to reopen completed orders.", 0.85, 0.85, 0.85)
    L("+ Version update notice: a single chat message appears when someone nearby is running a newer version. No whispers.", 0.85, 0.85, 0.85)
    L("+ WoW-native UI: all dropdowns (Active Shop, Load Existing, Rarity, Payment Type, Order Status, Emote Channel) now use Blizzard UIDropDownMenu style.", 0.85, 0.85, 0.85)
    L("+ Settings split into General and Responses sub-tabs.", 0.85, 0.85, 0.85)
    Gap()
    L("|cffFF6666Fixed|r", 1, 0.4, 0.4, 11)
    Gap()
    L("- Permissions tick boxes: Employee column no longer accidentally toggled the Manager box (was caused by ChatConfigCheckButtonTemplate oversized hit region).", 0.85, 0.85, 0.85)
    L("- Settings sub-tab ghosting: switching tabs no longer leaves text and textures from the previous tab visible.", 0.85, 0.85, 0.85)
    L("- Version parser updated to handle 4-part version strings (e.g. 1.3.6.1).", 0.85, 0.85, 0.85)
    L("- Order rows: status dropdown and claim button now sit inside the row frame. Delete button moved to top-right corner.", 0.85, 0.85, 0.85)
    L("- Product form layout: Rarity above Name, Icon on same row as Rarity, Stock/TRP3/Variants on same row as Price.", 0.85, 0.85, 0.85)
    L("- Variant rows redesigned: fixed-width name box, price and stock uses on the same line.", 0.85, 0.85, 0.85)
    L("- Completed order ETA countdown stopped. Working on it text hidden after completion.", 0.85, 0.85, 0.85)
    Gap(); Sep()

    L("|cff888888Full changelog: github.com/Jixsen-is-Gaming/Storekeeper|r", 0.55, 0.55, 0.55, 10)
    Gap()

    L("|cffFFD700Storekeeper  v1.3.6.1|r", 1, 0.82, 0, 13)
    L("Merchant Point of Sale (MPoS)  —  Hotfix", 0.55, 0.55, 0.55, 10)
    Gap(); Sep()

    L("|cffFF6666Fixed|r", 1, 0.4, 0.4, 11)
    Gap()
    L("• Management tab: content from the Categories sub-tab (drag handles, category rows, and the instruction label) no longer remains visible behind the Staff or Stock & Treasury sub-tabs after switching between them.", 0.85, 0.85, 0.85)
    L("• Finalise Order popup: the order summary now shows in a scrollable panel capped at 5 items. Carts with more than 5 lines no longer overflow the popup and obscure the payment buttons.", 0.85, 0.85, 0.85)
    L("• Arrange mode: the product list now fills the full height of the panel when Arrange is active, instead of leaving a large empty gap below that was reserved for the edit form.", 0.85, 0.85, 0.85)
    Gap(); Sep()


    -- Transparency note
    Gap()
    L("Small transparency note: this addon is developed with AI assistance — the code is written by Claude, guided by the developer's own ideas and direction.", 0.55, 0.55, 0.55, 10)
    Gap()

    sc:SetHeight(math.max(yo + 10, 30))
end

-- ─── Tab definitions ──────────────────────────────────────────────────────────

local TAB_KEYS   = {"products","shops","people","orders","tabs","logs","settings"}
local TAB_LABELS = {"Products","Shop(s) Overview","Management","Orders","Tabs","Activity Log","Personal Settings"}
local TAB_ICONS  = {
    "Interface\\Icons\\INV_Misc_Coin_01",        -- Products
    "Interface\\Icons\\INV_Box_01",              -- Shop(s) Overview
    "Interface\\Icons\\INV_Misc_GroupNeedMore",  -- Management
    "Interface\\Icons\\INV_Scroll_07",           -- Orders
    "Interface\\Icons\\INV_Misc_Note_01",        -- Tabs
    "Interface\\Icons\\INV_Misc_Book_01",        -- Activity Log
    "Interface\\Icons\\INV_Misc_Gear_01",        -- Personal Settings
}

-- ─── Tab switcher ─────────────────────────────────────────────────────────────

function M:SwitchTab(tab)
    -- Leaving the Products tab always exits arrange mode
    if tab ~= "products" then M._arrangeMode = false end
    M.activeTab = tab
    -- If rendered inside the Register, delegate to its SwitchToTab
    if SK.Register and SK.Register.SwitchToTab and SK.Register.isOpen then
        SK.Register.SwitchToTab(tab)
        return
    end
    -- Standalone manager window path
    for i, key in ipairs(TAB_KEYS) do
        local btn = M.tabBtns and M.tabBtns[i]
        if btn then
            local on = (key == tab)
            if btn.activebar then btn.activebar:SetAlpha(on and 1 or 0) end
            if btn.bg then
                if on then btn.bg:SetColorTexture(0.8,0.65,0.2,0.20)
                else        btn.bg:SetColorTexture(0.8,0.65,0.2,0) end
            end
            if btn.ic then
                if on then btn.ic:SetVertexColor(1,0.85,0.3,1)
                else       btn.ic:SetVertexColor(0.75,0.68,0.55,1) end
            end
        end
    end
    if M.contentPanel then
        if     tab=="products" then M:BuildProductTab()
        elseif tab=="staff" or tab=="people" then M:BuildPeopleTab()
        elseif tab=="orders"   then M:BuildOrdersTab()
        elseif tab=="tabs"     then M:BuildTabsTab()
        elseif tab=="logs"     then M:BuildLogsTab()
        elseif tab=="shops"    then M:BuildShopsTab()
        elseif tab=="settings" then M:BuildSettingsTab()
        end
    end
end

-- ─── Main Frame — Guild & Communities style ───────────────────────────────────

local SIDEBAR_W = 140
local TITLE_H   = 24

function M:Build()
    if M.mainFrame then M.mainFrame:Show(); return end

    local c       = SK:C()
    local isGob   = (SK.db.theme == SK.THEMES.GOBLIN)
    local W, H    = 680, 540
    local INSET   = 12

    -- Theme-driven texture IDs:
    -- Gnomish = Gnomeregan steel diamond plate (blue-grey)
    -- Goblin  = Blackrock Depths iron (warm brown/rust tint)
    -- Tileable dark metal panel — same texture for both themes,
    -- vertex colour provides the Gnomish (blue-steel) vs Goblin (green) distinction
    local BG_TEX_MAIN    = 374155   -- UI-Background-Rock (dark, tileable)
    local BG_TEX_SIDEBAR = 516765   -- DarkSandstone-Tile (slightly different texture)

    -- ── Outer frame — gold border, theme bg texture ───────────────────────
    local f = CreateFrame("Frame","StorekeeperManagerFrame",UIParent,"BackdropTemplate")
    f:SetSize(W,H); f:SetPoint("CENTER")
    f:SetMovable(true); f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart",f.StartMoving); f:SetScript("OnDragStop",f.StopMovingOrSizing)
    f:SetFrameStrata("DIALOG"); f:SetToplevel(true)
    -- Backdrop provides only the border; bg is a separate stretched texture layer
    f:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8X8",
        tile     = true, tileSize = 8,
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
        edgeSize = 32,
        insets   = {left=INSET, right=INSET, top=INSET, bottom=INSET},
    })
    f:SetBackdropColor(0, 0, 0, 0)  -- transparent — bg texture does the work
    f:SetBackdropBorderColor(1, 1, 1, 1)

    -- Tiled background — fills the entire frame regardless of size
    local bgTex = f:CreateTexture(nil,"BACKGROUND")
    bgTex:SetPoint("TOPLEFT", INSET, -INSET)
    bgTex:SetPoint("BOTTOMRIGHT", -INSET, INSET)
    bgTex:SetTexture(BG_TEX_MAIN)
    bgTex:SetHorizTile(true); bgTex:SetVertTile(true)
    if isGob then
        bgTex:SetVertexColor(0.38, 0.48, 0.28, 1)  -- Goblin: dark green-brown
    else
        bgTex:SetVertexColor(0.32, 0.40, 0.52, 1)  -- Gnomish: dark blue-steel
    end

    M.mainFrame = f

    if not M._specialFrameRegistered then
        tinsert(UISpecialFrames,"StorekeeperManagerFrame")
        M._specialFrameRegistered = true
    end
    f:SetScript("OnHide", function() M.isOpen = false end)

    -- ── Title bar — gold header ────────────────────────────────────────────
    local titleBar = CreateFrame("Frame",nil,f,"BackdropTemplate")
    titleBar:SetHeight(TITLE_H)
    titleBar:SetPoint("TOPLEFT",  INSET, -INSET)
    titleBar:SetPoint("TOPRIGHT", -INSET, -INSET)
    titleBar:SetBackdrop({
        bgFile   = "Interface\\DialogFrame\\UI-DialogBox-Gold-Background",
        tile     = true, tileSize = 256,
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
        edgeSize = 16,
        insets   = {left=4, right=4, top=4, bottom=4},
    })
    titleBar:SetBackdropColor(1, 1, 1, 1)
    titleBar:SetBackdropBorderColor(1, 1, 1, 0.8)
    titleBar:EnableMouse(true); titleBar:RegisterForDrag("LeftButton")
    titleBar:SetScript("OnDragStart",function() f:StartMoving() end)
    titleBar:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)

    local tl = titleBar:CreateFontString(nil,"OVERLAY","GameFontNormal")
    tl:SetFont("Fonts\\FRIZQT__.TTF",13,"OUTLINE")
    tl:SetPoint("LEFT",10,0)
    tl:SetText("|cffFFD700Storekeeper|r  — Manager")
    tl:SetShadowColor(0,0,0,1); tl:SetShadowOffset(1,-1)

    local xb = CreateFrame("Button",nil,titleBar,"UIPanelCloseButton")
    xb:SetSize(26,26); xb:SetPoint("RIGHT",-2,0)
    xb:SetScript("OnClick", function() M:Toggle() end)

    -- ── Right icon tab bar ─────────────────────────────────────────────────
    local TAB_W = 44  -- width of the right icon tab column
    local TAB_BTN_H = 44  -- height of each tab button (square icons)

    local tabBar = CreateFrame("Frame",nil,f,"BackdropTemplate")
    tabBar:SetWidth(TAB_W)
    tabBar:SetPoint("TOPRIGHT",    -INSET, -(INSET + TITLE_H + 2))
    tabBar:SetPoint("BOTTOMRIGHT", -INSET,   INSET)
    tabBar:SetBackdrop({
        bgFile  = "Interface\\Buttons\\WHITE8X8", tile=true, tileSize=8,
        edgeFile= "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=10,
        insets  = {left=2,right=2,top=2,bottom=2},
    })
    tabBar:SetBackdropColor(0.04, 0.04, 0.08, 0.92)
    tabBar:SetBackdropBorderColor(0.45, 0.35, 0.12, 0.7)

    -- Gold separator line between content and tab bar
    local sep = f:CreateTexture(nil,"ARTWORK"); sep:SetWidth(1)
    sep:SetPoint("TOPRIGHT",    -(INSET + TAB_W), -(INSET + TITLE_H + 2))
    sep:SetPoint("BOTTOMRIGHT", -(INSET + TAB_W),   INSET)
    sep:SetColorTexture(0.6, 0.48, 0.15, 0.5)

    -- ── Tab icon buttons ──────────────────────────────────────────────────
    M.tabBtns = {}

    for i, key in ipairs(TAB_KEYS) do
        local btn = CreateFrame("Button",nil,tabBar)
        btn:SetSize(TAB_W - 4, TAB_BTN_H)
        btn:SetPoint("TOPLEFT", 2, -((i-1)*TAB_BTN_H) - 2)
        btn:SetNormalTexture(""); btn:SetHighlightTexture("")
        btn:SetPushedTexture(""); btn:SetDisabledTexture("")

        -- Active/hover background
        local bg = btn:CreateTexture(nil,"BACKGROUND"); bg:SetAllPoints()
        bg:SetColorTexture(0.8, 0.65, 0.2, 0)

        -- Active indicator — gold bar on the left edge of the tab strip
        local bar = btn:CreateTexture(nil,"OVERLAY"); bar:SetWidth(3)
        bar:SetPoint("TOPLEFT",0,0); bar:SetPoint("BOTTOMLEFT",0,0)
        bar:SetColorTexture(1, 0.82, 0.0, 1)
        bar:SetAlpha(0)

        -- Divider between tabs
        local div = btn:CreateTexture(nil,"BORDER"); div:SetHeight(1)
        div:SetPoint("BOTTOMLEFT",2,0); div:SetPoint("BOTTOMRIGHT",-2,0)
        div:SetColorTexture(0.5, 0.4, 0.15, 0.35)

        -- Icon — centred in the button
        local ic = btn:CreateTexture(nil,"ARTWORK"); ic:SetSize(26,26)
        ic:SetPoint("CENTER",0,0)
        ic:SetTexture(TAB_ICONS[i] or "Interface\\Icons\\INV_Misc_QuestionMark")
        ic:SetTexCoord(0.08,0.92,0.08,0.92)

        btn.bg = bg; btn.activebar = bar; btn.ic = ic

        local k   = key
        local lbl = TAB_LABELS[i]
        btn:SetScript("OnClick",function() M:SwitchTab(k) end)
        btn:SetScript("OnEnter",function()
            if M.activeTab ~= k then
                bg:SetColorTexture(0.8, 0.65, 0.2, 0.15)
                ic:SetVertexColor(1, 0.92, 0.55, 1)
            end
            GameTooltip:SetOwner(btn,"ANCHOR_LEFT")
            GameTooltip:AddLine(lbl,1,0.82,0,1)
            GameTooltip:Show()
        end)
        btn:SetScript("OnLeave",function()
            if M.activeTab ~= k then
                bg:SetColorTexture(0.8, 0.65, 0.2, 0)
                ic:SetVertexColor(1,1,1,1)
            end
            GameTooltip:Hide()
        end)
        M.tabBtns[i] = btn
    end

    -- ── Content panel ──────────────────────────────────────────────────────
    local content = CreateFrame("Frame",nil,f,"BackdropTemplate")
    content:SetPoint("TOPLEFT",     INSET,            -(INSET + TITLE_H + 2))
    content:SetPoint("BOTTOMRIGHT", -(INSET + TAB_W + 1), INSET)
    content:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8", tile=true, tileSize=8,
    })
    -- Slightly less dark than sidebar so content area breathes
    content:SetBackdropColor(0, 0, 0, 0.15)
    local ctTex = content:CreateTexture(nil,"BACKGROUND"); ctTex:SetAllPoints()
    ctTex:SetTexture(BG_TEX_MAIN)
    ctTex:SetHorizTile(true); ctTex:SetVertTile(true)
    if isGob then
        ctTex:SetVertexColor(0.38, 0.48, 0.28, 0.6)
    else
        ctTex:SetVertexColor(0.32, 0.40, 0.52, 0.6)
    end

    M.contentPanel    = content
    M.contentChildren = {}

    M:SwitchTab("products")
end

function M:Toggle()
    if not M.mainFrame then M:Build() end
    if M.isOpen then
        M.mainFrame:Hide(); M.isOpen=false
    else
        M.mainFrame:Show(); M.isOpen=true; M:SwitchTab(M.activeTab or "products")
    end
end

function M:ApplyTheme()
    local wasOpen = M.isOpen
    if M.mainFrame then
        M.mainFrame:Hide(); M.mainFrame=nil
        M.contentPanel=nil; M.contentChildren={}; M.tabBtns=nil; M.isOpen=false
    end
    if wasOpen then M:Build(); M.mainFrame:Show(); M.isOpen=true end
end
