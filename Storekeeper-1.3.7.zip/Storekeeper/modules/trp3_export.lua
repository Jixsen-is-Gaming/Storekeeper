-- Storekeeper: TRP3 Profile Export
-- Generates a formatted TRP3 "About" tab text block from the active shop's
-- product catalogue. Players copy the output and paste it into TRP3 manually.
--
-- TRP3 markup used:
--   {h1:c} {h2:c} {h3:c} {p} {p:c}   — headings and paragraphs, with alignment
--   {col:RRGGBB}...{/col}             — colour spans
--   {icon:NAME:SIZE}                  — inline icon (named icons only)

Storekeeper.Export = Storekeeper.Export or {}
local SK = Storekeeper
local EX = SK.Export

-- ─── Defaults ────────────────────────────────────────────────────────────────

local DEFAULTS = {
    shopTitleSize   = "h1",      -- "h1" | "h2" | "none"
    categorySize    = "h2",      -- "h1" | "h2" | "h3" | "none"
    productSize     = "h3",      -- "h2" | "h3" | "p"
    alignment       = "c",       -- "c" (centre) | "l" (left, omit tag suffix)
    useCategoryColor = true,
    skipOutOfStock  = true,
}

-- Active settings — initialised from defaults, persisted in SK.db
local CFG = {}

local function LoadCFG()
    if not SK.db then return end
    SK.db.exportSettings = SK.db.exportSettings or {}
    local s = SK.db.exportSettings
    for k, v in pairs(DEFAULTS) do
        CFG[k] = (s[k] ~= nil) and s[k] or v
    end
end

local function SaveCFG()
    if not SK.db then return end
    SK.db.exportSettings = SK.db.exportSettings or {}
    for k, v in pairs(CFG) do
        SK.db.exportSettings[k] = v
    end
end

-- ─── Markup helpers ───────────────────────────────────────────────────────────

local function RGBToHex(r, g, b)
    r = math.max(0, math.min(1, r or 1))
    g = math.max(0, math.min(1, g or 0.82))
    b = math.max(0, math.min(1, b or 0))
    return string.format("%02X%02X%02X",
        math.floor(r * 255 + 0.5),
        math.floor(g * 255 + 0.5),
        math.floor(b * 255 + 0.5))
end

-- Wraps text in a TRP3 heading or paragraph tag.
-- tag: "h1"|"h2"|"h3"|"p"|"none"   align: "c"|"l"
local function Wrap(tag, align, text)
    if tag == "none" or tag == "" then return text end
    local suffix = (align == "c") and ":c" or ""
    return "{" .. tag .. suffix .. "}" .. text .. "{/" .. tag .. "}"
end

local function FormatPrice(copper)
    copper = math.floor(copper + 0.5)
    if copper == 0 then return "free" end
    local g = math.floor(copper / 10000)
    local s = math.floor((copper % 10000) / 100)
    local c = copper % 100
    local parts = {}
    if g > 0 then tinsert(parts, "{col:896f09}" .. g .. " gold{/col}")     end
    if s > 0 then tinsert(parts, "{col:818181}" .. s .. " silver{/col}")   end
    if c > 0 then tinsert(parts, "{col:D47D31}" .. c .. " copper{/col}")   end
    if #parts == 1 then return parts[1] end
    return table.concat(parts, " ")
end

local function IconTag(iconID)
    if not TRP3_API then return "" end
    if type(iconID) == "string" and iconID ~= "" then
        local name = iconID:match("([^\\]+)$") or iconID
        return "{icon:" .. name .. ":16} "
    end
    return ""
end

-- ─── Generator ────────────────────────────────────────────────────────────────

function EX:GenerateTRP3Text(shopName)
    LoadCFG()
    shopName = shopName or (SK.db and SK.db.activeShop)
    if not shopName then return nil, "No active shop." end

    local catsByName, catOrder = SK.DB:GetProductsByCategory(shopName)
    if not catOrder or #catOrder == 0 then
        return nil, "This shop has no products yet."
    end

    local lines = {}
    local align = CFG.alignment

    -- Shop title
    if CFG.shopTitleSize ~= "none" then
        tinsert(lines, Wrap(CFG.shopTitleSize, align, shopName))
    end

    for _, catName in ipairs(catOrder) do
        local products = catsByName[catName]
        if products and #products > 0 then

            -- Category heading
            if CFG.categorySize ~= "none" then
                local catLabel = catName
                if CFG.useCategoryColor then
                    local r, g, b = SK.DB:GetCategoryColor(shopName, catName)
                    local hex = RGBToHex(r, g, b)
                    catLabel = "{col:" .. hex .. "}" .. catName .. "{/col}"
                end
                tinsert(lines, Wrap(CFG.categorySize, align, catLabel))
            end

            for _, prod in ipairs(products) do
                -- Skip out-of-stock if requested
                if not CFG.skipOutOfStock or prod.stock == nil or prod.stock > 0 then

                    local priceStr = FormatPrice(prod.priceCopper)
                    local icon     = IconTag(prod.icon)
                    local nameStr  = icon .. prod.name .. " - " .. priceStr

                    tinsert(lines, Wrap(CFG.productSize, align, nameStr))

                    if prod.description and strtrim(prod.description) ~= "" then
                        tinsert(lines, Wrap("p", align, strtrim(prod.description)))
                    end
                end
            end

            -- Blank line between categories
            tinsert(lines, "")
        end
    end

    if #lines == 0 or (#lines == 1 and CFG.shopTitleSize ~= "none") then
        return nil, "No available products to export."
    end

    return table.concat(lines, "\n"), nil
end

-- ─── UI helpers ───────────────────────────────────────────────────────────────

local PAD = 8

local function MakeFrame(w, h, parent)
    local f = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    f:SetSize(w, h)
    f:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        edgeSize = 10,
        insets   = { left=4, right=4, top=4, bottom=4 },
    })
    f:SetBackdropColor(0.06, 0.06, 0.10, 0.97)
    f:SetBackdropBorderColor(0.45, 0.35, 0.12, 1)
    return f
end

local function Label(parent, text, size, r, g, b)
    local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    fs:SetFont("Fonts\\FRIZQT__.TTF", size or 10, "")
    fs:SetText(text)
    fs:SetTextColor(r or 0.85, g or 0.75, b or 0.55, 1)
    return fs
end

-- A small inline toggle/cycle button that displays its current value.
-- values: list of {key, label}
local function CycleBtn(parent, w, h, values, getCurrent, onSet)
    local btn = CreateFrame("Button", nil, parent, "BackdropTemplate")
    btn:SetSize(w, h)
    btn:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    btn:SetBackdropColor(0.10, 0.08, 0.04, 1)
    btn:SetBackdropBorderColor(0.45, 0.35, 0.12, 1)
    local lbl = btn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    lbl:SetAllPoints(); lbl:SetFont("Fonts\\FRIZQT__.TTF",10,"")
    lbl:SetTextColor(1,0.82,0,1)

    local function Refresh()
        local cur = getCurrent()
        for _, v in ipairs(values) do
            if v[1] == cur then lbl:SetText(v[2]); return end
        end
        lbl:SetText("?")
    end
    Refresh()

    btn:SetScript("OnClick", function()
        local cur = getCurrent()
        for i, v in ipairs(values) do
            if v[1] == cur then
                local next = values[(i % #values) + 1]
                onSet(next[1])
                Refresh()
                return
            end
        end
        onSet(values[1][1]); Refresh()
    end)
    btn:SetScript("OnEnter", function(s) s:SetBackdropColor(0.18,0.14,0.06,1) end)
    btn:SetScript("OnLeave", function(s) s:SetBackdropColor(0.10,0.08,0.04,1) end)

    btn.Refresh = Refresh
    return btn
end

-- A simple toggle checkbox button
local function CheckBtn(parent, getCurrent, onToggle)
    local btn = CreateFrame("Button", nil, parent, "BackdropTemplate")
    btn:SetSize(16, 16)
    btn:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    btn:SetBackdropBorderColor(0.45, 0.35, 0.12, 1)
    local check = btn:CreateTexture(nil, "ARTWORK")
    check:SetAllPoints()
    check:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")

    local function Refresh()
        local on = getCurrent()
        check:SetAlpha(on and 1 or 0)
        btn:SetBackdropColor(on and 0.08 or 0.06, on and 0.18 or 0.06, on and 0.08 or 0.10, 1)
    end
    Refresh()

    btn:SetScript("OnClick", function() onToggle(); Refresh() end)
    btn.Refresh = Refresh
    return btn
end

-- ─── Settings panel ───────────────────────────────────────────────────────────

local PANEL_W = 300
local PANEL_H = 234

local SIZE_OPTIONS = {
    {"h1",   "H1 — Large"},
    {"h2",   "H2 — Medium"},
    {"h3",   "H3 — Small"},
    {"p",    "P  — Body"},
    {"none", "Hidden"},
}
local TITLE_SIZE_OPTIONS = {
    {"h1",   "H1 — Large"},
    {"h2",   "H2 — Medium"},
    {"none", "Hidden"},
}
local ALIGN_OPTIONS = {
    {"c", "Centre"},
    {"l", "Left"},
}

function EX:ShowSettingsPanel(anchor)
    LoadCFG()

    if EX._settingsPanel then
        EX._settingsPanel:ClearAllPoints()
        EX._settingsPanel:SetPoint("BOTTOMLEFT", anchor, "TOPLEFT", 0, 4)
        EX._settingsPanel:Show()
        EX:_RefreshSettings()
        return
    end

    local f = MakeFrame(PANEL_W, PANEL_H, UIParent)
    f:SetPoint("BOTTOMLEFT", anchor, "TOPLEFT", 0, 4)
    f:SetFrameStrata("DIALOG")
    f:SetMovable(true); f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop",  f.StopMovingOrSizing)

    -- Title
    local title = Label(f, "|cffFFD700TRP3 Export Settings|r", 11)
    title:SetPoint("TOPLEFT", PAD, -PAD)

    local closeBtn = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function() f:Hide() end)

    -- Divider
    local div = f:CreateTexture(nil, "ARTWORK")
    div:SetHeight(1); div:SetColorTexture(0.45, 0.35, 0.12, 0.6)
    div:SetPoint("TOPLEFT", PAD, -24); div:SetPoint("TOPRIGHT", -PAD, -24)

    local yo = -32
    local LPAD = PAD + 2
    local BTN_W = 120
    local BTN_H = 18

    local btnRefs = {}

    local function Row(labelText, values, getCurrent, onSet)
        local lbl = Label(f, labelText, 10)
        lbl:SetPoint("TOPLEFT", LPAD, yo)
        lbl:SetWidth(PANEL_W - LPAD - BTN_W - PAD - 4)
        lbl:SetJustifyH("LEFT")

        local btn = CycleBtn(f, BTN_W, BTN_H, values,
            getCurrent, function(v) onSet(v); SaveCFG() end)
        btn:SetPoint("TOPRIGHT", -PAD, yo)
        tinsert(btnRefs, btn)

        yo = yo - (BTN_H + 5)
    end

    local function CheckRow(labelText, getCurrent, onToggle)
        local cb = CheckBtn(f,
            getCurrent,
            function() onToggle(); SaveCFG() end)
        cb:SetPoint("TOPLEFT", LPAD, yo)
        tinsert(btnRefs, cb)

        local lbl = Label(f, labelText, 10)
        lbl:SetPoint("LEFT", cb, "RIGHT", 5, 0)

        yo = yo - (16 + 6)
        return cb
    end

    local function Sep()
        local d = f:CreateTexture(nil,"ARTWORK")
        d:SetHeight(1); d:SetColorTexture(0.35,0.30,0.20,0.3)
        d:SetPoint("TOPLEFT", LPAD, yo + 2)
        d:SetPoint("TOPRIGHT", -PAD, yo + 2)
        yo = yo - 8
    end

    -- Rows
    Row("Shop title size", TITLE_SIZE_OPTIONS,
        function() return CFG.shopTitleSize end,
        function(v) CFG.shopTitleSize = v end)

    Row("Category title size", SIZE_OPTIONS,
        function() return CFG.categorySize end,
        function(v) CFG.categorySize = v end)

    Row("Product name size", SIZE_OPTIONS,
        function() return CFG.productSize end,
        function(v) CFG.productSize = v end)

    Row("Alignment", ALIGN_OPTIONS,
        function() return CFG.alignment end,
        function(v) CFG.alignment = v end)

    Sep()

    CheckRow("Use category colours",
        function() return CFG.useCategoryColor end,
        function() CFG.useCategoryColor = not CFG.useCategoryColor end)

    CheckRow("Skip out-of-stock products",
        function() return CFG.skipOutOfStock end,
        function() CFG.skipOutOfStock = not CFG.skipOutOfStock end)

    -- Generate button
    local genBtn = CreateFrame("Button", nil, f, "BackdropTemplate")
    genBtn:SetSize(PANEL_W - PAD*2, 22)
    genBtn:SetPoint("BOTTOMLEFT", PAD, PAD)
    genBtn:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    genBtn:SetBackdropColor(0.08,0.12,0.06,1)
    genBtn:SetBackdropBorderColor(0.35,0.55,0.20,1)
    local genLbl = genBtn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    genLbl:SetAllPoints(); genLbl:SetText("|cff88FF44Generate & Copy|r")
    genBtn:SetScript("OnClick", function()
        f:Hide()
        EX:OpenExport()
    end)
    genBtn:SetScript("OnEnter",function(s) s:SetBackdropColor(0.12,0.18,0.08,1) end)
    genBtn:SetScript("OnLeave",function(s) s:SetBackdropColor(0.08,0.12,0.06,1) end)

    EX._settingsPanel = f
    EX._settingsBtns  = btnRefs
end

function EX:_RefreshSettings()
    LoadCFG()
    if EX._settingsBtns then
        for _, b in ipairs(EX._settingsBtns) do
            if b.Refresh then b:Refresh() end
        end
    end
end

-- ─── Copy popup ───────────────────────────────────────────────────────────────

local POPUP_W = 480
local POPUP_H = 360

function EX:ShowCopyPopup(text)
    if EX._popup then
        EX._editBox:SetText(text)
        EX._editBox:SetFocus()
        EX._editBox:HighlightText()
        if EX._countLbl then
            EX._countLbl:SetText("|cff888888" .. #text .. " characters|r")
        end
        EX._popup:Show()
        return
    end

    local f = MakeFrame(POPUP_W, POPUP_H, UIParent)
    f:SetPoint("CENTER")
    f:SetFrameStrata("DIALOG")
    f:SetMovable(true); f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop",  f.StopMovingOrSizing)

    local title = Label(f, "|cffFFD700TRP3 Profile Text|r", 11)
    title:SetPoint("TOPLEFT", PAD+2, -PAD)

    local sub = Label(f, "Select all and copy, then paste into Total RP 3 → About (History).", 9, 0.6, 0.6, 0.6)
    sub:SetPoint("TOPLEFT", PAD+2, -22)

    local closeBtn = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function() f:Hide() end)

    local div = f:CreateTexture(nil, "ARTWORK")
    div:SetHeight(1); div:SetColorTexture(0.45, 0.35, 0.12, 0.6)
    div:SetPoint("TOPLEFT", PAD, -36); div:SetPoint("TOPRIGHT", -PAD, -36)

    local sf = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
    sf:SetPoint("TOPLEFT",     PAD, -46)
    sf:SetPoint("BOTTOMRIGHT", -26, 40)

    local eb = CreateFrame("EditBox", nil, sf)
    eb:SetMultiLine(true)
    eb:SetAutoFocus(false)
    eb:SetFontObject(ChatFontNormal)
    eb:SetWidth(sf:GetWidth() - 4)
    eb:SetText(text)
    eb:SetScript("OnEscapePressed", function() f:Hide() end)
    sf:SetScrollChild(eb)

    -- Select All button
    local selBtn = CreateFrame("Button", nil, f, "BackdropTemplate")
    selBtn:SetSize(100, 22); selBtn:SetPoint("BOTTOMLEFT", PAD, PAD)
    selBtn:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    selBtn:SetBackdropColor(0.12,0.10,0.06,1)
    selBtn:SetBackdropBorderColor(0.45,0.35,0.12,1)
    local selLbl = selBtn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    selLbl:SetAllPoints(); selLbl:SetText("Select All")
    selBtn:SetScript("OnClick",  function() eb:SetFocus(); eb:HighlightText() end)
    selBtn:SetScript("OnEnter",  function(s) s:SetBackdropColor(0.20,0.16,0.08,1) end)
    selBtn:SetScript("OnLeave",  function(s) s:SetBackdropColor(0.12,0.10,0.06,1) end)

    local countLbl = Label(f, "|cff888888" .. #text .. " characters|r", 9, 0.5, 0.5, 0.5)
    countLbl:SetPoint("BOTTOMRIGHT", -PAD, PAD+4)

    EX._popup    = f
    EX._editBox  = eb
    EX._countLbl = countLbl

    eb:SetFocus(); eb:HighlightText()
    f:Show()
end

-- ─── Entry points ─────────────────────────────────────────────────────────────

function EX:OpenSettings(anchor)
    EX:ShowSettingsPanel(anchor)
end

function EX:OpenExport()
    LoadCFG()
    local text, err = EX:GenerateTRP3Text()
    if err then
        print("|cffFFD700[Storekeeper]|r " .. err)
        return
    end
    EX:ShowCopyPopup(text)
end
