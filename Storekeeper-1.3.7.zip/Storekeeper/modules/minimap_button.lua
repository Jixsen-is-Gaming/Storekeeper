-- Storekeeper: Minimap Button
-- Exact LibDBIcon-1.0 layout. Tooltip uses GameTooltip anchored below
-- the button so cursor movement away from button does not cross the minimap.

Storekeeper.MinimapBtn = Storekeeper.MinimapBtn or {}
local SK = Storekeeper
local MB = SK.MinimapBtn

local function GetAngle() return (SK.db and SK.db.minimapAngle) or 220 end
local function SetAngle(a) if SK.db then SK.db.minimapAngle = a end end
local function GetRadius() return (Minimap:GetWidth() / 2) + 5 end

function MB:UpdatePosition()
    if not MB.button then return end
    local rad = math.rad(GetAngle())
    local r   = GetRadius()
    MB.button:SetPoint("CENTER", Minimap, "CENTER",
        r * math.cos(rad), r * math.sin(rad))
end

function MB:Build()
    if MB.button then return end

    -- Exact LibDBIcon-1.0: button 31x31, overlay 53x53 at TOPLEFT (no offset),
    -- background 20x20 at TOPLEFT(7,-5), icon 17x17 at TOPLEFT(7,-6)
    local btn = CreateFrame("Button", "StorekeeperMinimapButton", Minimap)
    btn:SetSize(31, 31)
    btn:SetFrameStrata("MEDIUM")
    btn:SetFrameLevel(Minimap:GetFrameLevel() + 8)
    btn:SetClampedToScreen(true)
    MB.button = btn

    local overlay = btn:CreateTexture(nil, "OVERLAY")
    overlay:SetSize(53, 53)
    overlay:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    overlay:SetPoint("TOPLEFT")

    local bg = btn:CreateTexture(nil, "BACKGROUND")
    bg:SetSize(20, 20)
    bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
    bg:SetPoint("TOPLEFT", btn, "TOPLEFT", 7, -5)

    local icon = btn:CreateTexture(nil, "ARTWORK")
    icon:SetSize(17, 17)
    icon:SetPoint("TOPLEFT", btn, "TOPLEFT", 7, -6)
    icon:SetTexCoord(0.05, 0.95, 0.05, 0.95)
    MB.iconTex = icon

    btn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    -- Tooltip: ANCHOR_BOTTOMLEFT places the tooltip below-left of the button.
    -- This keeps it away from the minimap portrait so the cursor moving
    -- toward/away from the minimap does NOT cross the tooltip and does NOT
    -- trigger OnLeave. The tooltip hides correctly via GameTooltip:Hide().
    btn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOMLEFT")
        GameTooltip:ClearLines()
        GameTooltip:AddLine("Storekeeper", 1, 0.82, 0)
        GameTooltip:AddLine("Version: " .. (SK.VERSION or "?"), 0.7, 0.7, 0.7)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Left-click:  Open Register",      1,   1,   1)
        GameTooltip:AddLine("Settings via the Register tabs",  0.6, 0.6, 0.6)
        GameTooltip:AddLine("Drag:        Reposition",         0.6, 0.6, 0.6)
        local peers    = SK.knownPeers or {}
        local outdated = {}
        for name, ver in pairs(peers) do
            if type(ver) == "string" and ver ~= SK.VERSION and ver ~= "?" then
                tinsert(outdated, name .. "  (v" .. ver .. ")")
            end
        end
        if #outdated > 0 then
            GameTooltip:AddLine(" ")
            GameTooltip:AddLine("Peers on different version:", 1, 0.6, 0.1)
            for _, s in ipairs(outdated) do
                GameTooltip:AddLine("  " .. s, 0.75, 0.75, 0.75)
            end
        end
        GameTooltip:Show()
    end)

    btn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    -- Drag vs click
    local dragging = false
    local downX, downY = 0, 0

    btn:SetScript("OnMouseDown", function(self, mouseBtn)
        if mouseBtn ~= "LeftButton" then return end
        downX, downY = GetCursorPosition()
        dragging = false
        self:SetScript("OnUpdate", function()
            if not IsMouseButtonDown("LeftButton") then
                self:SetScript("OnUpdate", nil); return
            end
            local nx, ny = GetCursorPosition()
            if not dragging and
               (math.abs(nx - downX) > 4 or math.abs(ny - downY) > 4) then
                dragging = true
            end
            if dragging then
                local scale = UIParent:GetEffectiveScale()
                local cx = Minimap:GetLeft()   + Minimap:GetWidth()  / 2
                local cy = Minimap:GetBottom() + Minimap:GetHeight() / 2
                SetAngle(math.deg(math.atan2(ny / scale - cy, nx / scale - cx)))
                MB:UpdatePosition()
            end
        end)
    end)

    btn:SetScript("OnMouseUp", function(self, mouseBtn)
        self:SetScript("OnUpdate", nil)
        if mouseBtn == "LeftButton" and not dragging then
            if SK.Register then SK.Register:Toggle() end
        end
        dragging = false
    end)

    MB:UpdatePosition()
    MB:ApplyTheme()
end

function MB:ApplyTheme()
    if not MB.iconTex then return end
    MB.iconTex:SetTexture("Interface\\Icons\\INV_Misc_Bag_07")
end
