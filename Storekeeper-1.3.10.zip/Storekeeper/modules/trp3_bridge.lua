-- Storekeeper: TRP3 Extended Bridge
-- Generates TRP3 Extended items as printed receipts.
--
-- NOTE: The player tooltip badge (Storekeeper badge below TRP3 tooltip) has been
-- temporarily DISABLED. All badge/tooltip code is preserved below in comments.

Storekeeper.TRP3 = Storekeeper.TRP3 or {}
local SK = Storekeeper
local T  = SK.TRP3

-- ─── Peer tracking (used by network.lua) ──────────────────────────────────────
Storekeeper.knownPeers = Storekeeper.knownPeers or {}

-- ─── On-hover peer discovery ──────────────────────────────────────────────────
-- When hovering a player we haven't heard from, whisper them a HELLO so they
-- respond with their version (same as our login broadcast, but targeted).
-- This means the tooltip works regardless of group membership or realm.
-- hoverPings throttles to one whisper per player per 30s.
local hoverPings = {}
local function PingPeer(name)
    if not name or name == "" then return end
    local key = name:lower()
    local myName = (UnitName("player") or ""):match("^([^%-]+)") or ""
    if key == myName:lower() then return end                      -- don't ping ourselves
    if Storekeeper.knownPeers[key] then return end                -- already known
    if hoverPings[key] then return end                            -- already pinged recently
    hoverPings[key] = true
    C_Timer.After(30, function() hoverPings[key] = nil end)       -- allow retry after 30s
    -- Use the full Name-Realm form so cross-realm whispers are delivered
    local SK = Storekeeper
    if SK.Net and SK.Net.SendHello then
        SK.Net:SendHello(name)
    end
end

-- ─── GameTooltip injection (kept active — low cost, no OnUpdate) ──────────────
-- Injects "Storekeeper vX" into the standard WoW GameTooltip when hovering
-- a player who also runs Storekeeper. Does NOT run on TRP3 tooltip.
local function HasSK(unit)
    if UnitIsUnit(unit, "player") then return true end
    local name = UnitName(unit)
    if not name then return false end
    name = name:match("^([^%-]+)") or name
    local myName = (UnitName("player") or ""):match("^([^%-]+)") or ""
    if name:lower() == myName:lower() then return true end
    return Storekeeper.knownPeers[name:lower()] ~= nil
end

local function GetVer(unit)
    if UnitIsUnit(unit, "player") then return SK.VERSION or "?" end
    local name = UnitName(unit)
    if not name then return SK.VERSION or "?" end
    name = name:match("^([^%-]+)") or name
    local myName = (UnitName("player") or ""):match("^([^%-]+)") or ""
    if name:lower() == myName:lower() then return SK.VERSION or "?" end
    local v = Storekeeper.knownPeers[name:lower()]
    if type(v) == "string" then return v end
    return "?"
end

-- ─── GameTooltip + TRP3 tooltip injection ────────────────────────────────────
-- Implementation follows Musician/modules/totalRP3/totalRP3.lua.
-- Key discoveries from Musician source:
--   1. TRP3_CharacterTooltip.target holds the player name TRP3 is showing
--   2. Hook TRP3's own updateTooltip so we re-inject when TRP3 refreshes
--   3. AddDoubleLine(" ", text) places text on the right side
--   4. Set font size via _G[tipName.."TextRight"..NumLines()] after adding
--   5. Call tooltip:Show() then :GetTop() to force layout recalc

-- playerHint: optional short player name, used by TRP3 path to avoid relying on
-- the mouseover unit token (which may not match t.target when the cursor has moved)
local function UpdateTooltipInfo(tooltip, unit, fontSize, playerHint)
    if not tooltip or not tooltip.AddDoubleLine then return end

    local ver
    if playerHint then
        -- TRP3 path: player name is known directly from t.target
        local myName = (UnitName("player") or ""):match("^([^%-]+)") or ""
        local isSelf = (playerHint:lower() == myName:lower())
        if isSelf then
            ver = SK.VERSION or "?"
        else
            local v = Storekeeper.knownPeers[playerHint:lower()]
            if not v then return end  -- not a known SK peer
            ver = (type(v) == "string") and v or "?"
        end
    else
        -- GameTooltip path: resolve from unit token
        if not unit or not UnitIsPlayer(unit) then return end
        if not HasSK(unit) then return end
        ver = GetVer(unit)
    end

    local tipName = tooltip:GetName()
    if not tipName then return end

    -- Build info text
    local infoText = "|cffFFD700Storekeeper|r  |cff888888v" .. ver .. "|r"

    -- Check if our line already exists — update in place if the text changed
    -- (e.g. Extended was just enabled/disabled), or move it to the bottom if needed
    local i = 1
    while _G[tipName .. "TextRight" .. i] do
        local line     = _G[tipName .. "TextRight" .. i]
        local lineText = line:GetText()
        if lineText and lineText:find("Storekeeper", 1, true) then
            if lineText == infoText then
                -- Already correct — only reposition if not at bottom
                if i ~= tooltip:NumLines() then
                    line:SetText("")
                    UpdateTooltipInfo(tooltip, unit, fontSize)
                end
            else
                -- Text changed (Extended enabled/disabled) — update in place
                line:SetText(infoText)
                if fontSize then
                    local font, _, flag = line:GetFont()
                    line:SetFont(font, fontSize, flag)
                end
                tooltip:Show()
                tooltip:GetTop()
            end
            return
        end
        i = i + 1
    end

    -- Add: empty left side, our text on the right
    tooltip:AddDoubleLine(" ", infoText, 1, 1, 1, 1, 1, 1)

    -- Smaller font for TRP3 tooltip (fontSize=10), default for GameTooltip
    if fontSize then
        local rightLine = _G[tipName .. "TextRight" .. tooltip:NumLines()]
        if rightLine then
            local font, _, flag = rightLine:GetFont()
            rightLine:SetFont(font, fontSize, flag)
        end
    end

    tooltip:Show()
    tooltip:GetTop()  -- force layout recalc (Musician pattern)
end

local function SetupTooltips()

    -- ── TRP3_CharacterTooltip (Musician pattern) ──────────────────────────
    local function HookTRP3Tooltip()
        if not TRP3_CharacterTooltip then return end

        -- t.target is the player name stored by TRP3 on its tooltip frame
        TRP3_CharacterTooltip:HookScript("OnShow", function(t)
            pcall(function()
                if not t.target then return end
                local name   = t.target:match("^([^%-]+)") or t.target
                local myName = (UnitName("player") or ""):match("^([^%-]+)") or ""
                local isSelf = (name:lower() == myName:lower())
                PingPeer(name)  -- no-op if already known or self
                -- Only inject badge if we already know their version; OnPeerDiscovered
                -- will inject it once the HELLO reply arrives if not yet known.
                if not isSelf and not Storekeeper.knownPeers[name:lower()] then return end
                UpdateTooltipInfo(TRP3_CharacterTooltip, "player", 10, name)
            end)
        end)

        -- Hook TRP3's own tooltip updater so we re-inject on every refresh
        -- This is what keeps Musician's line visible after cursor moves away
        pcall(function()
            if TRP3_API and TRP3_API.ui and TRP3_API.ui.tooltip and
               TRP3_API.ui.tooltip.updateTooltip then
                hooksecurefunc(TRP3_API.ui.tooltip, "updateTooltip", function()
                    pcall(function()
                        if not TRP3_CharacterTooltip or
                           not TRP3_CharacterTooltip:IsShown() then return end
                        local t    = TRP3_CharacterTooltip
                        if not t.target then return end
                        local name   = t.target:match("^([^%-]+)") or t.target
                        local myName = (UnitName("player") or ""):match("^([^%-]+)") or ""
                        local isSelf = (name:lower() == myName:lower())
                        if not isSelf and not Storekeeper.knownPeers[name:lower()] then return end
                        UpdateTooltipInfo(t, "player", 10, name)
                    end)
                end)
            end
        end)
    end

    -- ── OnPeerDiscovered: called by network.lua when a HELLO reply arrives ────
    -- Refreshes the TRP3 tooltip immediately if it is currently showing that player,
    -- so the badge appears without needing to re-hover.
    function SK.TRP3.OnPeerDiscovered(name, version)
        -- GameTooltip path
        pcall(function()
            local _, unit = GameTooltip:GetUnit()
            if unit and UnitIsPlayer(unit) then
                local tipName = (UnitName(unit) or ""):match("^([^%-]+)") or ""
                if tipName:lower() == name:lower() then
                    UpdateTooltipInfo(GameTooltip, unit, nil)
                end
            end
        end)
        -- TRP3 tooltip path
        pcall(function()
            if not TRP3_CharacterTooltip or not TRP3_CharacterTooltip:IsShown() then return end
            local t = TRP3_CharacterTooltip
            if not t.target then return end
            local tipName = t.target:match("^([^%-]+)") or t.target
            if tipName:lower() == name:lower() then
                UpdateTooltipInfo(t, "player", 10, tipName)
            end
        end)
    end

    -- Hook now if TRP3 already loaded, otherwise use TRP3's own callback
    if TRP3_CharacterTooltip then
        pcall(HookTRP3Tooltip)
    elseif TRP3_API and TRP3_Addon and TRP3_Addon.Events
       and TRP3_Addon.Events.WORKFLOW_ON_FINISH then
        pcall(function()
            TRP3_API.RegisterCallback(TRP3_Addon,
                TRP3_Addon.Events.WORKFLOW_ON_FINISH,
                function() pcall(HookTRP3Tooltip) end)
        end)
    else
        local trpWatcher = CreateFrame("Frame")
        trpWatcher:RegisterEvent("ADDON_LOADED")
        trpWatcher:SetScript("OnEvent", function(_, _, addon)
            if addon == "totalRP3" then
                C_Timer.After(1, function() pcall(HookTRP3Tooltip) end)
            end
        end)
    end

    -- ── Standard GameTooltip (non-TRP3 case) ─────────────────────────────
    local function OnUnitTooltip(tip)
        pcall(function()
            local _, unit = tip:GetUnit()
            if not unit or not UnitIsPlayer(unit) then return end
            local name = (UnitName(unit) or ""):match("^([^%-]+)") or ""
            PingPeer(name)
            UpdateTooltipInfo(tip, unit, nil)
        end)
    end

    if TooltipDataProcessor and Enum and Enum.TooltipDataType then
        pcall(TooltipDataProcessor.AddTooltipPostCall,
            Enum.TooltipDataType.Unit,
            function(tip) OnUnitTooltip(tip) end)
    end

    pcall(function()
        GameTooltip:HookScript("OnTooltipSetUnit", function(self)
            OnUnitTooltip(self)
        end)
    end)

    -- ── UPDATE_MOUSEOVER_UNIT pre-fetch ───────────────────────────────────
    -- Fires when the cursor moves over a new unit in the world or a unit
    -- frame.  Sending HELLO here means the reply usually arrives before the
    -- tooltip even opens, so the version shows immediately on first hover.
    local _hoverFrame = CreateFrame("Frame")
    _hoverFrame:RegisterEvent("UPDATE_MOUSEOVER_UNIT")
    _hoverFrame:SetScript("OnEvent", function()
        -- UnitName("mouseover") can be a secret/tainted string when hovering over
        -- unit frames inside secure contexts (e.g. LFR, raid frames). Wrap in
        -- pcall so taint errors are silently discarded rather than surfaced to
        -- the user.
        local ok, name = pcall(function()
            if not UnitExists("mouseover") or not UnitIsPlayer("mouseover") then return nil end
            return (UnitName("mouseover") or ""):match("^([^%-]+)") or ""
        end)
        if ok and name and name ~= "" then
            PingPeer(name)
        end
    end)

end

local _addonLoader = CreateFrame("Frame")
_addonLoader:RegisterEvent("ADDON_LOADED")
_addonLoader:SetScript("OnEvent", function(self, _, addon)
    if addon == "Storekeeper" then
        self:UnregisterEvent("ADDON_LOADED")
        pcall(SetupTooltips)
    end
end)

-- ─── TRP3 Extended receipt builder ────────────────────────────────────────────

local function Line(text, align) return { TX = text or "", AL = align or "LEFT" } end
local function Divider(char) char=char or "\xe2\x94\x80"; return Line(string.rep(char,38),"CENTER") end
local function Spacer() return Line("","LEFT") end

function T:BuildReceiptItem(shopName, sellerName, cart, totalCopper)
    local shop = SK.DB:GetShop(shopName)
    if not shop then return nil, "No active shop." end
    local theme    = SK.db.theme or "goblin"
    local isGoblin = (theme == "goblin")
    local lines    = {}
    if isGoblin then
        tinsert(lines, Line("BROKER COMMERCE NETWORK", "CENTER"))
        tinsert(lines, Line("Kezan Commerce Solutions", "CENTER"))
    else
        tinsert(lines, Line("BROKER LEDGER SYSTEM", "CENTER"))
        tinsert(lines, Line("Storekeeper", "CENTER"))
    end
    tinsert(lines, Divider("="))
    tinsert(lines, Line("SHOP:  " .. shopName, "LEFT"))
    tinsert(lines, Line("SOLD BY:  " .. sellerName, "LEFT"))
    tinsert(lines, Line("DATE:  " .. date("%d/%m/%Y"), "LEFT"))
    tinsert(lines, Divider())
    for _, entry in ipairs(cart) do
        local p = entry.product; local qty = entry.qty
        local nameStr = qty > 1 and (qty .. "x " .. p.name) or p.name
        tinsert(lines, Line(string.format("%-24s %s", nameStr, SK:FormatMoneyPlain(p.priceCopper*qty)), "LEFT"))
        if p.description and p.description ~= "" then
            tinsert(lines, Line("  (" .. p.description .. ")", "LEFT"))
        end
    end
    tinsert(lines, Divider())
    tinsert(lines, Line(string.format("TOTAL:  %s", SK:FormatMoneyPlain(totalCopper)), "LEFT"))
    tinsert(lines, Spacer())
    tinsert(lines, Line("Thank you for your patronage.", "CENTER"))
    tinsert(lines, Divider("="))
    -- ID must survive Extended's checkID (lowercase, alphanumeric + underscore).
    local itemID = "sk_receipt_" .. time() .. "_" .. math.random(1000, 9999)
    local now = date("%d/%m/%y %H:%M:%S")
    local receiptItem = {
        TY = "IT",
        MD = { MO = "NORMAL", CD = now, CB = sellerName, SD = now, SB = sellerName, V = 1 },
        BA = {
            NA = "Receipt - " .. shopName,
            DE = "A receipt from " .. shopName .. ", sold by " .. sellerName .. ".",
            QA = "Common",
            LE = "A receipt stamped with the mark of " .. shopName .. ".",
            IC = "INV_Misc_Note_06",
            WE = 0,      -- was WT, which Extended does not read
            ST = 0,      -- receipts do not stack; must be a number, not a bool
        },
        DS = { { LI = lines } },
    }
    return receiptItem, itemID
end

function T:PrintReceipt(shopName, sellerName, cart, totalCopper)
    -- Previously tested TRP3_Extended.DB.ROOT_CLASSES and TRP3_Extended.utils,
    -- neither of which exists, so this ALWAYS fell through to the chat
    -- fallback. Repointed at the same verified API the product items use.
    if not T:CanGiveItems() then
        T:FallbackChatReceipt(shopName, sellerName, cart, totalCopper)
        return false, "TRP3 Extended not found."
    end
    local receiptItem, itemID = T:BuildReceiptItem(shopName, sellerName, cart, totalCopper)
    if not receiptItem then return false, "Could not build receipt." end

    local ok, err = pcall(function()
        if TRP3_DB.my then TRP3_DB.my[itemID] = receiptItem end
        TRP3_API.extended.registerObject(itemID, receiptItem, 0)
    end)
    if not ok then
        T:FallbackChatReceipt(shopName, sellerName, cart, totalCopper)
        return false, tostring(err)
    end

    local ok2, res = pcall(function()
        return TRP3_API.inventory.addItem(nil, itemID,
            { count = 1, madeBy = UnitName("player") })
    end)
    if ok2 and (res == nil or res == 0) then return true, itemID end

    T:FallbackChatReceipt(shopName, sellerName, cart, totalCopper)
    return false, "Could not add the receipt to your inventory."
end

function T:FallbackChatReceipt(shopName, sellerName, cart, totalCopper)
    print("|cffFFD700[SK Receipt - " .. shopName .. "]|r")
    print("Sold by: " .. sellerName .. "  |  " .. date("%d/%m/%Y"))
    print("|cffFFD700" .. string.rep("-",32) .. "|r")
    for _, entry in ipairs(cart) do
        local p = entry.product; local qty = entry.qty
        print("  " .. (qty > 1 and qty.."x " or "") .. p.name .. "  -  " .. SK:FormatMoney(p.priceCopper*qty))
    end
    print("|cffFFD700" .. string.rep("-",32) .. "|r")
    print("TOTAL: " .. SK:FormatMoney(totalCopper))
end

-- ─── TRP3 Extended product items ──────────────────────────────────────────────
-- Verified against Total-RP-3-Extended source. The real API surface is:
--   TRP3_API.extended.classExists(id)          -> boolean
--   TRP3_API.extended.getClass(id)             -> class, or TRP3_DB.missing
--   TRP3_API.extended.registerObject(id, obj)  -> registers into TRP3_DB.global
--   TRP3_API.inventory.addItem(container, classID, itemData, dropIfFull, toSlot)
--       container nil = the player's own inventory
--       itemData      = { count = n, madeBy = creatorName }
--       returns 0 OK | 1 container full | 2 unique limit | 3 not a container
--               4 container cannot hold it
--   TRP3_DB.global   = live class registry (rebuilt each login)
--   TRP3_DB.my       = TRP3_Tools_DB, the player's own saved creations
--
-- There is NO `TRP3_Extended.DB` and no `TRP3_Extended.utils.item.addItem`.
-- TRP3_Extended is only the AceAddon object. Earlier code in this file assumed
-- otherwise, which is why receipts silently fell back to chat.
--
-- KNOWN LIMITATION: items can only be added to our OWN inventory. There is no
-- API to push an item into another player's bag. The seller hands over through
-- Extended's exchange window afterwards. Do not attempt to work around this.

-- Two modes per product (prod.trp3Mode):
--   "link"   — prod.trp3ItemID points at a class the user authored themselves.
--   "author" — Storekeeper writes the class from the product's fields.

function T:IsExtendedReady()
    local ok, ready = pcall(function()
        return TRP3_API ~= nil
           and TRP3_API.extended ~= nil
           and TRP3_API.extended.classExists ~= nil
           and TRP3_DB ~= nil
           and TRP3_DB.global ~= nil
    end)
    return ok and ready == true
end

function T:CanGiveItems()
    if not T:IsExtendedReady() then return false end
    local ok, has = pcall(function()
        return TRP3_API.inventory ~= nil and TRP3_API.inventory.addItem ~= nil
    end)
    return ok and has == true
end

-- Does this class ID exist? Uses Extended's own lookup so that inner-object
-- IDs ("ROOT child") resolve the same way they do everywhere else.
function T:ClassExists(itemID)
    if not itemID or itemID == "" then return false end
    if not T:IsExtendedReady() then return false end
    local ok, found = pcall(function()
        return TRP3_API.extended.classExists(itemID) == true
    end)
    return ok and found == true
end

-- TRP3 Extended stores BA.QA as a numeric Enum.ItemQuality value, NOT a string
-- (Poor=0, Common=1, Uncommon=2, Rare=3, Epic=4, Legendary=5). Writing the string
-- name here made Extended fall back to its default quality, so a product's rarity
-- never carried over to the item it authored. Numbers fix that.
local Q = (type(Enum) == "table" and Enum.ItemQuality) or {}
local RARITY_TO_QA = {
    common    = Q.Common    or 1,
    uncommon  = Q.Uncommon  or 2,
    rare      = Q.Rare      or 3,
    epic      = Q.Epic      or 4,
    legendary = Q.Legendary or 5,
}

-- Stack size for items Storekeeper authors. The TRP3 Extended bag is only 17
-- slots, and identical items stack up to BA.ST per slot, so a small stack size
-- makes big orders overflow fast. A large stack lets a bulk quantity of one item
-- sit in a single slot (e.g. 500 loaves = 1 slot instead of 25).
local STACK_SIZE = 1000

local function IconNameFor(icon)
    if type(icon) == "string" and icon ~= "" then return icon end
    local ok, name = pcall(function()
        if SK.IconPicker and SK.IconPicker.GetIconName then
            return SK.IconPicker:GetIconName(icon)
        end
        return nil
    end)
    if ok and type(name) == "string" and name ~= "" then return name end
    return "temp"
end

-- Extended sanitises IDs to lowercase alphanumeric+underscore, and uses a space
-- as its ID separator, so the generated ID must survive checkID unchanged.
-- The optional suffix keeps sibling IDs (e.g. one per variant) unique even when
-- several are minted in the same second.
local function MakeItemID(product, suffix)
    local base = "sk_" .. tostring(product.id or 0)
    if suffix and suffix ~= "" then base = base .. "_" .. tostring(suffix) end
    base = base .. "_" .. tostring(time())
    local ok, clean = pcall(function()
        return TRP3_API.extended.checkID(base)
    end)
    if ok and type(clean) == "string" and clean ~= "" then return clean end
    return base:lower():gsub("[^%w_]", "_")
end

-- Assemble an Extended item class from plain fields. Shared by the product and
-- its variants so they stay identical apart from name, price and (optionally)
-- the fields the caller overrides.
-- BA.ST is a STACK SIZE, not a flag: Inventory.lua does `(BA.ST or 0) > 0`,
-- so a boolean here throws "attempt to compare boolean with number".
local function BuildItemClass(nameStr, descStr, qa, icon, va)
    return {
        TY = "IT",
        MD = {
            MO = "NORMAL",
            CD = date("%d/%m/%y %H:%M:%S"),
            CB = UnitName("player"),
            SD = date("%d/%m/%y %H:%M:%S"),
            SB = UnitName("player"),
            V  = 1,
        },
        BA = {
            NA = nameStr or "Item",
            DE = descStr or "",
            LE = descStr or "",
            QA = qa or (Q.Common or 1),
            IC = icon or "temp",
            WE = 0,
            VA = tonumber(va) or 0,
            ST = STACK_SIZE,
            CR = true,
        },
    }
end

-- Write an item class into TRP3_DB.my (survives reload, shows in the player's
-- Extended database) and register it into the live TRP3_DB.global so it's usable
-- immediately without a /reload. Returns ok, err.
local function RegisterItem(itemID, itemClass)
    return pcall(function()
        if TRP3_DB.my then TRP3_DB.my[itemID] = itemClass end
        TRP3_API.extended.registerObject(itemID, itemClass, 0)
    end)
end

-- Build (or rebuild) an Extended item class for a product.
-- Returns true, itemID | false, errorText
function T:AuthorProductItem(product)
    if not product then return false, "No product." end
    if not T:IsExtendedReady() then return false, "TRP3 Extended not loaded." end

    local itemID = product.trp3ItemID
    if not itemID or itemID == "" then itemID = MakeItemID(product) end

    local desc = product.description
    if not desc or desc == "" then desc = product.name or "" end

    local qa   = RARITY_TO_QA[product.rarity or "common"] or (Q.Common or 1)
    local itemClass = BuildItemClass(product.name or "Item", desc, qa,
        IconNameFor(product.icon), product.priceCopper)

    local ok, err = RegisterItem(itemID, itemClass)
    if not ok then return false, tostring(err) end
    return true, itemID
end

-- Author (or rewrite) an Extended item for each named variant of a product.
-- Variant items inherit the product's rarity, icon and description, but use the
-- variant's own name ("Product (Variant)") and price. The resulting IDs are
-- written back onto product.variants[i].trp3ItemID so Get Items hands out the
-- right item per variant. Reuses a variant's existing ID when it already has one,
-- so repeated saves rewrite in place rather than spawning duplicates.
-- Returns authoredCount, problemList.
function T:AuthorProductVariants(product)
    local problems = {}
    if not product or not product.variants then return 0, problems end
    if not T:IsExtendedReady() then return 0, { "TRP3 Extended not loaded." } end

    local desc = product.description
    if not desc or desc == "" then desc = product.name or "" end
    local qa   = RARITY_TO_QA[product.rarity or "common"] or (Q.Common or 1)
    local icon = IconNameFor(product.icon)

    local authored = 0
    for i, v in ipairs(product.variants) do
        local vname = strtrim(v.name or "")
        if vname ~= "" then
            local itemID = v.trp3ItemID
            if not itemID or itemID == "" then itemID = MakeItemID(product, "v" .. i) end
            local fullName  = SK:LineLabel(product.name or "Item", vname)
            local itemClass = BuildItemClass(fullName, desc, qa, icon, v.priceCopper)
            local ok, err = RegisterItem(itemID, itemClass)
            if ok then
                v.trp3ItemID = itemID
                authored = authored + 1
            else
                tinsert(problems, vname .. ": " .. tostring(err))
            end
        end
    end
    return authored, problems
end

-- Author (or rewrite) a "receipt" item: a usable Extended item that, when used,
-- opens a document window showing the given body text (TRP3 markup). This is the
-- same shape TRP3 uses for a letter/document item - a root IT item whose onUse
-- script runs the document_show effect against an inner DO (document) object.
-- spec = { itemID (optional, reuse on update), name, icon, description,
--          actionLabel, body }. Returns true, itemID | false, errorText.
function T:AuthorReceiptItem(spec)
    if not spec then return false, "No receipt." end
    if not T:IsExtendedReady() then return false, "TRP3 Extended not loaded." end

    local itemID = spec.itemID
    if not itemID or itemID == "" then itemID = MakeItemID({ id = "rcpt" .. math.random(100000, 999999) }) end

    local name   = (spec.name and strtrim(spec.name) ~= "" and strtrim(spec.name)) or "Receipt"
    local action = (spec.actionLabel and strtrim(spec.actionLabel) ~= "" and strtrim(spec.actionLabel)) or "Read the receipt"
    local desc   = spec.description or ""
    local body   = spec.body or ""

    -- Inner document lives under "<itemID> receipt"; registerObject registers it
    -- recursively, and the onUse script points the document_show effect at it.
    local docKey    = "receipt"
    local docFullID = itemID .. " " .. docKey

    local itemClass = {
        TY = "IT",
        MD = {
            MO = "NORMAL",
            CD = date("%d/%m/%y %H:%M:%S"), CB = UnitName("player"),
            SD = date("%d/%m/%y %H:%M:%S"), SB = UnitName("player"),
            V  = 1,
        },
        BA = {
            NA = name,
            DE = desc,
            LE = desc,
            QA = Q.Common or 1,
            IC = IconNameFor(spec.icon),
            WE = 0,
            VA = 0,
            ST = false,   -- receipts aren't stackable
            US = true,    -- usable: right-click shows the action below
            CR = false,
        },
        US = { AC = action, SC = "onUse" },
        SC = {
            onUse = {
                ST = {
                    ["1"] = {
                        ["t"] = "list",
                        ["e"] = {
                            { id = "document_show", args = { docFullID } },
                        },
                    },
                },
            },
        },
        IN = {
            [docKey] = {
                TY   = "DO",
                BA   = { NA = name },
                PA   = { { TX = body } },
                HE   = 600,
                WI   = 450,
                BCK  = 8,
                BO   = 1,
                FR   = false,
                H1_F = "DestinyFontHuge",
                H2_F = "QuestFont_Huge",
                H3_F = "GameFontNormalLarge",
                P_F  = "GameTooltipHeader",
                MD   = { MO = "NO" },
            },
        },
    }

    local ok, err = RegisterItem(itemID, itemClass)
    if not ok then return false, tostring(err) end
    return true, itemID
end

-- Add a single already-authored item (by ID) to the player's own bag. Reuses the
-- cart path so stacking and the bag-full fallback apply. Returns ok, message.
function T:GiveItemByID(itemID, name)
    if not itemID or itemID == "" then return false, "No item ID." end
    if not T:CanGiveItems() then return false, "TRP3 Extended not detected." end
    if not T:ClassExists(itemID) then return false, "Item not in your TRP3 Extended database." end
    local added, problems, _, dropped = T:GiveCartItems({
        { product = { name = name or "Item", hasTRP3Item = true, trp3ItemID = itemID }, qty = 1 },
    })
    if added > 0 then return true, "added" end
    if (dropped or 0) > 0 then return true, "dropped" end
    return false, (problems and problems[1]) or "could not add"
end

-- Open the receipt document window (a live preview). Returns ok.
-- The inner document is registered under "<itemID> receipt"; verify that class
-- is actually present before calling showDocument, because showDocument does not
-- error on a missing class - it silently shows TRP3's own "Missing class" alert
-- and returns, which would hide the real cause from the caller.
function T:PreviewReceipt(itemID)
    if not itemID or itemID == "" then return false end
    if not (T:IsExtendedReady() and TRP3_API.extended and TRP3_API.extended.document
            and TRP3_API.extended.document.showDocument) then
        return false
    end
    local docFullID = itemID .. " receipt"
    if not T:ClassExists(docFullID) then return false end
    local ok = pcall(function()
        TRP3_API.extended.document.showDocument(docFullID, {})
    end)
    return ok
end

local ADD_ERRORS = {
    [1] = "inventory full",
    [2] = "unique item limit reached",
    [3] = "target is not a container",
    [4] = "container cannot hold it",
}

-- Add every cart line carrying an Extended item ID into OUR OWN inventory.
-- Deliberately manual — never called from checkout.
-- Returns addedCount, problemList, missingClassFlag.
-- missingClassFlag is set when at least one ID resolved to nothing in this
-- player's database, which is the case with an actual remedy (import string).
function T:GiveCartItems(cart)
    local problems = {}
    local missingClass = false
    local dropped = 0            -- items that didn't fit and were dropped as loot
    if not cart then return 0, problems, false, 0 end
    if not T:CanGiveItems() then return 0, problems, false, 0 end

    local me = UnitName("player")
    local added = 0

    -- When the bag fills, ask Extended to drop the overflow as a lootable pile at
    -- the player's feet rather than silently failing - but only in the open world,
    -- since a drop needs map coordinates and would be lost in an instance.
    local canDrop = false
    if AddOn_TotalRP3 and AddOn_TotalRP3.Map and AddOn_TotalRP3.Map.getPlayerCoordinates then
        local okc, x = pcall(AddOn_TotalRP3.Map.getPlayerCoordinates)
        canDrop = okc and x ~= nil
    end

    -- Cart lines opened from a Tab carry a stub product table (id/name/price
    -- only), so re-resolve against the live shop record before reading the
    -- TRP3 fields. Falls back to the cart's own table if the id is unknown.
    local byID = {}
    do
        local shopName = SK.db and SK.db.activeShop
        if shopName and SK.DB and SK.DB.GetProducts then
            for _, dp in ipairs(SK.DB:GetProducts(shopName) or {}) do
                if dp.id ~= nil then byID[dp.id] = dp end
            end
        end
    end

    for _, entry in ipairs(cart) do
        local p = entry and entry.product
        if p and p.id ~= nil and byID[p.id] then p = byID[p.id] end
        if p and p.hasTRP3Item then
            -- A variant may carry its own Extended item ID. Re-resolve it from the
            -- live product by variant name so an ID set after the line was carted
            -- (or a line from an older tab) is still honoured. Blank falls back to
            -- the product's own item.
            local itemID = p.trp3ItemID
            local vlabel = ""
            local ev     = entry.variant
            local evkey  = entry.variantKey or (ev and ev.name)
            if evkey and evkey ~= "" then
                vlabel = " (" .. evkey .. ")"
                local vid
                if p.variants then
                    for _, pv in ipairs(p.variants) do
                        if (pv.name or "") == evkey then vid = pv.trp3ItemID; break end
                    end
                end
                if (not vid or vid == "") and ev then vid = ev.trp3ItemID end
                if vid and vid ~= "" then itemID = vid end
            end

            local qty = tonumber(entry.qty) or 1
            if qty < 1 then qty = 1 end

            if not itemID or itemID == "" then
                tinsert(problems, (p.name or "?") .. vlabel .. ": no item ID set")
            elseif not T:ClassExists(itemID) then
                -- Not in THIS player's TRP3_DB.global. Almost always means they
                -- were never sent the item, not that the ID is wrong.
                tinsert(problems, (p.name or "?") .. vlabel .. ": not in your TRP3 Extended database")
                missingClass = true
            else
                -- addItem returns (code, countAdded). code nil/0 = all fit, 1 = bag
                -- filled (countAdded went in; with dropIfFull the rest was dropped),
                -- 2 = unique limit, 3/4 = container errors.
                local ok, res, cnt = pcall(function()
                    return TRP3_API.inventory.addItem(nil, itemID,
                        { count = qty, madeBy = me }, canDrop)
                end)
                cnt = tonumber(cnt) or 0
                if not ok then
                    tinsert(problems, (p.name or "?") .. vlabel .. ": " .. tostring(res))
                elseif res == nil or res == 0 then
                    added = added + qty
                elseif res == 1 then
                    -- Bag full. Whatever fit was added; the remainder was either
                    -- dropped nearby (open world) or couldn't be delivered.
                    added = added + cnt
                    local short = qty - cnt
                    if canDrop then
                        dropped = dropped + short
                    else
                        tinsert(problems, (p.name or "?") .. vlabel .. ": bag full, "
                            .. short .. " could not be delivered here")
                    end
                else
                    tinsert(problems, (p.name or "?") .. vlabel .. ": " ..
                        (ADD_ERRORS[res] or ("error " .. tostring(res))))
                end
            end
        end
    end

    return added, problems, missingClass, dropped
end

function T:CartHasTRP3Items(cart)
    local shopName = SK.db and SK.db.activeShop
    local byID = {}
    if shopName and SK.DB and SK.DB.GetProducts then
        for _, dp in ipairs(SK.DB:GetProducts(shopName) or {}) do
            if dp.id ~= nil then byID[dp.id] = dp end
        end
    end
    for _, entry in ipairs(cart or {}) do
        local p = entry and entry.product
        if p and p.id ~= nil and byID[p.id] then p = byID[p.id] end
        if p and p.hasTRP3Item then return true end
    end
    return false
end
