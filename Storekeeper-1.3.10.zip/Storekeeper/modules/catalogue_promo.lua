-- Storekeeper: Catalogue Promo
-- A one-time, friendly announcement of the companion addon "Storekeeper
-- Catalogue". Shown once per account after the addon is first installed (tracked
-- by SK.db.seenCataloguePromo). It is deliberately soft: it tells the shopkeeper
-- the Catalogue exists and gently suggests they may point their customers to it,
-- with a "Get the addon" button that opens a copyable CurseForge link.
--
-- All text is ASCII: FRIZQT__.TTF cannot render multi-byte characters (em-dash,
-- box-drawing, etc.), so hyphens and plain punctuation are used throughout.

local SK = Storekeeper

local CATALOGUE_URL = "https://www.curseforge.com/wow/addons/storekeeper-catalogue"

-- Small copy-the-link dialog, matching the pattern used elsewhere in the addon.
local function ShowCatalogueUrlCopy()
    if not StaticPopupDialogs["SK_CATALOGUE_URL"] then
        StaticPopupDialogs["SK_CATALOGUE_URL"] = {
            text           = "Storekeeper Catalogue on CurseForge\nPress |cffFFD700Ctrl+C|r to copy, then paste into your browser:",
            hasEditBox     = 1,
            editBoxWidth   = 320,
            button1        = "Close",
            OnAccept       = function(dialog) dialog:Hide() end,
            EditBoxOnEscapePressed = function(dialog) dialog:GetParent():Hide() end,
            EditBoxOnEnterPressed  = function(dialog) dialog:GetParent():Hide() end,
            timeout        = 0,
            whileDead      = 1,
            hideOnEscape   = 1,
            preferredIndex = 3,
        }
    end
    local dialog = StaticPopup_Show("SK_CATALOGUE_URL")
    if dialog and dialog.EditBox then
        dialog.EditBox:SetText(CATALOGUE_URL)
        dialog.EditBox:SetFocus()
        dialog.EditBox:HighlightText()
    end
end

-- Build (once) and show the announcement window.
-- True if the companion Catalogue addon is installed and loaded.
local function CatalogueInstalled()
    if C_AddOns and C_AddOns.IsAddOnLoaded then
        return C_AddOns.IsAddOnLoaded("StorekeeperCatalogue") and true or false
    elseif IsAddOnLoaded then
        return IsAddOnLoaded("StorekeeperCatalogue") and true or false
    end
    return false
end

-- Build (once) and show the announcement window. hasCatalogue tailors the copy:
-- shopkeepers who already run the Catalogue get a "remind your customers" nudge
-- rather than a "here is a new addon" pitch. Pass nil to auto-detect.
function SK:ShowCataloguePromo(hasCatalogue)
    if hasCatalogue == nil then hasCatalogue = CatalogueInstalled() end

    if SK._cataloguePromo then
        SK._cataloguePromo:Show()
        return
    end

    local W = 460

    local f = CreateFrame("Frame", "StorekeeperCataloguePromo", UIParent, "BackdropTemplate")
    f:SetWidth(W)
    f:SetPoint("CENTER")
    f:SetFrameStrata("FULLSCREEN_DIALOG")
    f:SetToplevel(true)
    f:SetMovable(true); f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop",  f.StopMovingOrSizing)
    f:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1,
    })
    f:SetBackdropColor(0.05, 0.05, 0.08, 0.98)
    f:SetBackdropBorderColor(0.72, 0.55, 0.14, 1)
    SK._cataloguePromo = f

    -- Let Escape close it.
    tinsert(UISpecialFrames, "StorekeeperCataloguePromo")

    -- Copy varies by audience.
    local titleText, subText, bodyText, getLabel
    if hasCatalogue then
        titleText = "|cffFFD700Storekeeper Catalogue|r"
        subText   = "|cff9BE08Fspread the word to your customers|r"
        bodyText  =
            "You are already running |cffFFD700Storekeeper Catalogue|r -- wonderful!\n\n" ..
            "Whenever it suits you, you are warmly welcome to let your customers " ..
            "know they can install it too, so they can browse your styled " ..
            "catalogue in-game whenever they like.\n\n" ..
            "It is entirely optional -- just a friendly nudge. The button below " ..
            "opens a link you can copy and pass along to them."
        getLabel  = "Copy share link"
    else
        titleText = "|cffFFD700New: Storekeeper Catalogue|r"
        subText   = "|cff9BE08Fa companion addon for your shop|r"
        bodyText  =
            "There is now a free companion addon: |cffFFD700Storekeeper Catalogue|r.\n\n" ..
            "It lets you publish a styled, browsable catalogue of your wares that " ..
            "nearby players can flip through in-game -- categories, colours, item " ..
            "art and descriptions, all laid out the way you like.\n\n" ..
            "If you would like, you are warmly welcome to let your customers know " ..
            "they can grab the Catalogue too, so they can browse your shop at their " ..
            "leisure. It is entirely optional -- no pressure at all, just a friendly " ..
            "heads-up in case it is useful to you and your patrons."
        getLabel  = "Get the addon"
    end

    local PADX = 18
    local y    = -16

    -- Title
    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, y)
    title:SetText(titleText)
    y = y - 30

    -- Subtitle
    local sub = f:CreateFontString(nil, "OVERLAY")
    sub:SetFont("Fonts\\FRIZQT__.TTF", 11, "")
    sub:SetPoint("TOP", 0, y)
    sub:SetText(subText)
    y = y - 26

    -- Divider
    local div = f:CreateTexture(nil, "ARTWORK")
    div:SetColorTexture(0.72, 0.55, 0.14, 0.5)
    div:SetHeight(1)
    div:SetPoint("TOPLEFT",  PADX, y)
    div:SetPoint("TOPRIGHT", -PADX, y)
    y = y - 14

    -- Body
    local body = f:CreateFontString(nil, "OVERLAY")
    body:SetFont("Fonts\\FRIZQT__.TTF", 12, "")
    body:SetPoint("TOPLEFT", PADX, y)
    body:SetWidth(W - PADX*2)
    body:SetJustifyH("LEFT")
    body:SetJustifyV("TOP")
    body:SetSpacing(3)
    body:SetTextColor(0.88, 0.88, 0.88, 1)
    body:SetText(bodyText)
    local bodyH = body:GetStringHeight() or 160
    y = y - bodyH - 18

    -- Buttons
    local BTN_H = 24
    local getBtn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    getBtn:SetSize(150, BTN_H)
    getBtn:SetPoint("TOPLEFT", PADX, y)
    getBtn:SetText(getLabel)
    getBtn:SetScript("OnClick", function() ShowCatalogueUrlCopy() end)
    getBtn:SetScript("OnEnter", function(s)
        GameTooltip:SetOwner(s, "ANCHOR_TOP")
        GameTooltip:AddLine(getLabel, 1, 1, 1)
        GameTooltip:AddLine("Opens a copyable link to the Catalogue on CurseForge.", 0.7, 0.7, 0.7)
        GameTooltip:AddLine(CATALOGUE_URL, 0.6, 0.8, 1)
        GameTooltip:Show()
    end)
    getBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)

    local closeBtn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    closeBtn:SetSize(110, BTN_H)
    closeBtn:SetPoint("TOPRIGHT", -PADX, y)
    closeBtn:SetText("Maybe later")
    closeBtn:SetScript("OnClick", function() f:Hide() end)

    y = y - BTN_H - 16
    f:SetHeight(math.abs(y))

    f:Show()
end

-- Show the announcement once per account, the first time the addon runs after
-- being installed. It shows to everyone -- including shopkeepers who already run
-- the Catalogue -- because the "please point your customers to it" message is
-- meant for them too; the copy just adapts to which audience they are.
function SK:MaybeShowCataloguePromo()
    if not SK.db then return end
    if SK.db.seenCataloguePromo then return end

    SK.db.seenCataloguePromo = true

    local hasCatalogue = CatalogueInstalled()
    -- Small delay so it lands after the login screen settles, not on top of it.
    C_Timer.After(4, function() SK:ShowCataloguePromo(hasCatalogue) end)
end
