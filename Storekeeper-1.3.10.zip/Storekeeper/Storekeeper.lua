-- Storekeeper: Main
-- Defines themes, helpers, and OnInitialize.
-- The Storekeeper global already exists (created by bootstrap.lua).

local SK = Storekeeper

-- ─── Themes ────────────────────────────────────────────────────────────────────

SK.THEMES = {
    GOBLIN  = "goblin",
    GNOMISH = "gnomish",
}

-- Colours inspired by TRP3's clean dark-navy visual language.
-- Goblin = warm dark green-tinted navy; Gnomish = cool steel-blue navy.
SK.COLORS = {
    goblin = {
        -- TRP3-style: dark navy with a green tint, clean teal-green accent
        primary    = {0.06, 0.28, 0.12, 1},   -- header/active tint (dark green)
        secondary  = {0.08, 0.18, 0.10, 1},   -- button bg
        accent     = {0.25, 0.85, 0.40, 1},   -- highlights, active tab bar (bright green)
        bg         = {0.07, 0.09, 0.08, 1},   -- main body bg
        bgLight    = {0.10, 0.14, 0.11, 1},   -- slightly lighter panels
        text       = {0.90, 0.95, 0.88, 1},   -- near-white body text
        textDim    = {0.55, 0.65, 0.55, 1},   -- muted labels
        danger     = {0.85, 0.22, 0.12, 1},
        border     = {0.22, 0.60, 0.28, 1},   -- thin border colour
        titleText  = "Merchant Point of Sale (MPoS)",
        subtitle   = "Storekeeper",
        btnClear   = "Clear Order",
        btnReceipt = "Receipt / Order",
        btnMenu    = "Manager",
        flavorText = "Every sale logged. Every coin counted. Every merchant served.",
    },
    gnomish = {
        -- TRP3-style: dark navy, cool steel-blue, gold accent
        primary    = {0.08, 0.16, 0.32, 1},   -- header tint (dark navy)
        secondary  = {0.10, 0.18, 0.28, 1},   -- button bg
        accent     = {0.30, 0.70, 1.00, 1},   -- teal-blue highlight (TRP3 signature)
        bg         = {0.07, 0.08, 0.14, 1},   -- main body
        bgLight    = {0.10, 0.12, 0.20, 1},   -- panels
        text       = {0.85, 0.90, 1.00, 1},   -- blue-white text
        textDim    = {0.50, 0.58, 0.75, 1},
        danger     = {0.85, 0.22, 0.12, 1},
        border     = {0.25, 0.50, 0.85, 1},   -- steel blue border
        titleText  = "Merchant Point of Sale (MPoS)",
        subtitle   = "Storekeeper",
        btnClear   = "Clear Order",
        btnReceipt = "Receipt / Order",
        btnMenu    = "Manager",
        flavorText = "Precision trade, maintained by Merchants.",
    },
}

-- ─── OnInitialize (called by AceAddon or core.lua fallback) ───────────────────

function SK:OnInitialize()
    -- Saved variables
    if not StorekeeperDB then
        StorekeeperDB = {
            theme      = SK.THEMES.GOBLIN,
            shops      = {},
            activeShop = nil,
        }
    end
    SK.db = StorekeeperDB

    -- Settings defaults (migrate existing saves gracefully)
    local s = SK.db
    if s.settings == nil then s.settings = {} end
    local cfg = s.settings
    if cfg.emoteTemplate  == nil then cfg.emoteTemplate  = "hands over a receipt from {shop} — {items} — Total: {total} ({payment}), served by {seller}." end
    if cfg.emoteChannel   == nil then cfg.emoteChannel   = "EMOTE" end
    -- Migrate old channel values (SAY/YELL/NONE removed)
    if cfg.emoteChannel == "NONE" or cfg.emoteChannel == "SAY" or cfg.emoteChannel == "YELL" then
        cfg.emoteChannel = cfg.emoteChannel == "NONE" and "PRINT" or "EMOTE"
    end
    if cfg.showPrice      == nil then cfg.showPrice      = true end
    if cfg.autoClearCart  == nil then cfg.autoClearCart  = true end
    -- Per-character seller IC name storage
    -- Initialisation is deferred to PLAYER_LOGIN (see core.lua) because
    -- UnitName("player") and TRP3 profile data are not reliable at ADDON_LOADED.
    if not SK.db.charNames then SK.db.charNames = {} end
    -- Helper: get/set this character's saved IC name
    function SK:GetSavedSellerIC()
        local key = UnitName("player") or "unknown"
        return SK.db.charNames and SK.db.charNames[key] or ""
    end
    function SK:SetSavedSellerIC(name)
        local key = UnitName("player") or "unknown"
        if not SK.db.charNames then SK.db.charNames = {} end
        SK.db.charNames[key] = name or ""
    end
    if cfg.autoCloseCategory == nil then cfg.autoCloseCategory = true end
    if cfg.notifyOrderClaimed  == nil then cfg.notifyOrderClaimed  = true end
    if cfg.notifyOrderReleased == nil then cfg.notifyOrderReleased = true end
    if cfg.notifyOrderStatus   == nil then cfg.notifyOrderStatus   = true end
    if cfg.notifyStaffJoined   == nil then cfg.notifyStaffJoined   = true end
    if cfg.notifySync          == nil then cfg.notifySync          = false end

    -- Slash commands
    local function slash(input)
        local raw = strtrim(input or "")
        local cmd = raw:lower()
        if cmd == "" or cmd == "register" then
            SK.Register:Toggle()
        elseif cmd == "manager" or cmd == "manage" then
            SK.Manager:Toggle()
        elseif cmd == "sync" then
            if SK.Net then SK.Net:RequestSync() end
        elseif cmd == "netdebug" then
            if SK.Net then
                SK.Net.debug = not SK.Net.debug
                print("|cffFFD700[SK]|r Network debug "..(SK.Net.debug and "|cff00FF00ON|r" or "|cffFF6666OFF|r")..
                      ". YELL status: "..(SK.Net._yellBlocked and "|cffFF6666blocked|r" or "|cff00FF00ok|r"))
                if SK.Net.debug then
                    print("  Logs every inbound/outbound SK_NET message. Session only.")
                end
            end
        elseif cmd == "versiontest" then
            -- Dev preview of the new-version popup, ignores the notify flag
            if SK.Net and SK.Net.ShowVersionPopup then
                SK.Net:ShowVersionPopup("9.9.9.9")
            end
        elseif cmd == "catalogue" or cmd == "catalog" then
            -- Re-open the Catalogue companion-addon announcement on demand
            if SK.ShowCataloguePromo then SK:ShowCataloguePromo() end
        elseif cmd == "catalogue reset" or cmd == "catalog reset" then
            -- Clear the "seen" flag so the announcement fires again next login
            if SK.db then SK.db.seenCataloguePromo = nil end
            print("|cffFFD700[SK]|r Catalogue announcement reset - it will show again on your next login.")
        elseif cmd == "shops" then
            -- Diagnostic: list every shop stored locally and your role in it
            print("|cffFFD700[Storekeeper]|r Local shops:")
            local any = false
            for name, data in pairs(SK.db and SK.db.shops or {}) do
                any = true
                local role = SK.DB:GetRole(name) or "|cffFF6666none|r"
                print(string.format("  |cffFFD700%s|r  (owner: %s)  role: %s",
                    name, tostring(data.owner or "?"), role))
            end
            if not any then print("  (none)") end
            print("  Use |cffffff00/sk forget <name>|r to remove an orphaned shop locally.")
        elseif cmd:sub(1,7) == "forget " then
            local target = strtrim(raw:sub(8))
            if target == "" then print("|cffFFD700[SK]|r Usage: /sk forget <shop name>"); return end
            -- Match case-insensitively against stored shop names
            local found
            for name in pairs(SK.db and SK.db.shops or {}) do
                if name:lower() == target:lower() then found = name; break end
            end
            if found then
                SK.db.shops[found] = nil
                if SK.db.activeShop == found then SK.db.activeShop = next(SK.db.shops or {}) end
                print("|cffFFD700[SK]|r Removed |cffFFD700"..found.."|r from this character locally. (No one else is affected.)")
                if SK.Register and SK.Register.RefreshShopLabel then SK.Register:RefreshShopLabel() end
                if SK.Manager and SK.Manager.Toggle and SK.Manager.isOpen then end
            else
                print("|cffFFD700[SK]|r No local shop named '"..target.."'. Use /sk shops to list them.")
            end
        else
            print("|cffFFD700[Storekeeper]|r Commands:")
            print("  /sk              -- Open register")
            print("  /sk manager      -- Open manager")
            print("  /sk sync         -- Request full sync from shop owner")
            print("  /sk shops        -- List shops stored on this character")
            print("  /sk netdebug     -- Toggle network message logging")
            print("  /sk forget <name>-- Remove an orphaned shop locally")
        end
    end
    SLASH_STOREKEEPER1 = "/sk"
    SLASH_STOREKEEPER2 = "/storekeeper"
    SlashCmdList["STOREKEEPER"] = slash

    -- Minimap button
    SK.MinimapBtn:Build()

    -- Network (whisper-based shop sync)
    if SK.Net then SK.Net:Init() end

    print("|cffFFD700[Storekeeper]|r v" .. SK.VERSION .. " loaded.")
end

-- ─── Helpers ──────────────────────────────────────────────────────────────────

function SK:C()
    return SK.COLORS[SK.db and SK.db.theme or SK.THEMES.GOBLIN]
end

function SK:Cfg()
    if SK.db and SK.db.settings then return SK.db.settings end
    return {}
end

-- Display label for a product line. Variants are shown by their own name only;
-- the parent product name is intentionally dropped so labels stay short. A line
-- with no variant falls back to the product name.
function SK:LineLabel(productName, variantName)
    if variantName and strtrim(variantName) ~= "" then
        return strtrim(variantName)
    end
    return productName or "?"
end

-- Starter body for the receipt-item template. Uses the same {tokens} as the
-- emote/text receipt, plus {buyer} and {date}. Wrapped in TRP3 document markup.
function SK:DefaultReceiptBody()
    return
        "{h1:c}{shop}{/h1}\n" ..
        "{p:c}- Receipt -{/p}\n\n" ..
        "{p}Sold to: {buyer}{/p}\n" ..
        "{p}Date: {date}{/p}\n\n" ..
        "{p}{items}{/p}\n\n" ..
        "{p}Total: {total}{/p}\n" ..
        "{p}Payment: {payment}{/p}\n\n" ..
        "{p:c}Thank you for your patronage!{/p}\n" ..
        "{p:c}~ {seller} ~{/p}"
end

-- Substitute {shop} {buyer} {seller} {items} {total} {payment} {date} in a
-- receipt template. Only these known tokens are replaced; TRP3 markup tags like
-- {h1}, {p}, {col:...} are left untouched (the replacer returns nil for anything
-- not in data, which tells gsub to keep the original). The function form is used
-- so replacement values containing % are safe.
function SK:FillReceipt(body, data)
    body = body or ""
    data = data or {}
    return (body:gsub("{(%w+)}", function(key)
        local v = data[key]
        if v == nil then return nil end
        return tostring(v)
    end))
end

function SK:FormatMoney(copper)
    copper = math.floor(copper + 0.5)
    local g = math.floor(copper / 10000)
    local s = math.floor((copper % 10000) / 100)
    local c = copper % 100
    local parts = {}
    if g > 0 then tinsert(parts, string.format("|cffFFD700%dg|r", g)) end
    if s > 0 then tinsert(parts, string.format("|cffC0C0C0%ds|r", s)) end
    if c > 0 or #parts == 0 then tinsert(parts, string.format("|cffCD7F32%dc|r", c)) end
    return table.concat(parts, " ")
end

function SK:FormatMoneyPlain(copper)
    copper = math.floor(copper + 0.5)
    local g = math.floor(copper / 10000)
    local s = math.floor((copper % 10000) / 100)
    local c = copper % 100
    local parts = {}
    if g > 0 then tinsert(parts, g .. "g") end
    if s > 0 then tinsert(parts, s .. "s") end
    if c > 0 or #parts == 0 then tinsert(parts, c .. "c") end
    return table.concat(parts, " ")
end

function SK:GetRPName()
    if TRP3_API then
        -- Method 1: modern TRP3 — getPlayerCurrentProfile
        local ok, name = pcall(function()
            local profile = TRP3_API.profile.getPlayerCurrentProfile()
            if profile and profile.player then
                local first = strtrim(profile.player.FN or "")
                local last  = strtrim(profile.player.LN or "")
                local full  = strtrim(first .. (last ~= "" and " " .. last or ""))
                if full ~= "" then return full end
            end
        end)
        if ok and name and name ~= "" then return name end

        -- Method 2: via unit ID -> current profile
        local ok2, name2 = pcall(function()
            local getUnitID = TRP3_API.utils and TRP3_API.utils.str and
                              TRP3_API.utils.str.getUnitID
            local unit = getUnitID and getUnitID("player")
            if unit then
                local data = TRP3_API.register and
                             TRP3_API.register.getUnitIDCurrentProfile and
                             TRP3_API.register.getUnitIDCurrentProfile(unit)
                if data and data.player then
                    local first = strtrim(data.player.FN or "")
                    local last  = strtrim(data.player.LN or "")
                    local full  = strtrim(first .. (last ~= "" and " " .. last or ""))
                    if full ~= "" then return full end
                end
            end
        end)
        if ok2 and name2 and name2 ~= "" then return name2 end

        -- Method 3: TRP3 MSP (Mary Sue Protocol) — used by some TRP3 versions
        local ok3, name3 = pcall(function()
            if msp and msp.char then
                local unitID = UnitName("player")
                local c = unitID and msp.char[unitID]
                if c and c.field then
                    local full = strtrim(c.field.NA or "")
                    if full ~= "" then return full end
                end
            end
        end)
        if ok3 and name3 and name3 ~= "" then return name3 end

        -- TRP3 is loaded but no IC name found — return empty so callers
        -- know not to use it rather than returning the OOC name by accident.
        return ""
    end
    -- No TRP3 at all — fall back to OOC name
    return UnitName("player") or ""
end
