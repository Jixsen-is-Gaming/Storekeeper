-- Storekeeper: Core
-- Hooks OnInitialize so the main addon body runs at the right time.
-- bootstrap.lua already created the Storekeeper global before this runs.

local SK = Storekeeper

-- If AceAddon is in play it will call SK:OnInitialize() automatically.
-- If not (plain table fallback), we fire it ourselves on ADDON_LOADED.
if not LibStub or not LibStub("AceAddon-3.0", true) then
    local f = CreateFrame("Frame")
    f:RegisterEvent("ADDON_LOADED")
    f:SetScript("OnEvent", function(_, _, name)
        if name == "Storekeeper" then
            if SK.OnInitialize then SK:OnInitialize() end
            f:UnregisterEvent("ADDON_LOADED")
        end
    end)
end

-- ─── Per-character activeShop validation ─────────────────────────────────────
-- StorekeeperDB is account-wide (SavedVariables). We store activeShop per
-- character in db.charActiveShop[oocName] and expose it through db.activeShop
-- as a live property so the rest of the code needs no changes.
local _loginGuard = CreateFrame("Frame")
_loginGuard:RegisterEvent("PLAYER_LOGIN")
_loginGuard:SetScript("OnEvent", function(self)
    self:UnregisterEvent("PLAYER_LOGIN")
    if not SK.db or not SK.DB then return end

    local charKey = UnitName("player") or "unknown"
    if not SK.db.charActiveShop then SK.db.charActiveShop = {} end

    -- ── Seller IC name: seed for this character if not yet set ───────────────
    -- Done here (not OnInitialize) because UnitName("player") and TRP3 profile
    -- data are both reliable by PLAYER_LOGIN.
    if not SK.db.charNames then SK.db.charNames = {} end
    local function SeedICName()
        if SK.db.charNames[charKey] ~= nil then return end  -- already set
        local trpName = SK:GetRPName()
        -- Only use TRP3 name if it's a real IC name (non-empty, not the OOC name)
        if trpName ~= "" and trpName ~= charKey then
            SK.db.charNames[charKey] = trpName
        else
            SK.db.charNames[charKey] = ""
        end
    end
    SeedICName()
    -- TRP3 may finish loading its profile data after PLAYER_LOGIN fires.
    -- Hook its ready callback so we can fill in a blank entry if needed.
    if SK.db.charNames[charKey] == "" then
        local _trp3Guard = CreateFrame("Frame")
        _trp3Guard:RegisterEvent("ADDON_LOADED")
        _trp3Guard:SetScript("OnEvent", function(self, _, addonName)
            if addonName == "totalRP3" or addonName == "totalRP3_Extended" then
                self:UnregisterEvent("ADDON_LOADED")
                SeedICName()
            end
        end)
    end

    -- Migrate legacy single activeShop into per-character table if needed
    if SK.db.activeShop and not SK.db.charActiveShop[charKey] then
        -- Only migrate if this character actually has access to it
        local available = SK.DB:GetAllShops()
        for _, s in ipairs(available) do
            if s.name == SK.db.activeShop then
                SK.db.charActiveShop[charKey] = SK.db.activeShop
                break
            end
        end
        SK.db.activeShop = nil
    end

    -- Restore this character's last active shop (validate it still exists + accessible)
    local saved = SK.db.charActiveShop[charKey]
    local available = SK.DB:GetAllShops()
    local found = false
    if saved then
        for _, s in ipairs(available) do
            if s.name == saved then found = true; break end
        end
    end
    if found then
        SK.db.activeShop = saved
    elseif #available > 0 then
        SK.db.activeShop = available[1].name
        SK.db.charActiveShop[charKey] = SK.db.activeShop
    else
        SK.db.activeShop = nil
    end
end)
