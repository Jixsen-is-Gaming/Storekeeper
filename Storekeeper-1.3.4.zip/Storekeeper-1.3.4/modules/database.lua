-- Storekeeper: Database Module

Storekeeper.DB = Storekeeper.DB or {}
local SK = Storekeeper
local DB = SK.DB

-- ─── Helpers ──────────────────────────────────────────────────────────────────

local function NextID(list)
    local max = 0
    for _, v in ipairs(list) do if (v.id or 0) > max then max = v.id end end
    return max + 1
end

local function NormShop(shopName)
    return SK.db.shops[shopName or SK.db.activeShop]
end

-- ─── Shop ─────────────────────────────────────────────────────────────────────

function DB:CreateShop(shopName, ownerName)
    if not shopName or shopName == "" then return false, "Shop name required." end
    if SK.db.shops[shopName] then return false, "Shop already exists." end
    SK.db.shops[shopName] = {
        owner     = ownerName or SK:GetRPName(),
        managers  = {},
        employees = {},
        products  = {},
        orders    = {},
        logs      = {},
    }
    if not SK.db.activeShop then SK.db.activeShop = shopName end
    return true
end

function DB:DeleteShop(shopName)
    if not SK.db.shops[shopName] then return false end
    SK.db.shops[shopName] = nil
    -- Pick next active shop only from shops this character has a role in
    if SK.db.activeShop == shopName then
        SK.db.activeShop = nil
        local remaining = DB:GetAllShops()
        if #remaining > 0 then
            SK.db.activeShop = remaining[1].name
        end
    end
    return true
end

function DB:GetShop(shopName) return NormShop(shopName) end

function DB:GetAllShops()
    local list = {}
    local ooc = UnitName("player") or ""
    local ic  = SK:GetRPName() or ""
    for name, data in pairs(SK.db.shops) do
        -- Check by OOC name first, then IC name — both belong to the current character
        local role = DB:GetRole(name, ooc)
        if not role and ic ~= "" then
            role = DB:GetRole(name, ic)
        end
        if role ~= nil then
            tinsert(list, {name=name, data=data})
        end
    end
    table.sort(list, function(a,b) return a.name < b.name end)
    return list
end

function DB:SetActiveShop(shopName)
    if not SK.db.shops[shopName] then return false end
    SK.db.activeShop = shopName
    -- Persist per-character so each character remembers their own last selection
    local charKey = UnitName("player") or "unknown"
    if not SK.db.charActiveShop then SK.db.charActiveShop = {} end
    SK.db.charActiveShop[charKey] = shopName
    return true
end

-- Ensure old shops without new fields still work
function DB:MigrateShop(shop)
    if not shop then return end
    shop.employees      = shop.employees      or {}
    shop.orders         = shop.orders         or {}
    shop.logs           = shop.logs           or {}
    shop.discounts      = shop.discounts      or {}
    shop.perms          = shop.perms          or {}
    shop.categoryColors = shop.categoryColors or {}
    shop.categoryOrder  = shop.categoryOrder  or {}
    shop.productSeq     = shop.productSeq     or 0
    shop.orderSeq       = shop.orderSeq       or 0
    shop.treasury       = shop.treasury       or 0
    -- Migrate old 'categories' field → categoryColors
    if shop.categories then
        for k, v in pairs(shop.categories) do
            if not shop.categoryColors[k] then
                shop.categoryColors[k] = v
            end
        end
        shop.categories = nil
    end
end

-- Set/save the full category order for a shop
function DB:SetCategoryOrder(shopName, orderTable)
    local shop = NormShop(shopName)
    if not shop then return end
    DB:MigrateShop(shop)
    shop.categoryOrder = orderTable or {}
end

-- Get the current category order, rebuilt to include any new categories
-- that products use but haven't been explicitly ordered yet.
-- Categories that have NO products are pruned from the list automatically.
function DB:GetCategoryOrder(shopName)
    local shop = NormShop(shopName)
    if not shop then return {} end
    DB:MigrateShop(shop)
    -- Get all categories that currently have products
    local _, allCats = DB:GetProductsByCategory(shopName)
    -- Build a set of active category names
    local activeCats = {}
    for _, name in ipairs(allCats) do activeCats[name] = true end
    -- Start with the stored order, keeping only active categories
    local seen = {}
    local result = {}
    for _, name in ipairs(shop.categoryOrder) do
        if activeCats[name] and not seen[name] then
            seen[name] = true
            tinsert(result, name)
        end
    end
    -- Append any active categories not yet in the stored order
    for _, name in ipairs(allCats) do
        if not seen[name] then
            seen[name] = true
            tinsert(result, name)
        end
    end
    -- Persist the cleaned order back
    shop.categoryOrder = result
    return result
end

-- Add to treasury (positive = deposit, negative = withdrawal)
function DB:AddTreasury(shopName, copperAmount)
    local shop = NormShop(shopName)
    if not shop then return end
    DB:MigrateShop(shop)
    shop.treasury = (shop.treasury or 0) + copperAmount
    if shop.treasury < 0 then shop.treasury = 0 end
    DB:AddLog(shopName, string.format("Treasury %s: %s (balance: %s)",
        copperAmount >= 0 and "deposit" or "withdrawal",
        SK:FormatMoneyPlain(math.abs(copperAmount)),
        SK:FormatMoneyPlain(shop.treasury)), "treasury")
end

-- Set stock on a product (nil = unlimited)
function DB:SetStock(shopName, productID, amount)
    local shop = NormShop(shopName)
    if not shop then return false end
    for _, p in ipairs(shop.products) do
        if p.id == productID then
            p.stock = amount  -- nil = unlimited, number = limited
            DB:BumpProductSeq(shopName)
            return true
        end
    end
    return false
end

-- Decrease stock when order is fulfilled
function DB:DecreaseStock(shopName, productID, qty)
    local shop = NormShop(shopName)
    if not shop then return end
    for _, p in ipairs(shop.products) do
        if p.id == productID and p.stock ~= nil then
            p.stock = math.max(0, p.stock - qty)
            DB:BumpProductSeq(shopName)
        end
    end
end


function DB:GetRole(shopName, playerName)
    local shop = NormShop(shopName)
    if not shop then return nil end
    DB:MigrateShop(shop)
    -- Build the set of names to check against.
    -- If playerName is explicitly provided, only check that name plus its
    -- IC alias (TRP3 name). Do NOT inject UnitName("player") — that caused
    -- shops belonging to other characters on the same account to appear for
    -- the currently logged-in character.
    local names = {}
    if playerName then
        names[playerName:lower()] = true
    else
        -- No name given — fall back to the current character
        local ooc = UnitName("player")
        if ooc then names[ooc:lower()] = true end
        local ic = SK:GetRPName()
        if ic then names[ic:lower()] = true end
    end
    if not shop.owner then return nil end
    if names[shop.owner:lower()] then return "owner" end
    for _, m in ipairs(shop.managers)  do if names[m:lower()] then return "manager"  end end
    for _, e in ipairs(shop.employees) do if names[e:lower()] then return "employee" end end
    return nil
end

function DB:IsManager(shopName, playerName)
    local role = DB:GetRole(shopName, playerName)
    return role == "owner" or role == "manager"
end

function DB:IsStaff(shopName, playerName)
    return DB:GetRole(shopName, playerName) ~= nil
end

-- Permission helpers — returns true if the given role can perform the action
function DB:CanTreasury(shopName, playerName)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    local role = DB:GetRole(shopName, playerName)
    if role == "owner" then return true end
    if role == "manager" then return shop.perms.mgrsCanTreasury ~= false end
    if role == "employee" then return shop.perms.empsCanTreasury == true end
    return false
end

-- ─── Managers ─────────────────────────────────────────────────────────────────

-- Helper: strip realm suffix and return only the character name
local function ShortName(name)
    if not name then return "" end
    return strtrim(name):match("^([^%-]+)") or strtrim(name)
end

function DB:AddManager(shopName, name)
    local shop = NormShop(shopName)
    if not shop then return false, "Shop not found." end
    name = ShortName(name)
    if name == "" then return false, "Invalid name." end
    for _, m in ipairs(shop.managers) do
        if ShortName(m):lower()==name:lower() then return false, name.." is already a manager." end
    end
    -- Remove from employees if present
    for i, e in ipairs(shop.employees) do
        if ShortName(e):lower()==name:lower() then tremove(shop.employees, i); break end
    end
    tinsert(shop.managers, name)
    DB:AddLog(shopName, "Manager added: "..name, "staff")
    return true
end

function DB:RemoveManager(shopName, name)
    local shop = NormShop(shopName)
    if not shop then return false end
    name = ShortName(name)
    for i, m in ipairs(shop.managers) do
        if ShortName(m):lower()==name:lower() then
            tremove(shop.managers, i)
            DB:AddLog(shopName, "Manager removed: "..name, "staff")
            return true
        end
    end
    return false, "Manager not found."
end

-- ─── Employees ────────────────────────────────────────────────────────────────

function DB:AddEmployee(shopName, name)
    local shop = NormShop(shopName)
    if not shop then return false, "Shop not found." end
    DB:MigrateShop(shop)
    name = ShortName(name)
    if name == "" then return false, "Invalid name." end
    for _, e in ipairs(shop.employees) do
        if ShortName(e):lower()==name:lower() then return false, name.." is already an employee." end
    end
    for _, m in ipairs(shop.managers) do
        if ShortName(m):lower()==name:lower() then return false, name.." is already a manager." end
    end
    tinsert(shop.employees, name)
    DB:AddLog(shopName, "Employee added: "..name, "staff")
    return true
end

function DB:RemoveEmployee(shopName, name)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    name = ShortName(name)
    for i, e in ipairs(shop.employees) do
        if ShortName(e):lower()==name:lower() then
            tremove(shop.employees, i)
            DB:AddLog(shopName, "Employee removed: "..name, "staff")
            return true
        end
    end
    return false, "Employee not found."
end

-- ─── Products ─────────────────────────────────────────────────────────────────

function DB:AddProduct(shopName, name, description, priceCopper, category, icon)
    local shop = NormShop(shopName)
    if not shop then return false, "Shop not found." end
    if not name or name=="" then return false, "Name required." end
    local p = {
        id=NextID(shop.products), name=name, description=description or "",
        priceCopper=priceCopper or 0, category=category or "General",
        icon=icon or "INV_Misc_Coin_01",
    }
    tinsert(shop.products, p)
    DB:BumpProductSeq(shopName)
    DB:AddLog(shopName, "Product added: "..name, "product")
    return true, p
end

-- Variant used by network sync — accepts a pre-built product table
function DB:AddProductFromTable(shopName, tbl)
    local shop = NormShop(shopName)
    if not shop then return false, "Shop not found." end
    if not tbl or not tbl.name or tbl.name == "" then return false, "Name required." end
    local p = {
        id          = NextID(shop.products),
        name        = tbl.name,
        description = tbl.description or "",
        priceCopper = tonumber(tbl.priceCopper) or 0,
        category    = tbl.category or "General",
        icon        = tbl.icon or 0,
        rarity      = tbl.rarity or "common",
        stock       = tbl.stock,
    }
    tinsert(shop.products, p)
    return true, p
end

function DB:EditProduct(shopName, productID, fields)
    local shop = NormShop(shopName)
    if not shop then return false end
    for _, p in ipairs(shop.products) do
        if p.id==productID then
            for k,v in pairs(fields) do p[k]=v end
            DB:BumpProductSeq(shopName)
            DB:AddLog(shopName, "Product edited: "..p.name, "product")
            return true
        end
    end
    return false, "Product not found."
end

function DB:DeleteProduct(shopName, productID)
    local shop = NormShop(shopName)
    if not shop then return false end
    for i, p in ipairs(shop.products) do
        if p.id==productID then
            DB:BumpProductSeq(shopName)
            DB:AddLog(shopName, "Product deleted: "..p.name, "product")
            tremove(shop.products, i)
            return true
        end
    end
    return false
end

function DB:GetProducts(shopName)
    local shop = NormShop(shopName)
    return shop and shop.products or {}
end

function DB:GetCategoryColor(shopName, category)
    local shop = NormShop(shopName)
    if not shop then return 1, 0.82, 0 end
    DB:MigrateShop(shop)
    local col = shop.categoryColors[category]
    if col then return col[1], col[2], col[3] end
    return 1, 0.82, 0  -- default gold
end

function DB:SetCategoryColor(shopName, category, r, g, b)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    shop.categoryColors[category] = {r, g, b}
    DB:BumpProductSeq(shopName)
    return true
end

-- Bump the product sequence number for a shop
function DB:BumpProductSeq(shopName)
    local shop = NormShop(shopName)
    if not shop then return end
    shop.productSeq = (shop.productSeq or 0) + 1
end

-- Bump the order sequence number for a shop
function DB:BumpOrderSeq(shopName)
    local shop = NormShop(shopName)
    if not shop then return end
    shop.orderSeq = (shop.orderSeq or 0) + 1
end

-- Rename a shop (owner only check is done in UI)
function DB:RenameShop(oldName, newName)
    if not oldName or not newName or newName == "" then return false, "Name required." end
    if oldName == newName then return false, "Same name." end
    if SK.db.shops[newName] then return false, "A shop named '"..newName.."' already exists." end
    local shop = SK.db.shops[oldName]
    if not shop then return false, "Shop not found." end
    SK.db.shops[newName] = shop
    SK.db.shops[oldName] = nil
    if SK.db.activeShop == oldName then SK.db.activeShop = newName end
    DB:AddLog(newName, "Shop renamed from '"..oldName.."' to '"..newName.."'.", "system")
    return true
end

-- ─── Export / Import ──────────────────────────────────────────────────────────
-- Exports a shop's products, categories, category order, and discounts as a
-- base64-like encoded string that can be shared on Discord and imported by staff.

local B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

local function EncodeBase64(data)
    local result = {}
    local len = #data
    local i = 1
    while i <= len do
        local b1 = data:byte(i) or 0
        local b2 = data:byte(i+1) or 0
        local b3 = data:byte(i+2) or 0
        local n = b1*65536 + b2*256 + b3
        result[#result+1] = B64:sub(math.floor(n/262144)%64+1,math.floor(n/262144)%64+1)
        result[#result+1] = B64:sub(math.floor(n/4096)%64+1,  math.floor(n/4096)%64+1)
        result[#result+1] = (i+1 <= len) and B64:sub(math.floor(n/64)%64+1, math.floor(n/64)%64+1) or "="
        result[#result+1] = (i+2 <= len) and B64:sub(n%64+1, n%64+1) or "="
        i = i + 3
    end
    return table.concat(result)
end

local function DecodeBase64(s)
    s = s:gsub("[^"..B64.."=]","")
    local lut = {}
    for i=1,64 do lut[B64:sub(i,i)] = i-1 end
    local result = {}
    local i = 1
    while i <= #s do
        local c1 = lut[s:sub(i,i)]   or 0
        local c2 = lut[s:sub(i+1,i+1)] or 0
        local c3 = lut[s:sub(i+2,i+2)] or 0
        local c4 = lut[s:sub(i+3,i+3)] or 0
        local n = c1*262144 + c2*4096 + c3*64 + c4
        result[#result+1] = string.char(math.floor(n/65536)%256)
        if s:sub(i+2,i+2) ~= "=" then result[#result+1] = string.char(math.floor(n/256)%256) end
        if s:sub(i+3,i+3) ~= "=" then result[#result+1] = string.char(n%256) end
        i = i + 4
    end
    return table.concat(result)
end

-- Simple serializer: converts a Lua table of primitives to a compact string.
-- Only handles string/number/boolean values and nested tables (no functions/userdata).
local function Serialize(val, depth)
    depth = depth or 0
    local t = type(val)
    if t == "string" then
        return '"'..val:gsub('\\','\\\\'):gsub('"','\\"'):gsub('\n','\\n')..'"'
    elseif t == "number" then
        return tostring(val)
    elseif t == "boolean" then
        return tostring(val)
    elseif t == "nil" then
        return "null"
    elseif t == "table" then
        -- Detect array vs hash
        local isArray = true
        local maxN = 0
        for k,_ in pairs(val) do
            if type(k) ~= "number" or k ~= math.floor(k) or k < 1 then
                isArray = false; break
            end
            if k > maxN then maxN = k end
        end
        if isArray and maxN == #val then
            local parts = {}
            for _, v in ipairs(val) do parts[#parts+1] = Serialize(v, depth+1) end
            return "["..table.concat(parts,",").."]"
        else
            local parts = {}
            for k, v in pairs(val) do
                if type(k) == "string" or type(k) == "number" then
                    parts[#parts+1] = Serialize(tostring(k),depth+1)..":"..Serialize(v,depth+1)
                end
            end
            table.sort(parts)
            return "{"..table.concat(parts,",").."}"
        end
    end
    return "null"
end

local function Deserialize(s, pos)
    pos = pos or 1
    -- skip whitespace
    while pos <= #s and s:sub(pos,pos):match("%s") do pos=pos+1 end
    local c = s:sub(pos,pos)
    if c == '"' then
        local result, i = {}, pos+1
        while i <= #s do
            local ch = s:sub(i,i)
            if ch == '\\' then
                local nc = s:sub(i+1,i+1)
                if nc == 'n' then result[#result+1]='\n'
                elseif nc == '"' then result[#result+1]='"'
                elseif nc == '\\' then result[#result+1]='\\'
                else result[#result+1]=nc end
                i = i+2
            elseif ch == '"' then
                return table.concat(result), i+1
            else result[#result+1]=ch; i=i+1 end
        end
        return table.concat(result), i
    elseif c == '[' then
        local arr, i = {}, pos+1
        while i <= #s do
            while i <= #s and s:sub(i,i):match("%s") do i=i+1 end
            if s:sub(i,i) == ']' then return arr, i+1 end
            if #arr > 0 and s:sub(i,i) == ',' then i=i+1 end
            local v, ni = Deserialize(s, i)
            arr[#arr+1] = v; i = ni
        end
        return arr, i
    elseif c == '{' then
        local obj, i = {}, pos+1
        while i <= #s do
            while i <= #s and s:sub(i,i):match("%s") do i=i+1 end
            if s:sub(i,i) == '}' then return obj, i+1 end
            if next(obj) ~= nil and s:sub(i,i) == ',' then i=i+1 end
            local k, ni = Deserialize(s, i); i = ni
            while i <= #s and s:sub(i,i):match("%s") do i=i+1 end
            i = i+1  -- skip ':'
            local v, ni2 = Deserialize(s, i); i = ni2
            -- Convert numeric string keys back to numbers if they look like integers
            local nk = tonumber(k)
            obj[nk or k] = v
        end
        return obj, i
    elseif s:sub(pos,pos+3) == "null" then
        return nil, pos+4
    elseif s:sub(pos,pos+3) == "true" then
        return true, pos+4
    elseif s:sub(pos,pos+4) == "false" then
        return false, pos+5
    else
        local num, npos = s:match("^(-?%d+%.?%d*)", pos)
        if num then return tonumber(num), pos+#num end
        return nil, pos+1
    end
end

function DB:ExportShop(shopName)
    local shop = NormShop(shopName)
    if not shop then return nil, "Shop not found." end
    DB:MigrateShop(shop)

    -- Build a minimal export payload: products, categoryColors, categoryOrder, discounts
    local payload = {
        shopName      = shopName,
        version       = SK.VERSION,
        products      = {},
        categoryColors= {},
        categoryOrder = shop.categoryOrder,
        discounts     = shop.discounts or {},
    }
    for _, p in ipairs(shop.products) do
        payload.products[#payload.products+1] = {
            name        = p.name,
            description = p.description or "",
            priceCopper = p.priceCopper or 0,
            category    = p.category or "General",
            icon        = p.icon or 134400,
            rarity      = p.rarity or "common",
            stock       = p.stock,  -- may be nil
        }
    end
    for catName, col in pairs(shop.categoryColors) do
        payload.categoryColors[catName] = col
    end

    local json   = Serialize(payload)
    local encoded = EncodeBase64(json)
    -- Prefix so we can validate on import
    return "SK133:"..encoded
end

function DB:ImportShop(shopName, code)
    if not code or code:sub(1,6) ~= "SK133:" then
        return false, "Invalid export code. Make sure you copied the full code."
    end
    local encoded = code:sub(7)
    local ok, payload = pcall(function()
        local json = DecodeBase64(encoded)
        local val = Deserialize(json)
        return val
    end)
    if not ok or type(payload) ~= "table" then
        return false, "Could not decode export code. It may be corrupted."
    end

    local shop = NormShop(shopName)
    if not shop then return false, "Shop not found." end
    DB:MigrateShop(shop)

    -- Merge products: add any that don't already exist by name
    local existingNames = {}
    for _, p in ipairs(shop.products) do existingNames[p.name:lower()] = true end

    local added = 0
    if type(payload.products) == "table" then
        for _, p in ipairs(payload.products) do
            if type(p) == "table" and p.name and not existingNames[p.name:lower()] then
                local newP = {
                    id          = (function()
                        local max = 0
                        for _, ep in ipairs(shop.products) do if (ep.id or 0) > max then max = ep.id end end
                        return max + 1
                    end)(),
                    name        = p.name,
                    description = p.description or "",
                    priceCopper = tonumber(p.priceCopper) or 0,
                    category    = p.category or "General",
                    icon        = tonumber(p.icon) or 134400,
                    rarity      = p.rarity or "common",
                    stock       = tonumber(p.stock),  -- may be nil
                }
                tinsert(shop.products, newP)
                existingNames[p.name:lower()] = true
                added = added + 1
            end
        end
    end

    -- Merge category colors
    if type(payload.categoryColors) == "table" then
        for catName, col in pairs(payload.categoryColors) do
            if type(col) == "table" and col[1] and col[2] and col[3] then
                shop.categoryColors[catName] = col
            end
        end
    end

    -- Merge category order (append new entries)
    if type(payload.categoryOrder) == "table" then
        local seen = {}
        for _, n in ipairs(shop.categoryOrder) do seen[n] = true end
        for _, n in ipairs(payload.categoryOrder) do
            if not seen[n] then
                tinsert(shop.categoryOrder, n)
                seen[n] = true
            end
        end
    end

    -- Merge discounts (add if label doesn't already exist)
    if type(payload.discounts) == "table" then
        local existDisc = {}
        for _, d in ipairs(shop.discounts or {}) do existDisc[d.label:lower()] = true end
        for _, d in ipairs(payload.discounts) do
            if type(d) == "table" and d.label and not existDisc[d.label:lower()] then
                tinsert(shop.discounts, {label=d.label, pct=tonumber(d.pct) or 10})
                existDisc[d.label:lower()] = true
            end
        end
    end

    DB:BumpProductSeq(shopName)
    DB:AddLog(shopName, string.format("Shop imported from export code: %d products added.", added), "system")
    return true, added
end

-- ─── Products by Category ─────────────────────────────────────────────────────

function DB:GetProductsByCategory(shopName)
    local shop = NormShop(shopName)
    local cats, order = {}, {}
    for _, p in ipairs(DB:GetProducts(shopName)) do
        local cat = p.category or "General"
        if not cats[cat] then cats[cat]={} ; tinsert(order, cat) end
        tinsert(cats[cat], p)
    end
    -- Sort by custom categoryOrder if defined, else alphabetically
    local customOrder = shop and shop.categoryOrder
    if customOrder and #customOrder > 0 then
        -- Build lookup: catName -> position
        local pos = {}
        for i, name in ipairs(customOrder) do pos[name] = i end
        table.sort(order, function(a, b)
            local pa = pos[a] or 999
            local pb = pos[b] or 999
            if pa == pb then return a < b end
            return pa < pb
        end)
    else
        table.sort(order)
    end
    return cats, order
end

-- ─── Orders ───────────────────────────────────────────────────────────────────
-- Order structure:
-- { id, timestamp, items[], totalCopper, paymentType, status,
--   sellerOOC, sellerIC, buyerOOC, buyerIC, deliveryNote,
--   notes }
-- paymentType: "paid" | "favor" | "delivery" | "commission"
-- status: "open" | "in_progress" | "ready" | "complete"

function DB:CreateOrder(shopName, orderData)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    local order = {
        id           = NextID(shop.orders),
        timestamp    = time(),
        items        = orderData.items        or {},
        totalCopper  = orderData.totalCopper  or 0,
        paymentType  = orderData.paymentType  or "paid",
        status       = orderData.status       or "open",
        sellerOOC    = orderData.sellerOOC    or "",
        sellerIC     = orderData.sellerIC     or "",
        buyerOOC     = orderData.buyerOOC     or "",
        buyerIC      = orderData.buyerIC      or "",
        deliveryNote = orderData.deliveryNote or "",
        notes        = orderData.notes        or "",
        -- New fields
        assignedTo      = "",   -- IC name of staff member working on it
        estimatedMinutes= 0,    -- 0 = not set
        claimedAt       = 0,    -- timestamp when claimed
    }
    tinsert(shop.orders, order)
    DB:BumpOrderSeq(shopName)
    DB:AddLog(shopName, string.format("Order #%d created (%s, %s)",
        order.id, order.paymentType, SK:FormatMoneyPlain(order.totalCopper)), "order")
    return true, order
end

-- Claim an order for the current player (unclaims any other order they held)
function DB:ClaimOrder(shopName, orderID, staffName, estimatedMinutes)
    local shop = NormShop(shopName)
    if not shop then return false, "Shop not found." end
    DB:MigrateShop(shop)
    -- Release any other order this person already claimed
    for _, o in ipairs(shop.orders) do
        if o.assignedTo == staffName and o.id ~= orderID then
            o.assignedTo = ""
            o.claimedAt  = 0
        end
    end
    for _, o in ipairs(shop.orders) do
        if o.id == orderID then
            if o.status == "complete" then
                return false, "This order is already complete."
            end
            if o.assignedTo ~= "" and o.assignedTo ~= staffName then
                return false, o.assignedTo.." is already working on this order."
            end
            o.assignedTo       = staffName
            o.estimatedMinutes = estimatedMinutes or 0
            o.claimedAt        = time()
            o.status           = "in_progress"
            DB:BumpOrderSeq(shopName)
            DB:AddLog(shopName, string.format("Order #%d claimed by %s (ETA: %d min)",
                orderID, staffName, o.estimatedMinutes), "order")
            return true
        end
    end
    return false, "Order not found."
end

function DB:UnclaimOrder(shopName, orderID)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    for _, o in ipairs(shop.orders) do
        if o.id == orderID then
            if o.status == "complete" then return false end  -- can't release completed orders
            DB:AddLog(shopName, string.format("Order #%d released by %s",
                orderID, o.assignedTo), "order")
            o.assignedTo       = ""
            o.estimatedMinutes = 0
            o.claimedAt        = 0
            o.status           = "open"
            DB:BumpOrderSeq(shopName)
            return true
        end
    end
    return false
end

function DB:UpdateOrderStatus(shopName, orderID, status)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    for _, o in ipairs(shop.orders) do
        if o.id==orderID then
            local prev = o.status
            o.status = status
            DB:BumpOrderSeq(shopName)
            DB:AddLog(shopName, string.format("Order #%d -> %s", orderID, status), "order")
            -- Add to treasury when a paid order is completed
            if status == "complete" and prev ~= "complete" then
                if o.paymentType == "paid" and o.totalCopper > 0 then
                    shop.treasury = (shop.treasury or 0) + o.totalCopper
                    DB:AddLog(shopName, string.format("Treasury +%s (Order #%d complete)",
                        SK:FormatMoneyPlain(o.totalCopper), orderID), "treasury")
                end
                -- Decrease stock for each item in the order
                for _, item in ipairs(o.items or {}) do
                    if item.product and item.product.id then
                        DB:DecreaseStock(shopName, item.product.id, item.qty or 1)
                    end
                end
            end
            return true
        end
    end
    return false
end

function DB:GetOrders(shopName)
    local shop = NormShop(shopName)
    if not shop then return {} end
    DB:MigrateShop(shop)
    return shop.orders
end

-- ─── Logs ─────────────────────────────────────────────────────────────────────

function DB:GetLogs(shopName)
    local shop = NormShop(shopName)
    if not shop then return {} end
    DB:MigrateShop(shop)
    return shop.logs
end

function DB:AddLog(shopName, message, category)
    local shop = NormShop(shopName)
    if not shop then return end
    DB:MigrateShop(shop)
    message = message:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r","")
    local entry = { timestamp=time(), message=message, category=category or "system" }
    tinsert(shop.logs, entry)
    while #shop.logs > 200 do tremove(shop.logs, 1) end
    if SK.Net and SK.Net.BroadcastLog then
        SK.Net:BroadcastLog(shopName, entry)
    end
end

function DB:DeleteOrder(shopName, orderID)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    for i, o in ipairs(shop.orders) do
        if o.id == orderID then
            tremove(shop.orders, i)
            DB:BumpOrderSeq(shopName)
            DB:AddLog(shopName, string.format("Order #%d deleted", orderID))
            return true
        end
    end
    return false
end

function DB:DeleteLog(shopName, index)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    if shop.logs[index] then
        tremove(shop.logs, index)
        return true
    end
    return false
end

function DB:ClearLogs(shopName)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    shop.logs = {}
    return true
end

-- ─── Discounts ────────────────────────────────────────────────────────────────

function DB:GetDiscounts(shopName)
    local shop = NormShop(shopName)
    if not shop then return {} end
    shop.discounts = shop.discounts or {}
    return shop.discounts
end

function DB:AddDiscount(shopName, label, pct)
    local shop = NormShop(shopName)
    if not shop then return false, "Shop not found." end
    shop.discounts = shop.discounts or {}
    pct = tonumber(pct) or 0
    if pct <= 0 or pct > 100 then return false, "Discount must be 1–100%." end
    if label == "" then return false, "Label required." end
    tinsert(shop.discounts, {label=label, pct=pct})
    DB:AddLog(shopName, "Discount added: "..label.." ("..pct.."%)")
    return true
end

function DB:DeleteDiscount(shopName, idx)
    local shop = NormShop(shopName)
    if not shop or not shop.discounts then return false end
    tremove(shop.discounts, idx)
    return true
end

function DB:MigrateShopDiscounts(shop)
    if not shop then return end
    shop.discounts = shop.discounts or {}
end

-- ─── Order Expiry ─────────────────────────────────────────────────────────────
-- Checks all claimed orders across all shops and releases any that have passed
-- their estimated completion time. Returns a list of {shopName, orderID} released.

function DB:CheckOrderExpiry()
    local now = time()
    local released = {}
    for shopName, shop in pairs(SK.db.shops or {}) do
        DB:MigrateShop(shop)
        for _, order in ipairs(shop.orders) do
            if order.claimedAt and order.claimedAt > 0
               and order.estimatedMinutes and order.estimatedMinutes > 0 then
                local deadline = order.claimedAt + order.estimatedMinutes * 60
                if now > deadline and order.status ~= "complete" then
                    -- Release the order back to unclaimed
                    order.assignedTo       = ""   -- was wrongly clearing claimedBy
                    order.claimedAt        = 0
                    order.estimatedMinutes = 0
                    order.status           = "open"
                    DB:BumpOrderSeq(shopName)
                    tinsert(released, {shopName=shopName, orderID=order.id})
                    DB:AddLog(shopName, "Order #"..order.id.." expired and was released for reclaiming.", "order")
                end
            end
        end
    end
    return released
end
