-- Storekeeper: Network — whisper-based invite & product sync
--
-- Protocol uses SendAddonMessage over WHISPER with prefix "SK_NET".
-- Fields are separated by \031 (unit separator, never appears in user text).
-- Products are serialised per-field with \030 (record separator) between products.
--
-- Commands:
--   INVITE   shopName \031 role \031 ownerName
--   ACCEPT   shopName \031 playerName \031 role
--   DECLINE  shopName \031 playerName
--   KICK     shopName
--   SHOP_DELETE shopName
--   SYNC_START  shopName \031 totalChunks
--   SYNC_CHUNK  shopName \031 chunkIdx \031 data
--   SYNC_END    shopName
--   LEAVE    shopName \031 playerName

local SK  = Storekeeper
local NET = {}
SK.Net    = NET

local PREFIX    = "SK_NET"
local SEP       = "\031"   -- field separator (unit separator — safe in addon msgs)
local RECSEP    = "\030"   -- record separator between products
local MAX_CHUNK = 200      -- WoW addon message limit is 255 bytes; 200 leaves headroom for prefix + cmd + shopName + idx overhead

-- Whether to notify the player in chat when a peer is running a newer version.
-- Kept disabled for now — flip to true in a future release to re-enable.
local NOTIFY_NEW_VERSION = true

-- ─── Pending state ───────────────────────────────────────────────────────────

local pendingInvite = nil
local syncBuffer    = {}

-- ─── Retry Queue ─────────────────────────────────────────────────────────────
-- Failed sends are queued here and retried with exponential backoff.
-- Each entry: { target, msg, attempts, nextRetry }

local retryQueue   = {}
local RETRY_DELAYS = {2, 5, 10}  -- seconds between attempts
local MAX_ATTEMPTS = 3

local function QueueRetry(target, msg)
    tinsert(retryQueue, {target=target, msg=msg, attempts=1, nextRetry=time()+RETRY_DELAYS[1]})
end

local function FlushRetryQueue()
    if #retryQueue == 0 then return end
    local now = time()
    local keep = {}
    for _, entry in ipairs(retryQueue) do
        if now >= entry.nextRetry then
            local result = C_ChatInfo and C_ChatInfo.SendAddonMessage and
                C_ChatInfo.SendAddonMessage(PREFIX, entry.msg, "WHISPER", entry.target)
            if result == Enum.SendAddonMessageResult.Success or result == true then
                -- Sent successfully — drop from queue
            elseif entry.attempts < MAX_ATTEMPTS then
                entry.attempts = entry.attempts + 1
                entry.nextRetry = now + (RETRY_DELAYS[entry.attempts] or 10)
                tinsert(keep, entry)
            end
            -- If max attempts reached, silently drop
        else
            tinsert(keep, entry)
        end
    end
    retryQueue = keep
end

-- ─── Outbound Send Queue ──────────────────────────────────────────────────────
-- All addon messages are funnelled through here so we never blast more than
-- one message per frame. WoW's addon message rate limit is ~800 bytes/sec on
-- whispers; sending a large product list to several staff members in a single
-- frame can exceed it and trigger a disconnect.
-- MSG_INTERVAL: one message per 0.1s = 10 msg/sec, safely under the cap.

local sendQueue    = {}
local MSG_INTERVAL = 0.1  -- seconds between sends
local _sendTicker  = nil

local function DrainSendQueue()
    if #sendQueue == 0 then
        if _sendTicker then _sendTicker:Cancel(); _sendTicker = nil end
        return
    end
    local entry = tremove(sendQueue, 1)
    local result
    if C_ChatInfo and C_ChatInfo.SendAddonMessage then
        result = C_ChatInfo.SendAddonMessage(PREFIX, entry.msg, entry.channel, entry.target)
    else
        SendAddonMessage(PREFIX, entry.msg, entry.channel, entry.target)
        return
    end
    if entry.channel == "WHISPER" and entry.target then
        if result == Enum.SendAddonMessageResult.AddonMessageThrottle then
            QueueRetry(entry.target, entry.msg)
        elseif result == Enum.SendAddonMessageResult.PlayerNotFound then
            -- Target is offline or doesn't exist — fire the failure callback if one was set
            if entry.onFail then entry.onFail() end
        end
    end
end

local function EnqueueSend(channel, target, msg, onFail)
    tinsert(sendQueue, {channel=channel, target=target, msg=msg, onFail=onFail})
    if not _sendTicker then
        _sendTicker = C_Timer.NewTicker(MSG_INTERVAL, DrainSendQueue)
    end
end

-- ─── Presence Awareness ──────────────────────────────────────────────────────
-- Track which staff members are known to be online via WoW's friends list.
-- If a player is on our friends list and shown offline, skip the whisper entirely.

local function IsKnownOffline(name)
    -- Only skip if we have definitive evidence they're offline (friends list)
    -- Unknown players (not on friends list) always get attempted
    local short = (name or ""):match("^([^%-]+)") or (name or "")
    local numFriends = C_FriendList and C_FriendList.GetNumFriends and C_FriendList.GetNumFriends() or 0
    for i = 1, numFriends do
        local info = C_FriendList.GetFriendInfoByIndex(i)
        if info and info.name:lower() == short:lower() then
            return not info.connected  -- known offline only if on friends list AND offline
        end
    end
    return false  -- not on friends list — attempt the send anyway
end

-- ─── Helpers ─────────────────────────────────────────────────────────────────

local function RawSend(channel, target, msg, onFail)
    EnqueueSend(channel, target, msg, onFail)
end

-- Best channel to reach a specific player:
-- RAID > PARTY > WHISPER (WHISPER is last resort — broken on connected realms)
local function GroupChannel()
    if IsInRaid()  then return "RAID"  end
    if IsInGroup() then return "PARTY" end
    return nil
end

-- Is this player name in our current group/raid?
local function IsInMyGroup(name)
    local short = name:match("^([^%-]+)") or name
    local unit  = IsInRaid() and "raid" or "party"
    local max   = IsInRaid() and 40 or 4
    for i = 1, max do
        local uname = UnitName(unit..i)
        if uname and uname:lower() == short:lower() then return true end
    end
    return false
end

-- Send a message to one person — via group channel if they're in the group,
-- otherwise whisper them directly
local function Send(target, ...)
    local fields = {...}
    local msg = table.concat(fields, SEP)
    local gc = GroupChannel()
    if gc and IsInMyGroup(target) then
        RawSend(gc, nil, msg)
    else
        RawSend("WHISPER", target, msg)
    end
end

-- Always whisper directly to one person — used for targeted messages like
-- INVITE, KICK, ACCEPT, DECLINE that must not be broadcast to the whole group.
-- Skips the send if the player is known to be offline via the friends list.
local function SendDirect(target, ...)
    if IsKnownOffline(target) then return end
    -- If the target is in our group/raid, route over the group channel. This is
    -- essential for same-Battle.net-account characters (main <-> alt), who cannot
    -- whisper each other at all — a whisper just errors with "No player named...".
    -- We tag the message with the intended recipient so other group members who
    -- happen to receive it can ignore it (see OnAddonMsg "@TO" handling).
    local gc = GroupChannel()
    if gc and IsInMyGroup(target) then
        local short = (target or ""):match("^([^%-]+)") or (target or "")
        local fields = {...}
        RawSend(gc, nil, "@TO"..SEP..short:lower()..SEP..table.concat(fields, SEP))
        return
    end
    -- Try to resolve to full realm-qualified name via group roster
    local short = (target or ""):match("^([^%-]+)") or (target or "")
    if not target:find("-") then
        local unitType = IsInRaid() and "raid" or "party"
        local maxUnits = IsInRaid() and 40 or 4
        for i = 1, maxUnits do
            local uname, urealm = UnitFullName(unitType..i)
            if uname and uname:lower() == short:lower() and urealm and urealm ~= "" then
                target = uname.."-"..urealm
                break
            end
        end
    end
    local fields = {...}
    local msg = table.concat(fields, SEP)
    RawSend("WHISPER", target, msg)
end

-- Like SendDirect but fires onFail if the target is offline or not found.
local function SendDirectWithFail(target, onFail, ...)
    if IsKnownOffline(target) then
        if onFail then onFail() end
        return
    end
    local short = (target or ""):match("^([^%-]+)") or (target or "")
    if not target:find("-") then
        local unitType = IsInRaid() and "raid" or "party"
        local maxUnits = IsInRaid() and 40 or 4
        for i = 1, maxUnits do
            local uname, urealm = UnitFullName(unitType..i)
            if uname and uname:lower() == short:lower() and urealm and urealm ~= "" then
                target = uname.."-"..urealm
                break
            end
        end
    end
    local fields = {...}
    local msg = table.concat(fields, SEP)
    RawSend("WHISPER", target, msg, onFail)
end

local function Split(str, maxFields)
    local parts = {}
    local s = 1
    local count = 0
    while true do
        count = count + 1
        -- If we've hit maxFields-1, dump the rest as the final field
        if maxFields and count >= maxFields then
            tinsert(parts, str:sub(s))
            break
        end
        local i = str:find(SEP, s, true)
        if not i then
            tinsert(parts, str:sub(s))
            break
        end
        tinsert(parts, str:sub(s, i - 1))
        s = i + #SEP
    end
    return parts
end

local function PlayerName()
    local name, realm = UnitFullName("player")
    if realm and realm ~= "" and not name:find("-") then
        return name.."-"..realm
    end
    return name
end

local function ShortName(n)
    return (n or ""):match("^([^%-]+)") or (n or "")
end

local function RefreshManagerStaff()
    if SK.Manager and SK.Manager.activeTab then
        if SK.Manager.activeTab == "staff" or SK.Manager.activeTab == "people" then
            SK.Manager:SwitchTab(SK.Manager.activeTab)
        end
    end
end

local function RefreshManagerProducts()
    if SK.Manager and SK.Manager.activeTab == "products" then
        SK.Manager:SwitchTab("products")
    end
end

-- ─── Serialisation ───────────────────────────────────────────────────────────
-- Each product is: id \031 name \031 category \031 description \031 priceCopper \031 icon
-- Products are joined with RECSEP

local function EscField(s)
    -- Replace SEP and RECSEP in field values (rare but safe)
    return tostring(s or ""):gsub(SEP, " "):gsub(RECSEP, " ")
end

-- Encode variants as "name:priceCopper|name:priceCopper" (pipe-delimited pairs)
local function SerialiseVariants(variants)
    if not variants or #variants == 0 then return "" end
    local parts = {}
    for _, v in ipairs(variants) do
        local n = tostring(v.name or ""):gsub(":", "-"):gsub("|", "-")
        parts[#parts+1] = n .. ":" .. tostring(v.priceCopper or 0)
    end
    return table.concat(parts, "|")
end

local function DeserialiseVariants(s)
    if not s or s == "" then return {} end
    local result = {}
    for pair in s:gmatch("[^|]+") do
        local name, price = pair:match("^(.+):(%d+)$")
        if name and price then
            result[#result+1] = {name=name, priceCopper=tonumber(price) or 0}
        end
    end
    return result
end

local function SerialiseProduct(p)
    return EscField(p.id)          .. SEP ..
           EscField(p.name)        .. SEP ..
           EscField(p.category)    .. SEP ..
           EscField(p.description) .. SEP ..
           EscField(p.priceCopper) .. SEP ..
           EscField(p.icon)        .. SEP ..
           EscField(p.rarity or "common") .. SEP ..
           EscField(p.stock ~= nil and tostring(p.stock) or "") .. SEP ..
           EscField(p.hasTRP3Item and "1" or "") .. SEP ..
           EscField(p.sortIndex ~= nil and tostring(p.sortIndex) or "") .. SEP ..
           EscField(SerialiseVariants(p.variants)) .. SEP ..
           EscField(p.restockCost ~= nil and tostring(p.restockCost) or "")
end

local function DeserialiseProduct(s)
    local f = Split(s)
    local stockStr   = f[8] or ""
    local sortStr    = f[10] or ""
    local restockStr = f[12] or ""
    return {
        id          = f[1] or "",
        name        = f[2] or "",
        category    = f[3] or "General",
        description = f[4] or "",
        priceCopper = tonumber(f[5]) or 0,
        icon        = tonumber(f[6]) or 0,
        rarity      = f[7] or "common",
        stock       = stockStr ~= "" and tonumber(stockStr) or nil,
        hasTRP3Item = (f[9] or "") == "1",
        sortIndex   = sortStr ~= "" and tonumber(sortStr) or nil,
        variants    = DeserialiseVariants(f[11] or ""),
        restockCost = restockStr ~= "" and tonumber(restockStr) or nil,
    }
end

local function SerialiseAllProducts(shopName)
    local prods = SK.DB:GetProducts(shopName)
    local parts = {}
    for _, p in ipairs(prods) do
        tinsert(parts, SerialiseProduct(p))
    end
    return table.concat(parts, RECSEP)
end

local function Chunkify(str)
    local chunks, pos, len = {}, 1, #str
    while pos <= len do
        tinsert(chunks, str:sub(pos, pos + MAX_CHUNK - 1))
        pos = pos + MAX_CHUNK
    end
    if #chunks == 0 then tinsert(chunks, "") end
    return chunks
end

-- ─── Order serialisation ─────────────────────────────────────────────────────
-- Order wire format (SEP-separated fields):
--   id \031 timestamp \031 status \031 paymentType \031 totalCopper
--   \031 sellerIC \031 sellerOOC \031 buyerIC \031 buyerOOC
--   \031 deliveryNote \031 notes \031 assignedTo \031 estimatedMinutes \031 claimedAt
--   \031 itemsStr   (items as "qty:name" joined by comma)

local function SerialiseOrder(o)
    local itemParts = {}
    for _, e in ipairs(o.items or {}) do
        -- e is {product={name=...}, qty=N} from cart, or may already be flattened
        local name = (e.product and e.product.name) or e.name or "?"
        local qty  = e.qty or 1
        tinsert(itemParts, EscField(qty)..":"..EscField(name))
    end
    local itemsStr = table.concat(itemParts, ",")
    return EscField(o.id)              .. SEP ..
           EscField(o.timestamp)       .. SEP ..
           EscField(o.status)          .. SEP ..
           EscField(o.paymentType)     .. SEP ..
           EscField(o.totalCopper)     .. SEP ..
           EscField(o.sellerIC)        .. SEP ..
           EscField(o.sellerOOC)       .. SEP ..
           EscField(o.buyerIC)         .. SEP ..
           EscField(o.buyerOOC)        .. SEP ..
           EscField(o.deliveryNote)    .. SEP ..
           EscField(o.notes)           .. SEP ..
           EscField(o.assignedTo)      .. SEP ..
           EscField(o.estimatedMinutes).. SEP ..
           EscField(o.claimedAt)       .. SEP ..
           itemsStr
end

local function DeserialiseOrder(s)
    local f = Split(s, 15)  -- 14 fixed fields + items remainder
    local items = {}
    local itemsStr = f[15] or ""
    for part in (itemsStr..","):gmatch("([^,]*),") do
        local qty, name = part:match("^(%d+):(.+)$")
        if qty and name then
            tinsert(items, {qty=tonumber(qty), product={name=name}, name=name})
        end
    end
    return {
        id              = tonumber(f[1])  or 0,
        timestamp       = tonumber(f[2])  or 0,
        status          = f[3]  or "open",
        paymentType     = f[4]  or "paid",
        totalCopper     = tonumber(f[5])  or 0,
        sellerIC        = f[6]  or "",
        sellerOOC       = f[7]  or "",
        buyerIC         = f[8]  or "",
        buyerOOC        = f[9]  or "",
        deliveryNote    = f[10] or "",
        notes           = f[11] or "",
        assignedTo      = f[12] or "",
        estimatedMinutes= tonumber(f[13]) or 0,
        claimedAt       = tonumber(f[14]) or 0,
        items           = items,
    }
end

-- ─── Tab serialisation ───────────────────────────────────────────────────────
-- Tab fixed fields then items remainder. Each item: qty:variantKey:priceCopper:name
-- (variantKey may be empty; name is last so it can contain spaces)

local function SerialiseTab(t)
    local itemParts = {}
    for _, e in ipairs(t.items or {}) do
        local name = (e.product and e.product.name) or "?"
        local price = (e.variant and e.variant.priceCopper) or (e.product and e.product.priceCopper) or 0
        local pid  = (e.product and e.product.id) or 0
        -- qty | variantKey | priceCopper | productId | name
        tinsert(itemParts, EscField(e.qty or 1).."\029"..EscField(e.variantKey or "").."\029"..
            EscField(price).."\029"..EscField(pid).."\029"..EscField(name))
    end
    local itemsStr = table.concat(itemParts, ",")
    return EscField(t.id)          .. SEP ..
           EscField(t.timestamp)   .. SEP ..
           EscField(t.status)      .. SEP ..
           EscField(t.holders)     .. SEP ..
           EscField(t.openedBy)    .. SEP ..
           EscField(t.paymentMode) .. SEP ..
           EscField(t.deposit)     .. SEP ..
           EscField(t.closedAt or 0) .. SEP ..
           itemsStr
end

local function DeserialiseTab(s)
    local f = Split(s, 9)  -- 8 fixed fields + items remainder
    local items = {}
    local itemsStr = f[9] or ""
    for part in (itemsStr..","):gmatch("([^,]*),") do
        if part ~= "" then
            local af = {}
            for sub in (part.."\029"):gmatch("([^\029]*)\029") do tinsert(af, sub) end
            local qty   = tonumber(af[1]) or 1
            local vkey  = af[2] or ""
            local price = tonumber(af[3]) or 0
            local pid   = tonumber(af[4]) or 0
            local name  = af[5] or "?"
            local entry = {qty=qty, variantKey=vkey,
                product={id=pid, name=name, priceCopper=price}}
            if vkey ~= "" then entry.variant = {name=vkey, priceCopper=price} end
            tinsert(items, entry)
        end
    end
    return {
        id          = tonumber(f[1]) or 0,
        timestamp   = tonumber(f[2]) or 0,
        status      = f[3] or "open",
        holders     = f[4] or "",
        openedBy    = f[5] or "",
        paymentMode = f[6] or "end",
        deposit     = tonumber(f[7]) or 0,
        closedAt    = tonumber(f[8]) or 0,
        items       = items,
    }
end

-- ─── SEND ────────────────────────────────────────────────────────────────────

function NET:SendInvite(shopName, target, role)
    role = role or "employee"
    local displayName = ShortName(target)
    local function onFail()
        -- Remove from pending — they can't receive the invite
        SK.DB:RemovePendingInvite(shopName, target)
        RefreshManagerStaff()
        pcall(SendChatMessage,
            "You've been invited to "..shopName.." as "..role..
            ". It looks like you may not have the Storekeeper addon installed yet. "..
            "You can find it on CurseForge. Once you have it, ask to be invited again!",
            "WHISPER", nil, target
        )
        print("|cffFFD700[SK]|r |cffFF9900"..displayName..
              " could not be reached via the addon.|r "..
              "They have been removed from pending. Ask them to install Storekeeper and invite again.")
    end
    -- Add to pending before sending so the UI shows them immediately
    SK.DB:AddPendingInvite(shopName, target, role)
    SendDirectWithFail(target, onFail, "INVITE", shopName, role, PlayerName())
    print("|cffFFD700[SK]|r Invite sent to |cffFFD700"..displayName.."|r — waiting for them to accept.")
    RefreshManagerStaff()
    return true
end

-- Withdraw a pending invite — sent to a player who has the addon but hasn't accepted yet.
function NET:SendWithdrawInvite(shopName, target)
    SK.DB:RemovePendingInvite(shopName, target)
    local short = (target:match("^([^%-]+)") or target):lower()
    if Storekeeper.knownPeers[short] then
        SendDirect(target, "WITHDRAW", shopName)
    end
end

-- Kick a staff member (remove button on roster row).
function NET:SendKick(shopName, target)
    local short = (target:match("^([^%-]+)") or target):lower()
    if Storekeeper.knownPeers[short] then
        SendDirect(target, "KICK", shopName)
    end
end

-- Broadcast a new or updated order to all staff (except self)
function NET:BroadcastOrder(shopName, order)
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end
    local myShort = (UnitName("player") or ""):lower()
    local targets, seen = {}, {}
    local function addT(name)
        if not name or name=="" then return end
        local s=(name:match("^([^%-]+)") or name):lower()
        if s==myShort or seen[s] then return end
        seen[s]=true; tinsert(targets, name)
    end
    addT(shop.owner)
    for _,n in ipairs(shop.managers)  do addT(n) end
    for _,n in ipairs(shop.employees) do addT(n) end
    if #targets==0 then return end

    local data   = SerialiseOrder(order)
    local chunks = Chunkify(data)
    local sid    = tostring(order.id)
    local total  = tostring(#chunks)
    for _, target in ipairs(targets) do
        SendDirect(target, "ORDER_START", shopName, sid, total)
        for i, chunk in ipairs(chunks) do
            SendDirect(target, "ORDER_CHUNK", shopName, sid, tostring(i), chunk)
        end
        SendDirect(target, "ORDER_END", shopName, sid)
    end
end

-- Broadcast an order deletion to all staff (except self)
function NET:BroadcastOrderDelete(shopName, orderID)
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end
    local myShort = (UnitName("player") or ""):lower()
    local targets, seen = {}, {}
    local function addT(name)
        if not name or name=="" then return end
        local s=(name:match("^([^%-]+)") or name):lower()
        if s==myShort or seen[s] then return end
        seen[s]=true; tinsert(targets, name)
    end
    addT(shop.owner)
    for _,n in ipairs(shop.managers)  do addT(n) end
    for _,n in ipairs(shop.employees) do addT(n) end
    for _, target in ipairs(targets) do
        SendDirect(target, "ORDER_DEL", shopName, tostring(orderID))
    end
end

-- Broadcast a single tab (create/update) to all staff except self
function NET:BroadcastTab(shopName, tab)
    if not tab then return end
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end
    local myShort = (UnitName("player") or ""):lower()
    local targets, seen = {}, {}
    local function addT(name)
        if not name or name=="" then return end
        local s2=(name:match("^([^%-]+)") or name):lower()
        if s2==myShort or seen[s2] then return end
        seen[s2]=true; tinsert(targets, name)
    end
    addT(shop.owner)
    for _,n in ipairs(shop.managers)  do addT(n) end
    for _,n in ipairs(shop.employees) do addT(n) end
    if #targets==0 then return end
    local data   = SerialiseTab(tab)
    local chunks = Chunkify(data)
    local sid    = tostring(tab.id)
    local tSeq   = tostring(shop.tabSeq or 0)
    for _, target in ipairs(targets) do
        SendDirect(target, "TAB_START", shopName, sid, tostring(#chunks), tSeq)
        for i, chunk in ipairs(chunks) do
            SendDirect(target, "TAB_CHUNK", shopName, sid, tostring(i), chunk)
        end
        SendDirect(target, "TAB_END", shopName, sid)
    end
end

function NET:BroadcastTabDelete(shopName, tabID)
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end
    local myShort = (UnitName("player") or ""):lower()
    local targets, seen = {}, {}
    local function addT(name)
        if not name or name=="" then return end
        local s2=(name:match("^([^%-]+)") or name):lower()
        if s2==myShort or seen[s2] then return end
        seen[s2]=true; tinsert(targets, name)
    end
    addT(shop.owner)
    for _,n in ipairs(shop.managers)  do addT(n) end
    for _,n in ipairs(shop.employees) do addT(n) end
    for _, target in ipairs(targets) do
        SendDirect(target, "TAB_DEL", shopName, tostring(tabID))
    end
end

function NET:SyncProducts(shopName, target)
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end
    SK.DB:MigrateShop(shop)
    local data   = SerialiseAllProducts(shopName)
    local chunks = Chunkify(data)
    local seq    = tostring(shop.productSeq or 0)
    Send(target, "SYNC_START", shopName, tostring(#chunks), seq)
    for i, chunk in ipairs(chunks) do
        Send(target, "SYNC_CHUNK", shopName, tostring(i), chunk)
    end
    Send(target, "SYNC_END", shopName)
    print("|cffFFD700[SK]|r Synced "..#SK.DB:GetProducts(shopName).." products to "..ShortName(target)..".")
end

-- Broadcast a claim notification to all staff of a shop (except the claimer).
-- Receivers print a chat message identifying which shop and order was claimed.
function NET:BroadcastClaimNotice(shopName, orderID, claimerName, etaMins)
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end
    local myShort = (UnitName("player") or ""):lower()
    local targets, seen = {}, {}
    local function addT(name)
        if not name or name=="" then return end
        local s=(name:match("^([^%-]+)") or name):lower()
        if s==myShort or seen[s] then return end
        seen[s]=true; tinsert(targets, name)
    end
    addT(shop.owner)
    for _,n in ipairs(shop.managers)  do addT(n) end
    for _,n in ipairs(shop.employees) do addT(n) end
    if #targets==0 then return end
    local eta = etaMins and etaMins > 0 and tostring(etaMins) or "0"
    for _, target in ipairs(targets) do
        SendDirect(target, "CLAIM_NOTICE", shopName, tostring(orderID), claimerName, eta)
    end
end

-- Broadcast a single log entry to the owner and all managers (not employees).
-- Called from DB:AddLog so every action by any staff member is visible to managers.
function NET:BroadcastLog(shopName, entry)
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end
    local myShort = (UnitName("player") or ""):lower()

    -- Only send to owner and managers, not employees
    local targets, seen = {}, {}
    local function addT(name)
        if not name or name=="" then return end
        local s = (name:match("^([^%-]+)") or name):lower()
        if s == myShort or seen[s] then return end
        seen[s] = true; tinsert(targets, name)
    end
    addT(shop.owner)
    for _, n in ipairs(shop.managers) do addT(n) end

    if #targets == 0 then return end

    local msg = EscField(entry.timestamp)..SEP..EscField(entry.message)
    for _, target in ipairs(targets) do
        SendDirect(target, "LOG_ENTRY", shopName, msg)
    end
end

-- Broadcast full product list to everyone in the shop except ourselves.
-- Called after any product add/edit/delete by any staff member.
-- Includes the new productSeq so receivers can detect if they're already current.
function NET:BroadcastProducts(shopName)
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end
    SK.DB:MigrateShop(shop)
    local myShort = (UnitName("player") or ""):lower()

    local targets, seen = {}, {}
    local function addTarget(name)
        if not name or name == "" then return end
        local short = (name:match("^([^%-]+)") or name):lower()
        if short == myShort or seen[short] or IsKnownOffline(name) then return end
        seen[short] = true
        tinsert(targets, name)
    end
    addTarget(shop.owner)
    for _, n in ipairs(shop.managers)  do addTarget(n) end
    for _, n in ipairs(shop.employees) do addTarget(n) end
    if #targets == 0 then return end

    local data   = SerialiseAllProducts(shopName)
    local chunks = Chunkify(data)
    local total  = tostring(#chunks)
    local seq    = tostring(shop.productSeq or 0)

    for _, target in ipairs(targets) do
        Send(target, "SYNC_START", shopName, total, seq)
        for i, chunk in ipairs(chunks) do
            Send(target, "SYNC_CHUNK", shopName, tostring(i), chunk)
        end
        Send(target, "SYNC_END", shopName)
    end
    -- Products can introduce new categories or reordering; push the authoritative
    -- category colors + order too, staggered behind the product stream so it
    -- arrives after the products have been processed.
    C_Timer.After(0.5, function() NET:BroadcastCategoryColors(shopName) end)
end

-- Push updated category colors + order to all staff (called after color/order change)
function NET:BroadcastCategoryColors(shopName)
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end
    SK.DB:MigrateShop(shop)
    local colorParts = {}
    for cat, col in pairs(shop.categoryColors or {}) do
        if col and #col >= 3 then
            tinsert(colorParts, EscField(cat).."="..
                string.format("%.3f:%.3f:%.3f", col[1], col[2], col[3]))
        end
    end
    local colorsStr = table.concat(colorParts, "|")
    local orderStr  = table.concat(shop.categoryOrder or {}, ",")
    local payload   = colorsStr .. "\n" .. orderStr
    local myShort   = (UnitName("player") or ""):lower()
    local targets, seen = {}, {}
    local function addT(n)
        if not n or n=="" then return end
        local s=(n:match("^([^%-]+)") or n):lower()
        if s==myShort or seen[s] or IsKnownOffline(n) then return end
        seen[s]=true; tinsert(targets,n)
    end
    for _, n in ipairs(shop.managers)  do addT(n) end
    for _, n in ipairs(shop.employees) do addT(n) end
    for _, target in ipairs(targets) do
        SendDirect(target, "CAT_COLORS", shopName, payload)
    end
end

-- Send category colors and order to a single target (used by SYNC_PING response).
function NET:SendCategoryColorsTo(shopName, target)
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end
    SK.DB:MigrateShop(shop)
    local colorParts = {}
    for cat, col in pairs(shop.categoryColors or {}) do
        if col and #col >= 3 then
            tinsert(colorParts, EscField(cat).."="..
                string.format("%.3f:%.3f:%.3f", col[1], col[2], col[3]))
        end
    end
    local colorsStr = table.concat(colorParts, "|")
    local orderStr  = table.concat(shop.categoryOrder or {}, ",")
    local payload   = colorsStr .. "\n" .. orderStr
    SendDirect(target, "CAT_COLORS", shopName, payload)
end

-- ─── Passive Ping ─────────────────────────────────────────────────────────────
-- On login/reload, staff ping the owner with their current sequence numbers.
-- The owner responds only with what has changed since those sequence numbers.

function NET:PingOwner()
    if not SK.db then return end
    for shopName, shop in pairs(SK.db.shops or {}) do
        SK.DB:MigrateShop(shop)
        local role = SK.DB:GetRole(shopName)
        -- Only non-owners ping — owners are the source of truth
        if role and role ~= "owner" then
            local pSeq = tostring(shop.productSeq or 0)
            local oSeq = tostring(shop.orderSeq   or 0)
            local tSeq = tostring(shop.tabSeq     or 0)
            SendDirect(shop.owner, "SYNC_PING", shopName, PlayerName(), pSeq, oSeq, tSeq)
        end
    end
end

function NET:Leave(shopName)
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end
    -- Only allow leave if this character is actually staff on this shop
    local myName = PlayerName()
    local role   = SK.DB:GetRole(shopName)
    if not role or role == "owner" then
        print("|cffFFD700[SK]|r You cannot leave a shop you own. Delete it from the Shops tab instead.")
        return
    end
    SendDirect(shop.owner, "LEAVE", shopName, myName)
    SK.DB:DeleteShop(shopName)
    if SK.db.activeShop == shopName then SK.db.activeShop = next(SK.db.shops) end
    print("|cffFFD700[SK]|r You left |cffFFD700"..shopName.."|r.")
    RefreshManagerStaff()
    if SK.Manager and SK.Manager.M and SK.Manager.M.BuildShopsTab then
        SK.Manager.M:BuildShopsTab()
    end
end

-- ─── RECEIVE ─────────────────────────────────────────────────────────────────

local function OnAddonMsg(_, event, prefix, message, _, sender)
    if prefix ~= PREFIX then return end
    -- Ignore messages from ourselves (we receive our own PARTY/RAID broadcasts)
    local myName = UnitName("player")
    local senderShort = (sender or ""):match("^([^%-]+)") or (sender or "")
    if myName and senderShort:lower() == myName:lower() then return end
    -- Addressed group message (@TO \031 recipientShort \031 realMessage): used to
    -- deliver "direct" messages over the group channel for same-account targets
    -- who can't be whispered. Drop it if it isn't addressed to us; otherwise
    -- strip the tag and process the real message normally.
    if message:sub(1, 3) == "@TO" then
        local toName, rest = message:match("^@TO\031([^\031]*)\031(.*)$")
        if not toName then return end
        if toName ~= (myName or ""):lower() then return end  -- not for us
        message = rest
    end
    -- Register this sender as a confirmed Storekeeper user for tooltip display
    if senderShort ~= "" and Storekeeper.knownPeers then
        -- Store version if included in message (f[2] may be version for some commands)
        -- Version is stored when we process HELLO; for other commands just mark as known
        if type(Storekeeper.knownPeers[senderShort:lower()]) ~= "string" then
            Storekeeper.knownPeers[senderShort:lower()] = true
        end
    end
    -- For SYNC_CHUNK, ORDER_CHUNK and LOGS_CHUNK we limit splits so data field is preserved whole
    local isSyncChunk  = message:sub(1, 10) == "SYNC_CHUNK"
    local isOrderChunk = message:sub(1, 11) == "ORDER_CHUNK"
    local isLogsChunk  = message:sub(1, 10) == "LOGS_CHUNK"
    local isLogEntry   = message:sub(1, 9)  == "LOG_ENTRY"
    local f = (isSyncChunk  and Split(message, 4))
           or (isOrderChunk and Split(message, 5))
           or (isLogsChunk  and Split(message, 4))
           or (isLogEntry   and Split(message, 3))
           or Split(message)
    local cmd = f[1]
    if not cmd then return end

    -- ── HELLO ── presence broadcast so peers discover each other for tooltip
    if cmd == "HELLO" then
        -- f[3] may contain sender's version
        local peerVersion = f[3] or "?"
        Storekeeper.knownPeers[senderShort:lower()] = peerVersion
        -- Notify tooltip system so it can refresh if this player is currently shown
        if SK.TRP3 and SK.TRP3.OnPeerDiscovered then
            SK.TRP3.OnPeerDiscovered(senderShort, peerVersion)
        end
        -- Use full sender (Name-Realm) for the whisper so cross-realm delivery works
        local whisperTarget = sender or senderShort
        C_Timer.After(0.5, function()
            RawSend("WHISPER", whisperTarget, "HELLO"..SEP..PlayerName()..SEP..(SK.VERSION or "?"))
        end)
        -- Version notification: if the peer is on a newer version than us,
        -- print a single local chat message once per session.
        if NOTIFY_NEW_VERSION and peerVersion ~= "?" and SK.VERSION then
            local function ParseVer(v)
                local a,b,d,e = v:match("^(%d+)%.(%d+)%.(%d+)%.?(%d*)$")
                if a then
                    return tonumber(a)*1000000+tonumber(b)*10000+tonumber(d)*100+(tonumber(e) or 0)
                end
                return 0
            end
            local myV   = ParseVer(SK.VERSION)
            local peerV = ParseVer(peerVersion)
            if peerV > myV and not NET._newerNoticed then
                NET._newerNoticed = true
                C_Timer.After(1, function()
                    print("|cffFFD700Storekeeper v"..peerVersion..
                          " |ris now available! Download at: |cff00CCFF"..
                          "https://www.curseforge.com/wow/addons/storekeeper-wow-pos|r")
                end)
            end
        end
        return

    -- ── INVITE ── received by the invited player
    elseif cmd == "INVITE" then
        local shopName, role, fromPlayer = f[2], f[3], f[4]
        if not shopName or not role then return end
        -- Ignore if this came from ourselves (same-account alt sending to alt)
        local myShort = (UnitName("player") or ""):lower()
        local fromShort = (ShortName(fromPlayer or sender)):lower()
        if fromShort == myShort then return end
        pendingInvite = {shopName=shopName, role=role, from=fromPlayer or sender}
        NET:ShowInvitePopup(shopName, role, fromPlayer or sender)

    -- ── ACCEPT ── received by the shop owner
    elseif cmd == "ACCEPT" then
        local shopName, who, role = f[2], f[3] or sender, f[4] or "employee"
        if not shopName then return end
        -- Ignore if this is our own character accepting their own invite (same-account)
        local myShort = (UnitName("player") or ""):lower()
        if (ShortName(who)):lower() == myShort then return end
        -- Remove from pending first
        SK.DB:RemovePendingInvite(shopName, who)
        -- Add to appropriate list
        if role == "manager" then
            SK.DB:AddManager(shopName, who)
        else
            SK.DB:AddEmployee(shopName, who)
        end
        if SK:Cfg().notifyStaffJoined ~= false then print("|cffFFD700[SK]|r "..ShortName(who).." joined |cffFFD700"..shopName.."|r as "..role..".") end
        RefreshManagerStaff()
        -- Refresh staff tab if open
        if SK.Register and SK.Register.SwitchToTab and SK.Register.isOpen and SK.Register.activeTab=="people" then
            SK.Register.SwitchToTab("people")
        end
        -- Push full roster + products back to the new member
        NET:SyncShop(shopName, who)

    -- ── DECLINE ── received by the shop owner
    elseif cmd == "DECLINE" then
        local shopName, who = f[2], f[3] or sender
        print("|cffFFD700[SK]|r "..ShortName(who).." declined the invite to |cffFFD700"..(shopName or "").."|r.")

    -- ── SHOP_DELETE ── owner deleted a shop; all staff remove it locally
    elseif cmd == "SHOP_DELETE" then
        local shopName = f[2]
        if not shopName then return end
        local s = SK.DB:GetShop(shopName)
        if s then
            -- Never delete a shop we own (guards against same-account loopback)
            local myOOC = (UnitName("player") or ""):lower()
            local myRP  = (SK:GetRPName() or ""):lower()
            local oL, oRPL = (s.owner or ""):lower(), (s.ownerRP or ""):lower()
            if (myOOC ~= "" and (myOOC == oL or myOOC == oRPL))
            or (myRP  ~= "" and (myRP  == oL or myRP  == oRPL)) then
                return
            end
            SK.DB:DeleteShop(shopName)
            print("|cffFFD700[SK]|r Shop |cffFFD700"..shopName.."|r has been deleted by its owner.")
            if SK.Register then
                if SK.Register.RefreshShopLabel then SK.Register:RefreshShopLabel() end
                if SK.Register.SwitchToTab and SK.Register.isOpen then
                    SK.Register.SwitchToTab(SK.Register.activeTab or "register")
                end
            end
        end

    -- ── WITHDRAW ── invite cancelled by owner before the invited player accepted
    elseif cmd == "WITHDRAW" then
        local shopName = f[2]
        if not shopName then return end
        -- If we have a pending invite for this shop, dismiss it
        if pendingInvite and pendingInvite.shopName == shopName then
            pendingInvite = nil
            StaticPopup_Hide("SK_INVITE")
            print("|cffFFD700[SK]|r The invitation to |cffFFD700"..shopName.."|r was withdrawn.")
        end

    -- ── KICK ── received by the kicked player
    elseif cmd == "KICK" then
        local shopName = f[2]
        if not shopName then return end
        local s = SK.DB:GetShop(shopName)
        -- Never delete a shop we own (guards against same-account loopback)
        if s then
            local myOOC = (UnitName("player") or ""):lower()
            local myRP  = (SK:GetRPName() or ""):lower()
            local oL, oRPL = (s.owner or ""):lower(), (s.ownerRP or ""):lower()
            if (myOOC ~= "" and (myOOC == oL or myOOC == oRPL))
            or (myRP  ~= "" and (myRP  == oL or myRP  == oRPL)) then
                return
            end
        end
        -- Remove the shop locally
        SK.DB:DeleteShop(shopName)
        print("|cffFFD700[SK]|r You were removed from |cffFFD700"..shopName.."|r.")
        -- Refresh UI
        if SK.Register then
            if SK.Register.RefreshShopLabel then SK.Register:RefreshShopLabel() end
            if SK.Register.SwitchToTab and SK.Register.isOpen then
                SK.Register.SwitchToTab(SK.Register.activeTab or "register")
            end
        end

    -- ── SYNC_START ──
    elseif cmd == "SYNC_START" then
        local shopName, total, seq = f[2], tonumber(f[3]) or 0, tonumber(f[4]) or 0
        if shopName then
            -- Each sync gets a unique token so a late SYNC_END from a stale sequence
            -- doesn't process the wrong buffer.
            local token = tostring(seq) .. "_" .. tostring(time())
            syncBuffer[shopName] = {total=total, chunks={}, received=0, seq=seq, token=token}
        end

    -- ── SYNC_CHUNK ──
    elseif cmd == "SYNC_CHUNK" then
        local shopName, idx, chunk = f[2], tonumber(f[3]), f[4] or ""
        local buf = syncBuffer[shopName]
        if buf and idx and not buf.chunks[idx] then
            -- Only store each chunk index once — ignore duplicates
            buf.chunks[idx] = chunk
            buf.received = buf.received + 1
        end

    -- ── SYNC_END ──
    elseif cmd == "SYNC_END" then
        local shopName = f[2]
        local buf = syncBuffer[shopName]
        if not buf then return end  -- no buffer — stale END, ignore silently

        -- Integrity check: all expected chunks must have arrived.
        -- If any are missing, wait for them rather than processing corrupt data.
        if buf.received < buf.total then
            -- Not all chunks arrived yet. Leave the buffer in place; it will be
            -- cleaned up if a new SYNC_START arrives for this shop.
            return
        end

        syncBuffer[shopName] = nil

        local data = table.concat(buf.chunks, "")
        local shop = SK.DB:GetShop(shopName)
        if not shop then
            -- Shop not created yet (SYNC_END arrived before SHOP_INFO) — create a stub
            SK.DB:CreateShop(shopName, "")
            shop = SK.DB:GetShop(shopName)
            if not shop then
                return
            end
        end

        -- Clear and repopulate products
        shop.products = {}
        local count = 0

        if data ~= "" then
            -- Split on RECSEP using plain find
            local pos = 1
            local dlen = #data
            while pos <= dlen do
                local i = data:find(RECSEP, pos, true)
                local prodStr = i and data:sub(pos, i - 1) or data:sub(pos)
                if prodStr ~= "" then
                    local p = DeserialiseProduct(prodStr)
                    if p.name and p.name ~= "" then
                        SK.DB:AddProductFromTable(shopName, p)
                        count = count + 1
                    end
                end
                if not i then break end
                pos = i + #RECSEP
            end
        end

        if SK:Cfg().notifySync then print("|cffFFD700[SK]|r Received "..count.." products for |cffFFD700"..shopName.."|r.") end
        -- Update local sequence number to match owner's
        if buf.seq and buf.seq > 0 then
            shop.productSeq = buf.seq
        end
        RefreshManagerProducts()
        -- Refresh register product grid if it's already built
        if SK.Register and SK.Register.BuildProductGrid then
            SK.Register:BuildProductGrid()
        end
        -- Request category colors from owner so register headers show correct colors
        local sOwner = shop and shop.owner
        if sOwner and sOwner ~= (UnitName("player") or "") then
            C_Timer.After(0.3, function()
                SendDirect(sOwner, "CAT_COLORS_REQUEST", shopName)
            end)
        end

    -- ── SHOP_INFO ── sent by owner after ACCEPT to give new member the full roster
    elseif cmd == "SHOP_INFO" then
        local shopName, ownerName, role, managersStr, employeesStr, colorsStr, ownerRP = f[2], f[3], f[4], f[5] or "", f[6] or "", f[7] or "", f[8] or ""
        local trackProdStr = f[9]  -- "1"/"0"; nil from older peers (leave setting unchanged)
        if not shopName then return end

        -- Guard: if WE are the owner of this shop, a SHOP_INFO is not for us. This
        -- can happen via same-account loopback (our own alt/main echoing). Processing
        -- it would wipe our roster and could self-delete our shop. Ignore it.
        local existing = SK.DB:GetShop(shopName)
        if existing then
            local myOOC = (UnitName("player") or ""):lower()
            local myRP  = (SK:GetRPName() or ""):lower()
            local exOwner = (existing.owner or ""):lower()
            local exOwnerRP = (existing.ownerRP or ""):lower()
            if (myOOC ~= "" and (myOOC == exOwner or myOOC == exOwnerRP))
            or (myRP  ~= "" and (myRP  == exOwner or myRP  == exOwnerRP)) then
                return
            end
        end

        local isNewShop = (SK.DB:GetShop(shopName) == nil)
        local shop = SK.DB:GetShop(shopName)
        if not shop then
            SK.DB:CreateShop(shopName, ownerName)
            shop = SK.DB:GetShop(shopName)
        end
        if shop then
            shop.owner = ownerName or shop.owner
            if ownerRP and ownerRP ~= "" then shop.ownerRP = ownerRP end
            -- Only honour the toggle if the sender actually included it; older
            -- peers omit field 9 and must not silently reset the local setting.
            if trackProdStr ~= nil and trackProdStr ~= "" then
                shop.trackProductionCost = (trackProdStr == "1")
            end
            shop.managers  = {}
            shop.employees = {}
            if managersStr ~= "" then
                for name in (managersStr..","):gmatch("([^,]+),") do
                    tinsert(shop.managers, name)
                end
            end
            if employeesStr ~= "" then
                for name in (employeesStr..","):gmatch("([^,]+),") do
                    tinsert(shop.employees, name)
                end
            end
            -- Parse category colors
            SK.DB:MigrateShop(shop)
            if colorsStr ~= "" then
                for entry in (colorsStr.."|"):gmatch("([^|]+)|") do
                    local cat, rgb = entry:match("^(.-)=(.+)$")
                    if cat and rgb then
                        local r,g,b = rgb:match("^(.-):(.-):(.-+)$")
                        if r then
                            shop.categoryColors[cat] = {tonumber(r) or 1, tonumber(g) or 0.82, tonumber(b) or 0}
                        end
                    end
                end
            end
        end
        -- Self-validate: if we are not on the roster the owner just sent, we may
        -- have been removed while offline. BUT we must be extremely careful here:
        -- deleting a shop is destructive, and a transient failure (e.g. TRP3 not
        -- loaded yet so our RP name resolves empty, or a same-account loopback of
        -- our own SHOP_INFO) must NEVER cause us to delete a shop we actually own
        -- or are still on. We only delete when we are confident we were removed.
        local myOOC = (UnitName("player") or ""):lower()
        local myRP  = (SK:GetRPName() or ""):lower()
        local ownerL = (shop.owner or ""):lower()
        local ownerRPL = (shop.ownerRP or ""):lower()
        -- Are we the owner (by either name)? If so, never self-delete.
        local iAmOwner = (myOOC ~= "" and myOOC == ownerL)
                      or (myRP  ~= "" and myRP  == ownerL)
                      or (myRP  ~= "" and myRP  == ownerRPL)
                      or (myOOC ~= "" and myOOC == ownerRPL)
        local myRole = SK.DB:GetRole(shopName)
        if not myRole and not iAmOwner then
            -- Extra guard: only delete if our OOC name is genuinely absent from the
            -- roster the owner sent. If TRP3 wasn't ready our RP name may be blank,
            -- but our OOC name check is reliable.
            local onRosterByOOC = false
            if myOOC ~= "" then
                if myOOC == ownerL then onRosterByOOC = true end
                for _, m in ipairs(shop.managers or {})  do if (m or ""):lower() == myOOC then onRosterByOOC = true end end
                for _, e in ipairs(shop.employees or {}) do if (e or ""):lower() == myOOC then onRosterByOOC = true end end
            end
            if not onRosterByOOC then
                SK.DB:DeleteShop(shopName)
                if SK.db and SK.db.activeShop == shopName then
                    SK.db.activeShop = next(SK.db.shops or {})
                end
                print("|cffFFD700[SK]|r You are no longer a member of |cffFFD700"..shopName..
                      "|r and it has been removed from your addon.")
                if SK.Register then
                    if SK.Register.RefreshShopLabel then SK.Register:RefreshShopLabel() end
                    if SK.Register.SwitchToTab and SK.Register.isOpen then
                        SK.Register.SwitchToTab(SK.Register.activeTab or "register")
                    end
                end
                return
            end
        end
        SK.db.activeShop = shopName
        RefreshManagerStaff()
        -- Refresh the Register UI so the new shop appears immediately
        if SK.Register then
            if SK.Register.RefreshShopLabel then SK.Register:RefreshShopLabel() end
            if SK.Register.BuildProductGrid then SK.Register:BuildProductGrid() end
            if SK.Register.SwitchToTab and SK.Register.isOpen then
                SK.Register.SwitchToTab("register")
            end
        end
        -- Only announce "joined" when the shop is genuinely new — not on roster updates
        if isNewShop then
            print("|cffFFD700[SK]|r Joined shop |cffFFD700"..shopName.."|r. Use the Shops tab to switch between shops.")
        end
        -- Refresh logs tab if open
        if SK.Manager and SK.Manager.M and SK.Manager.M.activeTab == "logs" then
            SK.Manager.M:BuildLogsTab()
        end

    -- ── ORDER_START ──
    elseif cmd == "ORDER_START" then
        local shopName, orderID, total, seq = f[2], f[3], tonumber(f[4]) or 0, tonumber(f[5]) or 0
        if shopName and orderID then
            syncBuffer["order_"..shopName.."_"..orderID] = {total=total, chunks={}, received=0, seq=seq}
        end

    -- ── ORDER_CHUNK ──
    elseif cmd == "ORDER_CHUNK" then
        local shopName, orderID, idx, chunk = f[2], f[3], tonumber(f[4]), f[5] or ""
        local key = "order_"..(shopName or "").."_"..(orderID or "")
        local buf = syncBuffer[key]
        if buf and idx and not buf.chunks[idx] then
            buf.chunks[idx] = chunk
            buf.received = buf.received + 1
        end

    -- ── ORDER_END ──
    elseif cmd == "ORDER_END" then
        local shopName, orderID = f[2], f[3]
        local key = "order_"..(shopName or "").."_"..(orderID or "")
        local buf = syncBuffer[key]
        if not buf then return end
        if buf.received < buf.total then return end  -- incomplete — wait
        local incomingOSeq = buf.seq  -- read before clearing
        syncBuffer[key] = nil
        local data = table.concat(buf.chunks, "")
        local shop = SK.DB:GetShop(shopName)
        if not shop then return end
        local order = DeserialiseOrder(data)
        -- Remove existing order with this ID if present, then insert
        SK.DB:MigrateShop(shop)
        for i, o in ipairs(shop.orders) do
            if o.id == order.id then tremove(shop.orders, i); break end
        end
        tinsert(shop.orders, order)
        -- Sort by ID so order is consistent
        table.sort(shop.orders, function(a,b) return (a.id or 0) < (b.id or 0) end)
        -- Update local orderSeq if the incoming order has a higher ID than we had
        if incomingOSeq and incomingOSeq > (shop.orderSeq or 0) then
            shop.orderSeq = incomingOSeq
        end
        -- Refresh orders tab — suppress auto-sync to avoid loop
        NET.suppressAutoSync = true
        if SK.Manager and SK.Manager.M and SK.Manager.M.BuildOrdersTab then
            SK.Manager.M:BuildOrdersTab()
        end
        NET.suppressAutoSync = false

    -- ── ORDER_DEL ──
    elseif cmd == "ORDER_DEL" then
        local shopName, orderID = f[2], tonumber(f[3])
        local shop = SK.DB:GetShop(shopName)
        if not shop or not orderID then return end
        SK.DB:MigrateShop(shop)
        for i, o in ipairs(shop.orders) do
            if o.id == orderID then tremove(shop.orders, i); break end
        end
        if SK.Manager and SK.Manager.M and SK.Manager.M.BuildOrdersTab then
            SK.Manager.M:BuildOrdersTab()
        end

    -- ── TAB_START ──
    elseif cmd == "TAB_START" then
        local shopName, tabID, total, seq = f[2], f[3], tonumber(f[4]) or 0, tonumber(f[5]) or 0
        if shopName and tabID then
            syncBuffer["tab_"..shopName.."_"..tabID] = {total=total, chunks={}, received=0, seq=seq}
        end

    -- ── TAB_CHUNK ──
    elseif cmd == "TAB_CHUNK" then
        local shopName, tabID, idx, chunk = f[2], f[3], tonumber(f[4]), f[5] or ""
        local key = "tab_"..(shopName or "").."_"..(tabID or "")
        local buf = syncBuffer[key]
        if buf and idx and not buf.chunks[idx] then
            buf.chunks[idx] = chunk
            buf.received = buf.received + 1
        end

    -- ── TAB_END ──
    elseif cmd == "TAB_END" then
        local shopName, tabID = f[2], f[3]
        local key = "tab_"..(shopName or "").."_"..(tabID or "")
        local buf = syncBuffer[key]
        if not buf then return end
        if buf.received < buf.total then return end  -- incomplete — wait
        local incomingTSeq = buf.seq
        syncBuffer[key] = nil
        local data = table.concat(buf.chunks, "")
        local shop = SK.DB:GetShop(shopName)
        if not shop then return end
        SK.DB:MigrateShop(shop)
        local tab = DeserialiseTab(data)
        for i, t in ipairs(shop.tabs) do
            if t.id == tab.id then tremove(shop.tabs, i); break end
        end
        tinsert(shop.tabs, tab)
        table.sort(shop.tabs, function(a,b) return (a.id or 0) < (b.id or 0) end)
        if incomingTSeq and incomingTSeq > (shop.tabSeq or 0) then
            shop.tabSeq = incomingTSeq
        end
        NET:RefreshTabsView()

    -- ── TAB_DEL ──
    elseif cmd == "TAB_DEL" then
        local shopName, tabID = f[2], tonumber(f[3])
        local shop = SK.DB:GetShop(shopName)
        if not shop or not tabID then return end
        SK.DB:MigrateShop(shop)
        for i, t in ipairs(shop.tabs) do
            if t.id == tabID then tremove(shop.tabs, i); break end
        end
        NET:RefreshTabsView()

    -- ── SYNC_REQUEST_TABS ── staff asks for tabs
    elseif cmd == "SYNC_REQUEST_TABS" then
        local shopName, who = f[2], f[3] or sender
        if not shopName then return end
        if SK.DB:IsManager(shopName) then
            NET:SyncTabs(shopName, who)
        end

    -- ── SYNC_PING ── staff logged in, sending their current seq numbers
    -- Owner responds with products/orders only if seq numbers differ.
    -- If the sender is no longer on the roster, send a KICK instead.
    elseif cmd == "SYNC_PING" then
        local shopName, who, theirPSeq, theirOSeq, theirTSeq = f[2], f[3] or sender, tonumber(f[4]) or 0, tonumber(f[5]) or 0, tonumber(f[6]) or 0
        if not shopName then return end
        if not SK.DB:IsManager(shopName) then return end
        local shop = SK.DB:GetShop(shopName)
        if not shop then return end
        SK.DB:MigrateShop(shop)
        -- If the pinging player is no longer on the roster, kick them
        local whoRole = SK.DB:GetRole(shopName, who)
        if not whoRole then
            SendDirect(who, "KICK", shopName)
            return
        end
        local myPSeq = shop.productSeq or 0
        local myOSeq = shop.orderSeq   or 0
        local myTSeq = shop.tabSeq     or 0
        -- Only push what's actually out of date
        if theirPSeq < myPSeq then
            NET:SyncProducts(shopName, who)
        end
        if theirOSeq < myOSeq then
            NET:SyncOrders(shopName, who)
        end
        if theirTSeq < myTSeq then
            C_Timer.After(0.6, function() NET:SyncTabs(shopName, who) end)
        end
        -- Always push category colors and roster so new peers stay in sync,
        -- even when product/order sequences are already up to date.
        C_Timer.After(0.4, function() NET:SendCategoryColorsTo(shopName, who) end)
        SendDirect(who, "SYNC_PONG", shopName)

    -- ── SYNC_PONG ── owner confirms we are already up to date
    elseif cmd == "SYNC_PONG" then
        -- Silent — we are current, nothing to do

    -- ── SYNC_REQUEST __ staff member asks owner to push everything
    elseif cmd == "SYNC_REQUEST" then
        local shopName, who = f[2], f[3] or sender
        if not shopName then return end
        -- Only respond if we are the owner or a manager of this shop
        if SK.DB:IsManager(shopName) then
            print("|cffFFD700[SK]|r "..ShortName(who).." requested a sync for |cffFFD700"..shopName.."|r.")
            -- Products first — this enqueues the bulk of the messages
            NET:SyncShop(shopName, who)
            -- Estimate how long the product sync will take: (chunks+2) messages * 0.1s each
            local shop = SK.DB:GetShop(shopName)
            local productDelay = 0.5  -- safe minimum
            if shop then
                local data = ""
                for _, p in ipairs(SK.DB:GetProducts(shopName) or {}) do
                    data = data .. "x"  -- rough byte estimate: just count products
                end
                -- Rough: serialised data ~80 bytes/product, chunks = ceil(len/200)
                local estChunks = math.ceil(math.max(1, #SK.DB:GetProducts(shopName)) * 80 / 200)
                productDelay = (estChunks + 2) * 0.1 + 0.3  -- queue drain time + margin
            end
            -- Send orders and colors after products have had time to arrive
            C_Timer.After(productDelay, function()
                NET:SyncOrders(shopName, who)
            end)
            C_Timer.After(productDelay + 0.4, function()
                NET:SyncTabs(shopName, who)
            end)
            C_Timer.After(productDelay + 0.8, function()
                NET:SendCategoryColorsTo(shopName, who)
            end)
        end

    -- ── SYNC_REQUEST_ORDERS ── staff asks for orders only (lighter request)
    elseif cmd == "SYNC_REQUEST_ORDERS" then
        local shopName, who = f[2], f[3] or sender
        if not shopName then return end
        if SK.DB:IsManager(shopName) then
            NET:SyncOrders(shopName, who)
        end

    -- ── SYNC_REQUEST_LOGS ── staff asks for logs
    elseif cmd == "SYNC_REQUEST_LOGS" then
        local shopName, who = f[2], f[3] or sender
        if not shopName then return end
        if SK.DB:IsManager(shopName) then
            NET:SyncLogs(shopName, who)
        end

    -- ── LOGS_START ──
    elseif cmd == "LOGS_START" then
        local shopName, total = f[2], tonumber(f[3]) or 0
        if shopName then
            syncBuffer["logs_"..shopName] = {total=total, chunks={}, received=0}
        end

    -- ── LOGS_CHUNK ──
    elseif cmd == "LOGS_CHUNK" then
        local shopName, idx, chunk = f[2], tonumber(f[3]), f[4] or ""
        local buf = syncBuffer["logs_"..(shopName or "")]
        if buf and idx and not buf.chunks[idx] then
            buf.chunks[idx] = chunk
            buf.received = buf.received + 1
        end

    -- ── LOGS_END ──
    elseif cmd == "LOGS_END" then
        local shopName = f[2]
        local buf = syncBuffer["logs_"..(shopName or "")]
        if not buf then return end
        if buf.received < buf.total then return end  -- incomplete — wait
        syncBuffer["logs_"..shopName] = nil
        local data = table.concat(buf.chunks, "")
        local shop = SK.DB:GetShop(shopName)
        if not shop then return end
        SK.DB:MigrateShop(shop)
        shop.logs = {}
        if data ~= "" then
            local pos = 1
            while pos <= #data do
                local i = data:find(RECSEP, pos, true)
                local entry = i and data:sub(pos, i-1) or data:sub(pos)
                if entry ~= "" then
                    local ts, msg = entry:match("^(%d+):(.*)$")
                    if ts then
                        tinsert(shop.logs, {timestamp=tonumber(ts), message=msg or ""})
                    end
                end
                if not i then break end
                pos = i + #RECSEP
            end
        end
        -- Refresh logs tab if open
        NET.suppressAutoSync = true
        if SK.Manager and SK.Manager.M and SK.Manager.M.activeTab == "logs" then
            SK.Manager.M:BuildLogsTab()
        end
        NET.suppressAutoSync = false

    -- ── CLAIM_NOTICE ── a staff member claimed an order; notify everyone else
    elseif cmd == "CLAIM_NOTICE" then
        local shopName, orderID, claimerName, eta = f[2], f[3], f[4], tonumber(f[5]) or 0
        if not shopName or not orderID then return end
        if not SK.DB:GetShop(shopName) then return end
        local cfg = SK:Cfg()
        if cfg.notifyOrderClaimed ~= false then
            local etaStr = eta > 0 and " |cff888888(Est. "..eta.." min)|r" or ""
            print("|cffFFD700[SK — "..shopName.."]|r Order #"..orderID..
                  " picked up by |cffFFD700"..ShortName(claimerName).."|r."..etaStr)
        end

    -- ── LOG_ENTRY ── a single log entry pushed by a staff member to managers/owner
    elseif cmd == "LOG_ENTRY" then
        local shopName, payload = f[2], f[3]
        if not shopName or not payload then return end
        local shop = SK.DB:GetShop(shopName)
        if not shop then return end
        -- Only managers and owner receive this (sender already filtered targets)
        local sep = payload:find(SEP, 1, true)
        local ts  = sep and tonumber(payload:sub(1, sep-1)) or time()
        local msg = sep and payload:sub(sep + #SEP) or payload
        -- Prepend sender name so manager knows who did what
        local senderName = ShortName(sender)
        msg = "|cffAAAAAA["..senderName.."]|r "..msg
        SK.DB:MigrateShop(shop)
        tinsert(shop.logs, {timestamp=ts, message=msg})
        while #shop.logs > 200 do tremove(shop.logs, 1) end
        -- Refresh logs tab if open, suppress auto-sync to avoid loop
        NET.suppressAutoSync = true
        if SK.Manager and SK.Manager.M and SK.Manager.M.activeTab == "logs" then
            SK.Manager.M:BuildLogsTab()
        end
        NET.suppressAutoSync = false

    -- ── CAT_COLORS_REQUEST ── staff asks owner to push category colors
    elseif cmd == "CAT_COLORS_REQUEST" then
        local shopName2 = f[2]
        if not shopName2 then return end
        if SK.DB:IsManager(shopName2, UnitName("player")) then
            NET:BroadcastCategoryColors(shopName2)
        end

    -- ── CAT_COLORS ── owner pushed updated category colors (and order) to staff
    elseif cmd == "CAT_COLORS" then
        local shopName, payload = f[2], f[3]
        if not shopName or not payload then return end
        local shop = SK.DB:GetShop(shopName)
        if not shop then return end
        SK.DB:MigrateShop(shop)
        -- Payload format: "colorsStr\norderStr"
        local colorsStr, orderStr = payload:match("^(.-)\n(.*)$")
        if not colorsStr then colorsStr = payload; orderStr = "" end
        -- Apply colors
        for entry in (colorsStr.."|"):gmatch("([^|]+)|") do
            local cat, rgb = entry:match("^(.-)=(.+)$")
            if cat and rgb then
                local r,g,b = rgb:match("^(.-):(.-):(.-+)$")
                if r then
                    shop.categoryColors[cat] = {tonumber(r) or 1, tonumber(g) or 0.82, tonumber(b) or 0}
                end
            end
        end
        -- Apply category order
        if orderStr and orderStr ~= "" then
            local ord = {}
            for name in (orderStr .. ","):gmatch("([^,]+),") do
                tinsert(ord, name)
            end
            if #ord > 0 then
                SK.DB:SetCategoryOrder(shopName, ord)
            end
        end
        -- Refresh register grid
        if SK.Register and SK.Register.BuildProductGrid then
            SK.Register:BuildProductGrid()
        end

    -- ── LEAVE ── received by the owner
    elseif cmd == "LEAVE" then
        local shopName, who = f[2], f[3] or sender
        if not shopName then return end
        SK.DB:RemoveEmployee(shopName, who)
        SK.DB:RemoveManager(shopName, who)
        print("|cffFFD700[SK]|r "..ShortName(who).." left |cffFFD700"..shopName.."|r.")
        RefreshManagerStaff()
    end
end

-- ─── SyncShop ─────────────────────────────────────────────────────────────────
-- Sends roster info first, then product data, to a newly accepted member

-- Send just the roster/colors/settings SHOP_INFO packet to one member (no products).
function NET:SendShopInfo(shopName, target)
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end
    SK.DB:MigrateShop(shop)

    -- Determine the role of this specific player
    local role = SK.DB:GetRole(shopName, target) or "employee"

    -- Build comma-separated roster strings
    local managersStr  = table.concat(shop.managers,  ",")
    local employeesStr = table.concat(shop.employees, ",")

    -- Serialise category colors: "catName=R:G:B|catName2=R:G:B"
    local colorParts = {}
    for cat, col in pairs(shop.categoryColors or {}) do
        if col and #col >= 3 then
            tinsert(colorParts, EscField(cat).."="..
                string.format("%.3f:%.3f:%.3f", col[1], col[2], col[3]))
        end
    end
    local colorsStr = table.concat(colorParts, "|")

    -- field 8 = ownerRP (display), field 9 = trackProductionCost toggle
    SendDirect(target, "SHOP_INFO", shopName, shop.owner, role, managersStr, employeesStr,
        colorsStr, shop.ownerRP or "", shop.trackProductionCost and "1" or "0")
end

function NET:SyncShop(shopName, target)
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end

    -- Send roster + colors + settings first, then products
    NET:SendShopInfo(shopName, target)
    NET:SyncProducts(shopName, target)
end

-- Push updated SHOP_INFO (roster/colors/settings only) to all staff. Used when
-- the owner changes a shop-wide setting such as the production-cost toggle.
function NET:BroadcastShopInfo(shopName)
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end
    for _, n in ipairs(shop.managers  or {}) do NET:SendShopInfo(shopName, n) end
    for _, n in ipairs(shop.employees or {}) do NET:SendShopInfo(shopName, n) end
end

-- ─── SyncOrders ───────────────────────────────────────────────────────────────
-- Push all current orders to a specific player

function NET:SyncOrders(shopName, target)
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end
    SK.DB:MigrateShop(shop)
    local orders = shop.orders or {}
    if #orders == 0 then return end
    local oSeq = tostring(shop.orderSeq or 0)
    for _, order in ipairs(orders) do
        local data   = SerialiseOrder(order)
        local chunks = Chunkify(data)
        local sid    = tostring(order.id)
        SendDirect(target, "ORDER_START", shopName, sid, tostring(#chunks), oSeq)
        for i, chunk in ipairs(chunks) do
            SendDirect(target, "ORDER_CHUNK", shopName, sid, tostring(i), chunk)
        end
        SendDirect(target, "ORDER_END", shopName, sid)
    end
    print("|cffFFD700[SK]|r Synced "..#orders.." orders to "..ShortName(target)..".")
end

-- ─── RequestSync ──────────────────────────────────────────────────────────────
-- Called by a staff member to ask the owner/manager to push everything

local lastSyncRequest = {}  -- shopName -> timestamp, throttle repeated requests

local function CanRequest(shopName)
    local now = time()
    local last = lastSyncRequest[shopName] or 0
    if now - last < 10 then return false end  -- 10 second cooldown
    lastSyncRequest[shopName] = now
    return true
end

function NET:RequestSync(shopName)
    shopName = shopName or (SK.db and SK.db.activeShop)
    if not shopName then
        print("|cffFFD700[SK]|r No active shop. Set one in the Manager first.")
        return
    end
    if not CanRequest(shopName) then
        print("|cffFFD700[SK]|r Sync already requested recently. Please wait a moment.")
        return
    end
    local shop = SK.DB:GetShop(shopName)
    if not shop then
        print("|cffFFD700[SK]|r Shop not found locally.")
        return
    end
    SendDirect(shop.owner, "SYNC_REQUEST", shopName, PlayerName())
    print("|cffFFD700[SK]|r Sync requested from "..ShortName(shop.owner)..".")
end

function NET:RequestOrderSync(shopName)
    shopName = shopName or (SK.db and SK.db.activeShop)
    if not shopName then return end
    if not CanRequest(shopName.."_orders") then return end  -- throttle
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end
    SendDirect(shop.owner, "SYNC_REQUEST_ORDERS", shopName, PlayerName())
end

function NET:RequestLogSync(shopName)
    shopName = shopName or (SK.db and SK.db.activeShop)
    if not shopName then return end
    if not CanRequest(shopName.."_logs") then return end  -- throttle
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end
    SendDirect(shop.owner, "SYNC_REQUEST_LOGS", shopName, PlayerName())
end

-- ─── SyncLogs ─────────────────────────────────────────────────────────────────

function NET:SyncLogs(shopName, target)
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end
    SK.DB:MigrateShop(shop)
    local logs = shop.logs or {}
    if #logs == 0 then
        -- Send empty log frame so receiver clears its buffer correctly
        Send(target, "LOGS_START", shopName, "0")
        Send(target, "LOGS_END", shopName)
        return
    end
    -- Serialise logs as: timestamp:message joined by RECSEP
    local parts = {}
    for _, log in ipairs(logs) do
        local msg = EscField(log.message or "")
        tinsert(parts, EscField(log.timestamp)..":"..msg)
    end
    local data   = table.concat(parts, RECSEP)
    local chunks = Chunkify(data)
    Send(target, "LOGS_START", shopName, tostring(#chunks))
    for i, chunk in ipairs(chunks) do
        Send(target, "LOGS_CHUNK", shopName, tostring(i), chunk)
    end
    Send(target, "LOGS_END", shopName)
end

-- ─── SyncTabs ─────────────────────────────────────────────────────────────────
-- Push all current tabs to a specific player

function NET:SyncTabs(shopName, target)
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end
    SK.DB:MigrateShop(shop)
    local tabs = shop.tabs or {}
    if #tabs == 0 then return end
    local tSeq = tostring(shop.tabSeq or 0)
    for _, tab in ipairs(tabs) do
        local data   = SerialiseTab(tab)
        local chunks = Chunkify(data)
        local sid    = tostring(tab.id)
        SendDirect(target, "TAB_START", shopName, sid, tostring(#chunks), tSeq)
        for i, chunk in ipairs(chunks) do
            SendDirect(target, "TAB_CHUNK", shopName, sid, tostring(i), chunk)
        end
        SendDirect(target, "TAB_END", shopName, sid)
    end
    print("|cffFFD700[SK]|r Synced "..#tabs.." tabs to "..ShortName(target)..".")
end

function NET:RequestTabSync(shopName)
    shopName = shopName or (SK.db and SK.db.activeShop)
    if not shopName then return end
    if not CanRequest(shopName.."_tabs") then return end  -- throttle
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end
    SendDirect(shop.owner, "SYNC_REQUEST_TABS", shopName, PlayerName())
end

-- Refresh whichever UI is currently showing the Tabs view
function NET:RefreshTabsView()
    NET.suppressAutoSync = true
    if SK.Register and SK.Register.isOpen and SK.Register.activeTab == "tabs"
       and SK.Register.SwitchToTab then
        SK.Register.SwitchToTab("tabs")
    elseif SK.Manager and SK.Manager.isOpen and SK.Manager.activeTab == "tabs"
           and SK.Manager.BuildTabsTab then
        SK.Manager:BuildTabsTab()
    end
    -- Also keep the register tab-mode banner total fresh
    if SK.Register and SK.Register.UpdateTabModeBanner then
        SK.Register:UpdateTabModeBanner()
    end
    NET.suppressAutoSync = false
end

function NET:ShowInvitePopup(shopName, role, fromPlayer)
    StaticPopupDialogs["SK_INVITE"] = {
        text    = "|cffFFD700[Storekeeper]|r\n"..ShortName(fromPlayer)..
                  " invited you to join\n|cffFFD700"..shopName..
                  "|r as "..role..".",
        button1 = "Accept",
        button2 = "Decline",
        OnAccept = function() NET:AcceptInvite() end,
        OnCancel = function() NET:DeclineInvite() end,
        timeout      = 60,
        whileDead    = true,
        hideOnEscape = true,
        preferredIndex = 3,
    }
    StaticPopup_Show("SK_INVITE")
end

function NET:AcceptInvite()
    if not pendingInvite then return end
    local inv = pendingInvite
    pendingInvite = nil

    -- Create shop locally with the owner's name (roster filled in by SHOP_INFO)
    local shop = SK.DB:GetShop(inv.shopName)
    if not shop then
        SK.DB:CreateShop(inv.shopName, inv.from)
        shop = SK.DB:GetShop(inv.shopName)
        if shop then shop.owner = inv.from end
    end

    -- Tell the owner — include our role so they add us correctly
    SendDirect(inv.from, "ACCEPT", inv.shopName, PlayerName(), inv.role)
    print("|cffFFD700[SK]|r You joined |cffFFD700"..inv.shopName.."|r as "..inv.role..".")
    -- activeShop will be set when SHOP_INFO arrives
end

function NET:DeclineInvite()
    if not pendingInvite then return end
    local inv = pendingInvite
    pendingInvite = nil
    SendDirect(inv.from, "DECLINE", inv.shopName, PlayerName())
    print("|cffFFD700[SK]|r Invite to |cffFFD700"..inv.shopName.."|r declined.")
end

-- ─── Shop Delete Broadcast ───────────────────────────────────────────────────
-- Owner calls this when deleting a shop — notifies all staff to remove it locally

function NET:BroadcastShopDelete(shopName)
    local shop = SK.DB:GetShop(shopName)
    if not shop then return end  -- already deleted locally; send from the data we have
    -- Collect all staff to notify
    local staff = {}
    for _, n in ipairs(shop.managers  or {}) do tinsert(staff, n) end
    for _, n in ipairs(shop.employees or {}) do tinsert(staff, n) end
    for _, n in ipairs(staff) do
        SendDirect(n, "SHOP_DELETE", shopName)
    end
end

-- ─── SendHello ────────────────────────────────────────────────────────────────
-- Whisper a HELLO directly to one player (used by on-hover peer discovery).
-- `target` may be a short name; we use it verbatim — the WoW API handles
-- same-realm delivery fine with just the short name, and cross-realm callers
-- should pass Name-Realm.  The recipient's HELLO handler will reply with their
-- version, populating our knownPeers table before the next hover.
function NET:SendHello(target)
    if not target or target == "" then return end
    RawSend("WHISPER", target, "HELLO"..SEP..PlayerName()..SEP..(SK.VERSION or "?"))
end

-- ─── INIT ────────────────────────────────────────────────────────────────────

function NET:Init()
    if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
        C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
    else
        RegisterAddonMessagePrefix(PREFIX)
    end

    local f = CreateFrame("Frame")
    f:RegisterEvent("CHAT_MSG_ADDON")
    f:RegisterEvent("PLAYER_ENTERING_WORLD")
    f:SetScript("OnEvent", function(self, event, ...)
        if event == "CHAT_MSG_ADDON" then
            OnAddonMsg(self, event, ...)
        elseif event == "PLAYER_ENTERING_WORLD" then
            -- Repair any RP-name owners to real character names once TRP3 is ready,
            -- then re-broadcast so members get the corrected (whisperable) name.
            C_Timer.After(4, function()
                SK.DB:RepairOwnerNames()
                if SK.db then
                    for shopName, shop in pairs(SK.db.shops or {}) do
                        local myOOC = (UnitName("player") or ""):lower()
                        if (shop.owner or ""):lower() == myOOC then
                            for _, n in ipairs(shop.managers  or {}) do SK.Net:SyncShop(shopName, n) end
                            for _, n in ipairs(shop.employees or {}) do SK.Net:SyncShop(shopName, n) end
                        end
                    end
                end
            end)
            -- Passive ping to shop owner for sync
            C_Timer.After(3, function() NET:PingOwner() end)
            -- Presence hello: broadcasts our presence so nearby Storekeeper
            -- users register us as a known peer (for tooltip display)
            C_Timer.After(5, function()
                local grp = GroupChannel()
                if grp then
                    RawSend(grp, nil, "HELLO"..SEP..PlayerName()..SEP..(SK.VERSION or "?"))
                end
                -- Also whisper known shop owners directly so they know we're online even without group
                if SK.db then
                    for shopName, shop in pairs(SK.db.shops or {}) do
                        SK.DB:MigrateShop(shop)
                        local role = SK.DB:GetRole(shopName)
                        if role and role ~= "owner" and shop.owner and shop.owner ~= "" then
                            C_Timer.After(1, function()
                                RawSend("WHISPER", shop.owner, "HELLO"..SEP..PlayerName()..SEP..(SK.VERSION or "?"))
                            end)
                        end
                    end
                end
            end)
            -- Proximity hello: YELL is an addon-message channel (invisible to chat,
            -- not displayed to non-Storekeeper users) that reaches everyone in
            -- shout range regardless of group status. This is what actually lets
            -- ungrouped players standing in the same area (e.g. a market or tavern)
            -- discover each other's version — the group/whisper hellos above only
            -- cover party/raid members and known shop owners.
            local function ProximityHello()
                RawSend("YELL", nil, "HELLO"..SEP..PlayerName()..SEP..(SK.VERSION or "?"))
            end
            C_Timer.After(8, ProximityHello)
            -- PLAYER_ENTERING_WORLD fires on every zone change/loading screen, not
            -- just initial login — guard so we never stack more than one ticker.
            if not NET._proximityTicker then
                NET._proximityTicker = C_Timer.NewTicker(180, ProximityHello)
            end
        end
    end)
    NET.listener = f

    -- Retry queue: flush every 3 seconds
    C_Timer.NewTicker(3, function() FlushRetryQueue() end)

    -- Order expiry: check every 30 seconds, notify and refresh live
    C_Timer.NewTicker(30, function()
        if not SK.DB or not SK.db then return end
        local released = SK.DB:CheckOrderExpiry()
        for _, r in ipairs(released) do
            if SK:Cfg().notifyOrderReleased ~= false then
                print("|cffFFD700[SK — "..r.shopName.."]|r Order #"..r.orderID..
                      " |cffFF9900expired|r and is available to claim again.")
            end
            -- Broadcast the updated order to all staff
            local shop = SK.DB:GetShop(r.shopName)
            if shop and SK.Net then
                for _, o in ipairs(shop.orders) do
                    if o.id == r.orderID then
                        SK.Net:BroadcastOrder(r.shopName, o); break
                    end
                end
            end
        end
        -- Refresh orders tab live if open (no tab switch needed)
        if #released > 0 and SK.Register and SK.Register.SwitchToTab
           and SK.Register.isOpen and SK.Register.activeTab == "orders" then
            SK.Register.SwitchToTab("orders")
        end
    end)
end

SK.Net = NET
