-- Storekeeper: Bootstrap
-- Loaded FIRST. Creates the addon object via AceAddon if available,
-- or a plain table otherwise. Either way, Storekeeper exists before
-- any module file runs.

local AceAddon = LibStub and LibStub("AceAddon-3.0", true)
if AceAddon then
    Storekeeper = AceAddon:NewAddon("Storekeeper")
else
    Storekeeper = {}
end

Storekeeper.VERSION = "1.3.8.3"
