-- Storekeeper: TRP3 Extended Bridge
-- Generates TRP3 Extended items as printed receipts.
--
-- NOTE: The player tooltip badge (Storekeeper badge below TRP3 tooltip) has been
-- temporarily DISABLED. All badge/tooltip code is preserved below in comments.

Storekeeper.TRP3 = Storekeeper.TRP3 or {}
local SK = Storekeeper
local T  = SK.TRP3

-- ─── Peer tracking (used by network.lua) ──────────────────────────────────────
Storekeeper.knownPeers = Storekeeper.knownPeers or {}

-- ─── On-hover peer discovery ──────────────────────────────────────────────────
-- When hovering a player we haven't heard from, whisper them a HELLO so they
-- respond with their version (same as our login broadcast, but targeted).
-- This means the tooltip works regardless of group membership or realm.
-- hoverPings throttles to one whisper per player per 30s.
local hoverPings = {}
local function PingPeer(name)
    if not name or name == "" then return end
    local key = name:lower()
    local myName = (UnitName("player") or ""):match("^([^%-]+)") or ""
    if key == myName:lower() then return end                      -- don't ping ourselves
    if Storekeeper.knownPeers[key] then return end                -- already known
    if hoverPings[key] then return end                            -- already pinged recently
    hoverPings[key] = true
    C_Timer.After(30, function() hoverPings[key] = nil end)       -- allow retry after 30s
    -- Use the full Name-Realm form so cross-realm whispers are delivered
    local SK = Storekeeper
    if SK.Net and SK.Net.SendHello then
        SK.Net:SendHello(name)
    end
end

-- ─── GameTooltip injection (kept active — low cost, no OnUpdate) ──────────────
-- Injects "Storekeeper vX" into the standard WoW GameTooltip when hovering
-- a player who also runs Storekeeper. Does NOT run on TRP3 tooltip.
local function HasSK(unit)
    if UnitIsUnit(unit, "player") then return true end
    local name = UnitName(unit)
    if not name then return false end
    name = name:match("^([^%-]+)") or name
    local myName = (UnitName("player") or ""):match("^([^%-]+)") or ""
    if name:lower() == myName:lower() then return true end
    return Storekeeper.knownPeers[name:lower()] ~= nil
end

local function GetVer(unit)
    if UnitIsUnit(unit, "player") then return SK.VERSION or "?" end
    local name = UnitName(unit)
    if not name then return SK.VERSION or "?" end
    name = name:match("^([^%-]+)") or name
    local myName = (UnitName("player") or ""):match("^([^%-]+)") or ""
    if name:lower() == myName:lower() then return SK.VERSION or "?" end
    local v = Storekeeper.knownPeers[name:lower()]
    if type(v) == "string" then return v end
    return "?"
end

-- ─── GameTooltip + TRP3 tooltip injection ────────────────────────────────────
-- Implementation follows Musician/modules/totalRP3/totalRP3.lua.
-- Key discoveries from Musician source:
--   1. TRP3_CharacterTooltip.target holds the player name TRP3 is showing
--   2. Hook TRP3's own updateTooltip so we re-inject when TRP3 refreshes
--   3. AddDoubleLine(" ", text) places text on the right side
--   4. Set font size via _G[tipName.."TextRight"..NumLines()] after adding
--   5. Call tooltip:Show() then :GetTop() to force layout recalc

-- playerHint: optional short player name, used by TRP3 path to avoid relying on
-- the mouseover unit token (which may not match t.target when the cursor has moved)
local function UpdateTooltipInfo(tooltip, unit, fontSize, playerHint)
    if not tooltip or not tooltip.AddDoubleLine then return end

    local ver
    if playerHint then
        -- TRP3 path: player name is known directly from t.target
        local myName = (UnitName("player") or ""):match("^([^%-]+)") or ""
        local isSelf = (playerHint:lower() == myName:lower())
        if isSelf then
            ver = SK.VERSION or "?"
        else
            local v = Storekeeper.knownPeers[playerHint:lower()]
            if not v then return end  -- not a known SK peer
            ver = (type(v) == "string") and v or "?"
        end
    else
        -- GameTooltip path: resolve from unit token
        if not unit or not UnitIsPlayer(unit) then return end
        if not HasSK(unit) then return end
        ver = GetVer(unit)
    end

    local tipName = tooltip:GetName()
    if not tipName then return end

    -- Build info text
    local infoText = "|cffFFD700Storekeeper|r  |cff888888v" .. ver .. "|r"

    -- Check if our line already exists — update in place if the text changed
    -- (e.g. Extended was just enabled/disabled), or move it to the bottom if needed
    local i = 1
    while _G[tipName .. "TextRight" .. i] do
        local line     = _G[tipName .. "TextRight" .. i]
        local lineText = line:GetText()
        if lineText and lineText:find("Storekeeper", 1, true) then
            if lineText == infoText then
                -- Already correct — only reposition if not at bottom
                if i ~= tooltip:NumLines() then
                    line:SetText("")
                    UpdateTooltipInfo(tooltip, unit, fontSize)
                end
            else
                -- Text changed (Extended enabled/disabled) — update in place
                line:SetText(infoText)
                if fontSize then
                    local font, _, flag = line:GetFont()
                    line:SetFont(font, fontSize, flag)
                end
                tooltip:Show()
                tooltip:GetTop()
            end
            return
        end
        i = i + 1
    end

    -- Add: empty left side, our text on the right
    tooltip:AddDoubleLine(" ", infoText, 1, 1, 1, 1, 1, 1)

    -- Smaller font for TRP3 tooltip (fontSize=10), default for GameTooltip
    if fontSize then
        local rightLine = _G[tipName .. "TextRight" .. tooltip:NumLines()]
        if rightLine then
            local font, _, flag = rightLine:GetFont()
            rightLine:SetFont(font, fontSize, flag)
        end
    end

    tooltip:Show()
    tooltip:GetTop()  -- force layout recalc (Musician pattern)
end

local function SetupTooltips()

    -- ── TRP3_CharacterTooltip (Musician pattern) ──────────────────────────
    local function HookTRP3Tooltip()
        if not TRP3_CharacterTooltip then return end

        -- t.target is the player name stored by TRP3 on its tooltip frame
        TRP3_CharacterTooltip:HookScript("OnShow", function(t)
            pcall(function()
                if not t.target then return end
                local name   = t.target:match("^([^%-]+)") or t.target
                local myName = (UnitName("player") or ""):match("^([^%-]+)") or ""
                local isSelf = (name:lower() == myName:lower())
                PingPeer(name)  -- no-op if already known or self
                -- Only inject badge if we already know their version; OnPeerDiscovered
                -- will inject it once the HELLO reply arrives if not yet known.
                if not isSelf and not Storekeeper.knownPeers[name:lower()] then return end
                UpdateTooltipInfo(TRP3_CharacterTooltip, "player", 10, name)
            end)
        end)

        -- Hook TRP3's own tooltip updater so we re-inject on every refresh
        -- This is what keeps Musician's line visible after cursor moves away
        pcall(function()
            if TRP3_API and TRP3_API.ui and TRP3_API.ui.tooltip and
               TRP3_API.ui.tooltip.updateTooltip then
                hooksecurefunc(TRP3_API.ui.tooltip, "updateTooltip", function()
                    pcall(function()
                        if not TRP3_CharacterTooltip or
                           not TRP3_CharacterTooltip:IsShown() then return end
                        local t    = TRP3_CharacterTooltip
                        if not t.target then return end
                        local name   = t.target:match("^([^%-]+)") or t.target
                        local myName = (UnitName("player") or ""):match("^([^%-]+)") or ""
                        local isSelf = (name:lower() == myName:lower())
                        if not isSelf and not Storekeeper.knownPeers[name:lower()] then return end
                        UpdateTooltipInfo(t, "player", 10, name)
                    end)
                end)
            end
        end)
    end

    -- ── OnPeerDiscovered: called by network.lua when a HELLO reply arrives ────
    -- Refreshes the TRP3 tooltip immediately if it is currently showing that player,
    -- so the badge appears without needing to re-hover.
    function SK.TRP3.OnPeerDiscovered(name, version)
        -- GameTooltip path
        pcall(function()
            local _, unit = GameTooltip:GetUnit()
            if unit and UnitIsPlayer(unit) then
                local tipName = (UnitName(unit) or ""):match("^([^%-]+)") or ""
                if tipName:lower() == name:lower() then
                    UpdateTooltipInfo(GameTooltip, unit, nil)
                end
            end
        end)
        -- TRP3 tooltip path
        pcall(function()
            if not TRP3_CharacterTooltip or not TRP3_CharacterTooltip:IsShown() then return end
            local t = TRP3_CharacterTooltip
            if not t.target then return end
            local tipName = t.target:match("^([^%-]+)") or t.target
            if tipName:lower() == name:lower() then
                UpdateTooltipInfo(t, "player", 10, tipName)
            end
        end)
    end

    -- Hook now if TRP3 already loaded, otherwise use TRP3's own callback
    if TRP3_CharacterTooltip then
        pcall(HookTRP3Tooltip)
    elseif TRP3_API and TRP3_Addon and TRP3_Addon.Events
       and TRP3_Addon.Events.WORKFLOW_ON_FINISH then
        pcall(function()
            TRP3_API.RegisterCallback(TRP3_Addon,
                TRP3_Addon.Events.WORKFLOW_ON_FINISH,
                function() pcall(HookTRP3Tooltip) end)
        end)
    else
        local trpWatcher = CreateFrame("Frame")
        trpWatcher:RegisterEvent("ADDON_LOADED")
        trpWatcher:SetScript("OnEvent", function(_, _, addon)
            if addon == "totalRP3" then
                C_Timer.After(1, function() pcall(HookTRP3Tooltip) end)
            end
        end)
    end

    -- ── Standard GameTooltip (non-TRP3 case) ─────────────────────────────
    local function OnUnitTooltip(tip)
        pcall(function()
            local _, unit = tip:GetUnit()
            if not unit or not UnitIsPlayer(unit) then return end
            local name = (UnitName(unit) or ""):match("^([^%-]+)") or ""
            PingPeer(name)
            UpdateTooltipInfo(tip, unit, nil)
        end)
    end

    if TooltipDataProcessor and Enum and Enum.TooltipDataType then
        pcall(TooltipDataProcessor.AddTooltipPostCall,
            Enum.TooltipDataType.Unit,
            function(tip) OnUnitTooltip(tip) end)
    end

    pcall(function()
        GameTooltip:HookScript("OnTooltipSetUnit", function(self)
            OnUnitTooltip(self)
        end)
    end)

    -- ── UPDATE_MOUSEOVER_UNIT pre-fetch ───────────────────────────────────
    -- Fires when the cursor moves over a new unit in the world or a unit
    -- frame.  Sending HELLO here means the reply usually arrives before the
    -- tooltip even opens, so the version shows immediately on first hover.
    local _hoverFrame = CreateFrame("Frame")
    _hoverFrame:RegisterEvent("UPDATE_MOUSEOVER_UNIT")
    _hoverFrame:SetScript("OnEvent", function()
        -- UnitName("mouseover") can be a secret/tainted string when hovering over
        -- unit frames inside secure contexts (e.g. LFR, raid frames). Wrap in
        -- pcall so taint errors are silently discarded rather than surfaced to
        -- the user.
        local ok, name = pcall(function()
            if not UnitExists("mouseover") or not UnitIsPlayer("mouseover") then return nil end
            return (UnitName("mouseover") or ""):match("^([^%-]+)") or ""
        end)
        if ok and name and name ~= "" then
            PingPeer(name)
        end
    end)

end

local _addonLoader = CreateFrame("Frame")
_addonLoader:RegisterEvent("ADDON_LOADED")
_addonLoader:SetScript("OnEvent", function(self, _, addon)
    if addon == "Storekeeper" then
        self:UnregisterEvent("ADDON_LOADED")
        pcall(SetupTooltips)
    end
end)

-- ─── TRP3 Extended receipt builder ────────────────────────────────────────────

local function Line(text, align) return { TX = text or "", AL = align or "LEFT" } end
local function Divider(char) char=char or "\xe2\x94\x80"; return Line(string.rep(char,38),"CENTER") end
local function Spacer() return Line("","LEFT") end

function T:BuildReceiptItem(shopName, sellerName, cart, totalCopper)
    local shop = SK.DB:GetShop(shopName)
    if not shop then return nil, "No active shop." end
    local theme    = SK.db.theme or "goblin"
    local isGoblin = (theme == "goblin")
    local lines    = {}
    if isGoblin then
        tinsert(lines, Line("BROKER COMMERCE NETWORK", "CENTER"))
        tinsert(lines, Line("Kezan Commerce Solutions", "CENTER"))
    else
        tinsert(lines, Line("BROKER LEDGER SYSTEM", "CENTER"))
        tinsert(lines, Line("Storekeeper", "CENTER"))
    end
    tinsert(lines, Divider("="))
    tinsert(lines, Line("SHOP:  " .. shopName, "LEFT"))
    tinsert(lines, Line("SOLD BY:  " .. sellerName, "LEFT"))
    tinsert(lines, Line("DATE:  " .. date("%d/%m/%Y"), "LEFT"))
    tinsert(lines, Divider())
    for _, entry in ipairs(cart) do
        local p = entry.product; local qty = entry.qty
        local nameStr = qty > 1 and (qty .. "x " .. p.name) or p.name
        tinsert(lines, Line(string.format("%-24s %s", nameStr, SK:FormatMoneyPlain(p.priceCopper*qty)), "LEFT"))
        if p.description and p.description ~= "" then
            tinsert(lines, Line("  (" .. p.description .. ")", "LEFT"))
        end
    end
    tinsert(lines, Divider())
    tinsert(lines, Line(string.format("TOTAL:  %s", SK:FormatMoneyPlain(totalCopper)), "LEFT"))
    tinsert(lines, Spacer())
    tinsert(lines, Line("Thank you for your patronage.", "CENTER"))
    tinsert(lines, Divider("="))
    -- ID must survive Extended's checkID (lowercase, alphanumeric + underscore).
    local itemID = "sk_receipt_" .. time() .. "_" .. math.random(1000, 9999)
    local now = date("%d/%m/%y %H:%M:%S")
    local receiptItem = {
        TY = "IT",
        MD = { MO = "NORMAL", CD = now, CB = sellerName, SD = now, SB = sellerName, V = 1 },
        BA = {
            NA = "Receipt - " .. shopName,
            DE = "A receipt from " .. shopName .. ", sold by " .. sellerName .. ".",
            QA = "Common",
            LE = "A receipt stamped with the mark of " .. shopName .. ".",
            IC = "INV_Misc_Note_06",
            WE = 0,      -- was WT, which Extended does not read
            ST = 0,      -- receipts do not stack; must be a number, not a bool
        },
        DS = { { LI = lines } },
    }
    return receiptItem, itemID
end

function T:PrintReceipt(shopName, sellerName, cart, totalCopper)
    -- Previously tested TRP3_Extended.DB.ROOT_CLASSES and TRP3_Extended.utils,
    -- neither of which exists, so this ALWAYS fell through to the chat
    -- fallback. Repointed at the same verified API the product items use.
    if not T:CanGiveItems() then
        T:FallbackChatReceipt(shopName, sellerName, cart, totalCopper)
        return false, "TRP3 Extended not found."
    end
    local receiptItem, itemID = T:BuildReceiptItem(shopName, sellerName, cart, totalCopper)
    if not receiptItem then return false, "Could not build receipt." end

    local ok, err = pcall(function()
        if TRP3_DB.my then TRP3_DB.my[itemID] = receiptItem end
        TRP3_API.extended.registerObject(itemID, receiptItem, 0)
    end)
    if not ok then
        T:FallbackChatReceipt(shopName, sellerName, cart, totalCopper)
        return false, tostring(err)
    end

    local ok2, res = pcall(function()
        return TRP3_API.inventory.addItem(nil, itemID,
            { count = 1, madeBy = UnitName("player") })
    end)
    if ok2 and (res == nil or res == 0) then return true, itemID end

    T:FallbackChatReceipt(shopName, sellerName, cart, totalCopper)
    return false, "Could not add the receipt to your inventory."
end

function T:FallbackChatReceipt(shopName, sellerName, cart, totalCopper)
    print("|cffFFD700[SK Receipt - " .. shopName .. "]|r")
    print("Sold by: " .. sellerName .. "  |  " .. date("%d/%m/%Y"))
    print("|cffFFD700" .. string.rep("-",32) .. "|r")
    for _, entry in ipairs(cart) do
        local p = entry.product; local qty = entry.qty
        print("  " .. (qty > 1 and qty.."x " or "") .. p.name .. "  -  " .. SK:FormatMoney(p.priceCopper*qty))
    end
    print("|cffFFD700" .. string.rep("-",32) .. "|r")
    print("TOTAL: " .. SK:FormatMoney(totalCopper))
end

-- ─── TRP3 Extended product items ──────────────────────────────────────────────
-- Verified against Total-RP-3-Extended source. The real API surface is:
--   TRP3_API.extended.classExists(id)          -> boolean
--   TRP3_API.extended.getClass(id)             -> class, or TRP3_DB.missing
--   TRP3_API.extended.registerObject(id, obj)  -> registers into TRP3_DB.global
--   TRP3_API.inventory.addItem(container, classID, itemData, dropIfFull, toSlot)
--       container nil = the player's own inventory
--       itemData      = { count = n, madeBy = creatorName }
--       returns 0 OK | 1 container full | 2 unique limit | 3 not a container
--               4 container cannot hold it
--   TRP3_DB.global   = live class registry (rebuilt each login)
--   TRP3_DB.my       = TRP3_Tools_DB, the player's own saved creations
--
-- There is NO `TRP3_Extended.DB` and no `TRP3_Extended.utils.item.addItem`.
-- TRP3_Extended is only the AceAddon object. Earlier code in this file assumed
-- otherwise, which is why receipts silently fell back to chat.
--
-- KNOWN LIMITATION: items can only be added to our OWN inventory. There is no
-- API to push an item into another player's bag. The seller hands over through
-- Extended's exchange window afterwards. Do not attempt to work around this.

-- Two modes per product (prod.trp3Mode):
--   "link"   — prod.trp3ItemID points at a class the user authored themselves.
--   "author" — Storekeeper writes the class from the product's fields.

function T:IsExtendedReady()
    local ok, ready = pcall(function()
        return TRP3_API ~= nil
           and TRP3_API.extended ~= nil
           and TRP3_API.extended.classExists ~= nil
           and TRP3_DB ~= nil
           and TRP3_DB.global ~= nil
    end)
    return ok and ready == true
end

function T:CanGiveItems()
    if not T:IsExtendedReady() then return false end
    local ok, has = pcall(function()
        return TRP3_API.inventory ~= nil and TRP3_API.inventory.addItem ~= nil
    end)
    return ok and has == true
end

-- Does this class ID exist? Uses Extended's own lookup so that inner-object
-- IDs ("ROOT child") resolve the same way they do everywhere else.
function T:ClassExists(itemID)
    if not itemID or itemID == "" then return false end
    if not T:IsExtendedReady() then return false end
    local ok, found = pcall(function()
        return TRP3_API.extended.classExists(itemID) == true
    end)
    return ok and found == true
end

local RARITY_TO_QA = {
    common    = "Common",
    uncommon  = "Uncommon",
    rare      = "Rare",
    epic      = "Epic",
    legendary = "Legendary",
}

local function IconNameFor(icon)
    if type(icon) == "string" and icon ~= "" then return icon end
    local ok, name = pcall(function()
        if SK.IconPicker and SK.IconPicker.GetIconName then
            return SK.IconPicker:GetIconName(icon)
        end
        return nil
    end)
    if ok and type(name) == "string" and name ~= "" then return name end
    return "temp"
end

-- Extended sanitises IDs to lowercase alphanumeric+underscore, and uses a space
-- as its ID separator, so the generated ID must survive checkID unchanged.
local function MakeItemID(product)
    local base = "sk_" .. tostring(product.id or 0) .. "_" .. tostring(time())
    local ok, clean = pcall(function()
        return TRP3_API.extended.checkID(base)
    end)
    if ok and type(clean) == "string" and clean ~= "" then return clean end
    return base:lower():gsub("[^%w_]", "_")
end

-- Build (or rebuild) an Extended item class for a product.
-- Writes to TRP3_DB.my (the player's saved creations, so it survives a reload
-- and shows up in their Extended database) and registers it into the live
-- TRP3_DB.global so it is usable immediately without a /reload.
-- Returns true, itemID | false, errorText
function T:AuthorProductItem(product)
    if not product then return false, "No product." end
    if not T:IsExtendedReady() then return false, "TRP3 Extended not loaded." end

    local itemID = product.trp3ItemID
    if not itemID or itemID == "" then itemID = MakeItemID(product) end

    local desc = product.description
    if not desc or desc == "" then desc = product.name or "" end

    -- BA.ST is a STACK SIZE, not a flag: Inventory.lua does `(BA.ST or 0) > 0`,
    -- so a boolean here throws "attempt to compare boolean with number".
    local itemClass = {
        TY = "IT",
        MD = {
            MO = "NORMAL",
            CD = date("%d/%m/%y %H:%M:%S"),
            CB = UnitName("player"),
            SD = date("%d/%m/%y %H:%M:%S"),
            SB = UnitName("player"),
            V  = 1,
        },
        BA = {
            NA = product.name or "Item",
            DE = desc,
            LE = desc,
            QA = RARITY_TO_QA[product.rarity or "common"] or "Common",
            IC = IconNameFor(product.icon),
            WE = 0,
            VA = tonumber(product.priceCopper) or 0,
            ST = 20,
            CR = true,
        },
    }

    local ok, err = pcall(function()
        if TRP3_DB.my then TRP3_DB.my[itemID] = itemClass end
        TRP3_API.extended.registerObject(itemID, itemClass, 0)
    end)
    if not ok then return false, tostring(err) end
    return true, itemID
end

local ADD_ERRORS = {
    [1] = "inventory full",
    [2] = "unique item limit reached",
    [3] = "target is not a container",
    [4] = "container cannot hold it",
}

-- Add every cart line carrying an Extended item ID into OUR OWN inventory.
-- Deliberately manual — never called from checkout.
-- Returns addedCount, problemList, missingClassFlag.
-- missingClassFlag is set when at least one ID resolved to nothing in this
-- player's database, which is the case with an actual remedy (import string).
function T:GiveCartItems(cart)
    local problems = {}
    local missingClass = false
    if not cart then return 0, problems, false end
    if not T:CanGiveItems() then return 0, problems, false end

    local me = UnitName("player")
    local added = 0

    -- Cart lines opened from a Tab carry a stub product table (id/name/price
    -- only), so re-resolve against the live shop record before reading the
    -- TRP3 fields. Falls back to the cart's own table if the id is unknown.
    local byID = {}
    do
        local shopName = SK.db and SK.db.activeShop
        if shopName and SK.DB and SK.DB.GetProducts then
            for _, dp in ipairs(SK.DB:GetProducts(shopName) or {}) do
                if dp.id ~= nil then byID[dp.id] = dp end
            end
        end
    end

    for _, entry in ipairs(cart) do
        local p = entry and entry.product
        if p and p.id ~= nil and byID[p.id] then p = byID[p.id] end
        if p and p.hasTRP3Item then
            local itemID = p.trp3ItemID
            local qty = tonumber(entry.qty) or 1
            if qty < 1 then qty = 1 end

            if not itemID or itemID == "" then
                tinsert(problems, (p.name or "?") .. ": no item ID set")
            elseif not T:ClassExists(itemID) then
                -- Not in THIS player's TRP3_DB.global. Almost always means they
                -- were never sent the item, not that the ID is wrong.
                tinsert(problems, (p.name or "?") .. ": not in your TRP3 Extended database")
                missingClass = true
            else
                local ok, res = pcall(function()
                    return TRP3_API.inventory.addItem(nil, itemID,
                        { count = qty, madeBy = me })
                end)
                if not ok then
                    tinsert(problems, (p.name or "?") .. ": " .. tostring(res))
                elseif res == nil or res == 0 then
                    added = added + qty
                else
                    tinsert(problems, (p.name or "?") .. ": " ..
                        (ADD_ERRORS[res] or ("error " .. tostring(res))))
                end
            end
        end
    end

    return added, problems, missingClass
end

function T:CartHasTRP3Items(cart)
    local shopName = SK.db and SK.db.activeShop
    local byID = {}
    if shopName and SK.DB and SK.DB.GetProducts then
        for _, dp in ipairs(SK.DB:GetProducts(shopName) or {}) do
            if dp.id ~= nil then byID[dp.id] = dp end
        end
    end
    for _, entry in ipairs(cart or {}) do
        local p = entry and entry.product
        if p and p.id ~= nil and byID[p.id] then p = byID[p.id] end
        if p and p.hasTRP3Item then return true end
    end
    return false
end
