-- Storekeeper: Database Module

Storekeeper.DB = Storekeeper.DB or {}
local SK = Storekeeper
local DB = SK.DB

-- ─── Helpers ──────────────────────────────────────────────────────────────────

local function NextID(list)
    local max = 0
    for _, v in ipairs(list) do if (v.id or 0) > max then max = v.id end end
    return max + 1
end

local function NormShop(shopName)
    return SK.db.shops[shopName or SK.db.activeShop]
end

-- ─── Shop ─────────────────────────────────────────────────────────────────────

function DB:CreateShop(shopName, ownerName)
    if not shopName or shopName == "" then return false, "Shop name required." end
    if SK.db.shops[shopName] then return false, "Shop already exists." end
    -- IMPORTANT: shop.owner is used as a network whisper target, so it MUST be a
    -- real character name (Name-Realm), never a TRP3/RP display name (which often
    -- contains a space and isn't whisperable). The RP name is kept separately for
    -- display only.
    local oocName = ownerName
    if not oocName or oocName == "" or oocName:find("%s") then
        -- No usable OOC name passed (or an RP name slipped in) — use this character
        local n, r = UnitFullName("player")
        if n then oocName = (r and r ~= "" and not n:find("-")) and (n.."-"..r) or n
        else oocName = ownerName end
    end
    SK.db.shops[shopName] = {
        owner     = oocName,
        ownerRP   = SK:GetRPName(),
        managers  = {},
        employees = {},
        products  = {},
        orders    = {},
        logs      = {},
    }
    if not SK.db.activeShop then SK.db.activeShop = shopName end
    return true
end

-- Display name for a shop's owner: prefer the RP name, fall back to the
-- character name. (shop.owner is always the routable character name.)
function DB:GetOwnerDisplay(shopName)
    local shop = NormShop(shopName)
    if not shop then return "?" end
    if shop.ownerRP and shop.ownerRP ~= "" then return shop.ownerRP end
    return shop.owner or "?"
end

-- Repair owner names that were stored as RP names (which contain a space and
-- aren't whisperable). For any shop OWNED by this character, replace the RP
-- name in shop.owner with the real character name and keep the RP name for
-- display. Safe to call repeatedly; only touches shops we own. Should be called
-- after TRP3 has loaded so GetRPName() resolves correctly.
function DB:RepairOwnerNames()
    if not SK.db or not SK.db.shops then return end
    local myRP = (SK:GetRPName() or "")
    if myRP == "" then return end  -- TRP3 not ready; try again later
    local n, r = UnitFullName("player")
    local myOOC = n and ((r and r ~= "" and not n:find("-")) and (n.."-"..r) or n) or nil
    if not myOOC then return end
    for _, shop in pairs(SK.db.shops) do
        if shop.owner and shop.owner:find("%s") and shop.owner:lower() == myRP:lower() then
            if not shop.ownerRP or shop.ownerRP == "" then shop.ownerRP = shop.owner end
            shop.owner = myOOC
        end
    end
end

function DB:DeleteShop(shopName)
    if not SK.db.shops[shopName] then return false end
    SK.db.shops[shopName] = nil
    -- Pick next active shop only from shops this character has a role in
    if SK.db.activeShop == shopName then
        SK.db.activeShop = nil
        local remaining = DB:GetAllShops()
        if #remaining > 0 then
            SK.db.activeShop = remaining[1].name
        end
    end
    return true
end

function DB:GetShop(shopName) return NormShop(shopName) end

function DB:GetAllShops()
    local list = {}
    local ooc = UnitName("player") or ""
    local ic  = SK:GetRPName() or ""
    for name, data in pairs(SK.db.shops) do
        -- Check by OOC name first, then IC name — both belong to the current character
        local role = DB:GetRole(name, ooc)
        if not role and ic ~= "" then
            role = DB:GetRole(name, ic)
        end
        if role ~= nil then
            tinsert(list, {name=name, data=data})
        end
    end
    table.sort(list, function(a,b) return a.name < b.name end)
    return list
end

function DB:SetActiveShop(shopName)
    if not SK.db.shops[shopName] then return false end
    SK.db.activeShop = shopName
    -- Persist per-character so each character remembers their own last selection
    local charKey = UnitName("player") or "unknown"
    if not SK.db.charActiveShop then SK.db.charActiveShop = {} end
    SK.db.charActiveShop[charKey] = shopName
    return true
end

-- Ensure old shops without new fields still work
function DB:MigrateShop(shop)
    if not shop then return end
    shop.employees      = shop.employees      or {}
    shop.orders         = shop.orders         or {}
    shop.tabs           = shop.tabs           or {}
    shop.logs           = shop.logs           or {}
    shop.discounts      = shop.discounts      or {}
    shop.perms          = shop.perms          or {}
    -- Ensure all permission keys exist with correct defaults.
    -- Managers default true; employees default false.
    do
        local p = shop.perms
        local function defOn(k)  if p[k] == nil then p[k] = true  end end
        local function defOff(k) if p[k] == nil then p[k] = false end end
        defOn("mgrsCanProducts");      defOff("empsCanProducts")
        defOn("mgrsCanDiscount");      defOff("empsCanDiscount")
        defOn("mgrsCanTreasury");      defOff("empsCanTreasury")
        defOn("mgrsCanStock");         defOff("empsCanStock")
        defOn("mgrsCanAddEmployees");  defOff("empsCanAddEmployees")
        defOn("mgrsCanManageTabs");    defOff("empsCanManageTabs")
        defOn("mgrsCanViewLogs");      defOff("empsCanViewLogs")
        defOn("mgrsCanClaimOrders");   defOn("empsCanClaimOrders")
        defOn("mgrsCanFinalizeOrders");defOn("empsCanFinalizeOrders")
        defOn("mgrsCanReopenOrders");  defOff("empsCanReopenOrders")
        defOn("mgrsCanFavour");        defOff("empsCanFavour")
    end
    shop.categoryColors  = shop.categoryColors  or {}
    shop.categoryOrder   = shop.categoryOrder   or {}
    shop.categoryEnabled = shop.categoryEnabled or {}
    shop.pendingInvites = shop.pendingInvites or {}
    shop.productSeq     = shop.productSeq     or 0
    -- Owner name fix: shop.owner must be a whisperable character name, NOT an RP
    -- name (which contains a space). Older shops stored the RP name. If this is
    -- OUR shop and owner has a space, repair it to our real character name and
    -- preserve the RP name for display.
    if shop.owner and shop.owner:find("%s") then
        if not shop.ownerRP or shop.ownerRP == "" then shop.ownerRP = shop.owner end
        local myRP = SK:GetRPName()
        if myRP and myRP ~= "" and myRP:lower() == shop.owner:lower() then
            local n, r = UnitFullName("player")
            if n then
                shop.owner = (r and r ~= "" and not n:find("-")) and (n.."-"..r) or n
            end
        end
    end
    -- Migrate products: ensure variants field exists; assign a stable sortIndex
    -- (used for manual within/across-category ordering). Products without one
    -- get sequential indices based on their current position.
    local maxSort = 0
    for _, p in ipairs(shop.products or {}) do
        if p.variants == nil then p.variants = {} end
        if type(p.sortIndex) == "number" and p.sortIndex > maxSort then maxSort = p.sortIndex end
    end
    for _, p in ipairs(shop.products or {}) do
        if type(p.sortIndex) ~= "number" then
            maxSort = maxSort + 1
            p.sortIndex = maxSort
        end
    end
    shop.orderSeq       = shop.orderSeq       or 0
    shop.tabSeq         = shop.tabSeq         or 0
    shop.treasury       = shop.treasury       or 0
    -- Migrate old 'categories' field → categoryColors
    if shop.categories then
        for k, v in pairs(shop.categories) do
            if not shop.categoryColors[k] then
                shop.categoryColors[k] = v
            end
        end
        shop.categories = nil
    end
end

-- Set/save the full category order for a shop
function DB:SetCategoryOrder(shopName, orderTable)
    local shop = NormShop(shopName)
    if not shop then return end
    DB:MigrateShop(shop)
    shop.categoryOrder = orderTable or {}
end

-- Get the current category order, rebuilt to include any new categories
-- that products use but haven't been explicitly ordered yet.
-- Categories that have NO products are pruned from the list automatically.
function DB:GetCategoryOrder(shopName)
    local shop = NormShop(shopName)
    if not shop then return {} end
    DB:MigrateShop(shop)
    -- Get all categories that currently have products
    local _, allCats = DB:GetProductsByCategory(shopName)
    -- Build a set of active category names
    local activeCats = {}
    for _, name in ipairs(allCats) do activeCats[name] = true end
    -- Start with the stored order, keeping only active categories
    local seen = {}
    local result = {}
    for _, name in ipairs(shop.categoryOrder) do
        if activeCats[name] and not seen[name] then
            seen[name] = true
            tinsert(result, name)
        end
    end
    -- Append any active categories not yet in the stored order
    for _, name in ipairs(allCats) do
        if not seen[name] then
            seen[name] = true
            tinsert(result, name)
        end
    end
    -- Persist the cleaned order back
    shop.categoryOrder = result
    return result
end

-- Add to treasury (positive = deposit, negative = withdrawal)
function DB:AddTreasury(shopName, copperAmount)
    local shop = NormShop(shopName)
    if not shop then return end
    DB:MigrateShop(shop)
    shop.treasury = (shop.treasury or 0) + copperAmount
    if shop.treasury < 0 then shop.treasury = 0 end
    DB:AddLog(shopName, string.format("Treasury %s: %s (balance: %s)",
        copperAmount >= 0 and "deposit" or "withdrawal",
        SK:FormatMoneyPlain(math.abs(copperAmount)),
        SK:FormatMoneyPlain(shop.treasury)), "treasury")
end

-- Set stock on a product (nil = unlimited)
function DB:SetStock(shopName, productID, amount)
    local shop = NormShop(shopName)
    if not shop then return false end
    for _, p in ipairs(shop.products) do
        if p.id == productID then
            p.stock = amount  -- nil = unlimited, number = limited
            DB:BumpProductSeq(shopName)
            return true
        end
    end
    return false
end

-- Decrease stock when order is fulfilled
function DB:DecreaseStock(shopName, productID, qty)
    local shop = NormShop(shopName)
    if not shop then return end
    for _, p in ipairs(shop.products) do
        if p.id == productID and p.stock ~= nil then
            p.stock = math.max(0, p.stock - qty)
            DB:BumpProductSeq(shopName)
        end
    end
end


function DB:GetRole(shopName, playerName)
    local shop = NormShop(shopName)
    if not shop then return nil end
    DB:MigrateShop(shop)
    -- A stored name may or may not include a realm ("Bob" vs "Bob-Realm").
    -- UnitName("player") has no realm. Match rule: if BOTH names carry a realm,
    -- they must match in full; otherwise compare on the bare character name.
    local function matches(stored, query)
        if not stored or not query then return false end
        stored, query = stored:lower(), query:lower()
        if stored == query then return true end
        local function bare(n) return (n:match("^([^%-]+)") or n) end
        local sHasRealm = stored:find("%-") ~= nil
        local qHasRealm = query:find("%-") ~= nil
        if sHasRealm and qHasRealm then
            return stored == query  -- both realmed: require exact
        end
        return bare(stored) == bare(query)
    end

    -- The query names representing "this person"
    local queries = {}
    if playerName then
        tinsert(queries, playerName)
    else
        local ooc = UnitName("player"); if ooc then tinsert(queries, ooc) end
        local ic = SK:GetRPName(); if ic and ic ~= "" then tinsert(queries, ic) end
    end

    local function anyMatch(stored)
        for _, q in ipairs(queries) do if matches(stored, q) then return true end end
        return false
    end

    if shop.owner and anyMatch(shop.owner) then return "owner" end
    if shop.ownerRP and shop.ownerRP ~= "" and anyMatch(shop.ownerRP) then return "owner" end
    for _, m in ipairs(shop.managers)  do if anyMatch(m) then return "manager"  end end
    for _, e in ipairs(shop.employees) do if anyMatch(e) then return "employee" end end
    return nil
end

function DB:IsManager(shopName, playerName)
    local role = DB:GetRole(shopName, playerName)
    return role == "owner" or role == "manager"
end

-- Resolve the *current character's* role by checking BOTH the OOC character
-- name and the IC/TRP3 name. Use this for UI gating (e.g. showing edit forms)
-- where the shop entry may be stored under either name. Passing an explicit
-- name to GetRole only checks that one name, which misses IC-named owners.
function DB:GetMyRole(shopName)
    local role = DB:GetRole(shopName, UnitName("player"))
    if not role then
        local ic = SK:GetRPName()
        if ic and ic ~= "" then role = DB:GetRole(shopName, ic) end
    end
    return role
end

function DB:IsMyManager(shopName)
    local r = DB:GetMyRole(shopName)
    return r == "owner" or r == "manager"
end

function DB:IsMyStaff(shopName)
    return DB:GetMyRole(shopName) ~= nil
end

function DB:IsStaff(shopName, playerName)
    return DB:GetRole(shopName, playerName) ~= nil
end

-- ─── Permission helpers ──────────────────────────────────────────────────────
-- Each helper returns true if the current (or given) character has the permission.
-- Owners always pass. Managers default to true unless explicitly disabled.
-- Employees default to false unless explicitly enabled.

local function PermCheck(shop, role, mgrsKey, empsKey)
    if role == "owner"   then return true end
    if role == "manager" then return shop.perms[mgrsKey] ~= false end
    if role == "employee" then return shop.perms[empsKey] == true end
    return false
end

-- Treasury: deposit/withdraw
function DB:CanTreasury(shopName, playerName)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    local role = DB:GetRole(shopName, playerName)
    return PermCheck(shop, role, "mgrsCanTreasury", "empsCanTreasury")
end

-- Tabs: reopen/edit a tab's payment settings
function DB:CanManageTabs(shopName)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    local role = DB:GetMyRole(shopName)
    return PermCheck(shop, role, "mgrsCanManageTabs", "empsCanManageTabs")
end

-- Products: add/edit/remove products
function DB:CanManageProducts(shopName)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    local role = DB:GetMyRole(shopName)
    return PermCheck(shop, role, "mgrsCanProducts", "empsCanProducts")
end

-- Discounts: apply discounts in register
function DB:CanDiscount(shopName)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    local role = DB:GetMyRole(shopName)
    return PermCheck(shop, role, "mgrsCanDiscount", "empsCanDiscount")
end

-- Stock: update stock levels
function DB:CanManageStock(shopName)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    local role = DB:GetMyRole(shopName)
    return PermCheck(shop, role, "mgrsCanStock", "empsCanStock")
end

-- Logs: view the Logs tab
function DB:CanViewLogs(shopName)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    local role = DB:GetMyRole(shopName)
    return PermCheck(shop, role, "mgrsCanViewLogs", "empsCanViewLogs")
end

-- Orders: claim/release orders
function DB:CanClaimOrders(shopName)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    local role = DB:GetMyRole(shopName)
    return PermCheck(shop, role, "mgrsCanClaimOrders", "empsCanClaimOrders")
end

-- Orders: finalize (confirm/close) an order
function DB:CanFinalizeOrders(shopName)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    local role = DB:GetMyRole(shopName)
    return PermCheck(shop, role, "mgrsCanFinalizeOrders", "empsCanFinalizeOrders")
end

-- Staff: add/invite employees
function DB:CanAddEmployees(shopName)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    local role = DB:GetMyRole(shopName)
    return PermCheck(shop, role, "mgrsCanAddEmployees", "empsCanAddEmployees")
end

-- Reopen / release a completed order
function DB:CanReopenOrders(shopName)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    local role = DB:GetMyRole(shopName)
    return PermCheck(shop, role, "mgrsCanReopenOrders", "empsCanReopenOrders")
end

-- Paid as Favour payment option
function DB:CanPayAsFavour(shopName)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    local role = DB:GetMyRole(shopName)
    return PermCheck(shop, role, "mgrsCanFavour", "empsCanFavour")
end

-- ─── Managers ─────────────────────────────────────────────────────────────────

-- Helper: strip realm suffix and return only the character name
local function ShortName(name)
    if not name then return "" end
    return strtrim(name):match("^([^%-]+)") or strtrim(name)
end

function DB:AddManager(shopName, name)
    local shop = NormShop(shopName)
    if not shop then return false, "Shop not found." end
    name = ShortName(name)
    if name == "" then return false, "Invalid name." end
    for _, m in ipairs(shop.managers) do
        if ShortName(m):lower()==name:lower() then return false, name.." is already a manager." end
    end
    -- Remove from employees if present
    for i, e in ipairs(shop.employees) do
        if ShortName(e):lower()==name:lower() then tremove(shop.employees, i); break end
    end
    tinsert(shop.managers, name)
    DB:AddLog(shopName, "Manager added: "..name, "staff")
    return true
end

function DB:RemoveManager(shopName, name)
    local shop = NormShop(shopName)
    if not shop then return false end
    name = ShortName(name)
    for i, m in ipairs(shop.managers) do
        if ShortName(m):lower()==name:lower() then
            tremove(shop.managers, i)
            DB:AddLog(shopName, "Manager removed: "..name, "staff")
            return true
        end
    end
    return false, "Manager not found."
end

-- ─── Employees ────────────────────────────────────────────────────────────────

function DB:AddEmployee(shopName, name)
    local shop = NormShop(shopName)
    if not shop then return false, "Shop not found." end
    DB:MigrateShop(shop)
    name = ShortName(name)
    if name == "" then return false, "Invalid name." end
    for _, e in ipairs(shop.employees) do
        if ShortName(e):lower()==name:lower() then return false, name.." is already an employee." end
    end
    for _, m in ipairs(shop.managers) do
        if ShortName(m):lower()==name:lower() then return false, name.." is already a manager." end
    end
    tinsert(shop.employees, name)
    DB:AddLog(shopName, "Employee added: "..name, "staff")
    return true
end

function DB:RemoveEmployee(shopName, name)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    name = ShortName(name)
    for i, e in ipairs(shop.employees) do
        if ShortName(e):lower()==name:lower() then
            tremove(shop.employees, i)
            DB:AddLog(shopName, "Employee removed: "..name, "staff")
            return true
        end
    end
    return false, "Employee not found."
end

-- ─── Pending Invites ──────────────────────────────────────────────────────────

function DB:AddPendingInvite(shopName, name, role)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    name = ShortName(name)
    -- Don't add if already pending, already an employee, or already a manager
    for _, p in ipairs(shop.pendingInvites) do
        if ShortName(p.name):lower() == name:lower() then return false, "Already pending." end
    end
    tinsert(shop.pendingInvites, {name=name, role=role or "employee"})
    return true
end

function DB:RemovePendingInvite(shopName, name)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    name = ShortName(name)
    for i, p in ipairs(shop.pendingInvites) do
        if ShortName(p.name):lower() == name:lower() then
            tremove(shop.pendingInvites, i)
            return true
        end
    end
    return false
end

function DB:GetPendingInvite(shopName, name)
    local shop = NormShop(shopName)
    if not shop then return nil end
    DB:MigrateShop(shop)
    name = ShortName(name)
    for _, p in ipairs(shop.pendingInvites) do
        if ShortName(p.name):lower() == name:lower() then return p end
    end
    return nil
end

-- ─── Products ─────────────────────────────────────────────────────────────────

function DB:AddProduct(shopName, name, description, priceCopper, category, icon)
    local shop = NormShop(shopName)
    if not shop then return false, "Shop not found." end
    if not name or name=="" then return false, "Name required." end
    local p = {
        id=NextID(shop.products), name=name, description=description or "",
        priceCopper=priceCopper or 0, category=category or "General",
        icon=icon or "INV_Misc_Coin_01",
        variants={},
    }
    tinsert(shop.products, p)
    DB:BumpProductSeq(shopName)
    DB:AddLog(shopName, "Product added: "..name, "product")
    return true, p
end

-- Variant used by network sync — accepts a pre-built product table
function DB:AddProductFromTable(shopName, tbl)
    local shop = NormShop(shopName)
    if not shop then return false, "Shop not found." end
    if not tbl or not tbl.name or tbl.name == "" then return false, "Name required." end
    local p = {
        id          = NextID(shop.products),
        name        = tbl.name,
        description = tbl.description or "",
        priceCopper = tonumber(tbl.priceCopper) or 0,
        category    = tbl.category or "General",
        icon        = tbl.icon or 0,
        rarity      = tbl.rarity or "common",
        stock       = tbl.stock,
        variants    = tbl.variants or {},
    }
    tinsert(shop.products, p)
    return true, p
end

function DB:EditProduct(shopName, productID, fields)
    local shop = NormShop(shopName)
    if not shop then return false end
    for _, p in ipairs(shop.products) do
        if p.id==productID then
            for k,v in pairs(fields) do p[k]=v end
            DB:BumpProductSeq(shopName)
            DB:AddLog(shopName, "Product edited: "..p.name, "product")
            return true
        end
    end
    return false, "Product not found."
end

function DB:DeleteProduct(shopName, productID)
    local shop = NormShop(shopName)
    if not shop then return false end
    for i, p in ipairs(shop.products) do
        if p.id==productID then
            DB:BumpProductSeq(shopName)
            DB:AddLog(shopName, "Product deleted: "..p.name, "product")
            tremove(shop.products, i)
            return true
        end
    end
    return false
end

function DB:GetProducts(shopName)
    local shop = NormShop(shopName)
    return shop and shop.products or {}
end

-- Move a product to a target category at a target position (1-based within that
-- category's ordered list). Used by the Products tab "Arrange" mode. Reassigns
-- the product's category if it changed, then renumbers sortIndex across the
-- affected categories so the order is stable and contiguous.
function DB:MoveProduct(shopName, productID, targetCategory, targetPos)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)

    local moving
    for _, p in ipairs(shop.products) do
        if p.id == productID then moving = p; break end
    end
    if not moving then return false, "Product not found." end

    local oldCategory = moving.category or "General"
    targetCategory = targetCategory or oldCategory

    -- Build the current ordered list of the target category (excluding the
    -- moving product, in case it's already there)
    local list = {}
    for _, p in ipairs(shop.products) do
        if (p.category or "General") == targetCategory and p.id ~= productID then
            tinsert(list, p)
        end
    end
    table.sort(list, function(a,b)
        local sa,sb = a.sortIndex or 0, b.sortIndex or 0
        if sa == sb then return (a.name or "") < (b.name or "") end
        return sa < sb
    end)

    -- Apply the category change, then insert at the requested position
    moving.category = targetCategory
    targetPos = math.min(math.max(targetPos or (#list+1), 1), #list+1)
    tinsert(list, targetPos, moving)

    -- Renumber sortIndex for the target category in big steps so future inserts
    -- have room (10, 20, 30, ...). Keep numbers globally unique-ish by basing on
    -- a per-category sequence — simplest is to renumber just this category.
    for i, p in ipairs(list) do
        p.sortIndex = i * 10
    end

    -- If the product changed categories, also renumber the OLD category so its
    -- ordering stays contiguous (cosmetic, keeps indices tidy).
    if oldCategory ~= targetCategory then
        local oldList = {}
        for _, p in ipairs(shop.products) do
            if (p.category or "General") == oldCategory then tinsert(oldList, p) end
        end
        table.sort(oldList, function(a,b)
            local sa,sb = a.sortIndex or 0, b.sortIndex or 0
            if sa == sb then return (a.name or "") < (b.name or "") end
            return sa < sb
        end)
        for i, p in ipairs(oldList) do p.sortIndex = i * 10 end
    end

    DB:BumpProductSeq(shopName)
    return true
end

function DB:GetCategoryColor(shopName, category)
    local shop = NormShop(shopName)
    if not shop then return 1, 0.82, 0 end
    DB:MigrateShop(shop)
    local col = shop.categoryColors[category]
    if col then return col[1], col[2], col[3] end
    return 1, 0.82, 0  -- default gold
end

function DB:SetCategoryColor(shopName, category, r, g, b)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    shop.categoryColors[category] = {r, g, b}
    DB:BumpProductSeq(shopName)
    return true
end

-- Category enabled/disabled state (defaults true for new categories)
function DB:IsCategoryEnabled(shopName, category)
    local shop = NormShop(shopName)
    if not shop then return true end
    DB:MigrateShop(shop)
    local v = shop.categoryEnabled[category]
    return v == nil or v == true
end

function DB:SetCategoryEnabled(shopName, category, enabled)
    local shop = NormShop(shopName)
    if not shop then return end
    DB:MigrateShop(shop)
    shop.categoryEnabled[category] = enabled and true or false
    DB:BumpProductSeq(shopName)
end

-- Rename a category everywhere it appears: every product tied to it, the
-- category color map, and the saved category order. If the new name already
-- exists, the two categories are merged (products fold into the existing one).
function DB:RenameCategory(shopName, oldName, newName)
    local shop = NormShop(shopName)
    if not shop then return false, "Shop not found." end
    DB:MigrateShop(shop)
    oldName = oldName and strtrim(oldName) or ""
    newName = newName and strtrim(newName) or ""
    if oldName == "" or newName == "" then return false, "Name cannot be empty." end
    if oldName == newName then return true end

    local merging = false
    for _, p in ipairs(shop.products) do
        if (p.category or "General") == newName then merging = true; break end
    end

    -- Update every product currently in the old category
    for _, p in ipairs(shop.products) do
        if (p.category or "General") == oldName then
            p.category = newName
        end
    end

    -- Move the color over (don't clobber an existing target color when merging)
    if shop.categoryColors[oldName] then
        if not (merging and shop.categoryColors[newName]) then
            shop.categoryColors[newName] = shop.categoryColors[oldName]
        end
        shop.categoryColors[oldName] = nil
    end

    -- Migrate enabled state
    if shop.categoryEnabled[oldName] ~= nil then
        if not (merging and shop.categoryEnabled[newName] ~= nil) then
            shop.categoryEnabled[newName] = shop.categoryEnabled[oldName]
        end
        shop.categoryEnabled[oldName] = nil
    end

    -- Update the saved order: replace oldName with newName, or drop it if the
    -- target already appears (merge case).
    local newOrder, seen = {}, {}
    for _, name in ipairs(shop.categoryOrder or {}) do
        local n = (name == oldName) and newName or name
        if not seen[n] then seen[n] = true; tinsert(newOrder, n) end
    end
    shop.categoryOrder = newOrder

    DB:BumpProductSeq(shopName)
    DB:AddLog(shopName, string.format("Category '%s' renamed to '%s'%s",
        oldName, newName, merging and " (merged)" or ""), "product")
    return true, merging
end

-- Bump the product sequence number for a shop
function DB:BumpProductSeq(shopName)
    local shop = NormShop(shopName)
    if not shop then return end
    shop.productSeq = (shop.productSeq or 0) + 1
end

-- Bump the order sequence number for a shop
function DB:BumpOrderSeq(shopName)
    local shop = NormShop(shopName)
    if not shop then return end
    shop.orderSeq = (shop.orderSeq or 0) + 1
end

-- Rename a shop (owner only check is done in UI)
function DB:RenameShop(oldName, newName)
    if not oldName or not newName or newName == "" then return false, "Name required." end
    if oldName == newName then return false, "Same name." end
    if SK.db.shops[newName] then return false, "A shop named '"..newName.."' already exists." end
    local shop = SK.db.shops[oldName]
    if not shop then return false, "Shop not found." end
    SK.db.shops[newName] = shop
    SK.db.shops[oldName] = nil
    if SK.db.activeShop == oldName then SK.db.activeShop = newName end
    DB:AddLog(newName, "Shop renamed from '"..oldName.."' to '"..newName.."'.", "system")
    return true
end

-- ─── Export / Import ──────────────────────────────────────────────────────────
-- Exports a shop's products, categories, category order, and discounts as a
-- base64-like encoded string that can be shared on Discord and imported by staff.

local B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

local function EncodeBase64(data)
    local result = {}
    local len = #data
    local i = 1
    while i <= len do
        local b1 = data:byte(i) or 0
        local b2 = data:byte(i+1) or 0
        local b3 = data:byte(i+2) or 0
        local n = b1*65536 + b2*256 + b3
        result[#result+1] = B64:sub(math.floor(n/262144)%64+1,math.floor(n/262144)%64+1)
        result[#result+1] = B64:sub(math.floor(n/4096)%64+1,  math.floor(n/4096)%64+1)
        result[#result+1] = (i+1 <= len) and B64:sub(math.floor(n/64)%64+1, math.floor(n/64)%64+1) or "="
        result[#result+1] = (i+2 <= len) and B64:sub(n%64+1, n%64+1) or "="
        i = i + 3
    end
    return table.concat(result)
end

local function DecodeBase64(s)
    s = s:gsub("[^"..B64.."=]","")
    local lut = {}
    for i=1,64 do lut[B64:sub(i,i)] = i-1 end
    local result = {}
    local i = 1
    while i <= #s do
        local c1 = lut[s:sub(i,i)]   or 0
        local c2 = lut[s:sub(i+1,i+1)] or 0
        local c3 = lut[s:sub(i+2,i+2)] or 0
        local c4 = lut[s:sub(i+3,i+3)] or 0
        local n = c1*262144 + c2*4096 + c3*64 + c4
        result[#result+1] = string.char(math.floor(n/65536)%256)
        if s:sub(i+2,i+2) ~= "=" then result[#result+1] = string.char(math.floor(n/256)%256) end
        if s:sub(i+3,i+3) ~= "=" then result[#result+1] = string.char(n%256) end
        i = i + 4
    end
    return table.concat(result)
end

-- Simple serializer: converts a Lua table of primitives to a compact string.
-- Only handles string/number/boolean values and nested tables (no functions/userdata).
local function Serialize(val, depth)
    depth = depth or 0
    local t = type(val)
    if t == "string" then
        return '"'..val:gsub('\\','\\\\'):gsub('"','\\"'):gsub('\n','\\n')..'"'
    elseif t == "number" then
        return tostring(val)
    elseif t == "boolean" then
        return tostring(val)
    elseif t == "nil" then
        return "null"
    elseif t == "table" then
        -- Detect array vs hash
        local isArray = true
        local maxN = 0
        for k,_ in pairs(val) do
            if type(k) ~= "number" or k ~= math.floor(k) or k < 1 then
                isArray = false; break
            end
            if k > maxN then maxN = k end
        end
        if isArray and maxN == #val then
            local parts = {}
            for _, v in ipairs(val) do parts[#parts+1] = Serialize(v, depth+1) end
            return "["..table.concat(parts,",").."]"
        else
            local parts = {}
            for k, v in pairs(val) do
                if type(k) == "string" or type(k) == "number" then
                    parts[#parts+1] = Serialize(tostring(k),depth+1)..":"..Serialize(v,depth+1)
                end
            end
            table.sort(parts)
            return "{"..table.concat(parts,",").."}"
        end
    end
    return "null"
end

local function Deserialize(s, pos)
    pos = pos or 1
    -- skip whitespace
    while pos <= #s and s:sub(pos,pos):match("%s") do pos=pos+1 end
    local c = s:sub(pos,pos)
    if c == '"' then
        local result, i = {}, pos+1
        while i <= #s do
            local ch = s:sub(i,i)
            if ch == '\\' then
                local nc = s:sub(i+1,i+1)
                if nc == 'n' then result[#result+1]='\n'
                elseif nc == '"' then result[#result+1]='"'
                elseif nc == '\\' then result[#result+1]='\\'
                else result[#result+1]=nc end
                i = i+2
            elseif ch == '"' then
                return table.concat(result), i+1
            else result[#result+1]=ch; i=i+1 end
        end
        return table.concat(result), i
    elseif c == '[' then
        local arr, i = {}, pos+1
        while i <= #s do
            while i <= #s and s:sub(i,i):match("%s") do i=i+1 end
            if s:sub(i,i) == ']' then return arr, i+1 end
            if #arr > 0 and s:sub(i,i) == ',' then i=i+1 end
            local v, ni = Deserialize(s, i)
            arr[#arr+1] = v; i = ni
        end
        return arr, i
    elseif c == '{' then
        local obj, i = {}, pos+1
        while i <= #s do
            while i <= #s and s:sub(i,i):match("%s") do i=i+1 end
            if s:sub(i,i) == '}' then return obj, i+1 end
            if next(obj) ~= nil and s:sub(i,i) == ',' then i=i+1 end
            local k, ni = Deserialize(s, i); i = ni
            while i <= #s and s:sub(i,i):match("%s") do i=i+1 end
            i = i+1  -- skip ':'
            local v, ni2 = Deserialize(s, i); i = ni2
            -- Convert numeric string keys back to numbers if they look like integers
            local nk = tonumber(k)
            obj[nk or k] = v
        end
        return obj, i
    elseif s:sub(pos,pos+3) == "null" then
        return nil, pos+4
    elseif s:sub(pos,pos+3) == "true" then
        return true, pos+4
    elseif s:sub(pos,pos+4) == "false" then
        return false, pos+5
    else
        local num, npos = s:match("^(-?%d+%.?%d*)", pos)
        if num then return tonumber(num), pos+#num end
        return nil, pos+1
    end
end

function DB:ExportShop(shopName)
    local shop = NormShop(shopName)
    if not shop then return nil, "Shop not found." end
    DB:MigrateShop(shop)

    -- Build a minimal export payload: products, categoryColors, categoryOrder, discounts
    local payload = {
        shopName      = shopName,
        version       = SK.VERSION,
        products      = {},
        categoryColors= {},
        categoryOrder = shop.categoryOrder,
        discounts     = shop.discounts or {},
    }
    for _, p in ipairs(shop.products) do
        payload.products[#payload.products+1] = {
            name        = p.name,
            description = p.description or "",
            priceCopper = p.priceCopper or 0,
            category    = p.category or "General",
            icon        = p.icon or 134400,
            rarity      = p.rarity or "common",
            stock       = p.stock,  -- may be nil
            sortIndex   = p.sortIndex,
            variants    = p.variants or {},
        }
    end
    for catName, col in pairs(shop.categoryColors) do
        payload.categoryColors[catName] = col
    end

    local json   = Serialize(payload)
    local encoded = EncodeBase64(json)
    -- Prefix so we can validate on import
    return "SK133:"..encoded
end

function DB:ImportShop(shopName, code)
    if not code or code:sub(1,6) ~= "SK133:" then
        return false, "Invalid export code. Make sure you copied the full code."
    end
    local encoded = code:sub(7)
    local ok, payload = pcall(function()
        local json = DecodeBase64(encoded)
        local val = Deserialize(json)
        return val
    end)
    if not ok or type(payload) ~= "table" then
        return false, "Could not decode export code. It may be corrupted."
    end

    local shop = NormShop(shopName)
    if not shop then return false, "Shop not found." end
    DB:MigrateShop(shop)

    -- Merge products: add any that don't already exist by name
    local existingNames = {}
    for _, p in ipairs(shop.products) do existingNames[p.name:lower()] = true end

    local added = 0
    if type(payload.products) == "table" then
        for _, p in ipairs(payload.products) do
            if type(p) == "table" and p.name and not existingNames[p.name:lower()] then
                local newP = {
                    id          = (function()
                        local max = 0
                        for _, ep in ipairs(shop.products) do if (ep.id or 0) > max then max = ep.id end end
                        return max + 1
                    end)(),
                    name        = p.name,
                    description = p.description or "",
                    priceCopper = tonumber(p.priceCopper) or 0,
                    category    = p.category or "General",
                    icon        = tonumber(p.icon) or 134400,
                    rarity      = p.rarity or "common",
                    stock       = tonumber(p.stock),  -- may be nil
                    sortIndex   = tonumber(p.sortIndex),
                    variants    = type(p.variants) == "table" and p.variants or {},
                }
                tinsert(shop.products, newP)
                existingNames[p.name:lower()] = true
                added = added + 1
            end
        end
    end

    -- Merge category colors
    if type(payload.categoryColors) == "table" then
        for catName, col in pairs(payload.categoryColors) do
            if type(col) == "table" and col[1] and col[2] and col[3] then
                shop.categoryColors[catName] = col
            end
        end
    end

    -- Merge category order (append new entries)
    if type(payload.categoryOrder) == "table" then
        local seen = {}
        for _, n in ipairs(shop.categoryOrder) do seen[n] = true end
        for _, n in ipairs(payload.categoryOrder) do
            if not seen[n] then
                tinsert(shop.categoryOrder, n)
                seen[n] = true
            end
        end
    end

    -- Merge discounts (add if label doesn't already exist)
    if type(payload.discounts) == "table" then
        local existDisc = {}
        for _, d in ipairs(shop.discounts or {}) do existDisc[d.label:lower()] = true end
        for _, d in ipairs(payload.discounts) do
            if type(d) == "table" and d.label and not existDisc[d.label:lower()] then
                tinsert(shop.discounts, {label=d.label, pct=tonumber(d.pct) or 10})
                existDisc[d.label:lower()] = true
            end
        end
    end

    DB:BumpProductSeq(shopName)
    DB:AddLog(shopName, string.format("Shop imported from export code: %d products added.", added), "system")
    return true, added
end

-- ─── Products by Category ─────────────────────────────────────────────────────

function DB:GetProductsByCategory(shopName)
    local shop = NormShop(shopName)
    local cats, order = {}, {}
    for _, p in ipairs(DB:GetProducts(shopName)) do
        local cat = p.category or "General"
        if not cats[cat] then cats[cat]={} ; tinsert(order, cat) end
        tinsert(cats[cat], p)
    end
    -- Within each category, sort products by their manual sortIndex
    for _, list in pairs(cats) do
        table.sort(list, function(a, b)
            local sa = a.sortIndex or 0
            local sb = b.sortIndex or 0
            if sa == sb then return (a.name or "") < (b.name or "") end
            return sa < sb
        end)
    end
    -- Sort by custom categoryOrder if defined, else alphabetically
    local customOrder = shop and shop.categoryOrder
    if customOrder and #customOrder > 0 then
        -- Build lookup: catName -> position
        local pos = {}
        for i, name in ipairs(customOrder) do pos[name] = i end
        table.sort(order, function(a, b)
            local pa = pos[a] or 999
            local pb = pos[b] or 999
            if pa == pb then return a < b end
            return pa < pb
        end)
    else
        table.sort(order)
    end
    return cats, order
end

-- ─── Orders ───────────────────────────────────────────────────────────────────
-- Order structure:
-- { id, timestamp, items[], totalCopper, paymentType, status,
--   sellerOOC, sellerIC, buyerOOC, buyerIC, deliveryNote,
--   notes }
-- paymentType: "paid" | "favor" | "delivery" | "commission"
-- status: "open" | "in_progress" | "ready" | "complete"

function DB:CreateOrder(shopName, orderData)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    local order = {
        id           = NextID(shop.orders),
        timestamp    = time(),
        items        = orderData.items        or {},
        totalCopper  = orderData.totalCopper  or 0,
        paymentType  = orderData.paymentType  or "paid",
        status       = orderData.status       or "open",
        sellerOOC    = orderData.sellerOOC    or "",
        sellerIC     = orderData.sellerIC     or "",
        buyerOOC     = orderData.buyerOOC     or "",
        buyerIC      = orderData.buyerIC      or "",
        deliveryNote = orderData.deliveryNote or "",
        notes        = orderData.notes        or "",
        checkedItems = orderData.checkedItems or {},
        -- New fields
        assignedTo      = "",   -- IC name of staff member working on it
        estimatedMinutes= 0,    -- 0 = not set
        claimedAt       = 0,    -- timestamp when claimed
    }
    tinsert(shop.orders, order)
    DB:BumpOrderSeq(shopName)
    DB:AddLog(shopName, string.format("Order #%d created (%s, %s)",
        order.id, order.paymentType, SK:FormatMoneyPlain(order.totalCopper)), "order")
    return true, order
end

-- Claim an order for the current player (unclaims any other order they held)
function DB:ClaimOrder(shopName, orderID, staffName, estimatedMinutes)
    local shop = NormShop(shopName)
    if not shop then return false, "Shop not found." end
    DB:MigrateShop(shop)
    -- Release any other order this person already claimed
    for _, o in ipairs(shop.orders) do
        if o.assignedTo == staffName and o.id ~= orderID then
            o.assignedTo = ""
            o.claimedAt  = 0
        end
    end
    for _, o in ipairs(shop.orders) do
        if o.id == orderID then
            if o.status == "complete" then
                return false, "This order is already complete."
            end
            if o.assignedTo ~= "" and o.assignedTo ~= staffName then
                return false, o.assignedTo.." is already working on this order."
            end
            o.assignedTo       = staffName
            o.estimatedMinutes = estimatedMinutes or 0
            o.claimedAt        = time()
            o.status           = "in_progress"
            DB:BumpOrderSeq(shopName)
            DB:AddLog(shopName, string.format("Order #%d claimed by %s (ETA: %d min)",
                orderID, staffName, o.estimatedMinutes), "order")
            return true
        end
    end
    return false, "Order not found."
end

function DB:UnclaimOrder(shopName, orderID)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    for _, o in ipairs(shop.orders) do
        if o.id == orderID then
            if o.status == "complete" then return false end  -- can't release completed orders
            DB:AddLog(shopName, string.format("Order #%d released by %s",
                orderID, o.assignedTo), "order")
            o.assignedTo       = ""
            o.estimatedMinutes = 0
            o.claimedAt        = 0
            o.status           = "open"
            DB:BumpOrderSeq(shopName)
            return true
        end
    end
    return false
end

function DB:UpdateOrderStatus(shopName, orderID, status)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    for _, o in ipairs(shop.orders) do
        if o.id==orderID then
            local prev = o.status
            o.status = status
            DB:BumpOrderSeq(shopName)
            DB:AddLog(shopName, string.format("Order #%d -> %s", orderID, status), "order")
            -- Add to treasury when a paid order is completed
            if status == "complete" and prev ~= "complete" then
                if o.paymentType == "paid" and o.totalCopper > 0 then
                    shop.treasury = (shop.treasury or 0) + o.totalCopper
                    DB:AddLog(shopName, string.format("Treasury +%s (Order #%d complete)",
                        SK:FormatMoneyPlain(o.totalCopper), orderID), "treasury")
                end
                -- Decrease stock for each item in the order
                for _, item in ipairs(o.items or {}) do
                    if item.product and item.product.id then
                        DB:DecreaseStock(shopName, item.product.id, item.qty or 1)
                    end
                end
            end
            return true
        end
    end
    return false
end

function DB:GetOrders(shopName)
    local shop = NormShop(shopName)
    if not shop then return {} end
    DB:MigrateShop(shop)
    return shop.orders
end

-- Toggle the checked state of a single item (by 1-based index) on an order.
-- checkedItems is a hash of index -> true for ticked items.
function DB:SetOrderItemChecked(shopName, orderID, itemIndex, checked)
    local shop = NormShop(shopName)
    if not shop then return end
    for _, o in ipairs(shop.orders) do
        if o.id == orderID then
            o.checkedItems = o.checkedItems or {}
            if checked then
                o.checkedItems[itemIndex] = true
            else
                o.checkedItems[itemIndex] = nil
            end
            DB:BumpOrderSeq(shopName)
            return
        end
    end
end

-- ─── Tabs (open tavern tabs) ──────────────────────────────────────────────────
-- Tab structure:
-- { id, timestamp, holders, openedBy, paymentMode, deposit, items[], status }
-- paymentMode: "deposit" (coin paid up front) | "end" (settle at end of night)
-- status: "open" | "closed"

function DB:BumpTabSeq(shopName)
    local shop = NormShop(shopName)
    if not shop then return end
    shop.tabSeq = (shop.tabSeq or 0) + 1
end

function DB:CreateTab(shopName, tabData)
    local shop = NormShop(shopName)
    if not shop then return false, "Shop not found." end
    DB:MigrateShop(shop)
    if not tabData.holders or strtrim(tabData.holders) == "" then
        return false, "Tab holder name required."
    end
    local tab = {
        id          = NextID(shop.tabs),
        timestamp   = time(),
        holders     = strtrim(tabData.holders),
        openedBy    = tabData.openedBy or SK:GetRPName() or "",
        paymentMode = tabData.paymentMode or "end",
        deposit     = tonumber(tabData.deposit) or 0,
        items       = {},
        status      = "open",
    }
    tinsert(shop.tabs, tab)
    DB:BumpTabSeq(shopName)
    DB:AddLog(shopName, string.format("Tab #%d opened for %s (by %s)",
        tab.id, tab.holders, tab.openedBy), "tab")
    -- Deposit/prepaid coin is collected up front, so it enters the treasury now.
    if (tab.paymentMode == "deposit" or tab.paymentMode == "prepaid") and tab.deposit > 0 then
        shop.treasury = (shop.treasury or 0) + tab.deposit
        DB:AddLog(shopName, string.format("Treasury +%s (Tab #%d deposit)",
            SK:FormatMoneyPlain(tab.deposit), tab.id), "treasury")
    end
    return true, tab
end

function DB:GetTabs(shopName)
    local shop = NormShop(shopName)
    if not shop then return {} end
    DB:MigrateShop(shop)
    return shop.tabs
end

function DB:GetTab(shopName, tabID)
    local shop = NormShop(shopName)
    if not shop then return nil end
    DB:MigrateShop(shop)
    for _, t in ipairs(shop.tabs) do
        if t.id == tabID then return t end
    end
    return nil
end

-- Compute the running total of a tab's items (in copper)
function DB:GetTabTotal(tab)
    if not tab then return 0 end
    local t = 0
    for _, e in ipairs(tab.items or {}) do
        local unit = (e.variant and e.variant.priceCopper) or (e.product and e.product.priceCopper) or 0
        t = t + unit * (e.qty or 1)
    end
    return t
end

-- Add an item (product + optional variant) to a tab. Stacks by product+variant.
function DB:AddTabItem(shopName, tabID, product, variant, qty)
    local tab = DB:GetTab(shopName, tabID)
    if not tab then return false, "Tab not found." end
    if tab.status ~= "open" then return false, "Tab is closed." end
    qty = qty or 1
    local vkey = variant and variant.name or ""
    for _, e in ipairs(tab.items) do
        if e.product and e.product.id == product.id and (e.variantKey or "") == vkey then
            e.qty = (e.qty or 1) + qty
            DB:BumpTabSeq(shopName)
            return true
        end
    end
    tinsert(tab.items, {
        product    = {id=product.id, name=product.name, priceCopper=product.priceCopper, icon=product.icon},
        variant    = variant,
        variantKey = vkey,
        qty        = qty,
    })
    DB:BumpTabSeq(shopName)
    local dn = product.name .. (vkey ~= "" and (" ("..vkey..")") or "")
    DB:AddLog(shopName, string.format("Tab #%d: added %dx %s", tabID, qty, dn), "tab")
    return true
end

-- Remove one of an item from a tab (by index in tab.items)
function DB:RemoveTabItem(shopName, tabID, itemIndex)
    local tab = DB:GetTab(shopName, tabID)
    if not tab then return false end
    if tab.status ~= "open" then return false, "Tab is closed." end
    local e = tab.items[itemIndex]
    if not e then return false end
    e.qty = (e.qty or 1) - 1
    if e.qty <= 0 then tremove(tab.items, itemIndex) end
    DB:BumpTabSeq(shopName)
    return true
end

-- Close (settle) a tab. If paymentMode is "end" the total is added to treasury;
-- for "deposit" tabs, only the overflow beyond the deposit is added.
function DB:CloseTab(shopName, tabID, tipCopper)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    local tab = DB:GetTab(shopName, tabID)
    if not tab then return false, "Tab not found." end
    if tab.status == "closed" then return false, "Tab already closed." end
    tipCopper = tonumber(tipCopper) or 0
    if tipCopper < 0 then tipCopper = 0 end
    local total = DB:GetTabTotal(tab)
    tab.status   = "closed"
    tab.closedAt = time()
    tab.tip      = tipCopper
    -- Decrease stock for each item now that the tab is settled
    for _, e in ipairs(tab.items or {}) do
        if e.product and e.product.id then
            DB:DecreaseStock(shopName, e.product.id, e.qty or 1)
        end
    end
    -- Treasury handling
    local toTreasury
    if tab.paymentMode == "deposit" or tab.paymentMode == "prepaid" then
        -- deposit/prepaid already collected up front at open; add only the
        -- balance owed beyond what was prepaid
        toTreasury = math.max(0, total - (tab.deposit or 0))
    else
        toTreasury = total
    end
    toTreasury = toTreasury + tipCopper
    -- Record exactly what we credited so a later reopen can reverse it cleanly
    tab.settledToTreasury = toTreasury
    if toTreasury > 0 then
        shop.treasury = (shop.treasury or 0) + toTreasury
        local extra = tipCopper > 0 and (" incl. "..SK:FormatMoneyPlain(tipCopper).." tip") or ""
        DB:AddLog(shopName, string.format("Treasury +%s (Tab #%d settled%s)",
            SK:FormatMoneyPlain(toTreasury), tabID, extra), "treasury")
    end
    DB:BumpTabSeq(shopName)
    DB:AddLog(shopName, string.format("Tab #%d closed for %s (total: %s)",
        tabID, tab.holders, SK:FormatMoneyPlain(total)), "tab")
    return true, total
end

-- Reopen a closed tab: reverses the treasury credit and stock deduction that
-- CloseTab applied, so the tab can be edited and re-settled cleanly.
function DB:ReopenTab(shopName, tabID)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    local tab = DB:GetTab(shopName, tabID)
    if not tab then return false, "Tab not found." end
    if tab.status ~= "closed" then return false, "Tab is not closed." end
    -- Reverse the treasury credit recorded at close
    local credited = tab.settledToTreasury or 0
    if credited > 0 then
        shop.treasury = math.max(0, (shop.treasury or 0) - credited)
        DB:AddLog(shopName, string.format("Treasury -%s (Tab #%d reopened)",
            SK:FormatMoneyPlain(credited), tabID), "treasury")
    end
    -- Restore stock that was deducted at close
    for _, e in ipairs(tab.items or {}) do
        if e.product and e.product.id then
            local p = nil
            for _, pp in ipairs(shop.products) do if pp.id == e.product.id then p = pp; break end end
            if p and p.stock ~= nil then p.stock = p.stock + (e.qty or 1) end
        end
    end
    tab.status            = "open"
    tab.closedAt          = nil
    tab.settledToTreasury = nil
    tab.tip               = nil
    DB:BumpProductSeq(shopName)
    DB:BumpTabSeq(shopName)
    DB:AddLog(shopName, string.format("Tab #%d reopened for %s", tabID, tab.holders), "tab")
    return true
end

-- Edit an open tab's settings (holders, payment mode, deposit). Adjusts the
-- treasury for any change to the up-front deposit amount.
function DB:EditTab(shopName, tabID, fields)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    local tab = DB:GetTab(shopName, tabID)
    if not tab then return false, "Tab not found." end
    if tab.status ~= "open" then return false, "Tab is closed." end
    if fields.holders ~= nil and strtrim(fields.holders) ~= "" then
        tab.holders = strtrim(fields.holders)
    end
    local oldMode    = tab.paymentMode
    local oldDeposit = (oldMode == "deposit" or oldMode == "prepaid") and (tab.deposit or 0) or 0
    if fields.paymentMode ~= nil then tab.paymentMode = fields.paymentMode end
    if fields.deposit ~= nil then tab.deposit = tonumber(fields.deposit) or 0 end
    -- New effective up-front deposit after the edit
    local newDeposit = (tab.paymentMode == "deposit" or tab.paymentMode == "prepaid") and (tab.deposit or 0) or 0
    local delta = newDeposit - oldDeposit
    if delta ~= 0 then
        shop.treasury = math.max(0, (shop.treasury or 0) + delta)
        DB:AddLog(shopName, string.format("Treasury %s%s (Tab #%d deposit changed)",
            delta >= 0 and "+" or "-", SK:FormatMoneyPlain(math.abs(delta)), tabID), "treasury")
    end
    DB:BumpTabSeq(shopName)
    DB:AddLog(shopName, string.format("Tab #%d edited", tabID), "tab")
    return true
end

function DB:DeleteTab(shopName, tabID)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    for i, t in ipairs(shop.tabs) do
        if t.id == tabID then
            tremove(shop.tabs, i)
            DB:BumpTabSeq(shopName)
            DB:AddLog(shopName, string.format("Tab #%d deleted", tabID), "tab")
            return true
        end
    end
    return false
end

-- ─── Logs ─────────────────────────────────────────────────────────────────────

function DB:GetLogs(shopName)
    local shop = NormShop(shopName)
    if not shop then return {} end
    DB:MigrateShop(shop)
    return shop.logs
end

function DB:AddLog(shopName, message, category)
    local shop = NormShop(shopName)
    if not shop then return end
    DB:MigrateShop(shop)
    message = message:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r","")
    local entry = { timestamp=time(), message=message, category=category or "system" }
    tinsert(shop.logs, entry)
    while #shop.logs > 200 do tremove(shop.logs, 1) end
    if SK.Net and SK.Net.BroadcastLog then
        SK.Net:BroadcastLog(shopName, entry)
    end
end

function DB:DeleteOrder(shopName, orderID)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    for i, o in ipairs(shop.orders) do
        if o.id == orderID then
            tremove(shop.orders, i)
            DB:BumpOrderSeq(shopName)
            DB:AddLog(shopName, string.format("Order #%d deleted", orderID))
            return true
        end
    end
    return false
end

function DB:DeleteLog(shopName, index)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    if shop.logs[index] then
        tremove(shop.logs, index)
        return true
    end
    return false
end

function DB:ClearLogs(shopName)
    local shop = NormShop(shopName)
    if not shop then return false end
    DB:MigrateShop(shop)
    shop.logs = {}
    return true
end

-- ─── Discounts ────────────────────────────────────────────────────────────────

function DB:GetDiscounts(shopName)
    local shop = NormShop(shopName)
    if not shop then return {} end
    shop.discounts = shop.discounts or {}
    return shop.discounts
end

function DB:AddDiscount(shopName, label, pct)
    local shop = NormShop(shopName)
    if not shop then return false, "Shop not found." end
    shop.discounts = shop.discounts or {}
    pct = tonumber(pct) or 0
    if pct <= 0 or pct > 100 then return false, "Discount must be 1–100%." end
    if label == "" then return false, "Label required." end
    tinsert(shop.discounts, {label=label, pct=pct})
    DB:AddLog(shopName, "Discount added: "..label.." ("..pct.."%)")
    return true
end

function DB:DeleteDiscount(shopName, idx)
    local shop = NormShop(shopName)
    if not shop or not shop.discounts then return false end
    tremove(shop.discounts, idx)
    return true
end

function DB:MigrateShopDiscounts(shop)
    if not shop then return end
    shop.discounts = shop.discounts or {}
end

-- ─── Order Expiry ─────────────────────────────────────────────────────────────
-- Checks all claimed orders across all shops and releases any that have passed
-- their estimated completion time. Returns a list of {shopName, orderID} released.

function DB:CheckOrderExpiry()
    local now = time()
    local released = {}
    for shopName, shop in pairs(SK.db.shops or {}) do
        DB:MigrateShop(shop)
        for _, order in ipairs(shop.orders) do
            if order.claimedAt and order.claimedAt > 0
               and order.estimatedMinutes and order.estimatedMinutes > 0 then
                local deadline = order.claimedAt + order.estimatedMinutes * 60
                if now > deadline and order.status ~= "complete" then
                    -- Release the order back to unclaimed
                    order.assignedTo       = ""   -- was wrongly clearing claimedBy
                    order.claimedAt        = 0
                    order.estimatedMinutes = 0
                    order.status           = "open"
                    DB:BumpOrderSeq(shopName)
                    tinsert(released, {shopName=shopName, orderID=order.id})
                    DB:AddLog(shopName, "Order #"..order.id.." expired and was released for reclaiming.", "order")
                end
            end
        end
    end
    return released
end
