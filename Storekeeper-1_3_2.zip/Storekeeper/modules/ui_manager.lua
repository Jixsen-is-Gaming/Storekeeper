-- Storekeeper: Manager UI — Guild & Communities visual style

Storekeeper.Manager = Storekeeper.Manager or {}
local SK = Storekeeper
local M  = SK.Manager

M.isOpen    = false
M.activeTab = "products"
M.editingProd = nil

local PAD = 8

-- ─── Helpers ──────────────────────────────────────────────────────────────────

local function FS(parent, text, size, r, g, b)
    -- Wrap in a Frame so it can be reparented/hidden on tab switch
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(300, size and (size+4) or 15)
    local fs = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    fs:SetFont("Fonts\\FRIZQT__.TTF", size or 11, "")
    fs:SetText(text or "")
    fs:SetTextColor(r or 1, g or 1, b or 1, 1)
    fs:SetPoint("LEFT", 0, 0)
    -- Proxy key methods so callers can use the wrapper like a FontString
    f.SetText  = function(_, t) fs:SetText(t) end
    f.GetText  = function(_) return fs:GetText() end
    f.SetTextColor = function(_, r2,g2,b2,a2) fs:SetTextColor(r2,g2,b2,a2 or 1) end
    f.SetPoint_FS  = f.SetPoint  -- keep original for layout
    return f
end

local function HLine(parent, y)
    -- Wrap in a Frame so it can be reparented
    local f = CreateFrame("Frame", nil, parent)
    f:SetHeight(1)
    f:SetPoint("TOPLEFT", PAD, y); f:SetPoint("TOPRIGHT", -PAD, y)
    local t = f:CreateTexture(nil, "ARTWORK"); t:SetAllPoints()
    t:SetColorTexture(0.35, 0.30, 0.20, 0.6)
    return f
end

local function Btn(parent, text, w, h)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(w or 80, h or 22); b:SetText(text or ""); return b
end

local function Box(parent, w, h)
    local e = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
    e:SetSize(w or 150, h or 20); e:SetAutoFocus(false)
    e:SetScript("OnEscapePressed", function(s) s:ClearFocus() end); return e
end

-- ─── Content Wipe ─────────────────────────────────────────────────────────────

local function GetContentPanel()
    return M.contentPanel
end

-- Graveyard: hidden frame to park orphaned widgets so they don't render
local _graveyard = CreateFrame("Frame", "StorekeeperGraveyard", UIParent)
_graveyard:Hide(); _graveyard:SetSize(1,1); _graveyard:SetPoint("CENTER",UIParent,"CENTER",10000,10000)

local function Bury(w)
    if not w then return end
    if w.ClearAllPoints then w:ClearAllPoints() end
    if w.Hide           then w:Hide() end
    if w.SetParent      then w:SetParent(_graveyard); w:Hide() end
end

local function WipeContent()
    local p = M.contentPanel
    if not p then return end
    for _, w in ipairs(M.contentChildren or {}) do Bury(w) end
    M.contentChildren = {}
    local skip = SK.Register and SK.Register.registerContent
    for _, child in ipairs({p:GetChildren()}) do
        if child and child ~= skip then Bury(child) end
    end
end

local function Track(w)
    tinsert(M.contentChildren, w)
    return w
end


-- ─── PRODUCTS TAB ─────────────────────────────────────────────────────────────

function M:BuildProductTab()
    WipeContent()
    local p   = GetContentPanel()
    local pw  = p:GetWidth() - PAD*2
    local shopName = SK.db and SK.db.activeShop

    if not shopName then
        local l = Track(FS(p, "No shop active. Open the Shops tab to create one.", 11, 0.65, 0.65, 0.65))
        l:SetPoint("CENTER"); return
    end

    local sf = Track(CreateFrame("ScrollFrame", nil, p, "UIPanelScrollFrameTemplate"))
    sf:SetPoint("TOPLEFT", PAD, -PAD); sf:SetPoint("BOTTOMRIGHT", -PAD-18, 244)
    local sc = CreateFrame("Frame", nil, sf)
    sc:SetWidth(sf:GetWidth()-4); sc:SetHeight(1); sf:SetScrollChild(sc)

    local products = SK.DB:GetProducts(shopName)
    local rh, yo = 30, 0

    -- Column layout constants — defined once, shared by header and every data row.
    -- sc width = sf_width - 4 = (content_W - PAD - (PAD+18)) - 4 = content_W - 38
    -- This must match exactly or rows overflow the scroll child and clip the buttons.
    local EDIT_W, DEL_W, GAP = 38, 34, 4
    local BTN_BLOCK = EDIT_W + DEL_W + GAP + 8
    local W       = p:GetWidth() - 38          -- exact scroll child width
    local NAME_W  = math.floor(W * 0.38)
    local CAT_X   = 28 + NAME_W + 4
    local CAT_W   = math.floor(W * 0.18)
    local PRC_X   = CAT_X + CAT_W + 4
    local PRC_W   = math.floor(W * 0.12)
    local STK_X   = PRC_X + PRC_W + 4
    local STK_W   = 36

    -- Header row
    local function ColHdr(txt, x, w, justify)
        local l = sc:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        l:SetPoint("TOPLEFT", x, -4)
        l:SetSize(w, 14)
        l:SetJustifyH(justify or "LEFT")
        l:SetText(txt)
        l:SetTextColor(1, 0.82, 0, 1)
    end
    ColHdr("Ic.",      2,       24,     "LEFT")
    ColHdr("Name",     28,      NAME_W, "LEFT")
    ColHdr("Category", CAT_X,   CAT_W,  "CENTER")
    ColHdr("Price",    PRC_X,   PRC_W,  "CENTER")
    ColHdr("Stock",    STK_X,   STK_W,  "LEFT")
    yo = 18

    if #products == 0 then
        local nl = sc:CreateFontString(nil,"OVERLAY","GameFontDisable")
        nl:SetPoint("TOPLEFT",4,-yo-6); nl:SetText("No products yet. Add one below.")
        sc:SetHeight(yo+30)
    end

    for idx, prod in ipairs(products) do
        local row = CreateFrame("Frame", nil, sc, "BackdropTemplate")
        row:SetSize(W, rh); row:SetPoint("TOPLEFT", 0, -yo)
        row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8"})
        row:SetBackdropColor(0, 0, 0, idx%2==0 and 0.20 or 0.05)

        local ic = row:CreateTexture(nil,"ARTWORK"); ic:SetSize(22,22); ic:SetPoint("LEFT",2,0)
        ic:SetTexture(type(prod.icon)=="number" and prod.icon or 134400)
        ic:SetTexCoord(0.08,0.92,0.08,0.92)

        local n = row:CreateFontString(nil,"OVERLAY","GameFontNormal"); n:SetFont("Fonts\\FRIZQT__.TTF",10,"")
        n:SetPoint("LEFT",28,4); n:SetSize(NAME_W,14); n:SetText(prod.name)
        local RCOL={poor={0.62,0.62,0.62},common={1,1,1},uncommon={0.12,1,0},rare={0,0.44,0.87},epic={0.64,0.21,0.93},legendary={1,0.5,0}}
        local rc2=RCOL[prod.rarity or "common"] or {1,1,1}
        n:SetTextColor(rc2[1],rc2[2],rc2[3],1)
        local d = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        d:SetPoint("LEFT",28,-7); d:SetSize(NAME_W,12)
        d:SetText(prod.description~="" and prod.description or ""); d:SetTextColor(0.5,0.5,0.5,1)

        local cat = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        cat:SetPoint("LEFT",CAT_X,0); cat:SetSize(CAT_W,rh); cat:SetText(prod.category or "General")

        local pr = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        pr:SetPoint("LEFT",PRC_X,0); pr:SetSize(math.max(PRC_W,20),rh)
        pr:SetText(SK:FormatMoney(prod.priceCopper))

        -- Stock column — separate from Price
        if prod.stock ~= nil then
            local stk = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            stk:SetPoint("LEFT", STK_X, 0); stk:SetSize(STK_W, rh)
            local stkcol = prod.stock<=0 and "FF4444" or prod.stock<=5 and "FFCC00" or "88FF88"
            stk:SetText("|cff"..stkcol..tostring(prod.stock).."|r")
        end

        local pid = prod.id
        local myR = SK.DB:GetRole(shopName, UnitName("player"))
        local shop0 = SK.DB:GetShop(shopName); SK.DB:MigrateShop(shop0)
        local canEditProd = (myR=="owner") or (myR=="manager" and shop0.perms.mgrsCanProducts~=false)
        if canEditProd then
            local eb = Btn(row,"Edit",EDIT_W,18); eb:SetPoint("RIGHT",-(DEL_W+GAP+2),0)
            local db = Btn(row,"Del",DEL_W,18);  db:SetPoint("RIGHT",-2,0)
            eb:SetScript("OnClick", function() M:OpenEditor(pid) end)
            db:SetScript("OnClick", function()
                SK.DB:DeleteProduct(shopName,pid); M:SwitchTab("products")
                if SK.Register and SK.Register.BuildProductGrid then SK.Register:BuildProductGrid() end
                if SK.Net then SK.Net:BroadcastProducts(shopName) end
            end)
        end
        yo = yo + rh + 2
    end
    sc:SetHeight(math.max(yo+4, 30))

    -- Form — only shown if user can edit products
    local myR0 = SK.DB:GetRole(shopName, UnitName("player"))
    local shop00 = SK.DB:GetShop(shopName); if shop00 then SK.DB:MigrateShop(shop00) end
    local canShowForm = (myR0=="owner") or (myR0=="manager" and (not shop00 or shop00.perms.mgrsCanProducts~=false))
    if not canShowForm then return end  -- employees see read-only list
    local form = Track(CreateFrame("Frame", nil, p, "BackdropTemplate"))
    form:SetPoint("BOTTOMLEFT",0,0); form:SetPoint("BOTTOMRIGHT",0,0); form:SetHeight(240)
    form:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    form:SetBackdropColor(0.05,0.06,0.10,1.0); form:SetBackdropBorderColor(0.45,0.35,0.12,0.9)

    FS(form,"Add / Edit Product",11,1,0.82,0):SetPoint("TOPLEFT",PAD,-8)

    -- Dropdown to load an existing product into the form
    local loadLbl = FS(form,"Load existing:",9,0.6,0.6,0.6); loadLbl:SetPoint("TOPLEFT",PAD,-24)
    local loadBtn = CreateFrame("Button",nil,form,"BackdropTemplate")
    loadBtn:SetSize(pw,18); loadBtn:SetPoint("TOPLEFT",PAD,-36)
    loadBtn:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    loadBtn:SetBackdropColor(0.08,0.08,0.12,1); loadBtn:SetBackdropBorderColor(0.3,0.3,0.4,1)
    local loadLblTxt=loadBtn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    loadLblTxt:SetPoint("LEFT",4,0); loadLblTxt:SetText("— select to load —")
    loadLblTxt:SetTextColor(0.55,0.55,0.55,1)
    local loadArrow=loadBtn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    loadArrow:SetPoint("RIGHT",-4,0); loadArrow:SetText("v"); loadArrow:SetTextColor(0.7,0.7,0.7,1)
    loadBtn:SetScript("OnClick",function(self)
        local prods = SK.DB:GetProducts(shopName)
        if #prods==0 then return end

        local ROW_H      = 20
        local MAX_ROWS   = 8   -- max visible rows before scroll kicks in
        local INNER_PAD  = 4   -- left/right inset inside backdrop
        local visible    = math.min(#prods, MAX_ROWS)
        local menuH      = visible * ROW_H + 6   -- 3px top + 3px bottom padding
        local innerW     = pw - INNER_PAD * 2

        -- Outer backdrop frame (fixed height, never grows beyond MAX_ROWS)
        local menu = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
        menu:SetFrameStrata("FULLSCREEN")
        menu:SetSize(pw, menuH)
        menu:SetPoint("TOPLEFT", self, "BOTTOMLEFT", 0, 0)
        menu:SetBackdrop({
            bgFile   = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            edgeSize = 10,
            insets   = {left=3, right=3, top=3, bottom=3},
        })
        menu:SetBackdropColor(0.06, 0.06, 0.10, 0.98)
        menu:SetBackdropBorderColor(0.5, 0.38, 0.10, 1)
        menu:EnableMouseWheel(true)

        -- Clip region sits just inside the backdrop insets
        local clip = CreateFrame("Frame", nil, menu)
        clip:SetPoint("TOPLEFT",     menu, "TOPLEFT",      INNER_PAD, -3)
        clip:SetPoint("BOTTOMRIGHT", menu, "BOTTOMRIGHT", -INNER_PAD,  3)
        clip:SetClipsChildren(true)

        -- Scrollable child — taller than the clip when list exceeds MAX_ROWS
        local child = CreateFrame("Frame", nil, clip)
        local totalH = #prods * ROW_H
        child:SetSize(innerW, totalH)
        child:SetPoint("TOPLEFT", clip, "TOPLEFT", 0, 0)

        local function CloseMenu()
            menu:Hide(); menu:SetParent(nil)
        end

        -- Build item buttons inside the child frame
        for i, prod in ipairs(prods) do
            local item = CreateFrame("Button", nil, child)
            item:SetSize(innerW, ROW_H)
            item:SetPoint("TOPLEFT", 0, -(i-1) * ROW_H)
            local itxt = item:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            itxt:SetAllPoints(); itxt:SetJustifyH("LEFT")
            itxt:SetText(prod.name); itxt:SetTextColor(0.85, 0.85, 0.85, 1)
            local pid, pname = prod.id, prod.name
            item:SetScript("OnEnter", function() itxt:SetTextColor(1, 0.82, 0, 1) end)
            item:SetScript("OnLeave", function() itxt:SetTextColor(0.85, 0.85, 0.85, 1) end)
            item:SetScript("OnClick", function()
                M:OpenEditor(pid)
                loadLblTxt:SetText(pname); loadLblTxt:SetTextColor(1, 0.82, 0, 1)
                CloseMenu()
            end)
        end

        -- Scroll state (offset in pixels from the top of the child)
        local scrollY = 0
        local function SetScroll(newY)
            local maxY = math.max(0, totalH - (visible * ROW_H))
            scrollY = math.max(0, math.min(newY, maxY))
            child:SetPoint("TOPLEFT", clip, "TOPLEFT", 0, scrollY)
        end

        menu:SetScript("OnMouseWheel", function(_, delta)
            SetScroll(scrollY - delta * ROW_H)
        end)

        -- Subtle scroll indicator when the list is longer than MAX_ROWS
        if #prods > MAX_ROWS then
            local arrow = menu:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            arrow:SetPoint("BOTTOMRIGHT", -6, 3)
            arrow:SetText("|cff888888v|r")
        end

        -- Close on outside click
        local closer = CreateFrame("Frame", nil, UIParent)
        closer:SetAllPoints(); closer:EnableMouse(true)
        closer:SetFrameStrata("FULLSCREEN")
        closer:SetScript("OnMouseDown", function()
            CloseMenu(); closer:Hide(); closer:SetParent(nil)
        end)
        menu:SetFrameLevel(closer:GetFrameLevel() + 1)
        child:SetFrameLevel(menu:GetFrameLevel() + 1)
    end)

    local nameW = math.floor(pw*0.55); local catW = pw - nameW - 8
    FS(form,"Name",9,0.7,0.7,0.7):SetPoint("TOPLEFT",PAD,-58)
    FS(form,"Category",9,0.7,0.7,0.7):SetPoint("TOPLEFT",PAD+nameW+8,-58)
    M.fName = Box(form,nameW,20); M.fName:SetPoint("TOPLEFT",PAD,-72)

    -- Category: plain EditBox the user types directly into, with a dropdown arrow
    -- for selecting existing categories, plus a color swatch.
    local catBtnW = catW - 28
    -- The EditBox is the source of truth — no proxy, no M.fCatName intermediate
    local catEdit = CreateFrame("EditBox",nil,form,"InputBoxTemplate")
    catEdit:SetSize(catBtnW-20,20); catEdit:SetPoint("TOPLEFT",PAD+nameW+8,-72)
    catEdit:SetAutoFocus(false); catEdit:SetMaxLetters(64)
    catEdit:SetText("General")
    catEdit:SetScript("OnEscapePressed",function(s) s:ClearFocus() end)
    M.fCatEdit = catEdit  -- SaveProduct reads this directly

    -- Small dropdown arrow button to the right of the editbox
    local catArrowBtn = CreateFrame("Button",nil,form,"BackdropTemplate")
    catArrowBtn:SetSize(18,20); catArrowBtn:SetPoint("LEFT",catEdit,"RIGHT",2,0)
    catArrowBtn:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    catArrowBtn:SetBackdropColor(0.08,0.08,0.12,1); catArrowBtn:SetBackdropBorderColor(0.35,0.28,0.10,0.8)
    local catArrowLbl=catArrowBtn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    catArrowLbl:SetAllPoints(); catArrowLbl:SetText("v"); catArrowLbl:SetTextColor(0.7,0.7,0.7,1)

    -- Color swatch button
    local colorSwatch=CreateFrame("Button",nil,form,"BackdropTemplate")
    colorSwatch:SetSize(22,20); colorSwatch:SetPoint("LEFT",catArrowBtn,"RIGHT",4,0)
    colorSwatch:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    colorSwatch:SetBackdropColor(1,0.82,0,1); colorSwatch:SetBackdropBorderColor(0.5,0.4,0.1,1)

    M.fCatColor = {1,0.82,0}
    local function UpdateCatColor()
        local r,g,b = M.fCatColor[1],M.fCatColor[2],M.fCatColor[3]
        colorSwatch:SetBackdropColor(r,g,b,1)
    end

    -- When user finishes typing a category name, load its color
    catEdit:SetScript("OnEditFocusLost",function(s)
        local txt = strtrim(s:GetText())
        if txt=="" then s:SetText("General"); txt="General" end
        local sn = SK.db and SK.db.activeShop
        if sn then
            local r,g,b = SK.DB:GetCategoryColor(sn,txt)
            M.fCatColor={r,g,b}; UpdateCatColor()
        end
    end)

    -- Color swatch
    colorSwatch:SetScript("OnClick",function()
        local pr,pg,pb = M.fCatColor[1],M.fCatColor[2],M.fCatColor[3]
        local function ApplyColor()
            local r,g,b
            if ColorPickerFrame.GetColorRGB then
                r,g,b = ColorPickerFrame:GetColorRGB()
            elseif ColorPickerFrame.Content and ColorPickerFrame.Content.ColorPicker then
                r,g,b = ColorPickerFrame.Content.ColorPicker:GetColorRGB()
            end
            if r then
                M.fCatColor={r,g,b}; UpdateCatColor()
                local sn = SK.db and SK.db.activeShop
                local catName = strtrim(catEdit:GetText())
                if sn and catName~="" then SK.DB:SetCategoryColor(sn,catName,r,g,b) end
            end
        end
        if ColorPickerFrame.SetupColorPickerAndShow then
            ColorPickerFrame:SetupColorPickerAndShow({r=pr,g=pg,b=pb,hasOpacity=false,
                swatchFunc=ApplyColor,cancelFunc=function() M.fCatColor={pr,pg,pb}; UpdateCatColor() end})
        else
            ColorPickerFrame.func=ApplyColor; ColorPickerFrame.hasOpacity=false
            ColorPickerFrame.cancelFunc=function() M.fCatColor={pr,pg,pb}; UpdateCatColor() end
            if ColorPickerFrame.SetColorRGB then ColorPickerFrame:SetColorRGB(pr,pg,pb) end
            ColorPickerFrame:Hide(); ColorPickerFrame:Show()
        end
    end)
    colorSwatch:SetScript("OnEnter",function(s)
        GameTooltip:SetOwner(s,"ANCHOR_TOP"); GameTooltip:AddLine("Category colour",1,1,1)
        GameTooltip:AddLine("Click to change this category's colour.",0.7,0.7,0.7); GameTooltip:Show()
    end)
    colorSwatch:SetScript("OnLeave",function() GameTooltip:Hide() end)

    -- Dropdown arrow: shows existing categories to pick from
    catArrowBtn:SetScript("OnClick",function(self)
        local cats,seen={},{}
        for _, p in ipairs(SK.DB:GetProducts(shopName)) do
            local cn=p.category or "General"
            if not seen[cn] then seen[cn]=true; tinsert(cats,cn) end
        end
        if not seen["General"] then tinsert(cats,1,"General") end
        if #cats==0 then return end
        local closer=CreateFrame("Frame",nil,UIParent)
        closer:SetAllPoints(); closer:EnableMouse(true); closer:SetFrameStrata("FULLSCREEN")
        local menu=CreateFrame("Frame",nil,UIParent,"BackdropTemplate")
        menu:SetFrameStrata("FULLSCREEN"); menu:SetWidth(catBtnW)
        menu:SetPoint("TOPLEFT",catEdit,"BOTTOMLEFT",0,0)
        menu:SetHeight(math.min(#cats,8)*20+6)
        menu:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",
            edgeSize=10,insets={left=3,right=3,top=3,bottom=3}})
        menu:SetBackdropColor(0.06,0.06,0.10,0.98); menu:SetBackdropBorderColor(0.5,0.38,0.10,1)
        menu:SetFrameLevel(closer:GetFrameLevel()+1)
        local my=-3
        for _, cn in ipairs(cats) do
            local r,g,b=SK.DB:GetCategoryColor(shopName,cn)
            local item=CreateFrame("Button",nil,menu)
            item:SetSize(catBtnW-8,18); item:SetPoint("TOPLEFT",4,my)
            local itxt=item:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            itxt:SetAllPoints(); itxt:SetJustifyH("LEFT")
            itxt:SetText(cn); itxt:SetTextColor(r,g,b,1)
            local cn2=cn
            item:SetScript("OnEnter",function() itxt:SetTextColor(1,0.95,0.5,1) end)
            item:SetScript("OnLeave",function() itxt:SetTextColor(r,g,b,1) end)
            item:SetScript("OnClick",function()
                catEdit:SetText(cn2)
                M.fCatColor={r,g,b}; UpdateCatColor()
                menu:Hide(); menu:SetParent(nil)
                closer:Hide(); closer:SetParent(nil)
            end)
            my=my-20
        end
        closer:SetScript("OnMouseDown",function()
            menu:Hide(); menu:SetParent(nil); closer:Hide(); closer:SetParent(nil)
        end)
    end)

    FS(form,"Description",9,0.7,0.7,0.7):SetPoint("TOPLEFT",PAD,-96)
    M.fDesc = Box(form,pw,20); M.fDesc:SetPoint("TOPLEFT",PAD,-110)

    FS(form,"Price",9,0.7,0.7,0.7):SetPoint("TOPLEFT",PAD,-134)
    -- Price boxes: gold, silver, copper — use raw tiny label frames (not FS wrapper)
    local function CurrLabel(parent, text, r,g,b)
        local f=CreateFrame("Frame",nil,parent); f:SetSize(12,20)
        local fs=f:CreateFontString(nil,"OVERLAY","GameFontNormal")
        fs:SetFont("Fonts\\FRIZQT__.TTF",9,""); fs:SetAllPoints()
        fs:SetText(text); fs:SetTextColor(r,g,b,1); return f
    end
    M.fGold   = Box(form,38,20); M.fGold:SetPoint("TOPLEFT",PAD,-148)
    local gL  = CurrLabel(form,"g",1,0.82,0);    gL:SetPoint("LEFT",M.fGold,"RIGHT",2,0)
    M.fSilver = Box(form,38,20);             M.fSilver:SetPoint("LEFT",gL,"RIGHT",2,0)
    local sL  = CurrLabel(form,"s",0.7,0.7,0.7); sL:SetPoint("LEFT",M.fSilver,"RIGHT",2,0)
    M.fCopper = Box(form,38,20);             M.fCopper:SetPoint("LEFT",sL,"RIGHT",2,0)
    CurrLabel(form,"c",0.7,0.4,0.1):SetPoint("LEFT",M.fCopper,"RIGHT",2,0)

    local iconSz = 36; local chooseBtnW = 64
    local iconX = pw - (iconSz + 6 + chooseBtnW)
    FS(form,"Icon",9,0.7,0.7,0.7):SetPoint("TOPLEFT",PAD+iconX,-134)
    local ipf = CreateFrame("Frame",nil,form,"BackdropTemplate"); ipf:SetSize(iconSz,iconSz)
    ipf:SetPoint("TOPLEFT",PAD+iconX,-146)
    ipf:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    ipf:SetBackdropColor(0,0,0,0.5); ipf:SetBackdropBorderColor(0.4,0.35,0.2,1)
    M.fIconPreview = ipf:CreateTexture(nil,"ARTWORK"); M.fIconPreview:SetSize(28,28); M.fIconPreview:SetPoint("CENTER")
    M.fIconPreview:SetTexture(133784); M.fIconPreview:SetTexCoord(0.08,0.92,0.08,0.92)
    M.fIconName = 133784

    local chooseBtn = Btn(form,"Choose",chooseBtnW,22)
    chooseBtn:SetPoint("LEFT",ipf,"RIGHT",6,0)
    chooseBtn:SetScript("OnClick",function()
        SK.IconPicker:Toggle(function(fid, label)
            M.fIconName = fid
            if M.fIconPreview then M.fIconPreview:SetTexture(fid) end
        end, form)
    end)

    -- Rarity dropdown
    local RARITIES = {
        {key="poor",      label="Poor",      r=0.62, g=0.62, b=0.62},
        {key="common",    label="Common",    r=1,    g=1,    b=1   },
        {key="uncommon",  label="Uncommon",  r=0.12, g=1,    b=0   },
        {key="rare",      label="Rare",      r=0,    g=0.44, b=0.87},
        {key="epic",      label="Epic",      r=0.64, g=0.21, b=0.93},
        {key="legendary", label="Legendary", r=1,    g=0.5,  b=0   },
    }
    M.fRarity = "common"
    FS(form,"Rarity",9,0.7,0.7,0.7):SetPoint("TOPLEFT",PAD,-168)
    local rarBtn=CreateFrame("Button",nil,form,"BackdropTemplate")
    rarBtn:SetSize(90,20); rarBtn:SetPoint("TOPLEFT",PAD,-182)
    rarBtn:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    rarBtn:SetBackdropColor(0.06,0.06,0.10,0.95); rarBtn:SetBackdropBorderColor(0.35,0.28,0.10,0.8)
    local rarLbl=rarBtn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    rarLbl:SetPoint("LEFT",4,0); rarLbl:SetPoint("RIGHT",-14,0); rarLbl:SetJustifyH("LEFT")
    rarLbl:SetText("Common"); rarLbl:SetTextColor(1,1,1,1)
    local rarArrow=rarBtn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    rarArrow:SetPoint("RIGHT",-2,0); rarArrow:SetText("v"); rarArrow:SetTextColor(0.7,0.7,0.7,1)
    M.rarLbl = rarLbl

    local function SetRarity(key)
        M.fRarity = key
        for _, rr in ipairs(RARITIES) do
            if rr.key==key then
                rarLbl:SetText(rr.label); rarLbl:SetTextColor(rr.r,rr.g,rr.b,1)
                -- Also update the name field text color
                if M.fName and M.fName.SetTextColor then
                    M.fName:SetTextColor(rr.r,rr.g,rr.b,1)
                end
                break
            end
        end
    end
    SetRarity("common")

    rarBtn:SetScript("OnClick",function(self)
        local rcloser=CreateFrame("Frame",nil,UIParent)
        rcloser:SetAllPoints(); rcloser:EnableMouse(true); rcloser:SetFrameStrata("FULLSCREEN")
        local rmenu=CreateFrame("Frame",nil,UIParent,"BackdropTemplate")
        rmenu:SetFrameStrata("FULLSCREEN"); rmenu:SetWidth(120); rmenu:SetHeight(#RARITIES*20+6)
        rmenu:SetPoint("TOPLEFT",self,"BOTTOMLEFT",0,0)
        rmenu:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",edgeSize=10,insets={left=3,right=3,top=3,bottom=3}})
        rmenu:SetBackdropColor(0.06,0.06,0.10,0.98); rmenu:SetBackdropBorderColor(0.5,0.38,0.10,1)
        rmenu:SetFrameLevel(rcloser:GetFrameLevel()+1)
        local rmy=-3
        for _, rr in ipairs(RARITIES) do
            local ri=CreateFrame("Button",nil,rmenu)
            ri:SetSize(114,18); ri:SetPoint("TOPLEFT",4,rmy)
            local rt=ri:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); rt:SetAllPoints(); rt:SetJustifyH("LEFT")
            rt:SetText(rr.label); rt:SetTextColor(rr.r,rr.g,rr.b,1)
            local rk=rr.key
            ri:SetScript("OnEnter",function() rt:SetTextColor(1,0.95,0.5,1) end)
            ri:SetScript("OnLeave",function() rt:SetTextColor(rr.r,rr.g,rr.b,1) end)
            ri:SetScript("OnClick",function()
                SetRarity(rk); rmenu:Hide(); rmenu:SetParent(nil)
                rcloser:Hide(); rcloser:SetParent(nil)
            end)
            rmy=rmy-20
        end
        rcloser:SetScript("OnMouseDown",function()
            rmenu:Hide(); rmenu:SetParent(nil); rcloser:Hide(); rcloser:SetParent(nil)
        end)
    end)

    local saveB = Btn(form,"Save",90,22); saveB:SetPoint("BOTTOMLEFT",PAD,8)
    saveB:SetScript("OnClick",function() M:SaveProduct() end)
    local clrB  = Btn(form,"Clear",70,22); clrB:SetPoint("LEFT",saveB,"RIGHT",6,0)
    clrB:SetScript("OnClick",function() M:ClearForm() end)

    -- Stock — same row as rarity (y=-168 label, y=-183 checkbox)
    FS(form,"Stock",9,0.7,0.7,0.7):SetPoint("TOPLEFT",PAD+96,-168)

    -- Manual checkbox: a toggle button with a square visual
    local stockCb=CreateFrame("Button",nil,form,"BackdropTemplate")
    stockCb:SetSize(16,16); stockCb:SetPoint("TOPLEFT",PAD+96,-183)
    stockCb:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",
        edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    stockCb:SetBackdropColor(0.06,0.06,0.10,1); stockCb:SetBackdropBorderColor(0.45,0.35,0.12,1)
    local stockCheck=stockCb:CreateTexture(nil,"ARTWORK"); stockCheck:SetAllPoints()
    stockCheck:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
    stockCheck:SetAlpha(0)
    local stockLbl=form:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    stockLbl:SetPoint("LEFT",stockCb,"RIGHT",3,0); stockLbl:SetText("Limited")
    stockLbl:SetTextColor(0.7,0.7,0.7,1)

    M.fStockLimited = false

    local stockAmtBox=Box(form,44,20); stockAmtBox:SetPoint("LEFT",stockLbl,"RIGHT",4,0)
    stockAmtBox:SetNumeric(true); stockAmtBox:SetText("")
    stockAmtBox:SetShown(false)
    local stockAmtHint=stockAmtBox:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    stockAmtHint:SetPoint("LEFT",4,0); stockAmtHint:SetText("qty")
    stockAmtHint:SetTextColor(0.35,0.35,0.35,1)
    stockAmtBox:SetScript("OnTextChanged",function(s) stockAmtHint:SetShown(s:GetText()=="") end)
    M.fStockAmt = stockAmtBox

    stockCb:SetScript("OnClick",function()
        M.fStockLimited = not M.fStockLimited
        stockCheck:SetAlpha(M.fStockLimited and 1 or 0)
        stockCb:SetBackdropColor(M.fStockLimited and 0.08 or 0.06,
            M.fStockLimited and 0.18 or 0.06, M.fStockLimited and 0.08 or 0.10, 1)
        stockAmtBox:SetShown(M.fStockLimited)
        if M.fStockLimited and stockAmtBox:GetText()=="" then stockAmtHint:SetShown(true) end
    end)
    M.fStockCb = stockCb

    -- TRP3 Extended item checkbox — on the right side of the stock row
    -- Positioned at x=PAD+200 so it's well clear of the Save button below
    FS(form,"TRP3 Item",9,0.7,0.7,0.7):SetPoint("TOPLEFT",PAD+200,-168)
    local trpCb=CreateFrame("Button",nil,form,"BackdropTemplate")
    trpCb:SetSize(16,16); trpCb:SetPoint("TOPLEFT",PAD+200,-183)
    trpCb:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",
        edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    trpCb:SetBackdropColor(0.06,0.06,0.10,1); trpCb:SetBackdropBorderColor(0.45,0.35,0.12,1)
    local trpCheck=trpCb:CreateTexture(nil,"ARTWORK"); trpCheck:SetAllPoints()
    trpCheck:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
    trpCheck:SetAlpha(0)
    local trpLbl=form:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    trpLbl:SetPoint("LEFT",trpCb,"RIGHT",3,0)
    trpLbl:SetText("Has TRP3 item")
    trpLbl:SetTextColor(0.7,0.7,0.7,1)
    local trpIcon=form:CreateTexture(nil,"ARTWORK")
    trpIcon:SetSize(14,14); trpIcon:SetPoint("LEFT",trpLbl,"RIGHT",4,0)
    trpIcon:SetTexture("Interface\\Icons\\INV_Scroll_07")
    trpIcon:SetAlpha(0)
    M.fTRP3Item = false
    trpCb:SetScript("OnClick",function()
        M.fTRP3Item = not M.fTRP3Item
        trpCheck:SetAlpha(M.fTRP3Item and 1 or 0)
        trpIcon:SetAlpha(M.fTRP3Item and 1 or 0)
        trpCb:SetBackdropColor(0.06, 0.06, M.fTRP3Item and 0.18 or 0.10, 1)
    end)
    M.fTRP3Cb = trpCb
    M.fTRP3Check = trpCheck
    M.fTRP3Icon = trpIcon

    M:ClearForm()

end

function M:ClearForm()
    M.editingProd = nil
    if M.fName   then M.fName:SetText("") end
    if M.fCatEdit then M.fCatEdit:SetText("General") end
    M.fCatColor={1,0.82,0}
    if M.fDesc   then M.fDesc:SetText("") end
    if M.fGold   then M.fGold:SetText("0") end
    if M.fSilver then M.fSilver:SetText("0") end
    if M.fCopper then M.fCopper:SetText("0") end
    M.fIconName = 133784
    if M.fIconPreview then M.fIconPreview:SetTexture(133784) end
    M.fRarity = "common"
    if M.rarLbl then M.rarLbl:SetText("Common"); M.rarLbl:SetTextColor(1,1,1,1) end
    -- Reset stock: if currently limited, click to toggle off
    if M.fStockLimited and M.fStockCb then M.fStockCb:Click() end
    M.fStockLimited = false
    if M.fStockAmt then M.fStockAmt:SetText(""); M.fStockAmt:SetShown(false) end
    -- Reset TRP3 item checkbox
    M.fTRP3Item = false
    if M.fTRP3Check then M.fTRP3Check:SetAlpha(0) end
    if M.fTRP3Icon  then M.fTRP3Icon:SetAlpha(0) end
    if M.fTRP3Cb    then M.fTRP3Cb:SetBackdropColor(0.06,0.06,0.10,1) end
end

function M:OpenEditor(pid)
    local shopName = SK.db and SK.db.activeShop; if not shopName then return end
    for _, prod in ipairs(SK.DB:GetProducts(shopName)) do
        if prod.id == pid then
            M.editingProd = pid
            if M.fName   then M.fName:SetText(prod.name or "") end
            if M.fDesc   then M.fDesc:SetText(prod.description or "") end
            if M.fCatEdit then M.fCatEdit:SetText(prod.category or "General") end
            M.fIconName = prod.icon or 133784
            if M.fIconPreview then M.fIconPreview:SetTexture(M.fIconName) end
            M.fRarity = prod.rarity or "common"
            if M.rarLbl then
                local RMAP={poor={0.62,0.62,0.62},common={1,1,1},uncommon={0.12,1,0},
                    rare={0,0.44,0.87},epic={0.64,0.21,0.93},legendary={1,0.5,0}}
                local lbl=({poor="Poor",common="Common",uncommon="Uncommon",rare="Rare",epic="Epic",legendary="Legendary"})[M.fRarity] or "Common"
                local col=RMAP[M.fRarity] or {1,1,1}
                M.rarLbl:SetText(lbl); M.rarLbl:SetTextColor(col[1],col[2],col[3],1)
            end
            local hasStock = prod.stock ~= nil
            if hasStock ~= M.fStockLimited then
                if M.fStockCb then M.fStockCb:Click() end
            end
            M.fStockLimited = hasStock
            if M.fStockAmt then
                M.fStockAmt:SetText(hasStock and tostring(prod.stock) or "")
                M.fStockAmt:SetShown(hasStock)
            end
            -- Restore TRP3 item checkbox
            local hasTRP3 = prod.hasTRP3Item == true
            if hasTRP3 ~= M.fTRP3Item then
                if M.fTRP3Cb then M.fTRP3Cb:Click() end
            end
            local g = math.floor(prod.priceCopper/10000)
            local s = math.floor((prod.priceCopper%10000)/100)
            local cv = prod.priceCopper%100
            if M.fGold   then M.fGold:SetText(tostring(g)) end
            if M.fSilver then M.fSilver:SetText(tostring(s)) end
            if M.fCopper then M.fCopper:SetText(tostring(cv)) end
            return
        end
    end
end

function M:SaveProduct()
    local shopName = SK.db and SK.db.activeShop
    if not shopName then print("|cffFFD700[SK]|r No active shop."); return end
    local name = M.fName and strtrim(M.fName:GetText()) or ""
    if name == "" then print("|cffFFD700[SK]|r Name required."); return end
    local g = tonumber(M.fGold and M.fGold:GetText()) or 0
    local s = tonumber(M.fSilver and M.fSilver:GetText()) or 0
    local c = tonumber(M.fCopper and M.fCopper:GetText()) or 0
    local catName = (M.fCatEdit and strtrim(M.fCatEdit:GetText())~="" and strtrim(M.fCatEdit:GetText())) or "General"
    -- Save category color
    if M.fCatColor then
        SK.DB:SetCategoryColor(shopName, catName, M.fCatColor[1], M.fCatColor[2], M.fCatColor[3])
    end
    local stockVal = nil
    if M.fStockLimited then stockVal = tonumber(M.fStockAmt and M.fStockAmt:GetText()) or 0 end
    local fields = {name=name, description=M.fDesc and strtrim(M.fDesc:GetText()) or "",
        category=catName, icon=M.fIconName or 133784, priceCopper=g*10000+s*100+c,
        rarity=M.fRarity or "common", stock=stockVal, hasTRP3Item=M.fTRP3Item or false}
    if M.editingProd then
        SK.DB:EditProduct(shopName,M.editingProd,fields)
    else
        local ok,prod=SK.DB:AddProduct(shopName,fields.name,fields.description,fields.priceCopper,fields.category,fields.icon)
        if ok and prod then prod.rarity=fields.rarity; prod.stock=fields.stock; prod.hasTRP3Item=fields.hasTRP3Item end
    end
    M:ClearForm(); M:SwitchTab("products")
    if SK.Register and SK.Register.BuildProductGrid then SK.Register:BuildProductGrid() end
    if SK.Net then
        SK.Net:BroadcastProducts(shopName)
        SK.Net:BroadcastCategoryColors(shopName)
    end
end

-- ─── STAFF TAB ────────────────────────────────────────────────────────────────

function M:BuildStaffTab()
    WipeContent()
    local p0 = GetContentPanel()
    local shopName = SK.db and SK.db.activeShop
    if not shopName then local l=Track(FS(p0,"No shop active.",11,0.65,0.65,0.65)); l:SetPoint("CENTER"); return end
    local shop = SK.DB:GetShop(shopName); if not shop then return end
    SK.DB:MigrateShop(shop)

    -- Scroll frame
    local sf = Track(CreateFrame("ScrollFrame", nil, p0, "UIPanelScrollFrameTemplate"))
    sf:SetPoint("TOPLEFT", 0, 0); sf:SetPoint("BOTTOMRIGHT", -16, 0)
    local sc = CreateFrame("Frame", nil, sf)
    sc:SetWidth(sf:GetWidth()-4); sc:SetHeight(1); sf:SetScrollChild(sc)
    local p = sc

    local pw  = p0:GetWidth() - PAD*2
    local yo  = -PAD
    local myName  = UnitName("player")
    local isOwner = SK.DB:IsManager(shopName, myName)

    -- Header
    Track(FS(p,"Shop:  |cffFFD700"..shopName.."|r",12)):SetPoint("TOPLEFT",PAD,yo); yo=yo-20
    Track(FS(p,"Owner:  |cffFFD700"..shop.owner.."|r",11)):SetPoint("TOPLEFT",PAD,yo); yo=yo-22
    Track(HLine(p,yo)); yo=yo-10

    if isOwner then
        -- ── Invite new member ────────────────────────────────────────────────
        Track(FS(p,"Add Staff Member",11,1,0.82,0)):SetPoint("TOPLEFT",PAD,yo); yo=yo-22

        local invBtnW = 52
        local nameW   = pw - invBtnW - 4
        local nameInp = Track(Box(p, nameW, 22)); nameInp:SetPoint("TOPLEFT",PAD,yo)

        local function DoAdd(role)
            local target = strtrim(nameInp:GetText() or "")
            if target == "" then return end
            target = target:match("^([^%-]+)") or target  -- strip realm
            local ok, err
            if role == "manager" then
                ok, err = SK.DB:AddManager(shopName, target)
            else
                ok, err = SK.DB:AddEmployee(shopName, target)
            end
            if ok then
                nameInp:SetText("")
                SK.Net:SendInvite(shopName, target, role)
                print("|cffFFD700[SK]|r "..target.." added as "..role..".")
                M:SwitchTab("staff")
            else
                print("|cffFFD700[SK]|r "..(err or "Error."))
            end
        end

        -- Single "Add" button with role toggle
        local roleSel  = "employee"
        local roleBtn  = Track(Btn(p, "Employee", invBtnW, 22))
        roleBtn:SetPoint("LEFT", nameInp, "RIGHT", 4, 0)
        roleBtn:SetScript("OnClick", function()
            roleSel = roleSel == "employee" and "manager" or "employee"
            roleBtn:SetText(roleSel == "employee" and "Employee" or "Manager")
        end)
        roleBtn:SetScript("OnEnter", function(s)
            GameTooltip:SetOwner(s,"ANCHOR_TOP")
            GameTooltip:AddLine("Click to toggle role",1,1,1)
            GameTooltip:Show()
        end)
        roleBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
        nameInp:SetScript("OnEnterPressed", function() DoAdd(roleSel) end)
        yo = yo - 28
        Track(HLine(p,yo)); yo=yo-10

        -- ── Roster ───────────────────────────────────────────────────────────
        -- Unified list: Managers first, then Employees
        -- Each row: [Name] [Manager checkbox] [Sync] [Remove]
        Track(FS(p,"Staff Roster",11,1,0.82,0)):SetPoint("TOPLEFT",PAD,yo); yo=yo-22

        -- Column header
        local colHdr = Track(p:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"))
        colHdr:SetPoint("TOPLEFT",PAD+4,yo); colHdr:SetText("|cff888888Name")
        local colMgr = Track(p:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"))
        colMgr:SetPoint("RIGHT",sc,"RIGHT",-98,yo); colMgr:SetText("|cff888888Manager")
        yo = yo - 18

        local function RosterRow(name, isManager)
            local row = Track(CreateFrame("Frame",nil,p,"BackdropTemplate"))
            row:SetHeight(24); row:SetPoint("TOPLEFT",PAD,yo); row:SetPoint("TOPRIGHT",-PAD,yo)
            row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
            row:SetBackdropColor(0,0,0,0.15); row:SetBackdropBorderColor(0.3,0.25,0.10,0.3)

            -- Role badge
            local badge = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            badge:SetPoint("LEFT",4,0)
            if isManager then
                badge:SetText("|cffFFD700[M]|r"); badge:SetTextColor(1,0.82,0,1)
            else
                badge:SetText("|cff888888[E]|r"); badge:SetTextColor(0.6,0.6,0.6,1)
            end

            -- Name
            local nl = row:CreateFontString(nil,"OVERLAY","GameFontNormal")
            nl:SetPoint("LEFT",32,0); nl:SetText(name); nl:SetTextColor(1,1,1,1)

            -- Manager checkbox
            local cbNm = "SKStaff_"..name:gsub("[^%w]","_").."_"..(isManager and "m" or "e")
            local cb = CreateFrame("CheckButton", cbNm, row, "ChatConfigCheckButtonTemplate")
            cb:SetSize(20,20); cb:SetPoint("RIGHT",-82,0)
            cb:SetChecked(isManager)
            cb:SetScript("OnClick", function(self)
                if self:GetChecked() then
                    -- Promote to manager
                    SK.DB:RemoveEmployee(shopName, name)
                    SK.DB:AddManager(shopName, name)
                else
                    -- Demote to employee
                    SK.DB:RemoveManager(shopName, name)
                    SK.DB:AddEmployee(shopName, name)
                end
                M:SwitchTab("staff")
            end)
            cb:SetScript("OnEnter", function(s)
                GameTooltip:SetOwner(s,"ANCHOR_TOP")
                GameTooltip:AddLine(isManager and "Demote to Employee" or "Promote to Manager",1,1,1)
                GameTooltip:Show()
            end)
            cb:SetScript("OnLeave", function() GameTooltip:Hide() end)
            Track(cb)

            -- Sync button
            local sb = Btn(row,"Sync",44,18); sb:SetPoint("RIGHT",-36,0)
            local n = name
            sb:SetScript("OnClick",function() SK.Net:SyncProducts(shopName,n) end)
            Track(sb)

            -- Remove button
            local rb = Btn(row,"X",28,18); rb:SetPoint("RIGHT",-4,0)
            rb:SetScript("OnClick",function()
                SK.Net:SendKick(shopName,n)
                if isManager then SK.DB:RemoveManager(shopName,n)
                else SK.DB:RemoveEmployee(shopName,n) end
                M:SwitchTab("staff")
            end)
            Track(rb)

            yo = yo - 26
        end

        -- Managers first, then employees
        for _, name in ipairs(shop.managers)  do RosterRow(name, true)  end
        for _, name in ipairs(shop.employees) do RosterRow(name, false) end

        if #shop.managers == 0 and #shop.employees == 0 then
            local nl = Track(FS(p,"No staff yet. Add someone above.",10,0.55,0.55,0.55))
            nl:SetPoint("TOPLEFT",PAD+4,yo); yo=yo-20
        end

        yo=yo-8; Track(HLine(p,yo)); yo=yo-10

        -- Sync All
        local syncAllBtn = Track(Btn(p,"Sync Products to All Staff",200,24))
        syncAllBtn:SetPoint("TOPLEFT",PAD,yo); yo=yo-32
        syncAllBtn:SetScript("OnClick",function()
            for _,n in ipairs(shop.managers)  do SK.Net:SyncProducts(shopName,n) end
            for _,n in ipairs(shop.employees) do SK.Net:SyncProducts(shopName,n) end
            print("|cffFFD700[SK]|r Synced to all staff.")
        end)

    else
        -- ── Non-owner view ───────────────────────────────────────────────────
        local myRole = SK.DB:GetRole(shopName, myName) or "member"
        Track(FS(p,"Your role:  |cffFFD700"..myRole.."|r",11)):SetPoint("TOPLEFT",PAD,yo); yo=yo-22

        Track(FS(p,"Managers",11,1,0.82,0)):SetPoint("TOPLEFT",PAD,yo); yo=yo-20
        if #shop.managers==0 then Track(FS(p,"None.",10,0.55,0.55,0.55)):SetPoint("TOPLEFT",PAD+4,yo); yo=yo-18 end
        for _,name in ipairs(shop.managers) do Track(FS(p,name,10)):SetPoint("TOPLEFT",PAD+4,yo); yo=yo-18 end
        yo=yo-6; Track(HLine(p,yo)); yo=yo-10

        Track(FS(p,"Employees",11,1,0.82,0)):SetPoint("TOPLEFT",PAD,yo); yo=yo-20
        if #shop.employees==0 then Track(FS(p,"None.",10,0.55,0.55,0.55)):SetPoint("TOPLEFT",PAD+4,yo); yo=yo-18 end
        for _,name in ipairs(shop.employees) do Track(FS(p,name,10)):SetPoint("TOPLEFT",PAD+4,yo); yo=yo-18 end
        yo=yo-10; Track(HLine(p,yo)); yo=yo-10

        local syncBtn = Track(Btn(p,"Request Sync",120,24))
        syncBtn:SetPoint("TOPLEFT",PAD,yo)
        syncBtn:SetScript("OnClick",function() if SK.Net then SK.Net:RequestSync(shopName) end end)
        syncBtn:SetScript("OnEnter",function(s)
            GameTooltip:SetOwner(s,"ANCHOR_TOP")
            GameTooltip:AddLine("Request Full Sync",1,1,1)
            GameTooltip:AddLine("Asks the owner to push products,\nroster and all orders to you.",0.7,0.7,0.7)
            GameTooltip:Show()
        end)
        syncBtn:SetScript("OnLeave",function() GameTooltip:Hide() end)

        local leaveBtn = Track(Btn(p,"Leave Shop",110,24))
        leaveBtn:SetPoint("TOPLEFT",PAD+128,yo)
        leaveBtn:SetScript("OnClick",function()
            StaticPopupDialogs["SK_LEAVE_CONFIRM"] = {
                text="Leave |cffFFD700"..shopName.."|r? This removes it from your shops list.",
                button1="Leave", button2="Cancel",
                OnAccept=function() SK.Net:Leave(shopName) end,
                timeout=0, whileDead=true, hideOnEscape=true,
            }
            StaticPopup_Show("SK_LEAVE_CONFIRM")
        end)
    end
    sc:SetHeight(math.max(math.abs(yo) + 60, 400))
end

-- ─── ORDERS TAB ───────────────────────────────────────────────────────────────

local STATUS_COLORS  = {open={1,0.6,0.1,1},in_progress={0.3,0.7,1,1},ready={0.2,1,0.4,1},complete={0.5,0.5,0.5,1}}
local STATUS_LABELS  = {open="Open",in_progress="In Progress",ready="Ready",complete="Complete"}
local PAYMENT_LABELS = {paid="Paid in Full",favor="Favour",delivery="Pay on Delivery",commission="Commission"}

local function FormatETA(order)
    if not order.claimedAt or order.claimedAt == 0 then return nil end
    if not order.estimatedMinutes or order.estimatedMinutes == 0 then return nil end
    local elapsed  = math.floor((time() - order.claimedAt) / 60)
    local remaining = order.estimatedMinutes - elapsed
    if remaining <= 0 then
        return "|cffFF4444Overdue by "..(math.abs(remaining)).." min|r"
    else
        return "|cff44FF44~"..remaining.." min remaining|r"
    end
end

function M:BuildOrdersTab()
    WipeContent()
    local p = GetContentPanel()
    local shopName = SK.db and SK.db.activeShop
    if not shopName then local l=Track(FS(p,"No shop active.",11,0.65,0.65,0.65)); l:SetPoint("CENTER"); return end

    local myName  = SK:GetRPName()
    local isOwner = SK.DB:IsManager(shopName, UnitName("player"))

    -- For non-owners: show a Request Sync button at the top
    local topOffset = -PAD
    if not isOwner then
        local syncBtn = Track(Btn(p, "Request Order Sync", 160, 22))
        syncBtn:SetPoint("TOPRIGHT", -PAD-18, topOffset)
        syncBtn:SetScript("OnClick", function()
            if SK.Net then SK.Net:RequestOrderSync(shopName) end
        end)
        GameTooltip:SetOwner(syncBtn, "ANCHOR_BOTTOM")
        syncBtn:SetScript("OnEnter", function(s)
            GameTooltip:SetOwner(s, "ANCHOR_BOTTOM")
            GameTooltip:AddLine("Request Order Sync", 1, 1, 1)
            GameTooltip:AddLine("Asks the shop owner to push\nall current orders to you.", 0.7, 0.7, 0.7)
            GameTooltip:Show()
        end)
        syncBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
        topOffset = topOffset - 30
    end

    local sf=Track(CreateFrame("ScrollFrame",nil,p,"UIPanelScrollFrameTemplate"))
    sf:SetPoint("TOPLEFT",PAD,topOffset); sf:SetPoint("BOTTOMRIGHT",-PAD-18,PAD)
    local sc=CreateFrame("Frame",nil,sf); sc:SetWidth(sf:GetWidth()-4); sc:SetHeight(1); sf:SetScrollChild(sc)

    local orders=SK.DB:GetOrders(shopName)
    local sorted={}; for i=#orders,1,-1 do tinsert(sorted,orders[i]) end

    if #sorted==0 then
        local nl=sc:CreateFontString(nil,"OVERLAY","GameFontDisable")
        nl:SetPoint("TOPLEFT",4,-10); nl:SetText("No orders yet."); sc:SetHeight(30); return
    end

    local yo,W=0,sc:GetWidth()
    for _,order in ipairs(sorted) do
        -- Migrate old orders that lack new fields
        order.assignedTo       = order.assignedTo       or ""
        order.estimatedMinutes = order.estimatedMinutes or 0
        order.claimedAt        = order.claimedAt        or 0

        local sc_col = STATUS_COLORS[order.status] or {0.7,0.7,0.7,1}
        local isAssigned = (order.assignedTo ~= "")
        local isMine     = (order.assignedTo == myName)
        local eta        = FormatETA(order)

        -- Calculate row height based on content lines
        local extraLines = 0
        if order.sellerIC~="" then extraLines=extraLines+1 end
        if order.buyerIC~="" then extraLines=extraLines+1 end
        if order.deliveryNote~="" then extraLines=extraLines+1 end
        if isAssigned then extraLines=extraLines+1 end
        if eta then extraLines=extraLines+1 end
        -- Extra space for ETA input row when order is free to claim
        local isFree = not isAssigned
        if isFree then extraLines=extraLines+1 end

        local rh = 84 + extraLines*13

        local row=CreateFrame("Frame",nil,sc,"BackdropTemplate")
        row:SetSize(W,rh); row:SetPoint("TOPLEFT",0,-yo)
        row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
        row:SetBackdropColor(0,0,0,0.18)
        row:SetBackdropBorderColor(sc_col[1]*0.4,sc_col[2]*0.4,sc_col[3]*0.4,1)

        -- Header line
        local hdr=row:CreateFontString(nil,"OVERLAY","GameFontNormal")
        hdr:SetFont("Fonts\\FRIZQT__.TTF",10,"OUTLINE"); hdr:SetPoint("TOPLEFT",6,-5)
        hdr:SetText(string.format("Order #%d  |cff888888%s|r  —  %s  —  |c"..
            string.format("ff%02x%02x%02x",sc_col[1]*255,sc_col[2]*255,sc_col[3]*255).."%s|r",
            order.id, date("%d/%m/%Y",order.timestamp),
            PAYMENT_LABELS[order.paymentType] or order.paymentType,
            STATUS_LABELS[order.status] or order.status))

        -- Items + total
        local items={}
        for _,e in ipairs(order.items) do tinsert(items,e.qty.."x "..e.product.name) end
        local il=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        il:SetPoint("TOPLEFT",6,-18); il:SetSize(W*0.65,14)
        il:SetText(table.concat(items,", ")); il:SetTextColor(0.82,0.82,0.82,1)
        local tl=row:CreateFontString(nil,"OVERLAY","GameFontNormal")
        tl:SetPoint("TOPRIGHT",-6,-18); tl:SetText(SK:FormatMoney(order.totalCopper))

        -- Info lines
        local iy=32
        local function InfoLine(text, r, g, b)
            local l=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            l:SetPoint("TOPLEFT",6,-iy); l:SetText(text)
            l:SetTextColor(r or 0.65, g or 0.65, b or 0.65, 1)
            iy=iy+13
        end

        if order.sellerIC~="" then InfoLine("Seller: "..order.sellerIC) end
        if order.buyerIC~="" then
            local buyerLine = "Buyer: "..order.buyerIC
            local ooc = order.buyerOOC or ""
            if ooc~="" and ooc~=order.buyerIC then
                buyerLine = buyerLine.."  ("..ooc..")"
            end
            InfoLine(buyerLine)
        elseif (order.buyerOOC or "")~="" then
            InfoLine("Buyer: ("..order.buyerOOC..")")
        end
        if order.deliveryNote~="" then InfoLine("Delivery: "..order.deliveryNote) end

        -- Assignment line (prominent if in progress)
        if isAssigned then
            local assignText = "Working on it: |cffFFD700"..order.assignedTo.."|r"
            if order.estimatedMinutes > 0 then
                assignText = assignText.."  (ETA "..order.estimatedMinutes.." min)"
            end
            InfoLine(assignText, 0.9, 0.85, 0.4)
        end
        if eta then InfoLine(eta, 1, 1, 1) end

        -- ── Bottom control strip ──────────────────────────────────────────
        local DEL_W  = 44
        local CLAIM_W= 80
        -- Status buttons only shown when order is claimed (by me or manager sees all)
        -- Rules:
        --   Free order   -> only Claim button, status buttons hidden
        --   My claim     -> Claim(Release) + status buttons active
        --   Others claim -> Claim(locked) + status buttons locked
        --   Complete     -> backwards status locked, release locked
        local canSeeStatus = isMine or isOwner
        local statusW = W - 12 - DEL_W - CLAIM_W - 8
        local sbCount = 4
        local bw = math.floor((statusW - (sbCount-1)*2) / sbCount)

        local statusBtns = {
            {key="open",label="Open"},
            {key="in_progress",label="In Progress"},
            {key="ready",label="Ready"},
            {key="complete",label="Complete"},
        }
        for i,sb in ipairs(statusBtns) do
            local sbtn=CreateFrame("Button",nil,row,"BackdropTemplate")
            sbtn:SetSize(bw,18); sbtn:SetPoint("BOTTOMLEFT",4+(i-1)*(bw+2),-4)
            sbtn:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
            local active=(order.status==sb.key)
            local bc=active and sc_col or {0.1,0.1,0.12,1}
            sbtn:SetBackdropColor(bc[1]*(active and 0.35 or 1),bc[2]*(active and 0.35 or 1),bc[3]*(active and 0.35 or 1),1)
            sbtn:SetBackdropBorderColor(active and sc_col[1] or 0.28,active and sc_col[2] or 0.28,active and sc_col[3] or 0.28,1)
            local lbl=sbtn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            lbl:SetAllPoints(); lbl:SetText(sb.label)
            lbl:SetTextColor(active and 1 or 0.6,active and 1 or 0.6,active and 1 or 0.6,1)
            local oid,skey=order.id,sb.key
            local completeLock = (order.status=="complete") and (skey~="complete")
            -- Hide entirely for unclaimed orders (only claimer/manager can change status)
            if not canSeeStatus or (not isAssigned and not isOwner) then
                sbtn:Hide()
            elseif completeLock or (isAssigned and not isMine and not isOwner) then
                sbtn:SetEnabled(false); sbtn:SetAlpha(0.35)
            end
            sbtn:SetScript("OnClick",function()
                if not canSeeStatus then return end
                if completeLock then return end
                if isAssigned and not isMine and not isOwner then return end
                SK.DB:UpdateOrderStatus(shopName,oid,skey)
                local shop2 = SK.DB:GetShop(shopName)
                if shop2 and SK.Net then
                    for _, o in ipairs(shop2.orders) do
                        if o.id == oid then SK.Net:BroadcastOrder(shopName, o); break end
                    end
                end
                if SK:Cfg().notifyOrderStatus ~= false then
                    print("|cffFFD700[SK]|r Order #"..oid.." -> "..skey)
                end
                M:SwitchTab("orders")
            end)
        end

        -- Claim / Release button
        local claimBtn=CreateFrame("Button",nil,row,"BackdropTemplate")
        claimBtn:SetSize(CLAIM_W,18)
        claimBtn:SetPoint("BOTTOMRIGHT",-(DEL_W+6),-4)
        claimBtn:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})

        if isMine then
            -- I hold it — show Release
            claimBtn:SetBackdropColor(0.35,0.10,0.10,1)
            claimBtn:SetBackdropBorderColor(0.7,0.2,0.2,1)
            local cl=claimBtn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            cl:SetAllPoints(); cl:SetText("Release"); cl:SetTextColor(1,0.5,0.5,1)
            local oid=order.id
            claimBtn:SetScript("OnClick",function()
                SK.DB:UnclaimOrder(shopName,oid)
                local shop2 = SK.DB:GetShop(shopName)
                if shop2 and SK.Net then
                    for _, o in ipairs(shop2.orders) do
                        if o.id == oid then SK.Net:BroadcastOrder(shopName, o); break end
                    end
                end
                M:SwitchTab("orders")
            end)
        elseif isAssigned then
            -- Someone else holds it — greyed out, show who
            claimBtn:SetBackdropColor(0.08,0.08,0.08,1)
            claimBtn:SetBackdropBorderColor(0.25,0.25,0.25,1)
            local cl=claimBtn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            cl:SetAllPoints(); cl:SetText("Claimed"); cl:SetTextColor(0.45,0.45,0.45,1)
        else
            -- Free to claim — show Claim + ETA input
            claimBtn:SetBackdropColor(0.08,0.18,0.08,1)
            claimBtn:SetBackdropBorderColor(0.2,0.55,0.2,1)
            local cl=claimBtn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            cl:SetAllPoints(); cl:SetText("Claim"); cl:SetTextColor(0.4,1,0.4,1)

            -- ETA row sits ABOVE the bottom strip so it doesn't overlap status buttons
            local etaRow=CreateFrame("Frame",nil,row)
            etaRow:SetSize(CLAIM_W+DEL_W+6, 20)
            etaRow:SetPoint("BOTTOMRIGHT",-2, 26)

            local etaLabel=etaRow:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            etaLabel:SetPoint("LEFT",0,0); etaLabel:SetText("ETA:")
            etaLabel:SetTextColor(0.65,0.65,0.65,1)

            local etaBox=CreateFrame("EditBox",nil,etaRow,"InputBoxTemplate")
            etaBox:SetSize(36,16); etaBox:SetPoint("LEFT",etaLabel,"RIGHT",4,0)
            etaBox:SetAutoFocus(false); etaBox:SetNumeric(true)
            etaBox:SetMaxLetters(4); etaBox:SetText("")
            etaBox:SetScript("OnEscapePressed",function(s) s:ClearFocus() end)

            -- Unit dropdown: minutes / hours / days / weeks
            local UNITS = {
                {label="min",  mult=1},
                {label="hrs",  mult=60},
                {label="days", mult=1440},
                {label="wks",  mult=10080},
            }
            local selUnit = 1  -- index into UNITS

            local unitBtn=CreateFrame("Button",nil,etaRow,"BackdropTemplate")
            unitBtn:SetSize(34,16); unitBtn:SetPoint("LEFT",etaBox,"RIGHT",2,0)
            unitBtn:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
            unitBtn:SetBackdropColor(0.10,0.10,0.14,1); unitBtn:SetBackdropBorderColor(0.4,0.4,0.5,1)
            local unitLbl=unitBtn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            unitLbl:SetAllPoints(); unitLbl:SetText(UNITS[selUnit].label); unitLbl:SetTextColor(0.85,0.85,0.85,1)
            unitBtn:SetScript("OnClick",function()
                selUnit = (selUnit % #UNITS) + 1
                unitLbl:SetText(UNITS[selUnit].label)
            end)
            unitBtn:SetScript("OnEnter",function(s)
                GameTooltip:SetOwner(s,"ANCHOR_TOP")
                GameTooltip:AddLine("Click to change unit",1,1,1)
                GameTooltip:AddLine("min / hrs / days / wks",0.7,0.7,0.7)
                GameTooltip:Show()
            end)
            unitBtn:SetScript("OnLeave",function() GameTooltip:Hide() end)

            local function GetETAMinutes()
                local n = tonumber(etaBox:GetText()) or 0
                return n * UNITS[selUnit].mult
            end

            -- Buyer name field (required before claiming)
            local buyerRow=CreateFrame("Frame",nil,row)
            buyerRow:SetSize(CLAIM_W+DEL_W+6+60, 20)
            buyerRow:SetPoint("BOTTOMRIGHT",-2, 48)
            local buyerLabel=buyerRow:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            buyerLabel:SetPoint("LEFT",0,0); buyerLabel:SetText("Buyer:")
            buyerLabel:SetTextColor(0.65,0.65,0.65,1)
            local buyerBox=CreateFrame("EditBox",nil,buyerRow,"InputBoxTemplate")
            buyerBox:SetSize(CLAIM_W+DEL_W+6+60-50,16); buyerBox:SetPoint("LEFT",buyerLabel,"RIGHT",4,0)
            buyerBox:SetAutoFocus(false); buyerBox:SetMaxLetters(64)
            buyerBox:SetText(order.buyerIC~="" and order.buyerIC or (order.buyerOOC~="" and order.buyerOOC or ""))
            buyerBox:SetScript("OnEscapePressed",function(s) s:ClearFocus() end)

            local oid=order.id
            claimBtn:SetScript("OnClick",function()
                local buyerName = strtrim(buyerBox:GetText())
                if buyerName=="" then
                    buyerBox:SetText(""); buyerBox:SetFocus()
                    print("|cffFFD700[SK]|r Please enter the buyer\'s name before claiming.")
                    return
                end
                local mins=GetETAMinutes()
                -- Save buyer name to order
                local shop2 = SK.DB:GetShop(shopName)
                if shop2 then
                    for _, o in ipairs(shop2.orders) do
                        if o.id == oid then
                            o.buyerIC  = buyerName
                            o.buyerOOC = buyerName
                            break
                        end
                    end
                end
                local ok,err=SK.DB:ClaimOrder(shopName,oid,myName,mins)
                if ok then
                    if shop2 and SK.Net then
                        for _, o in ipairs(shop2.orders) do
                            if o.id == oid then SK.Net:BroadcastOrder(shopName, o); break end
                        end
                        SK.Net:BroadcastClaimNotice(shopName, oid, myName, mins)
                    end
                    local etaStr = mins > 0 and " (ETA: "..mins.." min)" or ""
                    print("|cffFFD700[SK]|r Order #"..oid.." claimed"..etaStr..".")
                    M:SwitchTab("orders")
                else print("|cffFFD700[SK]|r "..(err or "Could not claim.")) end
            end)
            claimBtn:SetScript("OnEnter",function()
                GameTooltip:SetOwner(claimBtn,"ANCHOR_TOP")
                GameTooltip:AddLine("Claim this order",1,1,1)
                GameTooltip:AddLine("Enter estimated minutes, then click Claim.",0.7,0.7,0.7)
                GameTooltip:Show()
            end)
            claimBtn:SetScript("OnLeave",function() GameTooltip:Hide() end)
        end

        -- Delete button
        local delOrd=Btn(row,"Delete",DEL_W,18); delOrd:SetPoint("BOTTOMRIGHT",-2,-4)
        local oid=order.id
        delOrd:SetScript("OnClick",function()
            SK.DB:DeleteOrder(shopName,oid)
            if SK.Net then SK.Net:BroadcastOrderDelete(shopName, oid) end
            M:SwitchTab("orders")
        end)

        yo=yo+rh+10
    end
    sc:SetHeight(math.max(yo,30))
end

-- ─── LOGS TAB ─────────────────────────────────────────────────────────────────

function M:BuildLogsTab()
    WipeContent()
    local p = GetContentPanel()
    if not p then return end  -- content panel not ready (can happen during tab switch)
    local pw = p:GetWidth()-PAD*2
    local shopName = SK.db and SK.db.activeShop
    if not shopName then local l=Track(FS(p,"No shop active.",11,0.65,0.65,0.65)); l:SetPoint("CENTER"); return end

    -- Filter tabs
    local FILTERS = {
        {key="all",      label="All"},
        {key="treasury", label="Treasury"},
        {key="order",    label="Orders"},
        {key="product",  label="Products"},
        {key="staff",    label="Staff"},
    }
    M._logFilter = M._logFilter or "all"

    local TAB_H = 24
    local CLEAR_W = 62  -- width reserved for the Clear button
    local tabW  = math.floor((pw - CLEAR_W - 4) / #FILTERS)
    local filterBtns = {}
    for i, ft in ipairs(FILTERS) do
        local fb=Track(CreateFrame("Button",nil,p,"BackdropTemplate"))
        fb:SetSize(tabW,TAB_H); fb:SetPoint("TOPLEFT",PAD+(i-1)*tabW,-PAD)
        fb:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
        local lbl=fb:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); lbl:SetAllPoints()
        lbl:SetText(ft.label); lbl:SetJustifyH("CENTER")
        fb.key=ft.key; fb.lbl=lbl
        tinsert(filterBtns, fb)
        local function Refresh()
            for _, b in ipairs(filterBtns) do
                local on=(b.key==M._logFilter)
                b:SetBackdropColor(on and 0.12 or 0.06, on and 0.12 or 0.06, on and 0.18 or 0.10, 1)
                b:SetBackdropBorderColor(on and 0.5 or 0.25, on and 0.38 or 0.25, on and 0.10 or 0.10, 1)
                b.lbl:SetTextColor(on and 1 or 0.65, on and 0.82 or 0.65, on and 0 or 0.65, 1)
            end
        end
        fb:SetScript("OnClick",function()
            M._logFilter = ft.key
            M:SwitchTab("logs")  -- go through SwitchTab so content panel is always valid
        end)
        Refresh()
    end

    -- Clear All — sits in the filter tab row at the far right, raised above scroll content
    local clearAllBtn=Track(Btn(p,"Clear",58,TAB_H))
    clearAllBtn:SetPoint("TOPRIGHT",-PAD,-PAD)
    clearAllBtn:SetFrameLevel(clearAllBtn:GetFrameLevel()+10)
    clearAllBtn:SetScript("OnClick",function()
        SK.DB:ClearLogs(shopName)
        M:SwitchTab("logs")
    end)

    -- Scroll frame below filter tabs
    local sf=Track(CreateFrame("ScrollFrame",nil,p,"UIPanelScrollFrameTemplate"))
    sf:SetPoint("TOPLEFT",PAD,-(PAD+TAB_H+8))
    sf:SetPoint("BOTTOMRIGHT",-PAD-18,PAD)
    local sc=CreateFrame("Frame",nil,sf); sc:SetWidth(sf:GetWidth()-4); sc:SetHeight(1); sf:SetScrollChild(sc)

    local logs=SK.DB:GetLogs(shopName)
    -- Filter
    local filtered={}
    for i=#logs,1,-1 do
        local log=logs[i]
        if M._logFilter=="all" or (log.category or "system")==M._logFilter then
            tinsert(filtered, {entry=log, idx=i})
        end
    end

    if #filtered==0 then
        local nl=sc:CreateFontString(nil,"OVERLAY","GameFontDisable")
        nl:SetPoint("TOPLEFT",4,-10); nl:SetText("No entries for this filter."); sc:SetHeight(30); return
    end

    -- Color per category
    local CAT_COLOR = {
        treasury={1,0.82,0.2},  order={0.4,0.8,1},  product={0.6,1,0.6},
        staff={1,0.6,0.8},      system={0.6,0.6,0.6},
    }

    local yo,rh=0,20
    for _, item in ipairs(filtered) do
        local log=item.entry; local realIdx=item.idx
        local col=CAT_COLOR[log.category or "system"] or {0.6,0.6,0.6}
        local row=CreateFrame("Frame",nil,sc); row:SetSize(sc:GetWidth(),rh); row:SetPoint("TOPLEFT",0,-yo)
        local catDot=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        catDot:SetPoint("LEFT",2,0); catDot:SetSize(8,rh)
        catDot:SetText("•"); catDot:SetTextColor(col[1],col[2],col[3],1)
        local txt=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        txt:SetPoint("LEFT",14,0); txt:SetPoint("RIGHT",row,"RIGHT",-22,0); txt:SetHeight(rh)
        txt:SetJustifyV("MIDDLE"); txt:SetNonSpaceWrap(false)
        txt:SetText("|cff777777"..date("[%d/%m %H:%M]",log.timestamp).."|r  "..log.message)
        local xBtn=CreateFrame("Button",nil,row); xBtn:SetSize(16,16); xBtn:SetPoint("RIGHT",-2,0)
        local xTex=xBtn:CreateTexture(nil,"ARTWORK"); xTex:SetAllPoints()
        xTex:SetTexture("Interface\\Buttons\\UI-StopButton"); xTex:SetTexCoord(0.15,0.85,0.15,0.85)
        xTex:SetVertexColor(0.6,0.2,0.2,1)
        xBtn:SetScript("OnEnter",function() xTex:SetVertexColor(1,0.3,0.3,1) end)
        xBtn:SetScript("OnLeave",function() xTex:SetVertexColor(0.6,0.2,0.2,1) end)
        xBtn:SetScript("OnClick",function() SK.DB:DeleteLog(shopName,realIdx); M:BuildLogsTab() end)
        yo=yo+rh
    end
    sc:SetHeight(math.max(yo,30))
end

-- ─── SHOPS TAB ────────────────────────────────────────────────────────────────

function M:BuildShopsTab()
    WipeContent()
    local p0 = GetContentPanel(); local pw0 = p0:GetWidth()-PAD*2

    -- Wrap in scroll frame
    local sf = Track(CreateFrame("ScrollFrame", nil, p0, "UIPanelScrollFrameTemplate"))
    sf:SetPoint("TOPLEFT", 0, 0); sf:SetPoint("BOTTOMRIGHT", -16, PAD)
    local sc = CreateFrame("Frame", nil, sf)
    sc:SetWidth(sf:GetWidth()-4); sc:SetHeight(1); sf:SetScrollChild(sc)
    local p = sc
    local pw = sc:GetWidth()-PAD*2
    local myName = UnitName("player") or ""
    local shops = SK.DB:GetAllShops()
    local activeShop = SK.db.activeShop
    local activeData = activeShop and SK.DB:GetShop(activeShop)
    local isOwner = activeShop and SK.DB:GetRole(activeShop,myName)=="owner"
    local isManager = activeShop and SK.DB:IsManager(activeShop,myName)

    -- ── Section header ─────────────────────────────────────────────────
    Track(FS(p,"Shop(s) Overview",13,1,0.82,0)):SetPoint("TOPLEFT",PAD,-PAD)
    Track(HLine(p,-(PAD+18)))

    local yo = -(PAD+26)

    -- ── Shop dropdown ──────────────────────────────────────────────────
    Track(FS(p,"Active Shop",9,0.7,0.7,0.7)):SetPoint("TOPLEFT",PAD,yo); yo=yo-14

    local dropBtn=Track(CreateFrame("Button",nil,p,"BackdropTemplate"))
    dropBtn:SetSize(pw,24); dropBtn:SetPoint("TOPLEFT",PAD,yo)
    dropBtn:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",edgeSize=10,insets={left=2,right=2,top=2,bottom=2}})
    dropBtn:SetBackdropColor(0.06,0.06,0.10,0.95); dropBtn:SetBackdropBorderColor(0.45,0.35,0.12,0.85)
    local dropLbl=dropBtn:CreateFontString(nil,"OVERLAY","GameFontNormal")
    dropLbl:SetPoint("LEFT",8,0); dropLbl:SetPoint("RIGHT",-18,0); dropLbl:SetJustifyH("LEFT")
    dropLbl:SetText(activeShop or "— Select a shop —"); dropLbl:SetTextColor(activeShop and 1 or 0.6, activeShop and 0.82 or 0.6, 0, 1)
    local dropArrow=dropBtn:CreateFontString(nil,"OVERLAY","GameFontNormal")
    dropArrow:SetPoint("RIGHT",-4,0); dropArrow:SetText("v"); dropArrow:SetTextColor(0.7,0.7,0.7,1)

    dropBtn:SetScript("OnClick",function(self)
        if #shops==0 then return end
        local dcloser=CreateFrame("Frame",nil,UIParent)
        dcloser:SetAllPoints(); dcloser:EnableMouse(true); dcloser:SetFrameStrata("FULLSCREEN")
        local dmenu=CreateFrame("Frame",nil,UIParent,"BackdropTemplate")
        dmenu:SetFrameStrata("FULLSCREEN"); dmenu:SetWidth(pw)
        dmenu:SetPoint("TOPLEFT",self,"BOTTOMLEFT",0,0)
        dmenu:SetHeight(math.min(#shops,8)*24+6)
        dmenu:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",edgeSize=10,insets={left=3,right=3,top=3,bottom=3}})
        dmenu:SetBackdropColor(0.06,0.06,0.10,0.98); dmenu:SetBackdropBorderColor(0.45,0.35,0.12,1)
        dmenu:SetFrameLevel(dcloser:GetFrameLevel()+1)
        local dmy=-3
        for _,entry in ipairs(shops) do
            local di=CreateFrame("Button",nil,dmenu)
            di:SetSize(pw-8,20); di:SetPoint("TOPLEFT",4,dmy)
            local isAct=(entry.name==activeShop)
            local dt=di:CreateFontString(nil,"OVERLAY","GameFontNormal")
            dt:SetAllPoints(); dt:SetJustifyH("LEFT")
            dt:SetText((isAct and "|cffFFD700>> |r" or "   ")..entry.name)
            dt:SetTextColor(isAct and 1 or 0.85, isAct and 0.82 or 0.85, isAct and 0 or 0.85, 1)
            local en=entry.name
            di:SetScript("OnEnter",function() dt:SetTextColor(1,0.95,0.4,1) end)
            di:SetScript("OnLeave",function() dt:SetTextColor(isAct and 1 or 0.85, isAct and 0.82 or 0.85, isAct and 0 or 0.85,1) end)
            di:SetScript("OnClick",function()
                SK.DB:SetActiveShop(en)
                dmenu:Hide(); dmenu:SetParent(nil)
                dcloser:Hide(); dcloser:SetParent(nil)
                M:SwitchTab("shops")
                if SK.Register then SK.Register:RefreshShopLabel(); SK.Register:BuildProductGrid(); SK.Register:ClearCart() end
            end)
            dmy=dmy-24
        end
        dcloser:SetScript("OnMouseDown",function()
            dmenu:Hide(); dmenu:SetParent(nil); dcloser:Hide(); dcloser:SetParent(nil)
        end)
    end)
    yo=yo-30

    -- ── Create new shop ────────────────────────────────────────────────
    local newRow=Track(CreateFrame("Frame",nil,p)); newRow:SetSize(pw,24); newRow:SetPoint("TOPLEFT",PAD,yo)
    local ni=Box(newRow,pw-82,20); ni:SetPoint("LEFT",0,0)
    local nHint=newRow:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    nHint:SetPoint("LEFT",ni,"LEFT",4,0); nHint:SetText("New shop name..."); nHint:SetTextColor(0.35,0.35,0.35,1)
    ni:SetScript("OnTextChanged",function(s) nHint:SetShown(s:GetText()=="") end)
    local ncb=Btn(newRow,"Create",76,22); ncb:SetPoint("RIGHT",0,0)
    ncb:SetScript("OnClick",function()
        local name=strtrim(ni:GetText() or "")
        if name=="" then print("|cffFFD700[SK]|r Name required."); return end
        local ok,err=SK.DB:CreateShop(name,SK:GetRPName())
        if ok then ni:SetText(""); M:SwitchTab("shops")
        else print("|cffFFD700[SK]|r "..(err or "Error.")) end
    end)
    yo=yo-32

    if not activeShop or not activeData then
        Track(FS(p,"Select or create a shop above.",10,0.55,0.55,0.55)):SetPoint("TOPLEFT",PAD,yo)
        return
    end

    Track(HLine(p,yo-4)); yo=yo-16
    SK.DB:MigrateShop(activeData)

    -- ── Shop details ───────────────────────────────────────────────────
    local detailLbl=Track(FS(p,"|cffFFD700"..activeShop.."|r  —  Owner: "..activeData.owner..
        "  —  Your role: "..(SK.DB:GetRole(activeShop,myName) or "?"),10,0.8,0.8,0.8))
    detailLbl:SetPoint("TOPLEFT",PAD,yo); yo=yo-20

    -- Staff counts
    local staffLbl=Track(FS(p,"Managers: "..#(activeData.managers or {}).."  |  Employees: "..#(activeData.employees or {}),9,0.6,0.6,0.6))
    staffLbl:SetPoint("TOPLEFT",PAD,yo); yo=yo-24

    -- ── Treasury ──────────────────────────────────────────────────────
    Track(HLine(p,yo)); yo=yo-14
    Track(FS(p,"Treasury",11,1,0.82,0)):SetPoint("TOPLEFT",PAD,yo); yo=yo-20

    local treasStr = SK:FormatMoneyPlain(activeData.treasury or 0)
    local tLbl=Track(FS(p,treasStr,13,1,0.88,0.35)); tLbl:SetPoint("TOPLEFT",PAD,yo)

    -- "Withdraw All" button — always visible for owner, to the right of balance
    if isOwner then
        local wAllBtn=Track(Btn(p,"Withdraw All",90,18)); wAllBtn:SetPoint("TOPRIGHT",-PAD,yo)
        wAllBtn:SetScript("OnClick",function()
            local bal = activeData.treasury or 0
            if bal <= 0 then print("|cffFFD700[SK]|r Treasury is empty."); return end
            SK.DB:AddTreasury(activeShop, -bal)
            M:SwitchTab("shops")
        end)
    end

    if isOwner then
        -- Gold / Silver / Copper input row
        local function CL(parent,txt,r,g,b)
            local f=CreateFrame("Frame",nil,parent); f:SetSize(12,22)
            local fs=f:CreateFontString(nil,"OVERLAY","GameFontNormal"); fs:SetAllPoints()
            fs:SetFont("Fonts\\FRIZQT__.TTF",10,""); fs:SetText(txt); fs:SetTextColor(r,g,b,1)
            return f
        end
        local tRow=Track(CreateFrame("Frame",nil,p)); tRow:SetSize(pw,22); tRow:SetPoint("TOPLEFT",PAD,yo-24)
        local tGold=Box(tRow,40,20); tGold:SetPoint("LEFT",0,0); tGold:SetNumeric(true)
        local gL=CL(tRow,"g",1,0.82,0);    gL:SetPoint("LEFT",tGold,"RIGHT",2,0)
        local tSilv=Box(tRow,40,20);         tSilv:SetPoint("LEFT",gL,"RIGHT",2,0); tSilv:SetNumeric(true)
        local sL=CL(tRow,"s",0.7,0.7,0.7); sL:SetPoint("LEFT",tSilv,"RIGHT",2,0)
        local tCopp=Box(tRow,40,20);         tCopp:SetPoint("LEFT",sL,"RIGHT",2,0); tCopp:SetNumeric(true)
        local cL=CL(tRow,"c",0.7,0.4,0.1); cL:SetPoint("LEFT",tCopp,"RIGHT",2,0)

        local function GetCopper()
            return ((tonumber(tGold:GetText()) or 0)*10000)
                 + ((tonumber(tSilv:GetText()) or 0)*100)
                 + (tonumber(tCopp:GetText()) or 0)
        end
        local function ClearInputs() tGold:SetText(""); tSilv:SetText(""); tCopp:SetText("") end

        local tAdd=Btn(tRow,"Deposit",68,20); tAdd:SetPoint("LEFT",cL,"RIGHT",8,0)
        tAdd:SetScript("OnClick",function()
            local amt=GetCopper(); if amt==0 then return end
            SK.DB:AddTreasury(activeShop,amt); ClearInputs(); M:SwitchTab("shops")
        end)
        local tSub=Btn(tRow,"Withdraw",68,20); tSub:SetPoint("LEFT",tAdd,"RIGHT",4,0)
        tSub:SetScript("OnClick",function()
            local amt=GetCopper(); if amt==0 then return end
            SK.DB:AddTreasury(activeShop,-amt); ClearInputs(); M:SwitchTab("shops")
        end)
        yo=yo-52
    else
        yo=yo-26
    end

    -- ── Stock overview ─────────────────────────────────────────────────
    Track(HLine(p,yo)); yo=yo-14
    Track(FS(p,"Stock",11,1,0.82,0)):SetPoint("TOPLEFT",PAD,yo); yo=yo-20

    local products = SK.DB:GetProducts(activeShop)
    local hasStock = false
    for _, prod in ipairs(products) do
        if prod.stock ~= nil then hasStock=true; break end
    end

    if not hasStock then
        Track(FS(p,"No products with limited stock.",9,0.55,0.55,0.55)):SetPoint("TOPLEFT",PAD,yo)
        yo=yo-18
    else
        -- Header
        local sh=Track(CreateFrame("Frame",nil,p,"BackdropTemplate")); sh:SetSize(pw,18); sh:SetPoint("TOPLEFT",PAD,yo)
        sh:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
        sh:SetBackdropColor(0,0,0,0.4); sh:SetBackdropBorderColor(0.35,0.28,0.10,0.6)
        local h1=sh:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); h1:SetPoint("LEFT",6,0); h1:SetText("Product"); h1:SetTextColor(1,0.82,0,1)
        local h2=sh:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); h2:SetPoint("RIGHT",-6,0); h2:SetText("Stock"); h2:SetTextColor(1,0.82,0,1)
        yo=yo-20

        for _, prod in ipairs(products) do
            if prod.stock ~= nil then
                local sr=Track(CreateFrame("Frame",nil,p,"BackdropTemplate")); sr:SetSize(pw,22); sr:SetPoint("TOPLEFT",PAD,yo)
                sr:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
                sr:SetBackdropColor(0,0,0,0.15); sr:SetBackdropBorderColor(0.25,0.20,0.08,0.5)
                local pn=sr:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); pn:SetPoint("LEFT",6,0); pn:SetText(prod.name)
                local stCol = prod.stock==0 and {1,0.3,0.3} or prod.stock<=5 and {1,0.8,0.2} or {0.4,1,0.4}
                local sn2=sr:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); sn2:SetPoint("RIGHT",-60,0)
                sn2:SetText(prod.stock<=0 and "|cffFF4444Out of stock|r" or tostring(prod.stock))
                sn2:SetTextColor(stCol[1],stCol[2],stCol[3],1)
                if isOwner or (isManager and activeData.perms.mgrsCanStock~=false) then
                    local pid=prod.id
                    local plus=Btn(sr,"+",22,16); plus:SetPoint("RIGHT",-4,0)
                    plus:SetScript("OnClick",function()
                        SK.DB:SetStock(activeShop,pid,(prod.stock or 0)+1)
                        if SK.Net then SK.Net:BroadcastProducts(activeShop) end
                        M:SwitchTab("shops")
                    end)
                    local minus=Btn(sr,"-",22,16); minus:SetPoint("RIGHT",plus,"LEFT",-2,0)
                    minus:SetScript("OnClick",function()
                        SK.DB:SetStock(activeShop,pid,math.max(0,(prod.stock or 0)-1))
                        if SK.Net then SK.Net:BroadcastProducts(activeShop) end
                        M:SwitchTab("shops")
                    end)
                end
                yo=yo-24
            end
        end
    end

    -- ── Sync / Delete / Leave ──────────────────────────────────────────
    yo=yo-6; Track(HLine(p,yo)); yo=yo-14
    if activeShop and SK.Net then
        local syncBtn = Track(Btn(p, "Request Sync", 110, 24))
        syncBtn:SetPoint("TOPLEFT", PAD, yo)
        syncBtn:SetScript("OnClick", function()
            SK.Net:RequestSync(activeShop)
            print("|cffFFD700[SK]|r Sync requested for |cffFFD700"..activeShop.."|r.")
        end)
        syncBtn:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:AddLine("Request a full sync from the shop owner.", 1, 1, 1)
            GameTooltip:AddLine("Auto-sync runs on login; use this if data seems out of date.", 0.7, 0.7, 0.7)
            GameTooltip:Show()
        end)
        syncBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    end
    if isOwner then
        local delBtn=Track(Btn(p,"Delete This Shop",130,24)); delBtn:SetPoint("TOPLEFT",PAD+118,yo)
        delBtn:SetScript("OnClick",function()
            if SK.Net then SK.Net:BroadcastShopDelete(activeShop) end
            SK.DB:DeleteShop(activeShop); M:SwitchTab("shops")
        end)
    else
        local leaveBtn=Track(Btn(p,"Leave This Shop",130,24)); leaveBtn:SetPoint("TOPLEFT",PAD+118,yo)
        leaveBtn:SetScript("OnClick",function()
            if SK.Net then SK.Net:Leave(activeShop) end
            M:SwitchTab("shops")
        end)
    end
    sc:SetHeight(math.max(math.abs(yo) + 60, 400))
end

-- ─── SETTINGS TAB ─────────────────────────────────────────────────────────────

function M:BuildSettingsTab()
    WipeContent()
    local p   = GetContentPanel()
    local cfg = SK:Cfg()

    -- Outer scroll frame fills the whole content panel
    local sf = Track(CreateFrame("ScrollFrame",nil,p,"UIPanelScrollFrameTemplate"))
    sf:SetPoint("TOPLEFT",PAD,-PAD); sf:SetPoint("BOTTOMRIGHT",-PAD-18,PAD)
    local sc = CreateFrame("Frame",nil,sf)
    -- Width: use known register width minus all margins; GetWidth() may be 0 at build time
    local regW = SK.Register and SK.Register.mainFrame and SK.Register.mainFrame:GetWidth() or 760
    local spw = regW - 38 - PAD*2 - 8 - 22  -- frame insets + tab strip + padding + scrollbar
    if spw < 100 then spw = 400 end  -- safety fallback
    sc:SetWidth(spw); sc:SetHeight(1)
    sf:SetScrollChild(sc)

    local yo = 0  -- downward offset inside sc (always positive, subtracted in SetPoint)

    local function SH(text)
        local lbl = sc:CreateFontString(nil,"OVERLAY","GameFontNormal")
        lbl:SetFont("Fonts\\FRIZQT__.TTF",10,"OUTLINE")
        lbl:SetPoint("TOPLEFT",0,-yo); lbl:SetText(text); lbl:SetTextColor(1,0.82,0,1)
        local ln = sc:CreateTexture(nil,"ARTWORK"); ln:SetHeight(1)
        ln:SetPoint("TOPLEFT",0,-(yo+14)); ln:SetPoint("TOPRIGHT",0,-(yo+14))
        ln:SetColorTexture(0.55,0.42,0.12,0.5)
        yo = yo + 24
    end

    local cbIdx = 0
    local function Tog(label, getter, setter)
        cbIdx = cbIdx + 1
        local nm = "SKSet_"..cbIdx.."_"..math.floor(GetTime()*1000)
        local cb = CreateFrame("CheckButton",nm,sc,"ChatConfigCheckButtonTemplate")
        cb:SetSize(24,24); cb:SetPoint("TOPLEFT",0,-yo)
        cb:SetChecked(getter() and true or false)
        cb.Text:SetText(label); cb.Text:SetFont("Fonts\\FRIZQT__.TTF",10,"")
        cb:SetScript("OnClick",function(s) setter(s:GetChecked() and true or false) end)
        yo = yo + 28
    end

    local function Label(text, r,g,b)
        local l = sc:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        l:SetPoint("TOPLEFT",0,-yo); l:SetText(text)
        l:SetTextColor(r or 0.7,g or 0.7,b or 0.7,1)
        yo = yo + 14
        return l
    end

    -- ══ NOTIFICATIONS ════════════════════════════════════════════════════
    SH("Notifications")
    Tog("Order claimed by staff",
        function() return cfg.notifyOrderClaimed~=false end,
        function(v) cfg.notifyOrderClaimed=v end)
    Tog("Order released / expired",
        function() return cfg.notifyOrderReleased~=false end,
        function(v) cfg.notifyOrderReleased=v end)
    Tog("Order status changed",
        function() return cfg.notifyOrderStatus~=false end,
        function(v) cfg.notifyOrderStatus=v end)
    Tog("New staff member joined",
        function() return cfg.notifyStaffJoined~=false end,
        function(v) cfg.notifyStaffJoined=v end)
    Tog("Sync messages (verbose)",
        function() return cfg.notifySync==true end,
        function(v) cfg.notifySync=v end)
    yo = yo + 6

    -- ══ RECEIPT & EMOTE ══════════════════════════════════════════════════
    SH("Receipt & Emote")
    Label("|cffFFD700Tokens:|r  {shop}   {seller}   {items}   {total}   {payment}",1,1,1)
    yo = yo + 2
    Label("Emote template:")

    local editOuter = CreateFrame("Frame",nil,sc,"BackdropTemplate")
    editOuter:SetSize(spw,52); editOuter:SetPoint("TOPLEFT",0,-yo)
    editOuter:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    editOuter:SetBackdropColor(0,0,0,0.40); editOuter:SetBackdropBorderColor(0.40,0.35,0.20,0.8)
    local eSF = CreateFrame("ScrollFrame",nil,editOuter,"UIPanelScrollFrameTemplate")
    eSF:SetPoint("TOPLEFT",2,-2); eSF:SetPoint("BOTTOMRIGHT",-20,2)
    local eBox = CreateFrame("EditBox",nil,eSF)
    eBox:SetWidth(eSF:GetWidth()); eBox:SetHeight(48)
    eBox:SetMultiLine(true); eBox:SetAutoFocus(false); eBox:SetFontObject("GameFontNormal")
    eBox:SetText(cfg.emoteTemplate or "")
    eBox:SetScript("OnEscapePressed",function(s) s:ClearFocus() end)
    eBox:SetScript("OnTextChanged",function(s) cfg.emoteTemplate=s:GetText() end)
    eSF:SetScrollChild(eBox)
    yo = yo + 58

    yo = yo + 6
    -- ══ BEHAVIOUR ════════════════════════════════════════════════════════
    SH("Behaviour")
    Tog("Auto-clear cart after confirming an order",
        function() return cfg.autoClearCart~=false end,
        function(v) cfg.autoClearCart=v end)
    Tog("Auto-close category when opening another",
        function() return cfg.autoCloseCategory~=false end,
        function(v) cfg.autoCloseCategory=v end)
    yo = yo + 4

    -- Seller IC name
    Label("Seller IC name:")
    local selInp = CreateFrame("EditBox",nil,sc,"InputBoxTemplate")
    selInp:SetSize(spw-78,20); selInp:SetPoint("TOPLEFT",0,-yo); selInp:SetAutoFocus(false)
    selInp:SetScript("OnEscapePressed",function(s) s:ClearFocus() end)
    local saved = cfg.defaultSellerIC or ""
    if saved=="" then saved=SK:GetRPName() end
    selInp:SetText(saved)
    selInp:SetScript("OnTextChanged",function(s) cfg.defaultSellerIC=strtrim(s:GetText()) end)
    local trpBtn = CreateFrame("Button",nil,sc,"UIPanelButtonTemplate")
    trpBtn:SetSize(72,22); trpBtn:SetPoint("LEFT",selInp,"RIGHT",4,0); trpBtn:SetText("From TRP3")
    trpBtn:SetScript("OnClick",function()
        local n = SK:GetRPName(); selInp:SetText(n); cfg.defaultSellerIC=n
    end)
    yo = yo + 28

    yo = yo + 6
    -- ══ MINIMAP ══════════════════════════════════════════════════════════
    SH("Minimap")
    Label("Angle (0-360°, or drag the minimap button):")
    local angInp = CreateFrame("EditBox",nil,sc,"InputBoxTemplate")
    angInp:SetSize(56,20); angInp:SetPoint("TOPLEFT",0,-yo); angInp:SetAutoFocus(false)
    angInp:SetScript("OnEscapePressed",function(s) s:ClearFocus() end)
    angInp:SetText(tostring(math.floor(SK.db.minimapAngle or 220)))
    local angBtn = CreateFrame("Button",nil,sc,"UIPanelButtonTemplate")
    angBtn:SetSize(58,20); angBtn:SetPoint("LEFT",angInp,"RIGHT",6,0); angBtn:SetText("Apply")
    angBtn:SetScript("OnClick",function()
        local a=tonumber(angInp:GetText()); if a then SK.db.minimapAngle=a%360; SK.MinimapBtn:UpdatePosition() end
    end)
    yo = yo + 28

    yo = yo + 8
    -- ══ RESET ════════════════════════════════════════════════════════════
    local sep2=sc:CreateTexture(nil,"ARTWORK"); sep2:SetHeight(1)
    sep2:SetPoint("TOPLEFT",0,-yo); sep2:SetPoint("TOPRIGHT",0,-yo)
    sep2:SetColorTexture(0.35,0.30,0.20,0.6); yo=yo+10
    local rstBtn = CreateFrame("Button",nil,sc,"UIPanelButtonTemplate")
    rstBtn:SetSize(200,22); rstBtn:SetPoint("TOPLEFT",0,-yo); rstBtn:SetText("Reset All Settings to Default")
    rstBtn:SetScript("OnClick",function()
        SK.db.settings={
            emoteTemplate="hands over a receipt from {shop} — {items} — Total: {total} ({payment}), served by {seller}.",
            emoteChannel="EMOTE",showPrice=true,autoClearCart=true,defaultSellerIC="",
            autoCloseCategory=true,
            notifyOrderClaimed=true,notifyOrderReleased=true,
            notifyOrderStatus=true,notifyStaffJoined=true,notifySync=false,
        }
        M:SwitchTab("settings"); print("|cffFFD700[SK]|r Settings reset.")
    end)
    yo = yo + 32

    sc:SetHeight(yo + 10)
end


-- ─── PEOPLE & PERMISSIONS TAB ────────────────────────────────────────────────

function M:BuildPeopleTab()
    WipeContent()
    local p  = GetContentPanel()
    local pw = p:GetWidth() - PAD*2
    local shopName = SK.db and SK.db.activeShop
    if not shopName then
        Track(FS(p,"No shop active.",11,0.65,0.65,0.65)):SetPoint("CENTER"); return
    end

    local shop  = SK.DB:GetShop(shopName)
    if not shop then return end
    local myName = UnitName("player") or ""
    -- GetRole checks both OOC and IC names
    local role   = SK.DB:GetRole(shopName, myName)
    -- Fallback: also try IC name directly in case GetRole misses it
    if not role then role = SK.DB:GetRole(shopName, SK:GetRPName()) end
    local isOwner   = (role == "owner")
    local isManager = (role == "manager") or isOwner

    -- Permission: can managers edit discounts?
    shop.perms = shop.perms or {}
    local mgrsCanDiscount = shop.perms.mgrsCanDiscount ~= false  -- default true

    -- Scroll frame — identical setup to BuildWhatsNewTab which works correctly
    local sf = Track(CreateFrame("ScrollFrame", nil, p, "UIPanelScrollFrameTemplate"))
    sf:SetPoint("TOPLEFT", PAD, -PAD)
    sf:SetPoint("BOTTOMRIGHT", -PAD-18, PAD)
    local sc = CreateFrame("Frame", nil, sf)
    sc:SetWidth(sf:GetWidth()-4); sc:SetHeight(1); sf:SetScrollChild(sc)
    p = sc
    pw = sc:GetWidth() - PAD*2

    local yo = -PAD

    local function SH(text)
        Track(FS(p,text,10,1,0.82,0)):SetPoint("TOPLEFT",PAD,yo)
        Track(HLine(p,yo-14))  -- HLine wraps texture in a Frame so it can be reparented
        yo = yo - 24
    end

    local function Row(leftText, r,g,b, rightBtnLabel, rightBtnCb, rightBtnW)
        local row=Track(CreateFrame("Frame",nil,p,"BackdropTemplate"))
        row:SetPoint("TOPLEFT",PAD,yo); row:SetPoint("TOPRIGHT",-PAD,yo); row:SetHeight(26)
        row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
        row:SetBackdropColor(0,0,0,0.15); row:SetBackdropBorderColor(0.3,0.25,0.10,0.4)
        local lbl=row:CreateFontString(nil,"OVERLAY","GameFontNormal")
        lbl:SetPoint("LEFT",6,0); lbl:SetFont("Fonts\\FRIZQT__.TTF",10,"")
        lbl:SetText(leftText); lbl:SetTextColor(r or 1,g or 1,b or 1,1)
        if rightBtnLabel then
            local btn=Btn(row,rightBtnLabel,rightBtnW or 44,18)
            btn:SetPoint("RIGHT",-2,0)
            btn:SetScript("OnClick",rightBtnCb)
        end
        yo = yo - 28
        return row
    end

    -- ── STAFF ROSTER ────────────────────────────────────────────────────────
    SH("Staff Roster")

    if isOwner then
        -- Single text box to add an employee by name
        local addRow = Track(CreateFrame("Frame",nil,p))
        addRow:SetPoint("TOPLEFT",PAD,yo); addRow:SetPoint("TOPRIGHT",-PAD,yo); addRow:SetHeight(24)
        local ni = Box(addRow, pw-56, 20); ni:SetPoint("LEFT",0,0)
        local niHint = addRow:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        niHint:SetPoint("LEFT",ni,"LEFT",4,0); niHint:SetText("Add employee by name")
        niHint:SetTextColor(0.35,0.35,0.35,1)
        ni:SetScript("OnTextChanged",function(s) niHint:SetShown(s:GetText()=="") end)
        local addBtn = Btn(addRow,"Add",50,20); addBtn:SetPoint("RIGHT",0,0); Track(addBtn)
        local function DoAddEmployee()
            local t = strtrim(ni:GetText() or "")
            if t=="" then return end
            t = t:match("^([^%-]+)") or t
            local ok,err = SK.DB:AddEmployee(shopName, t)
            if ok then
                ni:SetText("")
                if SK.Net then SK.Net:SendInvite(shopName,t,"employee") end
                M:SwitchTab("people")
            else print("|cffFFD700[SK]|r "..(err or "Error.")) end
        end
        addBtn:SetScript("OnClick", DoAddEmployee)
        ni:SetScript("OnEnterPressed", DoAddEmployee)
        yo = yo - 30
        Track(HLine(p,yo)); yo = yo - 10

        -- Column headers — fixed widths so nothing overlaps
        local ICON_W = 22   -- guild icon
        local CB_W   = 24   -- checkbox
        local REM_W  = 30   -- X button
        local GAP    = 4

        local colName = Track(p:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"))
        colName:SetPoint("TOPLEFT", PAD+ICON_W+2, yo); colName:SetText("|cff888888Name|r")
        local colMgr = Track(p:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"))
        colMgr:SetPoint("TOPRIGHT", -(REM_W+GAP+2), yo); colMgr:SetText("|cff888888Manager|r")
        yo = yo - 18

        local function RosterRow(name, role)
            local row = Track(CreateFrame("Frame",nil,p,"BackdropTemplate"))
            row:SetHeight(26)
            row:SetPoint("TOPLEFT", PAD, yo); row:SetPoint("TOPRIGHT", -PAD, yo)
            row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",
                edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
            row:SetBackdropColor(0,0,0,0.15)
            row:SetBackdropBorderColor(0.25,0.22,0.10,0.3)

            -- Guild-style icon: crown=owner, star=manager, blank=employee
            -- Role icon — use reliable spell/item icons that always exist
            local ic = row:CreateTexture(nil,"ARTWORK"); ic:SetSize(16,16); ic:SetPoint("LEFT",3,0)
            if role=="owner" then
                -- Crown: Achievement_GuildPerk_EverybodysFriend (gold crown icon)
                ic:SetTexture(236377)
                ic:SetTexCoord(0.08,0.92,0.08,0.92)
            elseif role=="manager" then
                -- Star: Spell_Holy_Absolution (gold star/officer style)
                ic:SetTexture(135872)
                ic:SetTexCoord(0.08,0.92,0.08,0.92)
            else
                ic:SetAlpha(0)
            end

            -- Name label — right edge stops before checkbox column
            local nl = row:CreateFontString(nil,"OVERLAY","GameFontNormal")
            nl:SetPoint("LEFT", ICON_W+4, 0)
            nl:SetPoint("RIGHT", -(CB_W+GAP+REM_W+GAP+2), 0)
            nl:SetJustifyH("LEFT"); nl:SetWordWrap(false)
            if role=="owner" then nl:SetText("|cffFFD700"..name.."|r")
            elseif role=="manager" then nl:SetText("|cffFFCC55"..name.."|r")
            else nl:SetText(name) end

            -- Checkbox: shown for manager+employee only, anchored to RIGHT of X button
            if role ~= "owner" then
                local cbNm = "SKRst_"..name:gsub("[^%w]","_")
                local cb = CreateFrame("CheckButton",cbNm,row,"ChatConfigCheckButtonTemplate")
                cb:SetSize(CB_W,CB_W); cb:SetPoint("RIGHT", -(REM_W+GAP), 0)
                cb:SetChecked(role=="manager")
                local n,r = name,role
                cb:SetScript("OnClick",function(self)
                    if self:GetChecked() then
                        SK.DB:RemoveEmployee(shopName,n); SK.DB:AddManager(shopName,n)
                    else
                        SK.DB:RemoveManager(shopName,n); SK.DB:AddEmployee(shopName,n)
                    end
                    M:SwitchTab("people")
                end)
                cb:SetScript("OnEnter",function(s)
                    GameTooltip:SetOwner(s,"ANCHOR_TOP")
                    GameTooltip:AddLine(r=="manager" and "Demote to Employee" or "Promote to Manager",1,1,1)
                    GameTooltip:Show()
                end)
                cb:SetScript("OnLeave",function() GameTooltip:Hide() end)
                Track(cb)

                -- Remove / X button
                local rb = Btn(row,"X",REM_W,20); rb:SetPoint("RIGHT",-2,0); Track(rb)
                local n2,r2 = name,role
                rb:SetScript("OnClick",function()
                    if SK.Net then SK.Net:SendKick(shopName,n2) end
                    if r2=="manager" then SK.DB:RemoveManager(shopName,n2)
                    else SK.DB:RemoveEmployee(shopName,n2) end
                    M:SwitchTab("people")
                end)
            end
            yo = yo - 28
        end

        -- Owner first, then managers, then employees
        RosterRow(shop.owner, "owner")
        for _,name in ipairs(shop.managers  or {}) do RosterRow(name,"manager")  end
        for _,name in ipairs(shop.employees or {}) do RosterRow(name,"employee") end
        if #(shop.managers or{})==0 and #(shop.employees or{})==0 then
            Track(FS(p,"No staff yet. Add an employee above.",9,0.45,0.45,0.45)):SetPoint("TOPLEFT",PAD,yo); yo=yo-18
        end
        yo = yo - 8
    else
        -- Non-owner read-only
        local myRole = SK.DB:GetRole(shopName,myName) or "member"
        Track(FS(p,"Your role:  |cffFFD700"..myRole.."|r",11)):SetPoint("TOPLEFT",PAD,yo); yo=yo-22
        Track(FS(p,"Owner:  |cffFFD700"..shop.owner.."|r",10)):SetPoint("TOPLEFT",PAD,yo); yo=yo-20
        Track(FS(p,"Managers",10,1,0.82,0)):SetPoint("TOPLEFT",PAD,yo); yo=yo-18
        if #shop.managers==0 then Track(FS(p,"None.",9,0.45,0.45,0.45)):SetPoint("TOPLEFT",PAD+4,yo); yo=yo-16 end
        for _,n in ipairs(shop.managers) do Track(FS(p,n,10)):SetPoint("TOPLEFT",PAD+4,yo); yo=yo-18 end
        yo=yo-4; Track(HLine(p,yo)); yo=yo-8
        Track(FS(p,"Employees",10,1,0.82,0)):SetPoint("TOPLEFT",PAD,yo); yo=yo-18
        if #shop.employees==0 then Track(FS(p,"None.",9,0.45,0.45,0.45)):SetPoint("TOPLEFT",PAD+4,yo); yo=yo-16 end
        for _,n in ipairs(shop.employees) do Track(FS(p,n,10)):SetPoint("TOPLEFT",PAD+4,yo); yo=yo-18 end
        yo=yo-8; Track(HLine(p,yo)); yo=yo-10
        local syncBtn=Track(Btn(p,"Request Sync",120,24)); syncBtn:SetPoint("TOPLEFT",PAD,yo)
        syncBtn:SetScript("OnClick",function() if SK.Net then SK.Net:RequestSync(shopName) end end)
        local leaveBtn=Track(Btn(p,"Leave Shop",110,24)); leaveBtn:SetPoint("TOPLEFT",PAD+128,yo)
        leaveBtn:SetScript("OnClick",function()
            StaticPopupDialogs["SK_LEAVE_CONFIRM"]={text="Leave |cffFFD700"..shopName.."|r?",
                button1="Leave",button2="Cancel",OnAccept=function() SK.Net:Leave(shopName) end,
                timeout=0,whileDead=true,hideOnEscape=true}
            StaticPopup_Show("SK_LEAVE_CONFIRM")
        end)
        yo=yo-32
    end

    -- ── PERMISSIONS ─────────────────────────────────────────────────────────
    if isOwner then
        SH("Permissions")
        local perms = shop.perms
        local function Perm(label, getter, setter)
            local cbN="SKPerm_"..math.floor(GetTime()*1000)..math.random(9999)
            local cb=Track(CreateFrame("CheckButton",cbN,p,"ChatConfigCheckButtonTemplate"))
            cb:SetSize(24,24); cb:SetPoint("TOPLEFT",PAD,yo)
            cb:SetChecked(getter() and true or false)
            cb.Text:SetText(label); cb.Text:SetFont("Fonts\\FRIZQT__.TTF",10,"")
            cb:SetScript("OnClick",function(s) setter(s:GetChecked() and true or false) end)
            yo = yo - 28
        end
        Track(FS(p,"Managers:",10,1,0.82,0)):SetPoint("TOPLEFT",PAD,yo); yo=yo-20
        Perm("Managers can add/remove discounts",
            function() return perms.mgrsCanDiscount~=false end,
            function(v) perms.mgrsCanDiscount=v end)
        Perm("Managers can add/edit/remove products",
            function() return perms.mgrsCanProducts~=false end,
            function(v) perms.mgrsCanProducts=v end)
        Perm("Managers can update stock levels",
            function() return perms.mgrsCanStock~=false end,
            function(v) perms.mgrsCanStock=v end)
        Perm("Managers can add employees",
            function() return perms.mgrsCanAddEmployees~=false end,
            function(v) perms.mgrsCanAddEmployees=v end)
        yo=yo-4
        Track(FS(p,"Employees:",10,1,0.82,0)):SetPoint("TOPLEFT",PAD,yo); yo=yo-20
        Perm("Employees can apply discounts in register",
            function() return perms.empsCanDiscount~=false end,
            function(v) perms.empsCanDiscount=v end)
        Perm("Employees can finalize as Paid as a Favour",
            function() return perms.empsCanFavour~=false end,
            function(v) perms.empsCanFavour=v end)
        yo=yo-4
    end

    -- ── DISCOUNTS ───────────────────────────────────────────────────────────
    local canEditDiscounts = isOwner or (isManager and mgrsCanDiscount)
    if isManager or isOwner then
        SH("Discounts")
        local discounts = SK.DB:GetDiscounts(shopName)
        if #discounts == 0 then
            Track(FS(p,"No discounts yet.",9,0.45,0.45,0.45)):SetPoint("TOPLEFT",PAD,yo); yo=yo-18
        else
            for i, d in ipairs(discounts) do
                local di=i
                Row(d.label.."  —  "..d.pct.."%", 1,0.82,0,
                    canEditDiscounts and "Remove" or nil,
                    function() SK.DB:DeleteDiscount(shopName,di); M:SwitchTab("people") end,
                    54)
            end
        end

        if canEditDiscounts then
            -- Add discount form
            local addDisc=Track(CreateFrame("Frame",nil,p,"BackdropTemplate"))
            addDisc:SetPoint("TOPLEFT",PAD,yo); addDisc:SetPoint("TOPRIGHT",-PAD,yo); addDisc:SetHeight(28)
            addDisc:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
            addDisc:SetBackdropColor(0,0,0,0.20); addDisc:SetBackdropBorderColor(0.35,0.28,0.10,0.5)

            local dLabel=Box(addDisc,pw-110,20); dLabel:SetPoint("TOPLEFT",4,-4)
            local dlHint=addDisc:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            dlHint:SetPoint("LEFT",dLabel,"LEFT",4,0); dlHint:SetText("Label"); dlHint:SetTextColor(0.35,0.35,0.35,1)
            dLabel:SetScript("OnTextChanged",function(s) dlHint:SetShown(s:GetText()=="") end)

            local dPct=Box(addDisc,30,20); dPct:SetPoint("LEFT",dLabel,"RIGHT",4,0); dPct:SetNumeric(true)
            local dPctLbl=addDisc:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            dPctLbl:SetPoint("LEFT",dPct,"RIGHT",2,0); dPctLbl:SetText("%"); dPctLbl:SetTextColor(0.7,0.7,0.7,1)

            local dAdd=Btn(addDisc,"Add",34,20); dAdd:SetPoint("RIGHT",-4,-1)
            dAdd:SetScript("OnClick",function()
                local lbl=strtrim(dLabel:GetText())
                local pct=tonumber(dPct:GetText())
                local ok,err=SK.DB:AddDiscount(shopName,lbl,pct)
                if ok then dLabel:SetText(""); dPct:SetText(""); M:SwitchTab("people")
                else print("|cffFFD700[SK]|r "..(err or "Error.")) end
            end)
            yo = yo - 34
        end
    end

    -- ── Category Order ────────────────────────────────────────────────────────
    -- Owner/manager only — reorder categories shown in the Register grid.
    if isManager then
        yo = yo - 12
        SH("Category Order")
        local yoCO = yo  -- snapshot: rows always start from this fixed position

        local ordOrder = SK.DB:GetCategoryOrder(shopName)
        local COrows = {}

        local function RebuildCO()
            for _, w in ipairs(COrows) do w:Hide(); w:SetParent(nil) end
            wipe(COrows)
            ordOrder = SK.DB:GetCategoryOrder(shopName)

            local rowH, rowGap = 22, 4
            local upW, dnW, numW = 80, 92, 26
            local nameW = pw - numW - upW - dnW - 16

            for i, catName in ipairs(ordOrder) do
                local ry = yoCO - (i-1)*(rowH+rowGap)  -- use snapshot, not live yo

                local numLbl = Track(p:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"))
                numLbl:SetPoint("TOPLEFT", PAD, ry)
                numLbl:SetSize(numW, rowH); numLbl:SetJustifyH("RIGHT")
                numLbl:SetText("|cff888888"..i..".|r")
                tinsert(COrows, numLbl)

                local nameLbl = Track(p:CreateFontString(nil,"OVERLAY","GameFontNormal"))
                nameLbl:SetPoint("TOPLEFT", PAD+numW+6, ry)
                nameLbl:SetSize(nameW, rowH); nameLbl:SetJustifyH("LEFT")
                nameLbl:SetText(catName); nameLbl:SetTextColor(1,1,1,1)
                tinsert(COrows, nameLbl)

                local upX = PAD + numW + 6 + nameW + 4
                local ci = i

                local upBtn = Track(Btn(p, "Move Up", upW, rowH))
                upBtn:SetPoint("TOPLEFT", upX, ry)
                upBtn:SetScript("OnClick", function()
                    if ci > 1 then
                        ordOrder[ci], ordOrder[ci-1] = ordOrder[ci-1], ordOrder[ci]
                        SK.DB:SetCategoryOrder(shopName, ordOrder)
                        RebuildCO()
                        if SK.Register and SK.Register.BuildProductGrid then SK.Register:BuildProductGrid() end
                        if SK.Net then SK.Net:BroadcastCategoryColors(shopName) end
                    end
                end)
                tinsert(COrows, upBtn)

                local dnBtn = Track(Btn(p, "Move Down", dnW, rowH))
                dnBtn:SetPoint("TOPLEFT", upX+upW+2, ry)
                dnBtn:SetScript("OnClick", function()
                    if ci < #ordOrder then
                        ordOrder[ci], ordOrder[ci+1] = ordOrder[ci+1], ordOrder[ci]
                        SK.DB:SetCategoryOrder(shopName, ordOrder)
                        RebuildCO()
                        if SK.Register and SK.Register.BuildProductGrid then SK.Register:BuildProductGrid() end
                        if SK.Net then SK.Net:BroadcastCategoryColors(shopName) end
                    end
                end)
                tinsert(COrows, dnBtn)
            end

            -- Same approach as BuildWhatsNewTab: sc height = depth of last content + PAD
            local catCount = #ordOrder
            local rowH2, rowGap2 = 22, 4
            local lastRowBottom = math.abs(yoCO) + (catCount * (rowH2 + rowGap2))
            sc:SetHeight(math.max(lastRowBottom + PAD, 400))
        end

        RebuildCO()
    end

    -- Always update scroll child height
    if not isManager then
        sc:SetHeight(math.max(math.abs(yo) + PAD, 400))
    end
end

-- ─── WHAT'S NEW TAB ──────────────────────────────────────────────────────────

function M:BuildWhatsNewTab()
    WipeContent()
    local p = GetContentPanel(); if not p then return end

    Track(FS(p, "What's New", 13, 1, 0.82, 0)):SetPoint("TOPLEFT", PAD, -PAD)
    Track(HLine(p, -(PAD+18)))

    local sf = Track(CreateFrame("ScrollFrame", nil, p, "UIPanelScrollFrameTemplate"))
    sf:SetPoint("TOPLEFT", PAD, -(PAD+26))
    sf:SetPoint("BOTTOMRIGHT", -PAD-18, PAD)
    local sc = CreateFrame("Frame", nil, sf)
    sc:SetWidth(sf:GetWidth()-4); sc:SetHeight(1); sf:SetScrollChild(sc)

    local yo = 0
    local function L(text, r, g, b, size)
        local fs = sc:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        fs:SetFont("Fonts\\FRIZQT__.TTF", size or 11, "")
        fs:SetPoint("TOPLEFT", 0, -yo)
        fs:SetWidth(sc:GetWidth())
        fs:SetText(text); fs:SetTextColor(r or 1, g or 1, b or 1, 1)
        fs:SetJustifyH("LEFT"); fs:SetWordWrap(true)
        yo = yo + fs:GetStringHeight() + 4
    end
    local function Gap() yo = yo + 8 end
    local function Sep()
        local line = sc:CreateTexture(nil, "ARTWORK")
        line:SetHeight(1); line:SetPoint("TOPLEFT", 0, -yo)
        line:SetWidth(sc:GetWidth())
        line:SetColorTexture(0.35, 0.30, 0.20, 0.5)
        yo = yo + 10
    end

    -- ── Beta tester announcement (top of page) ─────────────────────────────
    L("|cffFFD700Storekeeper: Extended — BETA Testers Wanted!|r", 1, 0.82, 0, 13)
    Gap()
    L("A new addon, |cffFFD700Storekeeper: Extended|r, is currently in the making. We are looking for a small number of BETA testers to help us put it through its paces.", 0.92, 0.92, 0.92)
    L("Want to help? Fill out the short form below and we will be in contact. We are looking for roughly 2-3 testers.", 0.92, 0.92, 0.92)
    Gap()

    -- Beta form URL button
    local betaBtn = CreateFrame("Button", nil, sc, "BackdropTemplate")
    betaBtn:SetHeight(24); betaBtn:SetPoint("TOPLEFT", 0, -yo)
    betaBtn:SetWidth(sc:GetWidth())
    betaBtn:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",
        edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    betaBtn:SetBackdropColor(0.04,0.08,0.04,1)
    betaBtn:SetBackdropBorderColor(0.25,0.65,0.25,0.9)
    local betaTxt = betaBtn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    betaTxt:SetAllPoints(); betaTxt:SetJustifyH("LEFT")
    betaTxt:SetText("  |cff44FF44https://forms.gle/ubop1SxFPqmAxZ4D6|r  — BETA Tester Sign-up")
    betaBtn:SetScript("OnClick", function()
        if not _G.SKUrlCopy then
            _G.SKUrlCopy = CreateFrame("EditBox","SKUrlCopy",UIParent)
            _G.SKUrlCopy:SetSize(1,1); _G.SKUrlCopy:SetPoint("CENTER",UIParent,"CENTER",10000,10000)
            _G.SKUrlCopy:SetAutoFocus(false)
            _G.SKUrlCopy:SetScript("OnEscapePressed",function(s) s:ClearFocus() end)
        end
        _G.SKUrlCopy:SetText("https://forms.gle/ubop1SxFPqmAxZ4D6")
        _G.SKUrlCopy:SetFocus(); _G.SKUrlCopy:HighlightText()
        print("|cffFFD700[SK]|r Beta sign-up URL copied — paste it in your browser.")
    end)
    betaBtn:SetScript("OnEnter",function(self)
        GameTooltip:SetOwner(self,"ANCHOR_TOP")
        GameTooltip:AddLine("Click to copy the beta sign-up URL",1,1,1); GameTooltip:Show()
    end)
    betaBtn:SetScript("OnLeave",function() GameTooltip:Hide() end)
    yo = yo + 28
    Gap(); Sep()

    -- Tutorial button
    local tutBtn = CreateFrame("Button", nil, sc, "UIPanelButtonTemplate")
    tutBtn:SetSize(160, 26); tutBtn:SetPoint("TOPLEFT", 0, -yo)
    tutBtn:SetText("Start Tutorial")
    tutBtn:SetScript("OnClick", function()
        if SK.Tutorial then SK.Tutorial:Start() end
    end)
    yo = yo + 32
    Gap(); Sep()

    -- ── Community links ────────────────────────────────────────────────────────
    L("|cffFFD700Community & Support|r", 1, 0.82, 0, 12)
    Gap()

    local LINK_W = (sc:GetWidth() - 8) / 3  -- three equal-width buttons with 4px gaps
    local LINK_H = 28

    local links = {
        {
            label   = "|cff7289DADiscord|r",
            sub     = "Community Server",
            url     = "https://discord.gg/dHRTBNGR5S",
            borderR = 0.44, borderG = 0.54, borderB = 0.85,
        },
        {
            label   = "|cffFF6600CurseForge|r",
            sub     = "Project Page / Issues",
            url     = "https://www.curseforge.com/wow/addons/storekeeper-wow-pos",
            borderR = 0.85, borderG = 0.40, borderB = 0.10,
        },
        {
            label   = "|cffAAAAFFGitHub|r",
            sub     = "Source Code",
            url     = "https://github.com/Jixsen-is-Gaming/Storekeeper",
            borderR = 0.65, borderG = 0.65, borderB = 0.80,
        },
    }

    local function MakeLinkBtn(def, offsetX)
        local btn = CreateFrame("Button", nil, sc, "BackdropTemplate")
        btn:SetSize(LINK_W, LINK_H)
        btn:SetPoint("TOPLEFT", offsetX, -yo)
        btn:SetBackdrop({
            bgFile   = "Interface\\Buttons\\WHITE8X8", tile=true, tileSize=8,
            edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize=1,
        })
        btn:SetBackdropColor(0.06, 0.06, 0.10, 1)
        btn:SetBackdropBorderColor(def.borderR, def.borderG, def.borderB, 0.85)

        local lbl = btn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        lbl:SetPoint("TOP", 0, -4)
        lbl:SetWidth(LINK_W - 6)
        lbl:SetJustifyH("CENTER")
        lbl:SetText(def.label)

        local sub = btn:CreateFontString(nil, "OVERLAY")
        sub:SetFont("Fonts\\FRIZQT__.TTF", 9, "")
        sub:SetPoint("BOTTOM", 0, 4)
        sub:SetWidth(LINK_W - 6)
        sub:SetJustifyH("CENTER")
        sub:SetTextColor(0.60, 0.60, 0.60, 1)
        sub:SetText(def.sub)

        btn:SetScript("OnEnter", function(self)
            btn:SetBackdropBorderColor(def.borderR, def.borderG, def.borderB, 1)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:AddLine("Click to copy URL", 1, 1, 1)
            GameTooltip:AddLine(def.url, 0.6, 0.8, 1)
            GameTooltip:Show()
        end)
        btn:SetScript("OnLeave", function()
            btn:SetBackdropBorderColor(def.borderR, def.borderG, def.borderB, 0.85)
            GameTooltip:Hide()
        end)
        btn:SetScript("OnClick", function()
            if not _G.SKUrlCopy then
                _G.SKUrlCopy = CreateFrame("EditBox", "SKUrlCopy", UIParent)
                _G.SKUrlCopy:SetSize(1, 1)
                _G.SKUrlCopy:SetPoint("CENTER", UIParent, "CENTER", 10000, 10000)
                _G.SKUrlCopy:SetAutoFocus(false)
                _G.SKUrlCopy:SetScript("OnEscapePressed", function(s) s:ClearFocus() end)
            end
            _G.SKUrlCopy:SetText(def.url)
            _G.SKUrlCopy:SetFocus()
            _G.SKUrlCopy:HighlightText()
            print("|cffFFD700[SK]|r " .. def.sub .. " URL copied — paste it in your browser.")
        end)
    end

    -- Space each button with a small gap between them
    local gap4 = 4
    MakeLinkBtn(links[1], 0)
    MakeLinkBtn(links[2], LINK_W + gap4)
    MakeLinkBtn(links[3], (LINK_W + gap4) * 2)
    yo = yo + LINK_H + 4
    Gap(); Sep()

    -- Header (v1.3.2)
    L("|cffFFD700Storekeeper  v1.3.2|r", 1, 0.82, 0, 13)
    L("Merchant Point of Sale (MPoS)  —  Storekeeper", 0.55, 0.55, 0.55, 10)
    Gap(); Sep()

    L("|cffFF6666Bugs Fixed|r", 1, 0.4, 0.4, 11)
    Gap()
    L("• Network: empty log sync now correctly uses LOGS_START/END protocol instead of the unhandled LOGS_DATA command.", 0.85, 0.85, 0.85)
    L("• Network: category colours and category order were not pushed to staff whose products were already up to date on login.", 0.85, 0.85, 0.85)
    Gap(); Sep()

    L("|cff66FF66Added|r", 0.4, 1, 0.4, 11)
    Gap()
    L("• What's New tab now opens automatically the first time you log in after installing a new version.", 0.85, 0.85, 0.85)
    L("• Community links added to this tab: Discord, CurseForge, and GitHub — click any button to copy the URL to your clipboard.", 0.85, 0.85, 0.85)
    Gap(); Sep()

    L("|cffFFDD44Changed|r", 1, 0.87, 0.27, 11)
    Gap()
    L("• Network: full sync (SYNC_REQUEST) now also pushes category colours and order alongside products and orders.", 0.85, 0.85, 0.85)
    L("• Code: removed dead internal BroadcastToStaff function that was never called.", 0.85, 0.85, 0.85)
    Gap(); Sep()

    L("|cffFF6666Bugs Fixed|r", 1, 0.4, 0.4, 11)
    Gap()
    L("• Management tab: Move Up and Move Down buttons were too narrow, causing text to overflow outside the button borders.", 0.85, 0.85, 0.85)
    L("• Products tab: Category and Price column headers were misaligned with the data rows beneath them.", 0.85, 0.85, 0.85)
    L("• Shop(s) Overview: the Delete Shop and Leave This Shop buttons were clipped by the bottom border of the panel.", 0.85, 0.85, 0.85)
    Gap(); Sep()

    L("|cff66FF66Added|r", 0.4, 1, 0.4, 11)
    Gap()
    L("• Icon picker: updated from 20,073 icons (BfA 8.0 era) to 32,874 icons, covering all content through The War Within and Midnight.", 0.85, 0.85, 0.85)
    L("• Icon picker: runtime supplement — spellbook, mount journal, and pet journal are scanned at login to surface any icons not yet in the static list.", 0.85, 0.85, 0.85)
    Gap(); Sep()

    L("|cffFFDD44Changed|r", 1, 0.87, 0.27, 11)
    Gap()
    L("• Icon picker: now always opens Storekeeper's own built-in picker. Previously it would open TRP3's icon browser when TRP3 was loaded, causing confusion.", 0.85, 0.85, 0.85)
    L("• Code: removed dead TRP3 icon browser integration code (TRP3IconBrowserAvailable, OpenViaTRP3) that was no longer reachable.", 0.85, 0.85, 0.85)
    Gap(); Sep()
    Gap()
    L("• Finalize button — logs a sale instantly to the Activity Log and updates the treasury without creating a tracked order. Ideal for quick walk-up sales.", 0.85, 0.85, 0.85)
    L("• Confirm & Log button — creates a full tracked order with buyer IC and OOC name, assignable to a staff member with an ETA.", 0.85, 0.85, 0.85)
    L("• Payment types — Paid in Full, Paid as a Favour, or Pay After Delivery.", 0.85, 0.85, 0.85)
    L("• Out-of-stock products are dimmed and unclickable in the register grid.", 0.85, 0.85, 0.85)
    Gap(); Sep()

    -- Products
    L("|cffFFD700Products|r", 1, 0.85, 0.2, 11)
    Gap()
    L("• Rarity — assign Poor through Legendary rarity to products; name is tinted with the matching WoW rarity colour in the register grid and product list.", 0.85, 0.85, 0.85)
    L("• Stock — toggle limited stock per product; quantity decrements automatically on each sale and can be adjusted from the Shop(s) Overview tab.", 0.85, 0.85, 0.85)
    L("• Category colours — each category can be assigned a custom colour; the category header buttons in the register grid reflect it and it syncs to all staff.", 0.85, 0.85, 0.85)
    L("• Category field — type a new category name or pick from a dropdown of existing ones.", 0.85, 0.85, 0.85)
    Gap(); Sep()

    -- Orders
    L("|cffFFD700Orders|r", 1, 0.85, 0.2, 11)
    Gap()
    L("• Unclaimed orders show only a Claim button; status controls appear once claimed.", 0.85, 0.85, 0.85)
    L("• ETA expiry — claimed orders with a passed ETA automatically release back to unclaimed and refresh the order list live.", 0.85, 0.85, 0.85)
    L("• Buyer name (IC and OOC) is stored on the order and shown in the order list.", 0.85, 0.85, 0.85)
    Gap(); Sep()

    -- Shop & Treasury
    L("|cffFFD700Shop(s) Overview & Treasury|r", 1, 0.85, 0.2, 11)
    Gap()
    L("• Treasury — each shop tracks its total earnings in copper. Displayed as gold, silver, and copper with deposit and withdraw controls for owners.", 0.85, 0.85, 0.85)
    L("• Treasury auto-updates when a Paid in Full sale is finalised or a paid order is marked complete.", 0.85, 0.85, 0.85)
    L("• Withdraw All button for quick full withdrawal.", 0.85, 0.85, 0.85)
    L("• Stock overview table — lists all limited-stock products with +/- adjustment buttons (permission-gated).", 0.85, 0.85, 0.85)
    Gap(); Sep()

    -- Staff & Permissions
    L("|cffFFD700Staff & Permissions|r", 1, 0.85, 0.2, 11)
    Gap()
    L("• Owners can now configure what managers and employees are allowed to do: edit products, apply discounts, finalise as a favour, adjust stock, and add employees.", 0.85, 0.85, 0.85)
    L("• Staff receive automatic sync when coming online, including products, orders, and category colours.", 0.85, 0.85, 0.85)
    Gap(); Sep()

    -- Activity Log
    L("|cffFFD700Activity Log|r", 1, 0.85, 0.2, 11)
    Gap()
    L("• All shop events are now categorised: Treasury, Orders, Products, Staff, and System.", 0.85, 0.85, 0.85)
    L("• Filter tabs at the top of the log let you narrow to any category instantly.", 0.85, 0.85, 0.85)
    Gap(); Sep()

    -- Addon & Network
    L("|cffFFD700Addon & Network|r", 1, 0.85, 0.2, 11)
    Gap()
    L("• Merchant branding — the system is now attributed to the Storekeeper throughout the UI, TOC, and receipt templates.", 0.85, 0.85, 0.85)
    L("• Update notifications — if a colleague online is running a newer version of Storekeeper, you will receive a one-time chat notification with a download link.", 0.85, 0.85, 0.85)
    L("• Minimap button — fixed ring border alignment and correct LibDBIcon-standard sizing.", 0.85, 0.85, 0.85)
    L("• Minimap tooltip — updated to reflect current controls; settings are accessed through the register tabs.", 0.85, 0.85, 0.85)
    Gap(); Sep()

    -- Bug report
    L("|cffFFD700Found a bug or have a suggestion?|r", 1, 0.82, 0, 11)
    Gap()
    L("Report issues on the Curseforge project page:", 0.75, 0.75, 0.75)
    Gap()

    -- Clickable URL button
    local urlBtn = CreateFrame("Button", nil, sc, "BackdropTemplate")
    urlBtn:SetHeight(22); urlBtn:SetPoint("TOPLEFT", 0, -yo)
    urlBtn:SetWidth(sc:GetWidth())
    urlBtn:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",
        edgeFile="Interface\\Buttons\\WHITE8X8", edgeSize=1})
    urlBtn:SetBackdropColor(0.06,0.06,0.10,1)
    urlBtn:SetBackdropBorderColor(0.45,0.35,0.12,0.8)
    local urlTxt = urlBtn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    urlTxt:SetAllPoints(); urlTxt:SetJustifyH("LEFT")
    urlTxt:SetText("  |cff5599FFhttps://legacy.curseforge.com/wow/addons/storekeeper-wow-pos|r")
    urlBtn:SetScript("OnClick", function()
        if not _G.SKUrlCopy then
            _G.SKUrlCopy = CreateFrame("EditBox", "SKUrlCopy", UIParent)
            _G.SKUrlCopy:SetSize(1,1)
            _G.SKUrlCopy:SetPoint("CENTER", UIParent, "CENTER", 10000, 10000)
            _G.SKUrlCopy:SetAutoFocus(false)
            _G.SKUrlCopy:SetScript("OnEscapePressed", function(s) s:ClearFocus() end)
        end
        _G.SKUrlCopy:SetText("https://legacy.curseforge.com/wow/addons/storekeeper-wow-pos/settings/issues")
        _G.SKUrlCopy:SetFocus(); _G.SKUrlCopy:HighlightText()
        print("|cffFFD700[SK]|r Bug report URL copied — paste it in your browser.")
    end)
    urlBtn:SetScript("OnEnter", function()
        GameTooltip:SetOwner(urlBtn, "ANCHOR_TOP")
        GameTooltip:AddLine("Click to copy URL to clipboard", 1, 1, 1)
        GameTooltip:Show()
    end)
    urlBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    yo = yo + 26

    sc:SetHeight(math.max(yo + 10, 30))
end

-- ─── Tab definitions ──────────────────────────────────────────────────────────

local TAB_KEYS   = {"orders","people","products","shops","logs","settings"}
local TAB_LABELS = {"Orders","Management","Products","Shop(s) Overview","Activity Log","Personal Settings"}
local TAB_ICONS  = {
    "Interface\\Icons\\INV_Scroll_07",           -- Orders
    "Interface\\Icons\\INV_Misc_GroupNeedMore",  -- Management
    "Interface\\Icons\\INV_Misc_Coin_01",        -- Products
    "Interface\\Icons\\INV_Box_01",              -- Shop(s) Overview
    "Interface\\Icons\\INV_Misc_Book_01",        -- Activity Log
    "Interface\\Icons\\INV_Misc_Gear_01",        -- Personal Settings
}

-- ─── Tab switcher ─────────────────────────────────────────────────────────────

function M:SwitchTab(tab)
    M.activeTab = tab
    -- If rendered inside the Register, delegate to its SwitchToTab
    if SK.Register and SK.Register.SwitchToTab and SK.Register.isOpen then
        SK.Register.SwitchToTab(tab)
        return
    end
    -- Standalone manager window path
    for i, key in ipairs(TAB_KEYS) do
        local btn = M.tabBtns and M.tabBtns[i]
        if btn then
            local on = (key == tab)
            if btn.activebar then btn.activebar:SetAlpha(on and 1 or 0) end
            if btn.bg then
                if on then btn.bg:SetColorTexture(0.8,0.65,0.2,0.20)
                else        btn.bg:SetColorTexture(0.8,0.65,0.2,0) end
            end
            if btn.ic then
                if on then btn.ic:SetVertexColor(1,0.85,0.3,1)
                else       btn.ic:SetVertexColor(0.75,0.68,0.55,1) end
            end
        end
    end
    if M.contentPanel then
        if     tab=="products" then M:BuildProductTab()
        elseif tab=="staff"    then M:BuildPeopleTab()
        elseif tab=="people"   then M:BuildPeopleTab()
        elseif tab=="orders"   then M:BuildOrdersTab()
        elseif tab=="logs"     then M:BuildLogsTab()
        elseif tab=="shops"    then M:BuildShopsTab()
        elseif tab=="settings" then M:BuildSettingsTab()
        end
    end
end

-- ─── Main Frame — Guild & Communities style ───────────────────────────────────

local SIDEBAR_W = 140
local TITLE_H   = 24

function M:Build()
    if M.mainFrame then M.mainFrame:Show(); return end

    local c       = SK:C()
    local isGob   = (SK.db.theme == SK.THEMES.GOBLIN)
    local W, H    = 680, 540
    local INSET   = 12

    -- Theme-driven texture IDs:
    -- Gnomish = Gnomeregan steel diamond plate (blue-grey)
    -- Goblin  = Blackrock Depths iron (warm brown/rust tint)
    -- Tileable dark metal panel — same texture for both themes,
    -- vertex colour provides the Gnomish (blue-steel) vs Goblin (green) distinction
    local BG_TEX_MAIN    = 374155   -- UI-Background-Rock (dark, tileable)
    local BG_TEX_SIDEBAR = 516765   -- DarkSandstone-Tile (slightly different texture)

    -- ── Outer frame — gold border, theme bg texture ───────────────────────
    local f = CreateFrame("Frame","StorekeeperManagerFrame",UIParent,"BackdropTemplate")
    f:SetSize(W,H); f:SetPoint("CENTER",UIParent,"CENTER",300,0)
    f:SetMovable(true); f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart",f.StartMoving); f:SetScript("OnDragStop",f.StopMovingOrSizing)
    f:SetFrameStrata("DIALOG"); f:SetToplevel(true)
    -- Backdrop provides only the border; bg is a separate stretched texture layer
    f:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8X8",
        tile     = true, tileSize = 8,
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
        edgeSize = 32,
        insets   = {left=INSET, right=INSET, top=INSET, bottom=INSET},
    })
    f:SetBackdropColor(0, 0, 0, 0)  -- transparent — bg texture does the work
    f:SetBackdropBorderColor(1, 1, 1, 1)

    -- Tiled background — fills the entire frame regardless of size
    local bgTex = f:CreateTexture(nil,"BACKGROUND")
    bgTex:SetPoint("TOPLEFT", INSET, -INSET)
    bgTex:SetPoint("BOTTOMRIGHT", -INSET, INSET)
    bgTex:SetTexture(BG_TEX_MAIN)
    bgTex:SetHorizTile(true); bgTex:SetVertTile(true)
    if isGob then
        bgTex:SetVertexColor(0.38, 0.48, 0.28, 1)  -- Goblin: dark green-brown
    else
        bgTex:SetVertexColor(0.32, 0.40, 0.52, 1)  -- Gnomish: dark blue-steel
    end

    M.mainFrame = f

    if not M._specialFrameRegistered then
        tinsert(UISpecialFrames,"StorekeeperManagerFrame")
        M._specialFrameRegistered = true
    end
    f:SetScript("OnHide", function() M.isOpen = false end)

    -- ── Title bar — gold header ────────────────────────────────────────────
    local titleBar = CreateFrame("Frame",nil,f,"BackdropTemplate")
    titleBar:SetHeight(TITLE_H)
    titleBar:SetPoint("TOPLEFT",  INSET, -INSET)
    titleBar:SetPoint("TOPRIGHT", -INSET, -INSET)
    titleBar:SetBackdrop({
        bgFile   = "Interface\\DialogFrame\\UI-DialogBox-Gold-Background",
        tile     = true, tileSize = 256,
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
        edgeSize = 16,
        insets   = {left=4, right=4, top=4, bottom=4},
    })
    titleBar:SetBackdropColor(1, 1, 1, 1)
    titleBar:SetBackdropBorderColor(1, 1, 1, 0.8)
    titleBar:EnableMouse(true); titleBar:RegisterForDrag("LeftButton")
    titleBar:SetScript("OnDragStart",function() f:StartMoving() end)
    titleBar:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)

    local tl = titleBar:CreateFontString(nil,"OVERLAY","GameFontNormal")
    tl:SetFont("Fonts\\FRIZQT__.TTF",13,"OUTLINE")
    tl:SetPoint("LEFT",10,0)
    tl:SetText("|cffFFD700Storekeeper|r  — Manager")
    tl:SetShadowColor(0,0,0,1); tl:SetShadowOffset(1,-1)

    local xb = CreateFrame("Button",nil,titleBar,"UIPanelCloseButton")
    xb:SetSize(26,26); xb:SetPoint("RIGHT",-2,0)
    xb:SetScript("OnClick", function() M:Toggle() end)

    -- ── Right icon tab bar ─────────────────────────────────────────────────
    local TAB_W = 44  -- width of the right icon tab column
    local TAB_BTN_H = 44  -- height of each tab button (square icons)

    local tabBar = CreateFrame("Frame",nil,f,"BackdropTemplate")
    tabBar:SetWidth(TAB_W)
    tabBar:SetPoint("TOPRIGHT",    -INSET, -(INSET + TITLE_H + 2))
    tabBar:SetPoint("BOTTOMRIGHT", -INSET,   INSET)
    tabBar:SetBackdrop({
        bgFile  = "Interface\\Buttons\\WHITE8X8", tile=true, tileSize=8,
        edgeFile= "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=10,
        insets  = {left=2,right=2,top=2,bottom=2},
    })
    tabBar:SetBackdropColor(0.04, 0.04, 0.08, 0.92)
    tabBar:SetBackdropBorderColor(0.45, 0.35, 0.12, 0.7)

    -- Gold separator line between content and tab bar
    local sep = f:CreateTexture(nil,"ARTWORK"); sep:SetWidth(1)
    sep:SetPoint("TOPRIGHT",    -(INSET + TAB_W), -(INSET + TITLE_H + 2))
    sep:SetPoint("BOTTOMRIGHT", -(INSET + TAB_W),   INSET)
    sep:SetColorTexture(0.6, 0.48, 0.15, 0.5)

    -- ── Tab icon buttons ──────────────────────────────────────────────────
    M.tabBtns = {}

    for i, key in ipairs(TAB_KEYS) do
        local btn = CreateFrame("Button",nil,tabBar)
        btn:SetSize(TAB_W - 4, TAB_BTN_H)
        btn:SetPoint("TOPLEFT", 2, -((i-1)*TAB_BTN_H) - 2)
        btn:SetNormalTexture(""); btn:SetHighlightTexture("")
        btn:SetPushedTexture(""); btn:SetDisabledTexture("")

        -- Active/hover background
        local bg = btn:CreateTexture(nil,"BACKGROUND"); bg:SetAllPoints()
        bg:SetColorTexture(0.8, 0.65, 0.2, 0)

        -- Active indicator — gold bar on the left edge of the tab strip
        local bar = btn:CreateTexture(nil,"OVERLAY"); bar:SetWidth(3)
        bar:SetPoint("TOPLEFT",0,0); bar:SetPoint("BOTTOMLEFT",0,0)
        bar:SetColorTexture(1, 0.82, 0.0, 1)
        bar:SetAlpha(0)

        -- Divider between tabs
        local div = btn:CreateTexture(nil,"BORDER"); div:SetHeight(1)
        div:SetPoint("BOTTOMLEFT",2,0); div:SetPoint("BOTTOMRIGHT",-2,0)
        div:SetColorTexture(0.5, 0.4, 0.15, 0.35)

        -- Icon — centred in the button
        local ic = btn:CreateTexture(nil,"ARTWORK"); ic:SetSize(26,26)
        ic:SetPoint("CENTER",0,0)
        ic:SetTexture(TAB_ICONS[i] or "Interface\\Icons\\INV_Misc_QuestionMark")
        ic:SetTexCoord(0.08,0.92,0.08,0.92)

        btn.bg = bg; btn.activebar = bar; btn.ic = ic

        local k   = key
        local lbl = TAB_LABELS[i]
        btn:SetScript("OnClick",function() M:SwitchTab(k) end)
        btn:SetScript("OnEnter",function()
            if M.activeTab ~= k then
                bg:SetColorTexture(0.8, 0.65, 0.2, 0.15)
                ic:SetVertexColor(1, 0.92, 0.55, 1)
            end
            GameTooltip:SetOwner(btn,"ANCHOR_LEFT")
            GameTooltip:AddLine(lbl,1,0.82,0,1)
            GameTooltip:Show()
        end)
        btn:SetScript("OnLeave",function()
            if M.activeTab ~= k then
                bg:SetColorTexture(0.8, 0.65, 0.2, 0)
                ic:SetVertexColor(1,1,1,1)
            end
            GameTooltip:Hide()
        end)
        M.tabBtns[i] = btn
    end

    -- ── Content panel ──────────────────────────────────────────────────────
    local content = CreateFrame("Frame",nil,f,"BackdropTemplate")
    content:SetPoint("TOPLEFT",     INSET,            -(INSET + TITLE_H + 2))
    content:SetPoint("BOTTOMRIGHT", -(INSET + TAB_W + 1), INSET)
    content:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8", tile=true, tileSize=8,
    })
    -- Slightly less dark than sidebar so content area breathes
    content:SetBackdropColor(0, 0, 0, 0.15)
    local ctTex = content:CreateTexture(nil,"BACKGROUND"); ctTex:SetAllPoints()
    ctTex:SetTexture(BG_TEX_MAIN)
    ctTex:SetHorizTile(true); ctTex:SetVertTile(true)
    if isGob then
        ctTex:SetVertexColor(0.38, 0.48, 0.28, 0.6)
    else
        ctTex:SetVertexColor(0.32, 0.40, 0.52, 0.6)
    end

    M.contentPanel    = content
    M.contentChildren = {}

    M:SwitchTab("products")
end

function M:Toggle()
    if not M.mainFrame then M:Build() end
    if M.isOpen then
        M.mainFrame:Hide(); M.isOpen=false
    else
        M.mainFrame:Show(); M.isOpen=true; M:SwitchTab(M.activeTab or "products")
    end
end

function M:ApplyTheme()
    local wasOpen = M.isOpen
    if M.mainFrame then
        M.mainFrame:Hide(); M.mainFrame=nil
        M.contentPanel=nil; M.contentChildren={}; M.tabBtns=nil; M.isOpen=false
    end
    if wasOpen then M:Build(); M.mainFrame:Show(); M.isOpen=true end
end
