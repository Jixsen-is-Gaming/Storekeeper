# Storekeeper — Changelog

## v1.3.1

### Register
- Removed the Send Emote button from the register bottom bar — two buttons remain (Receipt/Order and Clear Order), now wider
- Added a Discount selector to the bottom bar — click to cycle through discounts configured in Settings. Active discount is shown with its label and percentage, and is applied to the cart total automatically
- Cart total now shows the applied discount percentage as a small indicator below the number
- Scrollbar on the product list is now fully inside the left panel border

### Orders
- ETA input when claiming an order now has a number field plus a unit toggle button (min / hrs / days / wks) — click the unit button to cycle. The value is automatically converted to minutes when saved

### Products
- Product creation form now has a "Load existing" dropdown — click to select any existing product and load it into the form for editing

### Settings
- Seller IC name field now auto-populates from TRP3 on first open if the field is blank
- Added a "From TRP3" button next to the seller name field to refresh it from your current TRP3 profile at any time
- Added a Discounts section — owners and managers can add named discounts with a percentage (e.g. "Guild Discount — 10%"). These appear in the register's discount selector

### Activity Log
- Fixed rectangles appearing in log entries — WoW color codes are now stripped from messages before they are stored

### Copy Receipt
- Tooltip on the Copy Receipt button now always appears in front of the Finalise Order popup when the popup has been moved
- The Copy Receipt popup itself now sits above the Finalise Order popup in the frame stack

### Version
- Bumped to v1.3.1

---

---

## v1.2.0
*Current release*

### UI
- Removed the Goblin/Gnomish theme switcher entirely — the toggle button, slash commands (`/sk goblin`, `/sk gnomish`), and the Appearance section in the Settings tab have all been removed
- The theme toggle button is replaced by a cogwheel (⚙) button that opens the Manager Settings tab directly
- Settings button removed from the title bar — the cogwheel now covers this role
- Minimap icon changed to a merchant bag (`INV_Misc_Bag_07`) — consistent regardless of theme
- Register frame rebuilt in Group Finder style: dark navy background (`UI-DialogBox-Background-Dark`), thin clean border with no inset gap, subtle gold inner accent lines
- Removed all corner decorations (wood planks, rivet bolts, squares) — frame is now clean
- Product grid padding fixed so items no longer touch the left panel border
- Bottom bar uses the same dark navy texture as the main frame for visual consistency
- Total display number colour changed to warm gold

### TRP3 Tooltip Integration
- `Storekeeper v1.2.0` now appears on the right side of the TRP3 character tooltip
- Line only appears when the hovered player is a confirmed Storekeeper user — not all players
- Peer detection works via the `SK_NET` addon message channel: any player whose Storekeeper sends a network message (login ping, sync, order, invite) is registered as a known peer
- You always see the line on your own portrait
- Uses three hook methods for maximum compatibility: `TooltipDataProcessor` (Dragonflight+), `GameTooltip:HookScript` (legacy fallback), and direct `TRP3_CharacterTooltip:HookScript("OnShow")` for TRP3's custom frame

### Network / Sync
- Added sequence numbers (`productSeq`, `orderSeq`) to every shop — bumped on every data mutation and included in the wire protocol
- Passive login sync: on `PLAYER_ENTERING_WORLD`, staff automatically ping the shop owner with their current sequence numbers; owner responds with only changed data or a lightweight `SYNC_PONG` if already current
- Retry queue: failed whisper sends are retried with 2s/5s/10s backoff, maximum 3 attempts
- Presence awareness: `IsKnownOffline()` checks the friends list before attempting whispers to known-offline players
- New network commands: `SYNC_PING`, `SYNC_PONG`

---

## v1.1.0

### UI
- Register rebuilt with Group Finder-inspired dark panel style
- Title bar darkened with gold border accent
- Bottom bar separated visually from main content area
- Total display box added with large gold number readout
- Three distinct bottom buttons: teal (Receipt/Order), dark gold (Clear Order), bright gold (Send Emote)
- Background switched to `BlackMarketBackground-Tile` with theme-based colour tint
- Cogwheel icon added to title bar for settings access

### Manager
- Multi-shop management panel with six tabs: Shops, Products, Orders, Managers, Logs, Settings
- Order tracking with claim system — staff can mark orders as claimed
- Log tab records all shop activity with timestamps
- Settings tab for receipt template, emote template, and shop configuration

### Network
- Full multi-staff sync system over `SK_NET` addon message prefix
- `SYNC_START/CHUNK/END` for product sync
- `ORDER_START/CHUNK/END` for order sync
- `ORDER_DEL` for order deletion broadcast
- `CLAIM_NOTICE` for claim notifications
- `LOG_ENTRY` and `LOGS_START/CHUNK/END` for log sync
- All targeted messages use whisper; broadcasts use PARTY/RAID with whisper fallback

### TRP3
- Receipt generation creates a TRP3 Extended document item added directly to inventory
- Fallback to chat-printed receipt when TRP3 Extended is not loaded
- Seller name auto-detected from TRP3 profile

### Other
- Minimap button with drag-to-reposition, right-click to open manager
- Icon picker for products (searchable texture list)
- TRP3 profile name used throughout for seller identification

---

## v1.0.0

- Initial release
- Basic register UI with product grid and cart
- Single shop support
- Price display in gold/silver/copper
- TRP3 receipt printing (basic)
- Slash commands: `/sk`, `/sk manager`
