-- Storekeeper: Core
-- Hooks OnInitialize so the main addon body runs at the right time.
-- bootstrap.lua already created the Storekeeper global before this runs.

local SK = Storekeeper

-- If AceAddon is in play it will call SK:OnInitialize() automatically.
-- If not (plain table fallback), we fire it ourselves on ADDON_LOADED.
if not LibStub or not LibStub("AceAddon-3.0", true) then
    local f = CreateFrame("Frame")
    f:RegisterEvent("ADDON_LOADED")
    f:SetScript("OnEvent", function(_, _, name)
        if name == "Storekeeper" then
            if SK.OnInitialize then SK:OnInitialize() end
            f:UnregisterEvent("ADDON_LOADED")
        end
    end)
end
