# Storekeeper — Merchant Point of Sale (MPoS)
**Version 1.3.1** | World of Warcraft Addon | Retail (The War Within / Midnight)

---

Storekeeper is a roleplay Point-of-Sale register for WoW merchants, maintained by the **Storekeeper**. Whether you run a travelling market stall, a noble house emporium, or a back-alley curiosities shop, Storekeeper gives you the tools to run it properly — in character, in style, and in sync with your entire staff.

---

## Features

### The Register
Click products to build a cart, apply discounts, and either **Finalize** a sale on the spot or **Confirm & Log** it as a tracked order. The register shows all your products grouped by category, colour-coded and rarity-tinted, with out-of-stock items automatically greyed out.

### Multi-Shop Management
Create and manage multiple shops from a single addon. Each shop has its own product list, staff roster, treasury, and activity log. Switch between shops from the **Shops** tab. Staff members receive automatic sync when they come online.

### Products & Inventory
- Assign products a **category**, **rarity** (Poor through Legendary), **icon**, price, and description
- Category headers are colour-coded — fully customisable per category
- **Limited stock** mode tracks quantities and decrements on sale
- Product changes sync automatically to all online staff

### Orders
Create tracked orders with buyer IC and OOC names, assign them to staff, set an ETA, and update status through fulfilment. Orders expire and auto-release if the ETA passes. All staff see live order updates.

### Treasury
Each shop has a treasury that tracks earnings. It auto-increments when a paid sale is finalised or a paid order is completed. Owners can deposit, withdraw, and view the full balance in gold, silver, and copper.

### Activity Log
Every meaningful action — sales, orders, treasury movements, staff changes — is logged with a timestamp. Filter by category: **All**, **Treasury**, **Orders**, **Products**, or **Staff**.

### Staff & Permissions
Owners add managers and employees by character name. Owners configure what each role can do: edit products, apply discounts, finalise as a favour, manage stock levels, and more. All staff sync in real time.

### TRP3 Receipt Printing
When **TRP3: Extended** is loaded, pressing **Print Receipt** generates a document item in your TRP3 inventory — a properly formatted receipt with shop name, seller name, itemised cart, and total. Falls back to a clean chat-formatted receipt if TRP3: Extended is not installed.

### Minimap Button
A standard LibDBIcon-compatible minimap button. Left-click to open the register. Drag to reposition. All settings and management live inside the register's own tabs.

---

## Navigation Tabs

All functionality is accessed from the sidebar inside the register window:

| Tab | Description |
|---|---|
| Register | The point-of-sale grid and cart |
| Orders | Tracked order queue |
| Management | Staff roster and permissions |
| Products | Add, edit, and remove products |
| Shop(s) Overview | Multi-shop management and treasury |
| Activity Log | Filterable history of all shop events |
| Personal Settings | Per-character preferences |
| What's New | Patch notes and bug report link |

---

## Slash Commands

| Command | Action |
|---|---|
| `/sk` or `/storekeeper` | Open / close the register |

---

## Quick Start

1. Type `/sk` to open the register
2. Go to the **Shop(s) Overview** tab — create your shop and set it active
3. Go to the **Products** tab — add your products with names, prices, and icons
4. Go to the **Management** tab — add staff by character name and set permissions
5. Return to the **Register** tab — click products to build a cart and start selling

---

## Requirements & Compatibility

- **WoW Retail** (The War Within / Midnight)
- **Optional:** TRP3: Extended — for receipt item generation
- Compatible with TRP3, MyRolePlay, and XRP

---

## Reporting Bugs

Found an issue or have a suggestion? Please use the Curseforge issue tracker:
**https://legacy.curseforge.com/wow/addons/storekeeper-wow-pos/settings/issues**

---

*"Every copper counts — and we count every copper."*
*— Storekeeper*
